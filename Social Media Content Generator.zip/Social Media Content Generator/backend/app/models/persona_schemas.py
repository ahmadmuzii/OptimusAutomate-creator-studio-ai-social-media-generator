from __future__ import annotations

from pydantic import BaseModel, Field


class PersonaCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    age_range: str | None = None
    location_market: str | None = None
    main_problem: str | None = None
    desired_outcome: str | None = None
    objections: str | None = None
    preferred_tone: str | None = None
    preferred_platform: str | None = None
    buying_stage: str | None = None
    content_interests: list[str] | None = None
    common_questions: list[str] | None = None
    main_motivation: str | None = None
    cta_preference: str | None = None
    language_preference: str | None = None
    notes: str | None = None
    is_primary: bool = False


class PersonaUpdateRequest(BaseModel):
    name: str | None = None
    description: str | None = None
    age_range: str | None = None
    location_market: str | None = None
    main_problem: str | None = None
    desired_outcome: str | None = None
    objections: str | None = None
    preferred_tone: str | None = None
    preferred_platform: str | None = None
    buying_stage: str | None = None
    content_interests: list[str] | None = None
    common_questions: list[str] | None = None
    main_motivation: str | None = None
    cta_preference: str | None = None
    language_preference: str | None = None
    notes: str | None = None
    is_primary: bool | None = None


class PersonaResponse(BaseModel):
    id: int
    brand_id: int
    name: str
    description: str | None = None
    age_range: str | None = None
    location_market: str | None = None
    main_problem: str | None = None
    desired_outcome: str | None = None
    objections: str | None = None
    preferred_tone: str | None = None
    preferred_platform: str | None = None
    buying_stage: str | None = None
    content_interests: list[str] | None = None
    common_questions: list[str] | None = None
    main_motivation: str | None = None
    cta_preference: str | None = None
    language_preference: str | None = None
    notes: str | None = None
    is_primary: bool = False
    created_at: str | None = None

    model_config = {"from_attributes": True}
