from __future__ import annotations

from typing import Any

from app.config import settings
from app.logging_config import get_logger
from app.ai.groq_client import groq_json_chat

logger = get_logger("app.services.llm")


def _build_system_prompt(days: int) -> str:
    return f"""You are a social media content strategy AI. Generate a {days}-day campaign strategy as JSON only.

You must follow these rules strictly:

1. Return valid JSON with EXACTLY this structure — no markdown, no code fences, no extra text:
{{
  "campaign_name": string,
  "campaign_summary": string,
  "strategy": string,
  "day_plans": [{{
    "day": integer,
    "theme": string,
    "purpose": string,
    "funnel_stage": string,
    "content_type": string,
    "audience_action": string,
    "reason_for_format": string,
    "source_fact_ids": [integer]
  }}],
  "generation_source": "groq"
}}

2. The "day_plans" array must contain EXACTLY {days} items, numbered 1-{days}.

3. Every field must be non-empty and meaningful.

4. Campaign information must relate to the specific brand, niche, audience and campaign goal.

5. Each day plan must specify: theme (meaningful topic for the day), purpose (why this day matters), funnel_stage (awareness, interest, decision, etc.), content_type (carousel, reel, static_post, etc.), audience_action (what we want readers to do), and source_fact_ids (approved facts that must be included in the post).

6. Never invent unsupported claims, statistics, or structure.

7. Return ONLY valid JSON — no markdown, no code fences.

Important: Include "generation_source": "groq" in the output JSON.
"""


def _build_user_prompt(
    brand_name: str,
    brand_description: str,
    niche: str,
    target_audience: str,
    platform: str,
    tone: str,
    campaign_goal: str,
    days: int,
) -> str:
    day_descriptions = {
        1: "Brand introduction and positioning",
        2: "Educational content about {brand_name}",
        3: "Audience pain point and solution",
        4: "Behind-the-scenes brand story",
        5: "Product or service spotlight",
        6: "Engagement-focused content",
        7: "Call-to-action and conversion focus",
    }

    lines = [f"Generate a {days}-day {campaign_goal.replace('_', ' ')} campaign strategy."]
    lines.append("")
    lines.append(f"Brand: {brand_name}")
    lines.append(f"Description: {brand_description}")
    lines.append(f"Niche: {niche}")
    lines.append(f"Target Audience: {target_audience}")
    lines.append(f"Platform: {platform}")
    lines.append(f"Tone: {tone}")
    lines.append(f"Goal: {campaign_goal}")
    lines.append("")
    lines.append(f"Key themes and audience actions for each day:")
    for day_num in range(1, days + 1):
        desc = day_descriptions.get(day_num, "Strategic content")
        lines.append(f"Day {day_num}: {desc}")
    lines.append("")
    lines.append("Output ONLY valid JSON matching the required schema.")
    return "\n".join(lines)


def _build_caption_prompt(
    post_idea: str,
    platform: str,
    tone: str,
    brand_details: dict[str, Any],
) -> str:
    brand_name = brand_details.get("brandName", "the brand")
    niche = brand_details.get("niche", "this space")
    audience = brand_details.get("targetAudience", "our audience")
    goal = brand_details.get("campaignGoal", "engagement")
    description = brand_details.get("brandDescription", "")

    return f"""Generate a single social media caption.

Brand: {brand_name}
Description: {description}
Platform: {platform}
Tone: {tone}
Goal: {goal}
Post Idea: {post_idea}

Return valid JSON only:
{{
  "caption": "string",
  "callToAction": "string",
  "hashtags": ["string", "string"]
}}

Rules:
- Caption must be complete and publish-ready
- CTA must be natural and relevant
- Hashtags: 3-10 depending on platform
- No markdown, no code fences"""


def call_groq(
    brand_name: str,
    brand_description: str,
    niche: str,
    target_audience: str,
    platform: str,
    tone: str,
    campaign_goal: str,
    days: int = 7,
) -> dict[str, Any] | None:
    if not settings.groq_enabled:
        logger.info("groq_disabled_by_config")
        return None

    if not settings.groq_api_key:
        logger.warning("groq_api_key_not_set")
        return None

    system_prompt = _build_system_prompt(days)
    user_prompt = _build_user_prompt(
        brand_name=brand_name,
        brand_description=brand_description,
        niche=niche,
        target_audience=target_audience,
        platform=platform,
        tone=tone,
        campaign_goal=campaign_goal,
        days=days,
    )

    result = groq_json_chat(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        model=settings.groq_model,
        temperature=0.7,
        max_tokens=settings.groq_strategy_max_output_tokens,
        retries=settings.groq_max_retries,
        request_type="strategy",
    )

    if result is None:
        logger.error("groq_strategy_all_retries_exhausted")
        return None

    return result


def call_groq_for_caption(
    post_idea: str,
    platform: str,
    tone: str,
    brand_details: dict[str, Any],
) -> dict[str, Any] | None:
    if not settings.groq_enabled:
        return None

    if not settings.groq_api_key:
        return None

    prompt = _build_caption_prompt(post_idea, platform, tone, brand_details)
    system_msg = "You are a social media copywriter. Output only valid JSON with caption, callToAction, and hashtags."

    result = groq_json_chat(
        system_prompt=system_msg,
        user_prompt=prompt,
        model=settings.groq_model,
        temperature=0.7,
        max_tokens=settings.groq_campaign_max_output_tokens,
        retries=settings.groq_max_retries,
        request_type="caption",
    )

    return result
