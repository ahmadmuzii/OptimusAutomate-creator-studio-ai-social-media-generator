from __future__ import annotations

import difflib
import re

_PLATFORM_DISPLAY: dict[str, str] = {
    "instagram": "Instagram",
    "linkedin": "LinkedIn",
    "tiktok": "TikTok",
    "facebook": "Facebook",
    "x": "X",
}


def _word_positions(text: str) -> list[tuple[int, int, str]]:
    return [(m.start(), m.end(), m.group()) for m in re.finditer(r"[A-Za-z0-9]+(?:[.'&][A-Za-z0-9]+)*", text)]


def _find_replacements(text: str, official_name: str, threshold: float = 0.80) -> list[tuple[int, int, str]]:
    if not official_name or not text:
        return []

    official_word_tokens = re.findall(r"[A-Za-z0-9]+(?:[.'&][A-Za-z0-9]+)*", official_name)
    official_words = [w.lower() for w in official_word_tokens]
    official_word_map = {w.lower(): w for w in official_word_tokens}
    if not official_words:
        return []

    positions = _word_positions(text)
    word_texts = [p[2] for p in positions]
    word_lowers = [w.lower() for w in word_texts]
    n = len(official_words)

    replacements: list[tuple[int, int, str]] = []

    # 1. Multi-word sliding window match
    for i in range(len(word_lowers) - n + 1):
        window_lowers = word_lowers[i : i + n]
        window_text = " ".join(window_lowers)
        window_joined = "".join(window_lowers)
        official_joined = "".join(official_words)
        official_text = " ".join(official_words)

        if window_text == official_text or window_joined == official_joined:
            start = positions[i][0]
            end = positions[i + n - 1][1]
            replacements.append((start, end, official_name))
            continue

        if len(window_text) >= 3:
            ratio = difflib.SequenceMatcher(None, window_text, official_text).ratio()
            if ratio >= threshold:
                start = positions[i][0]
                end = positions[i + n - 1][1]
                replacements.append((start, end, official_name))

    # 2. Single-word fuzzy match (for misspellings of any official word)
    if not replacements:
        for ws, we, wt in positions:
            wl = wt.lower()
            if len(wl) < 3:
                continue
            for ow_lower in official_words:
                if wl == ow_lower:
                    break
                ratio = difflib.SequenceMatcher(None, wl, ow_lower).ratio()
                if ratio >= threshold:
                    cased_word = official_word_map.get(ow_lower, ow_lower)
                    replacements.append((ws, we, cased_word))
                    break

    return replacements


def preserve_brand_name(text: str, official_name: str) -> str:
    replacements = _find_replacements(text, official_name)
    if not replacements:
        return text

    result = list(text)
    for start, end, replacement in sorted(replacements, key=lambda x: x[0], reverse=True):
        existing = text[start:end]
        if existing.lower() != replacement.lower():
            result[start:end] = replacement

    return "".join(result)


def validate_campaign_texts(calendar: list[dict], official_name: str) -> list[dict]:
    if not official_name:
        return calendar

    validated = []
    for item in calendar:
        entry = dict(item)
        for field in ("contentTheme", "postIdea", "caption", "callToAction"):
            if isinstance(entry.get(field), str):
                entry[field] = preserve_brand_name(entry[field], official_name)
        validated.append(entry)
    return validated


def format_campaign_title(brand_name: str, platform: str, tone: str) -> str:
    tone_display = tone.replace("_", " ").title()
    platform_display = _PLATFORM_DISPLAY.get(platform, platform.title())
    return f"{brand_name} \u00b7 {platform_display} \u00b7 {tone_display} Campaign"
