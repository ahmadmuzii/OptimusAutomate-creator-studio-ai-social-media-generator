import { Sparkles, Zap } from 'lucide-react'

export function Header() {
  return (
    <header className="relative overflow-hidden bg-white border-b border-gray-100">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-50/50 via-white to-purple-50/30" />

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-100 text-purple-700 text-sm font-medium">
            <Sparkles className="w-4 h-4" />
            <span>AI-Powered Content Studio</span>
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-gray-900 tracking-tight">
            Social Media{' '}
            <span className="bg-gradient-to-r from-purple-600 to-purple-900 bg-clip-text text-transparent">
              Content Generator
            </span>
          </h1>

          <p className="text-lg md:text-xl text-gray-500 max-w-2xl font-light leading-relaxed">
            Plan 7 days of content in seconds. Craft engaging posts tailored to your brand voice and audience.
          </p>

          <div className="flex items-center gap-6 mt-4 text-sm text-gray-400">
            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-purple-500" />
              <span>5 Platforms</span>
            </div>
            <div className="w-1 h-1 rounded-full bg-gray-300" />
            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-purple-500" />
              <span>7 Tones</span>
            </div>
            <div className="w-1 h-1 rounded-full bg-gray-300" />
            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-purple-500" />
              <span>7-Day Calendar</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
