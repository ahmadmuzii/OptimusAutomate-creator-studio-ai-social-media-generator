from __future__ import annotations

import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, UploadFile

from app.api.deps_auth import require_current_user
from app.config import settings
from app.exceptions import AppError
from app.models.db_models import User

router = APIRouter(prefix="/upload", tags=["Uploads"])

ALLOWED_MIME_TYPES = frozenset(
    {
        "image/jpeg",
        "image/png",
        "image/webp",
    }
)

CHUNK_SIZE = 64 * 1024  # 64 KB


@router.post("")
def upload_file(
    file: UploadFile,
    type: str = "avatar",
    current_user: User = Depends(require_current_user),
):
    ext = file.filename.rsplit(".", 1)[-1].lower() if file.filename else ""
    if ext not in settings.allowed_upload_extensions:
        raise AppError(
            status_code=400,
            detail=f"Invalid file type '{ext}'. Allowed: {', '.join(settings.allowed_upload_extensions)}",
        )

    if file.content_type and file.content_type not in ALLOWED_MIME_TYPES:
        raise AppError(
            status_code=400,
            detail=f"Invalid MIME type '{file.content_type}'.",
        )

    sub_dir = "avatar" if type == "avatar" else "logo"
    upload_path = Path(settings.upload_dir) / sub_dir
    upload_path.mkdir(parents=True, exist_ok=True)

    filename = f"{uuid.uuid4().hex}.{ext}"
    filepath = upload_path / filename

    total = 0
    max_bytes = settings.max_upload_size_mb * 1024 * 1024
    header = b""

    with filepath.open("wb") as f:
        while chunk := file.file.read(CHUNK_SIZE):
            total += len(chunk)
            if total > max_bytes:
                filepath.unlink(missing_ok=True)
                raise AppError(
                    status_code=400,
                    detail=f"File too large. Maximum {settings.max_upload_size_mb} MB.",
                )
            if len(header) < 32:
                header += chunk[: 32 - len(header)]
            f.write(chunk)

    if not _is_valid_image_header(header, ext):
        filepath.unlink(missing_ok=True)
        raise AppError(
            status_code=400,
            detail="Uploaded file is not a valid image or extension does not match content.",
        )

    return {"url": f"/{settings.upload_dir}/{sub_dir}/{filename}"}


def _is_valid_image_header(header: bytes, ext: str) -> bool:
    if ext == "jpg" or ext == "jpeg":
        return header[:2] == b"\xff\xd8"
    if ext == "png":
        return header[:4] == b"\x89PNG"
    if ext == "webp":
        return header[:4] == b"RIFF" and header[8:12] == b"WEBP"
    return False
