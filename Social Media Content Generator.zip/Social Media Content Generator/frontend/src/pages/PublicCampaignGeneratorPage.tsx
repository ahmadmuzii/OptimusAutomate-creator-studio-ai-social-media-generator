import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Sparkles, ArrowRight, AlertTriangle } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { platforms } from '@/config/platforms'
import { tones } from '@/config/tones'
import { demoCalendarData, demoBrands } from '@/data/landingDemoData'
import { cn } from '@/utils/cn'
import { Button } from '@/components/ui/Button'
import type { DayPlan } from '@/types/calendar'

const niches = ['Technology', 'Fashion', 'Food & Beverage', 'Fitness', 'Music', 'Finance', 'Health', 'Education', 'Travel', 'Real Estate']
const goals = ['brand_awareness', 'engagement', 'sales', 'education', 'lead_generation', 'community_building']

const demoResults: Record<string, DayPlan[] | undefined> = {
  technology: demoCalendarData.saas,
  fitness: demoCalendarData.fitness,
  music: demoCalendarData.music,
  fashion: demoCalendarData.fashion,
}

export function PublicCampaignGeneratorPage() {
  const { isAuthenticated } = useAuth()
  const navigate = useNavigate()
  const reduced = useReducedMotionPreference()

  const [brandName, setBrandName] = useState('')
  const [description, setDescription] = useState('')
  const [niche, setNiche] = useState('')
  const [audience, setAudience] = useState('')
  const [goal, setGoal] = useState('brand_awareness')
  const [platform, setPlatform] = useState('instagram')
  const [tone, setTone] = useState('professional')
  const [generated, setGenerated] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleGenerate = () => {
    if (!brandName.trim() || !niche) return
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      setGenerated(true)
    }, 800)
  }

  const applyDemoBrand = (id: string) => {
    const brand = demoBrands.find((b) => b.id === id)
    if (!brand) return
    setBrandName(brand.name)
    setDescription(`A ${brand.niche} brand targeting ${brand.audience}`)
    setNiche(brand.niche)
    setAudience(brand.audience.split(' ').slice(-1)[0] || '')
    setGoal(brand.goal)
    setGenerated(false)
  }

  const results = (demoResults[niche.toLowerCase()] || demoCalendarData.coffee)!

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white border-b border-gray-100 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="text-sm font-bold text-gray-900">Creator Studio</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link to="/login" className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors">
              Sign In
            </Link>
            <Link
              to="/signup"
              className="bg-gradient-to-r from-purple-600 via-purple-700 to-purple-900 text-white text-sm font-semibold px-4 py-2 rounded-xl shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-200"
            >
              Create Free Account
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-100 text-purple-700 text-sm font-medium mb-4">
            <Sparkles className="w-4 h-4" />
            Interactive Demo
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            Try the Campaign Generator
          </h1>
          <p className="mt-3 text-gray-500 max-w-xl mx-auto">
            Fill in the brief below to see a preview. The full version saves your brand, generates 7 days, and lets you manage every post.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 justify-center mb-10">
          <span className="text-xs font-medium text-gray-400 mr-1 self-center">Quick fill:</span>
          {demoBrands.map((b) => (
            <button
              key={b.id}
              onClick={() => applyDemoBrand(b.id)}
              className="px-3 py-1.5 rounded-full text-xs font-medium border border-gray-200 bg-white text-gray-600 hover:border-purple-300 hover:text-purple-700 transition-all"
            >
              {b.name}
            </button>
          ))}
          <span className="text-[10px] text-gray-400 ml-2 self-center">(demo examples)</span>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-6 md:p-8 shadow-sm mb-8">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label htmlFor="brand-name" className="block text-sm font-medium text-gray-700 mb-1.5">Brand Name</label>
                <input
                  id="brand-name"
                  type="text"
                  value={brandName}
                  onChange={(e) => { setBrandName(e.target.value); setGenerated(false) }}
                  placeholder="e.g. Urban Brew Studio"
                  className="w-full rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 transition-all"
                  maxLength={60}
                />
              </div>
              <div>
                <label htmlFor="brand-desc" className="block text-sm font-medium text-gray-700 mb-1.5">Short Description</label>
                <textarea
                  id="brand-desc"
                  value={description}
                  onChange={(e) => { setDescription(e.target.value); setGenerated(false) }}
                  placeholder="Describe what your brand does..."
                  className="w-full rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 transition-all resize-none"
                  rows={3}
                  maxLength={300}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="niche" className="block text-sm font-medium text-gray-700 mb-1.5">Niche</label>
                  <select
                    id="niche"
                    value={niche}
                    onChange={(e) => { setNiche(e.target.value); setGenerated(false) }}
                    className="w-full rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 transition-all"
                  >
                    <option value="">Select niche</option>
                    {niches.map((n) => <option key={n} value={n.toLowerCase()}>{n}</option>)}
                  </select>
                </div>
                <div>
                  <label htmlFor="audience" className="block text-sm font-medium text-gray-700 mb-1.5">Target Audience</label>
                  <input
                    id="audience"
                    type="text"
                    value={audience}
                    onChange={(e) => { setAudience(e.target.value); setGenerated(false) }}
                    placeholder="e.g. Urban professionals"
                    className="w-full rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 transition-all"
                    maxLength={100}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label htmlFor="goal" className="block text-sm font-medium text-gray-700 mb-1.5">Campaign Goal</label>
                <select
                  id="goal"
                  value={goal}
                  onChange={(e) => { setGoal(e.target.value); setGenerated(false) }}
                  className="w-full rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 transition-all"
                >
                  {goals.map((g) => <option key={g} value={g}>{g.replace(/_/g, ' ')}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Platform</label>
                <div className="grid grid-cols-5 gap-2">
                  {platforms.map((p) => {
                    const Icon = p.icon
                    return (
                      <button
                        key={p.id}
                        onClick={() => { setPlatform(p.id); setGenerated(false) }}
                        className={cn(
                          'flex flex-col items-center gap-1 p-2 rounded-xl border text-xs font-medium transition-all',
                          platform === p.id
                            ? 'border-purple-600 bg-purple-50 text-purple-700'
                            : 'border-gray-200 text-gray-500 hover:border-purple-300',
                        )}
                      >
                        <Icon className="w-4 h-4" />
                        <span className="text-[9px]">{p.name}</span>
                      </button>
                    )
                  })}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Tone</label>
                <div className="flex flex-wrap gap-2">
                  {tones.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => { setTone(t.id); setGenerated(false) }}
                      className={cn(
                        'px-3 py-1.5 rounded-lg text-xs font-medium border transition-all',
                        tone === t.id
                          ? 'border-purple-600 bg-purple-50 text-purple-700'
                          : 'border-gray-200 text-gray-500 hover:border-purple-300',
                      )}
                    >
                      {t.emoji} {t.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 flex flex-col sm:flex-row items-center gap-4">
            <Button
              onClick={handleGenerate}
              disabled={!brandName.trim() || !niche}
              loading={loading}
              size="lg"
              className="w-full sm:w-auto"
            >
              {loading ? 'Generating...' : 'Generate Preview'}
            </Button>
            {isAuthenticated && (
              <button
                onClick={() => navigate('/dashboard/generate')}
                className="text-sm font-medium text-purple-600 hover:text-purple-700 transition-colors"
              >
                Go to full generator &rarr;
              </button>
            )}
          </div>
        </div>

        {generated && (
          <motion.div
            initial={reduced ? undefined : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="bg-gradient-to-br from-purple-50 to-purple-100/30 rounded-2xl border border-purple-100 p-2 mb-8">
              <div className="bg-white rounded-xl p-6">
                <div className="flex items-center gap-2 mb-1">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  <span className="text-xs font-semibold text-purple-600 uppercase tracking-wider">Campaign Preview</span>
                  <span className="text-[10px] text-gray-400 ml-auto">Example &middot; First 3 days shown</span>
                </div>
                <p className="text-xs text-gray-400 mb-4">
                  Campaign for <span className="font-medium text-gray-700">{brandName || 'your brand'}</span> &middot; {platform} &middot; {tone}
                </p>

                <div className="grid md:grid-cols-3 gap-4 mb-6">
                  {results.slice(0, 3).map((day, i) => (
                    <div key={i} className="bg-gray-50 rounded-xl p-4 border border-gray-100">
                      <div className="text-xs font-bold text-purple-600 mb-1">Day {day.day}</div>
                      <div className="text-sm font-semibold text-gray-900 mb-1">{day.contentTheme}</div>
                      <p className="text-xs text-gray-500 mb-2 line-clamp-2">{day.postIdea}</p>
                      <div className="text-[10px] text-gray-400">{day.contentType} &middot; {day.suggestedTime}</div>
                    </div>
                  ))}
                </div>

                <div className="bg-gray-50 rounded-xl p-4 border border-gray-100 mb-4">
                  <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Sample Caption</div>
                  <p className="text-sm text-gray-700 leading-relaxed line-clamp-3">
                    &ldquo;{results[0]?.caption?.slice(0, 150)}...&rdquo;
                  </p>
                  <div className="mt-2 text-xs text-purple-700 font-medium">CTA: {results[0]?.callToAction}</div>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {results[0]?.hashtags?.slice(0, 6).map((tag, i) => (
                    <span key={i} className="text-[10px] px-2 py-0.5 rounded-full bg-purple-100 text-purple-600">{tag}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 md:p-6 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-amber-800">This is a demonstration preview</p>
                <p className="text-sm text-amber-700 mt-1">
                  Create a free account to unlock the full 7-day campaign, save your brand profiles, edit posts, and manage your content calendar.
                </p>
                <div className="mt-4">
                  <Button
                    onClick={() => navigate('/signup')}
                    icon={<ArrowRight className="w-4 h-4" />}
                    size="md"
                  >
                    Unlock the Full Campaign
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}
