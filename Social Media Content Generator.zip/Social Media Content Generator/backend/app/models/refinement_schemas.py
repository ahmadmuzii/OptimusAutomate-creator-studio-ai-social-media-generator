from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

RefinementAction = Literal[
    "regenerate_caption",
    "shorten_caption",
    "make_professional",
    "make_funnier",
    "change_tone",
    "improve_hook",
    "rewrite_cta",
    "regenerate_hashtags",
    "regenerate_complete_post",
    "custom",
]

SupportedTone = Literal[
    "professional",
    "funny",
    "luxury",
    "genz",
    "motivational",
    "casual",
    "bold",
]


class RefinementRequest(BaseModel):
    action: RefinementAction
    target_tone: SupportedTone | None = None
    custom_instruction: str | None = Field(default=None, max_length=500)


class BrandCheckViolation(BaseModel):
    type: str
    text: str


class BrandCheckBlock(BaseModel):
    status: Literal["blocked"] = "blocked"
    message: str
    violations: list[BrandCheckViolation] = Field(default_factory=list)


class RefinedPostData(BaseModel):
    id: int
    campaign_id: int
    day_number: int
    hook: str = Field(default="", alias="hook")
    caption: str
    call_to_action: str | None = None
    hashtags: list[str] = Field(default_factory=list)
    content_theme: str = ""
    post_idea: str = ""
    content_type: str = ""
    suggested_time: str | None = None
    tone: str | None = None
    updated_at: str = ""

    model_config = {"populate_by_name": True}


class RefinementResponse(BaseModel):
    post: RefinedPostData
    refinement: dict = Field(default_factory=dict)


class CampaignPostRevisionResponse(BaseModel):
    id: int
    campaign_post_id: int
    revision_number: int
    action: str
    previous_caption: str
    previous_call_to_action: str | None = None
    previous_hashtags: list[str] = Field(default_factory=list)
    previous_tone: str | None = None
    generation_source: str
    created_at: str

    model_config = {"from_attributes": True}


class RefinedPostOutput(BaseModel):
    hook: str = Field(default="", max_length=500)
    caption: str = Field(..., max_length=5000)
    call_to_action: str = Field(default="", max_length=500)
    hashtags: list[str] = Field(default_factory=list)
    content_theme: str = Field(default="", max_length=200)
    post_idea: str = Field(default="", max_length=500)
    content_type: str = Field(default="static_post", max_length=100)
    suggested_time: str | None = Field(default=None, max_length=100)
    tone: str = Field(default="professional", max_length=50)
    changed_fields: list[str] = Field(default_factory=list)
