from __future__ import annotations

from pydantic import BaseModel, Field


class CalendarRequest(BaseModel):
    brand_name: str = Field(..., min_length=1, max_length=200, alias="brandName")
    brand_description: str = Field(..., min_length=1, max_length=1000, alias="brandDescription")
    niche: str = Field(..., min_length=1, max_length=200, alias="niche")
    target_audience: str = Field(..., min_length=1, max_length=500, alias="targetAudience")
    platform: str = Field(..., min_length=1, max_length=50)
    tone: str = Field(..., min_length=1, max_length=50)
    campaign_goal: str = Field(..., min_length=1, max_length=200, alias="campaignGoal")
    brand_profile_id: int | None = Field(default=None, alias="brandProfileId")
    days_count: int = Field(default=7, ge=1, le=30, alias="daysCount")
    persona_ids: list[int] = Field(default_factory=list, alias="personaIds")
    conversion_path_id: int | None = Field(default=None, alias="conversionPathId")
    strategy_id: int | None = Field(default=None, alias="strategyId")
    performance_insight_ids: list[int] = Field(default_factory=list, alias="performanceInsightIds")
    experiment_learning_ids: list[int] = Field(default_factory=list, alias="experimentLearningIds")
    competitor_opportunity_ids: list[int] = Field(default_factory=list, alias="competitorOpportunityIds")
    use_guardrails: bool = True
    use_personas: bool = True
    use_source_facts: bool = True
    use_performance_memory: bool = True
    use_experiment_learnings: bool = False
    use_competitor_gaps: bool = False
    use_campaign_history: bool = True

    model_config = {"populate_by_name": True}


class DayPlan(BaseModel):
    day: int = Field(..., ge=1, le=30)
    content_theme: str = Field(..., alias="contentTheme")
    post_idea: str = Field(..., alias="postIdea")
    content_type: str = Field(..., alias="contentType")
    suggested_time: str = Field(..., alias="suggestedTime")
    platform: str
    caption: str
    call_to_action: str = Field(..., alias="callToAction")
    hashtags: list[str]
    persona_name: str | None = Field(default=None, alias="personaName")
    audience_problem: str | None = Field(default=None, alias="audienceProblem")
    desired_action: str | None = Field(default=None, alias="desiredAction")
    source_fact_ids: list[int] = Field(default_factory=list, alias="sourceFactIds")
    purpose: str | None = None
    funnel_stage: str | None = None

    model_config = {"populate_by_name": True}


class CalendarResponse(BaseModel):
    calendar: list[DayPlan]
    generation_source: str = Field(default="fallback", alias="generationSource")
    saved: bool = False
    generation_trace: dict | None = Field(default=None, alias="generationTrace")
    intelligence_summary: dict | None = Field(default=None, alias="intelligenceSummary")

    model_config = {"populate_by_name": True}


class CaptionRequest(BaseModel):
    post_idea: str = Field(..., min_length=1, max_length=500, alias="postIdea")
    platform: str = Field(..., min_length=1, max_length=50)
    tone: str = Field(..., min_length=1, max_length=50)
    brand_details: dict = Field(..., alias="brandDetails")

    model_config = {"populate_by_name": True}


class CaptionResponse(BaseModel):
    caption: str
    call_to_action: str = Field(default="", alias="callToAction")
    hashtags: list[str]

    model_config = {"populate_by_name": True}


class PlatformResponse(BaseModel):
    platforms: list[str]


class ToneResponse(BaseModel):
    tones: list[str]


class HealthResponse(BaseModel):
    status: str
    version: str
    environment: str
