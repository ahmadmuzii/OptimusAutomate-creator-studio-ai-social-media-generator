import { useEffect, useState } from 'react'
import { Building2, FileText, Target, Users, Goal, ChevronDown } from 'lucide-react'
import type { BrandFormData, BrandProfile } from '@/types/common'
import * as api from '@/api/endpoints'

interface BrandFormProps {
  formData: BrandFormData
  onChange: (field: keyof BrandFormData, value: string) => void
  onSelectBrand?: (brand: BrandProfile | null) => void
  selectedBrandId?: number | null
  errors?: Partial<Record<keyof BrandFormData, string>>
}

const fields: Array<{
  id: keyof BrandFormData
  label: string
  placeholder: string
  icon: typeof Building2
  type: 'text' | 'textarea'
  rows?: number
}> = [
  { id: 'brandName', label: 'Brand Name', placeholder: 'e.g., Lumina Coffee Co.', icon: Building2, type: 'text' },
  { id: 'brandDescription', label: 'Brand Description', placeholder: 'What does your brand do? What makes it unique?', icon: FileText, type: 'textarea', rows: 3 },
  { id: 'niche', label: 'Niche / Industry', placeholder: 'e.g., Sustainable Fashion, SaaS, Fitness', icon: Target, type: 'text' },
  { id: 'targetAudience', label: 'Target Audience', placeholder: 'e.g., Gen Z entrepreneurs, busy moms, tech professionals', icon: Users, type: 'text' },
  { id: 'campaignGoal', label: 'Campaign Goal', placeholder: 'e.g., Increase engagement, Launch new product, Build community', icon: Goal, type: 'text' },
]

export function BrandForm({ formData, onChange, onSelectBrand, selectedBrandId, errors }: BrandFormProps) {
  const [brands, setBrands] = useState<BrandProfile[]>([])
  const [loadingBrands, setLoadingBrands] = useState(true)

  useEffect(() => {
    api.fetchBrands()
      .then(setBrands)
      .catch(() => setBrands([]))
      .finally(() => setLoadingBrands(false))
  }, [])

  const handleBrandSelect = (brandId: string) => {
    if (!brandId) {
      onSelectBrand?.(null)
      onChange('brandName', '')
      onChange('brandDescription', '')
      onChange('niche', '')
      onChange('targetAudience', '')
      onChange('campaignGoal', '')
      onChange('brandId', '')
      return
    }
    const brand = brands.find((b) => b.id === Number(brandId))
    if (brand) {
      onSelectBrand?.(brand)
      onChange('brandName', brand.name)
      onChange('brandDescription', brand.description || '')
      onChange('niche', brand.niche || '')
      onChange('targetAudience', brand.target_audience || '')
      onChange('campaignGoal', formData.campaignGoal)
      onChange('brandId', String(brand.id))
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2 mb-6">
        <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
          <Building2 className="w-4 h-4 text-purple-600" />
        </div>
        <h2 className="text-lg font-semibold text-gray-900">Brand Details</h2>
      </div>

      {/* Saved brand selector */}
      <div className="p-4 rounded-xl bg-purple-50/50 border border-purple-100">
        <label className="block text-sm font-medium text-purple-700 mb-2">
          Load from saved brand (optional)
        </label>
        <div className="relative">
          <select
            value={selectedBrandId ?? ''}
            onChange={(e) => handleBrandSelect(e.target.value)}
            className="w-full px-3 py-2.5 rounded-xl border border-purple-200 bg-white text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500/50 appearance-none"
          >
            <option value="">-- Enter brand manually or select a saved brand --</option>
            {brands.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name} {b.niche ? `(${b.niche})` : ''}
              </option>
            ))}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
        </div>
        {loadingBrands && <p className="text-xs text-gray-400 mt-1">Loading brands...</p>}
        {!loadingBrands && brands.length === 0 && (
          <p className="text-xs text-gray-400 mt-1">No saved brands yet. Fill in the form below manually.</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {fields.map((field) => {
          const Icon = field.icon
          return (
            <div key={field.id} className={field.type === 'textarea' ? 'md:col-span-2' : ''}>
              <label htmlFor={field.id} className="block text-sm font-medium text-gray-700 mb-1.5">
                {field.label}
              </label>
              <div className="relative">
                <div className="absolute left-3 top-3 text-gray-400 pointer-events-none">
                  <Icon className="w-4 h-4" />
                </div>
                {field.type === 'textarea' ? (
                  <textarea
                    id={field.id}
                    value={formData[field.id] ?? ''}
                    onChange={(e) => onChange(field.id, e.target.value)}
                    placeholder={field.placeholder}
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 bg-white text-gray-900 placeholder-gray-400 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 transition-all duration-200"
                  />
                ) : (
                  <input
                    id={field.id}
                    type="text"
                    value={formData[field.id] ?? ''}
                    onChange={(e) => onChange(field.id, e.target.value)}
                    placeholder={field.placeholder}
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 bg-white text-gray-900 placeholder-gray-400 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 transition-all duration-200"
                  />
                )}
              </div>
              {errors?.[field.id] && (
                <p className="mt-1 text-xs text-red-500">{errors[field.id]}</p>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
