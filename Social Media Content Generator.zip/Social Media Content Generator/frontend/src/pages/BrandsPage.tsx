import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Plus, Building2, Globe, Users, Trash2, Edit3, X, Check,
  Eye, Search, ArrowUpDown, Copy, Sparkles, ChevronDown,
  Loader2, Camera,
} from 'lucide-react'
import * as api from '@/api/endpoints'
import type { BrandProfile } from '@/types/common'
import { ROUTES } from '@/routes/paths'
import { useToast } from '@/components/ui/Toast'
import { PageTransition } from '@/components/layout/PageTransition'
import { Skeleton, CardSkeleton } from '@/components/ui/Skeleton'

type SortKey = 'updated' | 'name' | 'campaigns'

export function BrandsPage() {
  const navigate = useNavigate()
  const { showToast } = useToast()
  const [brands, setBrands] = useState<BrandProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [sort, setSort] = useState<SortKey>('updated')
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<number | null>(null)
  const [form, setForm] = useState({ name: '', description: '', niche: '', target_audience: '', website: '', logo_url: '' })
  const [saving, setSaving] = useState(false)
  const logoFileInputRef = useRef<HTMLInputElement>(null)
  const [uploadingLogo, setUploadingLogo] = useState(false)

  const loadBrands = () => {
    api.fetchBrands()
      .then(setBrands)
      .catch(() => setBrands([]))
      .finally(() => setLoading(false))
  }

  useEffect(() => { loadBrands() }, [])

  const resetForm = () => {
    setForm({ name: '', description: '', niche: '', target_audience: '', website: '', logo_url: '' })
    setEditingId(null)
    setShowForm(false)
  }

  const handleEdit = (b: BrandProfile) => {
    setForm({
      name: b.name,
      description: b.description || '',
      niche: b.niche || '',
      target_audience: b.target_audience || '',
      website: b.website || '',
      logo_url: b.logo_url || '',
    })
    setEditingId(b.id)
    setShowForm(true)
  }

  const handleSave = async () => {
    if (!form.name.trim()) return
    setSaving(true)
    try {
      if (editingId) {
        await api.updateBrand(editingId, form)
      } else {
        await api.createBrand(form)
      }
      resetForm()
      loadBrands()
    } catch (_err) { /* silently ignore */ }
    setSaving(false)
  }

  const handleDelete = async (id: number) => {
    try {
      await api.deleteBrand(id)
      loadBrands()
    } catch (_err) { /* silently ignore */ }
  }

  const handleLogoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploadingLogo(true)
    try {
      const { url } = await api.uploadFile(file, 'logo')
      setForm((prev) => ({ ...prev, logo_url: url }))
    } catch {
      showToast('Failed to upload logo.', 'error')
    }
    setUploadingLogo(false)
    if (logoFileInputRef.current) logoFileInputRef.current.value = ''
  }

  const handleDuplicate = async (b: BrandProfile) => {
    try {
      await api.createBrand({
        name: `${b.name} (Copy)`,
        description: b.description,
        niche: b.niche,
        target_audience: b.target_audience,
        website: b.website,
      })
      loadBrands()
    } catch (_err) { /* silently ignore */ }
  }

  const filtered = useMemo(() => {
    let result = [...brands]
    if (search.trim()) {
      const q = search.toLowerCase()
      result = result.filter((b) =>
        b.name.toLowerCase().includes(q) ||
        b.niche?.toLowerCase().includes(q) ||
        b.description?.toLowerCase().includes(q) ||
        b.target_audience?.toLowerCase().includes(q)
      )
    }
    result.sort((a, b) => {
      switch (sort) {
        case 'name': return a.name.localeCompare(b.name)
        case 'campaigns': return (b.campaign_count || 0) - (a.campaign_count || 0)
        default: return 0
      }
    })
    return result
  }, [brands, search, sort])

  if (loading) {
    return (
      <PageTransition>
        <div className="max-w-6xl mx-auto space-y-6">
          <Skeleton className="h-7 w-24 mb-2" />
          <Skeleton className="h-4 w-40" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => <CardSkeleton key={i} />)}
          </div>
        </div>
      </PageTransition>
    )
  }

  return (
    <PageTransition>
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Brands</h1>
            <p className="text-gray-500 mt-1">Manage your brand profiles.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search brands..."
                className="pl-9 pr-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm w-56"
              />
            </div>
            <div className="relative">
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as SortKey)}
                className="appearance-none pl-3 pr-8 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-sm bg-white text-gray-700"
              >
                <option value="updated">Recently updated</option>
                <option value="name">Name A-Z</option>
                <option value="campaigns">Most campaigns</option>
              </select>
              <ArrowUpDown className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" />
            </div>
            <button
              onClick={() => { resetForm(); setShowForm(true) }}
              className="bg-gradient-to-r from-purple-600 to-purple-800 text-white text-sm font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 hover:scale-[1.02] transition-all duration-200 flex items-center gap-2 shrink-0"
            >
              <Plus className="w-4 h-4" /> New Brand
            </button>
          </div>
        </div>

        {/* Form */}
        {showForm && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">{editingId ? 'Edit Brand' : 'New Brand'}</h2>
              <button onClick={resetForm} className="p-1 rounded-lg hover:bg-gray-100 text-gray-400">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Logo</label>
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-xl overflow-hidden bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center text-white font-bold text-lg shrink-0">
                    {form.logo_url ? (
                      <img src={form.logo_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      form.name.charAt(0).toUpperCase() || '?'
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => logoFileInputRef.current?.click()}
                    disabled={uploadingLogo}
                    className="px-3 py-2 text-sm font-medium text-purple-700 bg-purple-50 rounded-xl hover:bg-purple-100 transition-colors flex items-center gap-2 disabled:opacity-50"
                  >
                    {uploadingLogo ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera className="w-4 h-4" />}
                    {form.logo_url ? 'Change' : 'Upload'}
                  </button>
                  {form.logo_url && (
                    <button
                      type="button"
                      onClick={() => setForm((prev) => ({ ...prev, logo_url: '' }))}
                      className="text-xs text-red-500 hover:text-red-700"
                    >
                      Remove
                    </button>
                  )}
                  <input
                    ref={logoFileInputRef}
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    className="hidden"
                    onChange={handleLogoSelect}
                  />
                </div>
              </div>
              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                <input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm resize-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Niche</label>
                <input
                  value={form.niche}
                  onChange={(e) => setForm({ ...form, niche: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Target Audience</label>
                <input
                  value={form.target_audience}
                  onChange={(e) => setForm({ ...form, target_audience: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Website</label>
                <input
                  value={form.website}
                  onChange={(e) => setForm({ ...form, website: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-4">
              <button onClick={resetForm} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900">Cancel</button>
              <button
                onClick={handleSave}
                disabled={saving || !form.name.trim()}
                className="bg-gradient-to-r from-purple-600 to-purple-800 text-white text-sm font-semibold px-5 py-2 rounded-xl shadow-lg hover:shadow-purple-500/40 hover:scale-[1.02] transition-all duration-200 disabled:opacity-50 flex items-center gap-2"
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                {editingId ? 'Update' : 'Create'}
              </button>
            </div>
          </motion.div>
        )}

        {/* Empty state */}
        {filtered.length === 0 && !loading && (
          <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center">
            <Building2 className="w-12 h-12 text-gray-200 mx-auto mb-4" />
            {search ? (
              <p className="text-gray-400 text-sm">No brands match your search.</p>
            ) : (
              <>
                <p className="text-gray-900 font-semibold mb-1">Create your first brand profile</p>
                <p className="text-gray-400 text-sm mb-5">
                  Brand profiles store your business details so you can generate campaigns faster.
                </p>
                <button
                  onClick={() => { resetForm(); setShowForm(true) }}
                  className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-purple-800 text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-lg hover:shadow-purple-500/40 hover:scale-[1.02] transition-all duration-200"
                >
                  <Plus className="w-4 h-4" /> Create Brand
                </button>
              </>
            )}
          </div>
        )}

        {/* Brand grid */}
        {filtered.length > 0 && (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map((b, i) => (
              <motion.div
                key={b.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04, duration: 0.3 }}
                className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-lg hover:border-purple-200 transition-all duration-300 overflow-hidden group"
              >
                <div className="p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-11 h-11 rounded-xl overflow-hidden bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center text-white font-bold text-sm shrink-0">
                        {b.logo_url ? (
                          <img src={b.logo_url} alt="" className="w-full h-full object-cover" />
                        ) : (
                          b.name.charAt(0).toUpperCase()
                        )}
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-semibold text-gray-900 text-sm truncate">{b.name}</h3>
                        {b.niche && <p className="text-xs text-gray-400 truncate">{b.niche}</p>}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => navigate(ROUTES.brandDetail.replace(':brandId', String(b.id)))}
                        className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-purple-600 opacity-0 group-hover:opacity-100 transition-all duration-200"
                        title="View Campaigns"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => handleEdit(b)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-blue-600" title="Edit">
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <div className="relative group/dropdown">
                        <button className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400" title="More actions">
                          <ChevronDown className="w-3.5 h-3.5" />
                        </button>
                        <div className="absolute right-0 top-full mt-1 w-40 bg-white rounded-xl border border-gray-100 shadow-lg py-1 hidden group-hover/dropdown:block z-10">
                          <button
                            onClick={() => handleDuplicate(b)}
                            className="w-full flex items-center gap-2 px-3 py-2 text-xs text-gray-600 hover:bg-gray-50"
                          >
                            <Copy className="w-3.5 h-3.5" /> Duplicate
                          </button>
                          <button
                            onClick={() => navigate(ROUTES.generate, { state: { brandId: b.id } })}
                            className="w-full flex items-center gap-2 px-3 py-2 text-xs text-gray-600 hover:bg-gray-50"
                          >
                            <Sparkles className="w-3.5 h-3.5" /> Generate campaign
                          </button>
                          <button
                            onClick={() => handleDelete(b.id)}
                            className="w-full flex items-center gap-2 px-3 py-2 text-xs text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-3.5 h-3.5" /> Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {b.description && (
                    <p className="text-sm text-gray-600 mb-3 line-clamp-2 break-words">{b.description}</p>
                  )}

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-gray-400">
                    {b.target_audience && (
                      <span className="flex items-center gap-1"><Users className="w-3 h-3" />{b.target_audience}</span>
                    )}
                    {b.website && <span className="flex items-center gap-1"><Globe className="w-3 h-3" />Website</span>}
                    {(b.campaign_count ?? 0) > 0 && (
                      <span className="font-medium text-purple-600">{b.campaign_count} campaign{(b.campaign_count ?? 0) !== 1 ? 's' : ''}</span>
                    )}
                  </div>
                </div>
                <div className="border-t border-gray-50 px-5 py-2.5">
                  <button
                    onClick={() => navigate(ROUTES.brandDetail.replace(':brandId', String(b.id)))}
                    className="text-xs font-medium text-purple-600 hover:text-purple-800 transition-colors"
                  >
                    View Campaigns &rarr;
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </PageTransition>
  )
}
