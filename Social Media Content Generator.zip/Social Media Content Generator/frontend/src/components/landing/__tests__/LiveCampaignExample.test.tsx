import { render, screen, fireEvent } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import { LiveCampaignExample } from '@/components/landing/LiveCampaignExample'
import { buildLiveDemo } from '@/lib/buildLiveDemo'

vi.mock('@/hooks/useReducedMotionPreference', () => ({
  useReducedMotionPreference: () => false,
}))

function renderLiveDemo() {
  return render(<LiveCampaignExample />)
}

describe('LiveCampaignExample', () => {
  it('renders the section heading', () => {
    renderLiveDemo()
    expect(screen.getByText('Live Campaign Example')).toBeDefined()
  })

  it('renders the brand name Urban Brew Studio', () => {
    renderLiveDemo()
    const brandElements = screen.getAllByText(/Urban Brew Studio/)
    expect(brandElements.length).toBeGreaterThan(0)
  })

  it('shows Instagram as default platform button with selected styling', () => {
    renderLiveDemo()
    const instaBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('Instagram'))
    expect(instaBtn).toBeDefined()
    expect(instaBtn!.getAttribute('aria-pressed')).toBe('true')
  })

  it('shows Professional as default tone button with selected styling', () => {
    renderLiveDemo()
    const profBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('Professional'))
    expect(profBtn).toBeDefined()
    expect(profBtn!.getAttribute('aria-pressed')).toBe('true')
  })

  it('selecting LinkedIn toggles aria-pressed from Instagram to LinkedIn', () => {
    renderLiveDemo()
    const linkedinBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('LinkedIn'))
    expect(linkedinBtn).toBeDefined()
    fireEvent.click(linkedinBtn!)
    expect(linkedinBtn!.getAttribute('aria-pressed')).toBe('true')
    const instaBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('Instagram'))
    expect(instaBtn!.getAttribute('aria-pressed')).toBe('false')
  })

  it('selecting Funny tone toggles aria-pressed from Professional to Funny', () => {
    renderLiveDemo()
    const funnyBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('Funny'))
    expect(funnyBtn).toBeDefined()
    fireEvent.click(funnyBtn!)
    expect(funnyBtn!.getAttribute('aria-pressed')).toBe('true')
    const profBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('Professional'))
    expect(profBtn!.getAttribute('aria-pressed')).toBe('false')
  })

  it('selecting Luxury tone toggles aria-pressed', () => {
    renderLiveDemo()
    const luxuryBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('Luxury'))
    expect(luxuryBtn).toBeDefined()
    fireEvent.click(luxuryBtn!)
    expect(luxuryBtn!.getAttribute('aria-pressed')).toBe('true')
  })

  it('selecting Gen Z tone toggles aria-pressed', () => {
    renderLiveDemo()
    const genzBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('Gen Z'))
    expect(genzBtn).toBeDefined()
    fireEvent.click(genzBtn!)
    expect(genzBtn!.getAttribute('aria-pressed')).toBe('true')
  })

  it('changing both platform and tone preserves both selections', () => {
    renderLiveDemo()
    const linkedinBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('LinkedIn'))
    const genzBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('Gen Z'))
    fireEvent.click(linkedinBtn!)
    fireEvent.click(genzBtn!)
    expect(linkedinBtn!.getAttribute('aria-pressed')).toBe('true')
    expect(genzBtn!.getAttribute('aria-pressed')).toBe('true')
  })

  it('shows 7 day cards', () => {
    renderLiveDemo()
    for (let i = 1; i <= 7; i++) {
      expect(screen.getByText(`Day ${i}`)).toBeDefined()
    }
  })

  it('shows copy button for captions', () => {
    renderLiveDemo()
    const copyButtons = document.querySelectorAll('[title="Copy caption"]')
    expect(copyButtons.length).toBeGreaterThan(0)
  })

  it('no real API request is made when controls change', () => {
    const fetchSpy = vi.spyOn(globalThis, 'fetch')
    renderLiveDemo()
    const tiktokBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('TikTok'))
    fireEvent.click(tiktokBtn!)
    const genzBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('Gen Z'))
    fireEvent.click(genzBtn!)
    expect(fetchSpy).not.toHaveBeenCalled()
    fetchSpy.mockRestore()
  })

  it('unselected buttons have aria-pressed=false', () => {
    renderLiveDemo()
    const tiktokBtn = screen.getAllByRole('button').find((b) => b.textContent?.includes('TikTok'))
    expect(tiktokBtn!.getAttribute('aria-pressed')).toBe('false')
  })

  it('default demo shows 5+ hashtags for Instagram', () => {
    renderLiveDemo()
    const hashtagElements = document.querySelectorAll('.rounded-full.bg-purple-100')
    expect(hashtagElements.length).toBeGreaterThanOrEqual(5)
  })
})

describe('buildLiveDemo', () => {
  it('returns correct default for instagram + professional', () => {
    const demo = buildLiveDemo({ platform: 'instagram', tone: 'professional' })
    expect(demo.platform).toBe('instagram')
    expect(demo.tone).toBe('professional')
    expect(demo.days).toHaveLength(7)
    expect(demo.featuredCaptions).toHaveLength(2)
    expect(demo.hashtags.length).toBeGreaterThan(0)
  })

  it('X platform reduces hashtag count', () => {
    const xDemo = buildLiveDemo({ platform: 'x', tone: 'professional' })
    const instaDemo = buildLiveDemo({ platform: 'instagram', tone: 'professional' })
    expect(xDemo.hashtags.length).toBeLessThan(instaDemo.hashtags.length)
  })

  it('LinkedIn platform uses professional content types', () => {
    const demo = buildLiveDemo({ platform: 'linkedin', tone: 'professional' })
    const types = demo.days.map((d) => d.contentType)
    expect(types).not.toContain('Reel')
    expect(types).not.toContain('Static Post')
  })

  it('TikTok platform uses short video content types', () => {
    const demo = buildLiveDemo({ platform: 'tiktok', tone: 'professional' })
    const types = demo.days.map((d) => d.contentType)
    expect(types).not.toContain('Carousel')
    expect(types).not.toContain('Industry Insight')
  })

  it('Facebook platform uses community-style content types', () => {
    const demo = buildLiveDemo({ platform: 'facebook', tone: 'professional' })
    const types = demo.days.map((d) => d.contentType)
    expect(types).not.toContain('Reel')
    expect(types).not.toContain('Short Video')
  })

  it('Luxury tone modifies caption text', () => {
    const prof = buildLiveDemo({ platform: 'instagram', tone: 'professional' })
    const lux = buildLiveDemo({ platform: 'instagram', tone: 'luxury' })
    expect(prof.featuredCaptions[0]!.caption).not.toBe(lux.featuredCaptions[0]!.caption)
  })

  it('Funny tone modifies CTA text', () => {
    const prof = buildLiveDemo({ platform: 'instagram', tone: 'professional' })
    const funny = buildLiveDemo({ platform: 'instagram', tone: 'funny' })
    expect(prof.featuredCaptions[0]!.cta).not.toBe(funny.featuredCaptions[0]!.cta)
  })

  it('Gen Z tone adds casual phrases', () => {
    const demo = buildLiveDemo({ platform: 'instagram', tone: 'genz' })
    const phrases = ['honestly', 'bestie', 'cap', 'vibe', 'obsessed']
    const hasPhrase = phrases.some((p) => demo.featuredCaptions[0]!.caption.toLowerCase().includes(p))
    expect(hasPhrase).toBe(true)
  })

  it('all 20 combinations produce valid output', () => {
    const platformKeys = ['instagram', 'linkedin', 'tiktok', 'facebook', 'x'] as const
    const toneKeys = ['professional', 'funny', 'luxury', 'genz'] as const
    for (const p of platformKeys) {
      for (const t of toneKeys) {
        const demo = buildLiveDemo({ platform: p, tone: t })
        expect(demo.days).toHaveLength(7)
        expect(demo.featuredCaptions).toHaveLength(2)
        expect(demo.hashtags.length).toBeGreaterThan(0)
      }
    }
  })

  it('Instagram + Professional first featured caption contains brand name', () => {
    const demo = buildLiveDemo({ platform: 'instagram', tone: 'professional' })
    expect(demo.featuredCaptions[0]!.caption).toContain('Urban Brew Studio')
  })
})
