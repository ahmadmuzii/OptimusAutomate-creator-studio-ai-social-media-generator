from __future__ import annotations


class TestExperimentsAPI:
    """Test A/B experiment CRUD, variants, and winner declaration endpoints."""

    def test_create_experiment(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Hook Test A/B",
            "variable_tested": "hook_style",
            "success_metric": "engagement",
            "variants": [
                {"label": "Question Hook", "variable_value": "question", "content_value": "What if..."},
                {"label": "Stat Hook", "variable_value": "statistic", "content_value": "80% of..."},
            ],
        }
        response = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data["variants"]) == 2
        assert data["status"] == "draft"

    def test_list_experiments(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "List Test",
            "variable_tested": "hook_style",
            "success_metric": "engagement",
            "variants": [{"label": "A", "variable_value": "a", "content_value": "c1"}],
        }
        client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        )

        response = client.get(
            f"/api/v1/brands/{brand_id}/experiments",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["name"] == "List Test"

    def test_get_experiment(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Get Test",
            "variable_tested": "cta_style",
            "success_metric": "clicks",
            "variants": [{"label": "V1", "variable_value": "v1", "content_value": "c1"}],
        }
        created = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        ).json()

        response = client.get(
            f"/api/v1/brands/{brand_id}/experiments/{created['id']}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Get Test"
        assert data["variable_tested"] == "cta_style"

    def test_update_experiment(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Old Name",
            "variable_tested": "hook_style",
            "success_metric": "engagement",
            "variants": [{"label": "V1", "variable_value": "v1", "content_value": "c1"}],
        }
        created = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        ).json()

        response = client.put(
            f"/api/v1/brands/{brand_id}/experiments/{created['id']}",
            json={"name": "New Name", "status": "active"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "New Name"
        assert data["status"] == "active"

    def test_delete_experiment(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Delete Me",
            "variable_tested": "hook_style",
            "variants": [],
        }
        created = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        ).json()

        response = client.delete(
            f"/api/v1/brands/{brand_id}/experiments/{created['id']}",
            headers=auth_headers,
        )
        assert response.status_code == 200

        get_resp = client.get(
            f"/api/v1/brands/{brand_id}/experiments",
            headers=auth_headers,
        )
        assert len(get_resp.json()) == 0

    def test_add_variant(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Add Variant Test",
            "variable_tested": "hook_style",
            "variants": [],
        }
        exp = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        ).json()

        response = client.post(
            f"/api/v1/brands/{brand_id}/experiments/{exp['id']}/variants",
            json={"label": "New Variant", "variable_value": "new_val", "content_value": "new content"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["label"] == "New Variant"
        assert data["status"] == "draft"

    def test_update_variant_results(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Variant Results Test",
            "variable_tested": "hook_style",
            "success_metric": "engagement",
            "variants": [
                {"label": "A", "variable_value": "a", "content_value": "content a"},
            ],
        }
        exp = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        ).json()
        variant_id = exp["variants"][0]["id"]

        response = client.patch(
            f"/api/v1/brands/{brand_id}/experiments/variants/{variant_id}",
            json={"impressions": 1000, "clicks": 200, "engagement": 500},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["impressions"] == 1000
        assert data["clicks"] == 200
        assert data["engagement"] == 500

    def test_json_body_accepted(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "JSON Body Test",
            "variable_tested": "hook_style",
            "success_metric": "engagement",
            "variants": [
                {"label": "A", "variable_value": "a", "content_value": "content a"},
            ],
        }
        exp = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        ).json()
        variant_id = exp["variants"][0]["id"]

        response = client.post(
            f"/api/v1/brands/{brand_id}/experiments/{exp['id']}/declare-winner",
            json={"variant_id": variant_id},
            headers=auth_headers,
        )
        assert response.status_code == 200

    def test_missing_variant_id_returns_422(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Missing ID Test",
            "variable_tested": "hook_style",
            "success_metric": "engagement",
            "variants": [
                {"label": "A", "variable_value": "a", "content_value": "content a"},
            ],
        }
        exp = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        ).json()

        response = client.post(
            f"/api/v1/brands/{brand_id}/experiments/{exp['id']}/declare-winner",
            json={},
            headers=auth_headers,
        )
        assert response.status_code == 422

    def test_invalid_variant_id_returns_404(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Invalid Variant Test",
            "variable_tested": "hook_style",
            "success_metric": "engagement",
            "variants": [
                {"label": "A", "variable_value": "a", "content_value": "content a"},
            ],
        }
        exp = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        ).json()

        response = client.post(
            f"/api/v1/brands/{brand_id}/experiments/{exp['id']}/declare-winner",
            json={"variant_id": 99999},
            headers=auth_headers,
        )
        assert response.status_code == 404

    def test_variant_from_another_experiment_rejected(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        # Create first experiment with variant A
        exp1 = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json={
                "name": "Exp1",
                "variable_tested": "hook_style",
                "success_metric": "engagement",
                "variants": [{"label": "A", "variable_value": "a", "content_value": "c"}],
            },
            headers=auth_headers,
        ).json()
        variant_id = exp1["variants"][0]["id"]

        # Create second experiment
        exp2 = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json={
                "name": "Exp2",
                "variable_tested": "hook_style",
                "success_metric": "engagement",
                "variants": [{"label": "B", "variable_value": "b", "content_value": "c"}],
            },
            headers=auth_headers,
        ).json()

        # Try to declare variant from exp1 as winner of exp2
        response = client.post(
            f"/api/v1/brands/{brand_id}/experiments/{exp2['id']}/declare-winner",
            json={"variant_id": variant_id},
            headers=auth_headers,
        )
        assert response.status_code == 404

    def test_valid_winner_persists(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Persistence Test",
            "variable_tested": "hook_style",
            "success_metric": "engagement",
            "variants": [
                {"label": "A", "variable_value": "a", "content_value": "content a"},
            ],
        }
        exp = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        ).json()
        variant_id = exp["variants"][0]["id"]

        response = client.post(
            f"/api/v1/brands/{brand_id}/experiments/{exp['id']}/declare-winner",
            json={"variant_id": variant_id},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "completed"
        winners = [v for v in data["variants"] if v["is_winner"]]
        assert len(winners) == 1
        assert winners[0]["id"] == variant_id

        # Persist after refresh
        refreshed = client.get(
            f"/api/v1/brands/{brand_id}/experiments/{exp['id']}",
            headers=auth_headers,
        ).json()
        assert refreshed["status"] == "completed"
        winners = [v for v in refreshed["variants"] if v["is_winner"]]
        assert len(winners) == 1
        assert winners[0]["id"] == variant_id

    def test_declare_new_winner_clears_previous(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Clear Previous Winner",
            "variable_tested": "hook_style",
            "success_metric": "engagement",
            "variants": [
                {"label": "A", "variable_value": "a", "content_value": "content a"},
                {"label": "B", "variable_value": "b", "content_value": "content b"},
            ],
        }
        exp = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        ).json()
        var_a = exp["variants"][0]["id"]
        var_b = exp["variants"][1]["id"]

        # Declare A as winner
        r1 = client.post(
            f"/api/v1/brands/{brand_id}/experiments/{exp['id']}/declare-winner",
            json={"variant_id": var_a},
            headers=auth_headers,
        )
        assert r1.status_code == 200

        # Declare B as winner
        r2 = client.post(
            f"/api/v1/brands/{brand_id}/experiments/{exp['id']}/declare-winner",
            json={"variant_id": var_b},
            headers=auth_headers,
        )
        assert r2.status_code == 200
        data = r2.json()

        winners = [v for v in data["variants"] if v["is_winner"]]
        assert len(winners) == 1
        assert winners[0]["id"] == var_b

        # A is no longer winner
        a_ref = [v for v in data["variants"] if v["id"] == var_a][0]
        assert a_ref["is_winner"] is False

    def test_cannot_access_other_users_experiment(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Mine",
            "variable_tested": "hook_style",
            "variants": [],
        }
        created = client.post(
            f"/api/v1/brands/{brand_id}/experiments",
            json=payload,
            headers=auth_headers,
        ).json()

        response = client.get(
            f"/api/v1/brands/{brand_id}/experiments/{created['id']}",
            headers=second_auth_headers,
        )
        assert response.status_code == 404
