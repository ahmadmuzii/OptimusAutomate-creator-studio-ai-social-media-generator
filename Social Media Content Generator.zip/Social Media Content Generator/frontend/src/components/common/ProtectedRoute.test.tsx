import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen } from '@testing-library/react'
import { ProtectedRoute } from './ProtectedRoute'

const mockNavigate = vi.fn()

vi.mock('react-router-dom', () => ({
  Navigate: ({ to, state }: { to: string; state?: Record<string, unknown> }) => {
    mockNavigate(to, state)
    return <div data-testid="navigate">{to}</div>
  },
  useLocation: () => ({ pathname: '/dashboard' }),
}))

vi.mock('@/context/AuthContext', () => ({
  useAuth: vi.fn(),
}))

import { useAuth } from '@/context/AuthContext'

beforeEach(() => {
  vi.clearAllMocks()
})

describe('ProtectedRoute', () => {
  it('shows spinner while loading', () => {
    vi.mocked(useAuth).mockReturnValue({
      isAuthenticated: false,
      isLoading: true,
    } as ReturnType<typeof useAuth>)

    const { container } = render(
      <ProtectedRoute>
        <p>Protected Content</p>
      </ProtectedRoute>,
    )

    expect(screen.queryByText('Protected Content')).not.toBeInTheDocument()
    const spinner = container.querySelector('.animate-spin')
    expect(spinner).toBeInTheDocument()
  })

  it('redirects to login when not authenticated', () => {
    vi.mocked(useAuth).mockReturnValue({
      isAuthenticated: false,
      isLoading: false,
    } as ReturnType<typeof useAuth>)

    render(
      <ProtectedRoute>
        <p>Protected Content</p>
      </ProtectedRoute>,
    )

    expect(mockNavigate).toHaveBeenCalledWith('/login', { from: { pathname: '/dashboard' } })
    expect(screen.getByTestId('navigate')).toBeInTheDocument()
    expect(screen.queryByText('Protected Content')).not.toBeInTheDocument()
  })

  it('renders children when authenticated', () => {
    vi.mocked(useAuth).mockReturnValue({
      isAuthenticated: true,
      isLoading: false,
    } as ReturnType<typeof useAuth>)

    render(
      <ProtectedRoute>
        <p>Protected Content</p>
      </ProtectedRoute>,
    )

    expect(screen.getByText('Protected Content')).toBeInTheDocument()
    expect(screen.queryByTestId('navigate')).not.toBeInTheDocument()
  })
})
