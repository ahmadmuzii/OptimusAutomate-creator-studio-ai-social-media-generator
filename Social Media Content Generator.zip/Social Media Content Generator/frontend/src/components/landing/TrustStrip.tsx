import { CheckCircle2 } from 'lucide-react'

const capabilities = [
  '5 major platforms',
  '7 tone options',
  'Brand-aware generation',
  'Editable campaign calendar',
]

export function TrustStrip() {
  return (
    <section className="border-y border-gray-100 bg-gray-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
          <span className="text-sm font-medium text-gray-400">Product capabilities:</span>
          {capabilities.map((cap) => (
            <div key={cap} className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-purple-500" />
              <span className="text-sm text-gray-600">{cap}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
