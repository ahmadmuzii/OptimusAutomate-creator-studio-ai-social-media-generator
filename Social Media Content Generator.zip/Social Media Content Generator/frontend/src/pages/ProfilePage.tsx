import { useState, useEffect, useRef } from 'react'
import { Loader2, Save, Check, CalendarDays, Camera } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/components/ui/Toast'
import * as api from '@/api/endpoints'

export function ProfilePage() {
  const { user, updateUser } = useAuth()
  const { showToast } = useToast()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const [name, setName] = useState('')
  const [bio, setBio] = useState('')
  const [jobTitle, setJobTitle] = useState('')
  const [location, setLocation] = useState('')
  const [personalWebsite, setPersonalWebsite] = useState('')
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    if (user) {
      setName(user.name || '')
      setBio(user.bio || '')
      setJobTitle(user.job_title || '')
      setLocation(user.location || '')
      setPersonalWebsite(user.personal_website || '')
    }
  }, [user])

  const handleAvatarSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    try {
      const { url } = await api.uploadFile(file, 'avatar')
      await updateUser({ avatar_url: url })
      showToast('Profile picture updated.', 'success')
    } catch {
      showToast('Failed to upload profile picture.', 'error')
    }
    setUploading(false)
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const handleSave = async () => {
    if (!name.trim()) {
      showToast('Name is required.', 'error')
      return
    }
    setSaving(true)
    try {
      await updateUser({
        name: name.trim(),
        bio: bio.trim() || null,
        job_title: jobTitle.trim() || null,
        location: location.trim() || null,
        personal_website: personalWebsite.trim() || null,
      })
      setSaved(true)
      showToast('Profile saved.', 'success')
      setTimeout(() => setSaved(false), 2000)
    } catch {
      showToast('Failed to save profile.', 'error')
    }
    setSaving(false)
  }

  const createdDate = user?.id
    ? new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
    : ''

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Profile</h1>
        <p className="text-gray-500 mt-1">Manage your personal account details.</p>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
        <div className="flex items-center gap-4 mb-6 pb-6 border-b border-gray-50">
          <div className="relative shrink-0">
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="w-16 h-16 rounded-full overflow-hidden bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center text-white text-xl font-bold hover:ring-2 hover:ring-purple-300 transition-all disabled:opacity-60"
            >
              {user?.avatar_url ? (
                <img src={user.avatar_url} alt="" className="w-full h-full object-cover" />
              ) : (
                user?.name?.charAt(0)?.toUpperCase() || 'U'
              )}
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center shadow-md hover:bg-purple-700 transition-colors"
            >
              {uploading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Camera className="w-3 h-3" />}
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={handleAvatarSelect}
            />
          </div>
          <div className="min-w-0">
            <p className="font-semibold text-gray-900 text-lg">{user?.name}</p>
            <p className="text-sm text-gray-500">{user?.email}</p>
            {user?.id && (
              <p className="text-xs text-gray-400 mt-1 flex items-center gap-1.5">
                <CalendarDays className="w-3 h-3" />
                Member since {createdDate}
              </p>
            )}
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Job Title</label>
              <input
                value={jobTitle}
                onChange={(e) => setJobTitle(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm"
                placeholder="e.g. Marketing Manager"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
              <input
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm"
                placeholder="e.g. New York, USA"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Personal Bio</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={3}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm resize-none"
              placeholder="Tell us about yourself — not a brand description"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Personal Website</label>
            <input
              value={personalWebsite}
              onChange={(e) => setPersonalWebsite(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm"
              placeholder="https://yourpersonalwebsite.com"
            />
          </div>
        </div>

        <div className="flex justify-end mt-6 pt-4 border-t border-gray-50">
          <button
            onClick={handleSave}
            disabled={saving || !name.trim()}
            className="bg-gradient-to-r from-purple-600 to-purple-800 text-white text-sm font-semibold px-6 py-2.5 rounded-xl shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 hover:scale-[1.02] transition-all duration-200 disabled:opacity-50 flex items-center gap-2"
          >
            {saving ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Saving...</>
            ) : saved ? (
              <><Check className="w-4 h-4 text-green-300" /> Saved</>
            ) : (
              <><Save className="w-4 h-4" /> Save changes</>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
