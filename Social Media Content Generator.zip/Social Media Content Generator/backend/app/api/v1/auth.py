from __future__ import annotations

import datetime
from datetime import timezone

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.config import settings
from app.database import get_db
from app.exceptions import AppError, AuthenticationError
from app.logging_config import get_logger
from app.models.db_models import User
from app.services.auth_service import (
    create_access_token,
    create_refresh_token,
    create_user,
    decode_refresh_token,
    generate_reset_token,
    get_user_by_email,
    get_user_by_id,
    hash_password,
    hash_reset_token,
    verify_password,
    verify_reset_token,
)

router = APIRouter(prefix="/auth", tags=["Auth"])

logger = get_logger("api.auth")

RESET_TOKEN_EXPIRE_HOURS = 1
REFRESH_COOKIE_KEY = "refresh_token"


class SignupRequest(BaseModel):
    email: EmailStr = Field(..., max_length=255)
    password: str = Field(..., min_length=6, max_length=128)
    name: str = Field(..., min_length=1, max_length=255)


class LoginRequest(BaseModel):
    email: str = Field(..., min_length=1, max_length=255)
    password: str = Field(..., min_length=1, max_length=128)


class AuthResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict = Field(default_factory=dict)


class UserResponse(BaseModel):
    id: int
    email: str
    name: str
    brand_name: str | None
    niche: str | None
    bio: str | None
    avatar_url: str | None
    job_title: str | None = None
    location: str | None = None
    personal_website: str | None = None
    theme_preference: str = "light"


class UpdateProfileRequest(BaseModel):
    name: str | None = None
    bio: str | None = None
    avatar_url: str | None = None
    job_title: str | None = None
    location: str | None = None
    personal_website: str | None = None


class UpdateSettingsRequest(BaseModel):
    theme_preference: str = "light"


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(..., min_length=1, max_length=128)
    new_password: str = Field(..., min_length=6, max_length=128)


class ForgotPasswordRequest(BaseModel):
    email: str = Field(..., min_length=1, max_length=255)


class ResetPasswordRequest(BaseModel):
    token: str = Field(..., min_length=1)
    new_password: str = Field(..., min_length=6, max_length=128)


def _set_refresh_cookie(response: Response, token: str) -> None:
    response.set_cookie(
        key=REFRESH_COOKIE_KEY,
        value=token,
        httponly=True,
        secure=not settings.is_development,
        samesite="lax",
        max_age=settings.refresh_token_expire_days * 86400,
        path="/api/v1/auth",
    )


def _auth_response(user: User, response: Response) -> AuthResponse:
    access_token = create_access_token({"sub": str(user.id)})
    refresh_token = create_refresh_token({"sub": str(user.id)})
    _set_refresh_cookie(response, refresh_token)
    return AuthResponse(
        access_token=access_token,
        user={
            "id": user.id,
            "email": user.email,
            "name": user.name,
            "brand_name": user.brand_name,
            "niche": user.niche,
            "bio": user.bio,
            "avatar_url": user.avatar_url,
            "job_title": user.job_title,
            "location": user.location,
            "personal_website": user.personal_website,
            "theme_preference": user.theme_preference,
        },
    )


@router.post("/signup", response_model=AuthResponse)
def signup(request: SignupRequest, response: Response, db: Session = Depends(get_db)):
    existing = get_user_by_email(db, request.email)
    if existing:
        raise AppError(status_code=409, detail="Email already registered")
    user = create_user(db, email=request.email, password=request.password, name=request.name)
    logger.info("user_signed_up", user_id=user.id)
    return _auth_response(user, response)


@router.post("/login", response_model=AuthResponse)
def login(request: LoginRequest, response: Response, db: Session = Depends(get_db)):
    user = get_user_by_email(db, request.email)
    if not user or not verify_password(request.password, user.password_hash):
        raise AuthenticationError(detail="Invalid or email")
    logger.info("user_logged_in", user_id=user.id)
    return _auth_response(user, response)


@router.post("/refresh", response_model=AuthResponse)
def refresh(request: Request, response: Response, db: Session = Depends(get_db)):
    raw_token = request.cookies.get(REFRESH_COOKIE_KEY)
    if not raw_token:
        raise AuthenticationError(detail="No refresh token found")
    payload = decode_refresh_token(raw_token)
    if payload is None:
        raise AuthenticationError(detail="Invalid or expired refresh token")
    user_id = payload.get("sub")
    try:
        user = get_user_by_id(db, int(user_id))
    except (ValueError, TypeError):
        raise AuthenticationError(detail="Invalid or expired refresh token")
    if user is None:
        raise AuthenticationError(detail="Invalid or expired refresh token")
    logger.info("token_refreshed", user_id=user.id)
    return _auth_response(user, response)


@router.post("/logout")
def logout(response: Response):
    response.delete_cookie(
        key=REFRESH_COOKIE_KEY,
        path="/api/v1/auth",
        httponly=True,
        secure=not settings.is_development,
        samesite="lax",
    )
    return {"detail": "Logged out successfully"}


@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(require_current_user)):
    return UserResponse(
        id=current_user.id,
        email=current_user.email,
        name=current_user.name,
        brand_name=current_user.brand_name,
        niche=current_user.niche,
        bio=current_user.bio,
        avatar_url=current_user.avatar_url,
        job_title=current_user.job_title,
        location=current_user.location,
        personal_website=current_user.personal_website,
        theme_preference=current_user.theme_preference,
    )


@router.put("/me", response_model=UserResponse)
def update_me(
    request: UpdateProfileRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    if request.name is not None:
        current_user.name = request.name
    if request.bio is not None:
        current_user.bio = request.bio
    if request.avatar_url is not None:
        current_user.avatar_url = request.avatar_url
    if request.job_title is not None:
        current_user.job_title = request.job_title
    if request.location is not None:
        current_user.location = request.location
    if request.personal_website is not None:
        current_user.personal_website = request.personal_website
    db.commit()
    db.refresh(current_user)
    return UserResponse(
        id=current_user.id,
        email=current_user.email,
        name=current_user.name,
        brand_name=current_user.brand_name,
        niche=current_user.niche,
        bio=current_user.bio,
        avatar_url=current_user.avatar_url,
        job_title=current_user.job_title,
        location=current_user.location,
        personal_website=current_user.personal_website,
        theme_preference=current_user.theme_preference,
    )


@router.put("/settings", response_model=UserResponse)
def update_settings(
    request: UpdateSettingsRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    if request.theme_preference not in ("light", "dark", "system"):
        raise AppError(status_code=400, detail="Invalid theme preference")
    current_user.theme_preference = request.theme_preference
    db.commit()
    db.refresh(current_user)
    return UserResponse(
        id=current_user.id,
        email=current_user.email,
        name=current_user.name,
        brand_name=current_user.brand_name,
        niche=current_user.niche,
        bio=current_user.bio,
        avatar_url=current_user.avatar_url,
        job_title=current_user.job_title,
        location=current_user.location,
        personal_website=current_user.personal_website,
        theme_preference=current_user.theme_preference,
    )


@router.put("/password")
def change_password(
    request: ChangePasswordRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    if not verify_password(request.current_password, current_user.password_hash):
        raise AppError(status_code=400, detail="Current password is incorrect")
    current_user.password_hash = hash_password(request.new_password)
    db.commit()
    return {"detail": "Password updated successfully"}


@router.delete("/me")
def delete_account(
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    db.delete(current_user)
    db.commit()
    return {"detail": "Account deleted successfully"}


@router.post("/forgot-password")
def forgot_password(request: ForgotPasswordRequest, db: Session = Depends(get_db)):
    user = get_user_by_email(db, request.email)
    if user:
        reset_token = generate_reset_token()
        hashed = hash_reset_token(reset_token)
        user.reset_token_hash = hashed
        user.reset_token_expires = datetime.datetime.now(timezone.utc) + datetime.timedelta(
            hours=RESET_TOKEN_EXPIRE_HOURS
        )
        db.commit()
        if settings.is_development:
            logger.info("reset_token_generated", user_id=user.id, reset_token=reset_token)
        else:
            logger.info("reset_token_generated", user_id=user.id)
    return {"message": "If an account exists with this email, password reset instructions have been sent."}


@router.post("/reset-password")
def reset_password(request: ResetPasswordRequest, db: Session = Depends(get_db)):
    users = (
        db.query(User)
        .filter(
            User.reset_token_hash.isnot(None),
            User.reset_token_expires.isnot(None),
            User.reset_token_expires > datetime.datetime.now(timezone.utc),
        )
        .all()
    )
    matched_user = None
    for u in users:
        if u.reset_token_hash and verify_reset_token(request.token, u.reset_token_hash):
            matched_user = u
            break
    if not matched_user:
        raise AuthenticationError(detail="Invalid or expired reset token")
    matched_user.password_hash = hash_password(request.new_password)
    matched_user.reset_token_hash = None
    matched_user.reset_token_expires = None
    db.commit()
    logger.info("password_reset_completed", user_id=matched_user.id)
    return {"message": "Password has been reset successfully."}
