from __future__ import annotations

import datetime

from pydantic import BaseModel, ConfigDict


class ExperimentVariantCreate(BaseModel):
    label: str
    variable_value: str
    content_value: str | None = None


class ExperimentVariantUpdate(BaseModel):
    label: str | None = None
    variable_value: str | None = None
    content_value: str | None = None


class ExperimentVariantResponse(BaseModel):
    id: int
    label: str
    variable_value: str
    content_value: str | None = None
    status: str
    impressions: int | None = None
    clicks: int | None = None
    engagement: int | None = None
    conversions: int | None = None
    is_winner: bool

    model_config = ConfigDict(from_attributes=True)


class ExperimentCreate(BaseModel):
    name: str
    campaign_id: int | None = None
    variable_tested: str
    success_metric: str | None = None
    variants: list[ExperimentVariantCreate] = []


class ExperimentUpdate(BaseModel):
    name: str | None = None
    variable_tested: str | None = None
    success_metric: str | None = None
    status: str | None = None


class ExperimentResponse(BaseModel):
    id: int
    brand_id: int
    campaign_id: int | None = None
    name: str
    variable_tested: str
    success_metric: str | None = None
    status: str
    variants: list[ExperimentVariantResponse] = []
    created_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)


class ExperimentVariantResultUpdate(BaseModel):
    impressions: int | None = None
    clicks: int | None = None
    engagement: int | None = None
    conversions: int | None = None


class DeclareWinnerRequest(BaseModel):
    variant_id: int
