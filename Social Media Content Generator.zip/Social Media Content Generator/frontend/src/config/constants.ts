export const API_ENDPOINTS = {
  platforms: '/api/v1/platforms',
  tones: '/api/v1/tones',
  generateCalendar: '/api/v1/generate-calendar',
  generateCaption: '/api/v1/generate-caption',
  health: '/api/v1/health',
  auth: '/api/v1/auth',
  brands: '/api/v1/brands',
  campaigns: '/api/v1/campaigns',
  upload: '/api/v1/upload',
  workspaces: '/api/v1/workspaces',
} as const

export const VALID_POST_STATUSES = ['draft', 'scheduled', 'published'] as const

export const CALENDAR_DAYS = 7

export const MESSAGES = {
  generateSuccess: 'Your campaign is ready!',
  generateLoading: 'Our AI is crafting your content calendar...',
  emptyState: 'Fill in your brand details above, select a platform and tone, then click generate to see your 7-day campaign plan.',
} as const
