export interface ConversionPath {
  id: number
  brand_id: number
  name: string
  destination_type: string
  destination_value: string
  primary_action: string | null
  cta_keyword: string | null
  campaign_goal: string | null
  tracking_label: string | null
  utm_source: string | null
  utm_medium: string | null
  utm_campaign: string | null
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface ConversionPathCreate {
  name: string
  destination_type: string
  destination_value: string
  primary_action?: string | null
  cta_keyword?: string | null
  campaign_goal?: string | null
  tracking_label?: string | null
  utm_source?: string | null
  utm_medium?: string | null
  utm_campaign?: string | null
  is_active?: boolean
}

export interface ConversionPathUpdate {
  name?: string
  destination_type?: string
  destination_value?: string
  primary_action?: string | null
  cta_keyword?: string | null
  campaign_goal?: string | null
  tracking_label?: string | null
  utm_source?: string | null
  utm_medium?: string | null
  utm_campaign?: string | null
  is_active?: boolean
}
