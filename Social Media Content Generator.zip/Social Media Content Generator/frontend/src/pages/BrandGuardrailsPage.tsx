import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowLeft, Save, Plus, Trash2, Shield,
} from 'lucide-react'
import * as api from '@/api/endpoints'
import type { BrandGuardrail } from '@/types/guardrails'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'

type SectionKey = 'language' | 'claims' | 'style' | 'examples'

interface SectionState {
  expanded: boolean
  hasChanges: boolean
}

function makeSections(): Record<SectionKey, SectionState> {
  return {
    language: { expanded: true, hasChanges: false },
    claims: { expanded: false, hasChanges: false },
    style: { expanded: false, hasChanges: false },
    examples: { expanded: false, hasChanges: false },
  }
}

export function normalizeGuardrails(raw: Record<string, unknown> | null | undefined): BrandGuardrail {
  const arr = (key: string): string[] =>
    Array.isArray(raw?.[key]) ? (raw[key] as string[]) : []
  return {
    id: (raw?.id as number) ?? 0,
    brand_id: (raw?.brand_id as number) ?? 0,
    required_phrases: arr('required_phrases'),
    forbidden_words: arr('forbidden_words'),
    competitors_never_mention: arr('competitors_never_mention'),
    approved_product_descriptions: arr('approved_product_descriptions'),
    allowed_claims: arr('allowed_claims'),
    restricted_claims: arr('restricted_claims'),
    preferred_spellings:
      raw?.preferred_spellings && typeof raw.preferred_spellings === 'object' && !Array.isArray(raw.preferred_spellings)
        ? (raw.preferred_spellings as Record<string, string>)
        : {},
    preferred_capitalizations: arr('preferred_capitalizations'),
    product_names: arr('product_names'),
    service_names: arr('service_names'),
    brand_name_aliases: arr('brand_name_aliases'),
    required_legal_disclaimer: (raw?.required_legal_disclaimer as string) ?? null,
    example_posts_liked: Array.isArray(raw?.example_posts_liked)
      ? (raw.example_posts_liked as Array<{ caption?: string; notes?: string }>)
      : null,
    example_posts_disliked: Array.isArray(raw?.example_posts_disliked)
      ? (raw.example_posts_disliked as Array<{ caption?: string; notes?: string }>)
      : null,
    emoji_allowance: (raw?.emoji_allowance as string) ?? null,
    profanity_level: (raw?.profanity_level as string) ?? null,
    formality_level: (raw?.formality_level as string) ?? null,
    max_hashtag_count: (raw?.max_hashtag_count as number) ?? null,
    min_hashtag_count: (raw?.min_hashtag_count as number) ?? null,
    allowed_languages: arr('allowed_languages'),
    default_language: (raw?.default_language as string) ?? null,
    preferred_cta_style: (raw?.preferred_cta_style as string) ?? null,
    forbidden_cta_styles: arr('forbidden_cta_styles'),
    restricted_topics: arr('restricted_topics'),
    sensitive_topics_requiring_review: arr('sensitive_topics_requiring_review'),
    created_at: (raw?.created_at as string) ?? null,
    updated_at: (raw?.updated_at as string) ?? null,
  }
}

const FIELD_SECTION: Record<string, SectionKey> = {
  required_phrases: 'language',
  forbidden_words: 'language',
  competitors_never_mention: 'language',
  preferred_spellings: 'language',
  preferred_capitalizations: 'language',
  product_names: 'language',
  service_names: 'language',
  brand_name_aliases: 'language',
  approved_product_descriptions: 'claims',
  allowed_claims: 'claims',
  restricted_claims: 'claims',
  required_legal_disclaimer: 'claims',
  sensitive_topics_requiring_review: 'claims',
  restricted_topics: 'claims',
  emoji_allowance: 'style',
  profanity_level: 'style',
  formality_level: 'style',
  max_hashtag_count: 'style',
  min_hashtag_count: 'style',
  allowed_languages: 'style',
  default_language: 'style',
  preferred_cta_style: 'style',
  forbidden_cta_styles: 'style',
  example_posts_liked: 'examples',
  example_posts_disliked: 'examples',
}

interface StringListEditorProps {
  label: string
  fieldKey: keyof BrandGuardrail
  placeholder: string
  items: string[]
  onUpdate: (key: keyof BrandGuardrail, index: number, value: string) => void
  onRemove: (key: keyof BrandGuardrail, index: number) => void
  onAdd: (key: keyof BrandGuardrail) => void
}

function StringListEditor({ label, fieldKey, placeholder, items, onUpdate, onRemove, onAdd }: StringListEditorProps) {
  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-gray-700">{label}</label>
      {items.length === 0 && (
        <p className="text-xs text-gray-400">None configured.</p>
      )}
      {items.map((item, i) => (
        <div key={`${fieldKey}-${i}`} className="flex items-center gap-2">
          <input
            value={item}
            onChange={e => onUpdate(fieldKey, i, e.target.value)}
            placeholder={placeholder}
            className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <button onClick={() => onRemove(fieldKey, i)} className="p-1.5 hover:bg-red-50 rounded-lg text-gray-400 hover:text-red-500">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      ))}
      <button onClick={() => onAdd(fieldKey)} className="text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1">
        <Plus className="w-3.5 h-3.5" /> Add {label.toLowerCase()}
      </button>
    </div>
  )
}

export function BrandGuardrailsPage() {
  const { brandId, brand } = useBrandWorkspace()

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [data, setData] = useState<BrandGuardrail | null>(null)
  const [sections, setSections] = useState<Record<SectionKey, SectionState>>(makeSections)

  useEffect(() => {
    api.fetchGuardrails(brandId)
      .then((guardrails) => setData(normalizeGuardrails(guardrails as Record<string, unknown>)))
      .catch(() => setError('Could not load guardrails.'))
      .finally(() => setLoading(false))
  }, [brandId])

  const toggleSection = (key: SectionKey) => {
    setSections(prev => ({
      ...prev,
      [key]: { ...prev[key], expanded: !prev[key].expanded },
    }))
  }

  const markChanged = (fieldKey: string) => {
    const sectionKey = FIELD_SECTION[fieldKey] || 'language'
    setSections(prev => ({
      ...prev,
      [sectionKey]: { ...prev[sectionKey], hasChanges: true },
    }))
  }

  const updateField = useCallback(<K extends keyof BrandGuardrail>(key: K, value: BrandGuardrail[K]) => {
    setData(prev => prev ? { ...prev, [key]: value } : prev)
    markChanged(key as string)
  }, [])

  const updateListField = useCallback((key: keyof BrandGuardrail, index: number, value: string) => {
    setData(prev => {
      if (!prev) return prev
      const arr = [...((prev[key] as string[]) || [])]
      arr[index] = value
      return { ...prev, [key]: arr }
    })
    markChanged(key as string)
  }, [])

  const addToList = useCallback((key: keyof BrandGuardrail) => {
    setData(prev => {
      if (!prev) return prev
      const arr = [...((prev[key] as string[]) || []), '']
      return { ...prev, [key]: arr }
    })
    markChanged(key as string)
  }, [])

  const removeFromList = useCallback((key: keyof BrandGuardrail, index: number) => {
    setData(prev => {
      if (!prev) return prev
      return { ...prev, [key]: ((prev[key] as string[]) || []).filter((_, i) => i !== index) }
    })
    markChanged(key as string)
  }, [])

  const handleSave = async () => {
    if (!data) return
    setSaving(true)
    try {
      const payload: Record<string, unknown> = {
        required_phrases: data.required_phrases,
        forbidden_words: data.forbidden_words,
        competitors_never_mention: data.competitors_never_mention,
        approved_product_descriptions: data.approved_product_descriptions,
        allowed_claims: data.allowed_claims,
        restricted_claims: data.restricted_claims,
        preferred_spellings: data.preferred_spellings,
        preferred_capitalizations: data.preferred_capitalizations,
        product_names: data.product_names,
        service_names: data.service_names,
        brand_name_aliases: data.brand_name_aliases,
        required_legal_disclaimer: data.required_legal_disclaimer,
        emoji_allowance: data.emoji_allowance,
        profanity_level: data.profanity_level,
        formality_level: data.formality_level,
        max_hashtag_count: data.max_hashtag_count,
        min_hashtag_count: data.min_hashtag_count,
        allowed_languages: data.allowed_languages,
        default_language: data.default_language,
        preferred_cta_style: data.preferred_cta_style,
        forbidden_cta_styles: data.forbidden_cta_styles,
        restricted_topics: data.restricted_topics,
        sensitive_topics_requiring_review: data.sensitive_topics_requiring_review,
      }
      Object.keys(payload).forEach(k => { if (payload[k] === null) delete payload[k] })
      await api.updateGuardrails(brandId, payload)
      const fresh = await api.fetchGuardrails(brandId)
      setData(fresh as BrandGuardrail)
      setSections(makeSections())
    } catch { setError('Failed to save.') }
    finally { setSaving(false) }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="w-full space-y-6">
        <Link to={ROUTES.brands} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Brands
        </Link>
        <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      </div>
    )
  }

  const sectionBadge = (key: SectionKey) => {
    const s = sections[key]
    if (s.hasChanges) return <span className="ml-2 text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">Unsaved</span>
    return null
  }

  const sectionIcon = (key: SectionKey) => {
    return sections[key].expanded ? '▼' : '▶'
  }

  return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Shield className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Brand Guardrails</h1>
        </div>
        <Button onClick={handleSave} disabled={saving} className="flex items-center gap-2">
          <Save className="w-4 h-4" />
          {saving ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Configure language, compliance, and style rules. These guardrails will be checked every time content is generated for {brand.name}.
      </p>

      <div className="space-y-4">
        {/* Language Rules */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <button onClick={() => toggleSection('language')} className="w-full flex items-center justify-between p-5 hover:bg-gray-50 transition-colors">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold text-gray-900">Language Rules</h2>
              {sectionBadge('language')}
            </div>
            <span className="text-gray-400">{sectionIcon('language')}</span>
          </button>
          {sections.language.expanded && (
            <div className="px-5 pb-5 space-y-6">
              <StringListEditor label="Required Phrases" fieldKey="required_phrases" placeholder="e.g., ethically sourced" items={data?.required_phrases || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
              <StringListEditor label="Forbidden Words" fieldKey="forbidden_words" placeholder="e.g., cheap" items={data?.forbidden_words || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
              <StringListEditor label="Competitors Never to Mention" fieldKey="competitors_never_mention" placeholder="e.g., CompetitorName" items={data?.competitors_never_mention || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Preferred Spellings</label>
                {data?.preferred_spellings && Object.keys(data.preferred_spellings).length > 0
                  ? Object.entries(data.preferred_spellings).map(([incorrect, correct], i) => (
                    <div key={`preferred_spellings-${i}`} className="flex items-center gap-2">
                      <input value={incorrect} onChange={e => {
                        const newSpellings = { ...(data?.preferred_spellings || {}) }
                        delete newSpellings[incorrect]
                        newSpellings[e.target.value] = correct
                        updateField('preferred_spellings', newSpellings)
                      }} placeholder="Incorrect spelling" className="w-1/2 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <span className="text-gray-400">→</span>
                      <input value={correct} onChange={e => {
                        const newSpellings = { ...(data?.preferred_spellings || {}) }
                        newSpellings[incorrect] = e.target.value
                        updateField('preferred_spellings', newSpellings)
                      }} placeholder="Correct spelling" className="w-1/2 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <button onClick={() => {
                        const newSpellings = { ...(data?.preferred_spellings || {}) }
                        delete newSpellings[incorrect]
                        updateField('preferred_spellings', newSpellings)
                      }} className="p-1.5 hover:bg-red-50 rounded-lg text-gray-400 hover:text-red-500">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                  : <p className="text-xs text-gray-400">None configured.</p>
                }
                <button onClick={() => {
                  const newSpellings = { ...(data?.preferred_spellings || {}), '': '' }
                  updateField('preferred_spellings', newSpellings)
                }} className="text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1">
                  <Plus className="w-3.5 h-3.5" /> Add spelling rule
                </button>
              </div>
              <StringListEditor label="Preferred Capitalizations" fieldKey="preferred_capitalizations" placeholder="e.g., CreatorStudio" items={data?.preferred_capitalizations || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
              <StringListEditor label="Product Names" fieldKey="product_names" placeholder="e.g., Pro Plan" items={data?.product_names || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
              <StringListEditor label="Service Names" fieldKey="service_names" placeholder="e.g., Consultation Package" items={data?.service_names || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
              <StringListEditor label="Brand Name Aliases" fieldKey="brand_name_aliases" placeholder="e.g., CS" items={data?.brand_name_aliases || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
            </div>
          )}
        </div>

        {/* Claims & Compliance */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <button onClick={() => toggleSection('claims')} className="w-full flex items-center justify-between p-5 hover:bg-gray-50 transition-colors">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold text-gray-900">Claims & Compliance</h2>
              {sectionBadge('claims')}
            </div>
            <span className="text-gray-400">{sectionIcon('claims')}</span>
          </button>
          {sections.claims.expanded && (
            <div className="px-5 pb-5 space-y-6">
              <StringListEditor label="Approved Product Descriptions" fieldKey="approved_product_descriptions" placeholder="e.g., Handcrafted with care" items={data?.approved_product_descriptions || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
              <StringListEditor label="Allowed Claims" fieldKey="allowed_claims" placeholder="e.g., Clinically tested" items={data?.allowed_claims || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
              <StringListEditor label="Restricted Claims" fieldKey="restricted_claims" placeholder="e.g., guaranteed results" items={data?.restricted_claims || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Required Legal Disclaimer</label>
                <textarea
                  value={data?.required_legal_disclaimer || ''}
                  onChange={e => updateField('required_legal_disclaimer', e.target.value || null)}
                  placeholder="e.g., *Results may vary. Terms and conditions apply."
                  rows={3}
                  className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <StringListEditor label="Sensitive Topics Requiring Review" fieldKey="sensitive_topics_requiring_review" placeholder="e.g., health claims" items={data?.sensitive_topics_requiring_review || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
              <StringListEditor label="Restricted Topics" fieldKey="restricted_topics" placeholder="e.g., politics" items={data?.restricted_topics || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
            </div>
          )}
        </div>

        {/* Style Rules */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <button onClick={() => toggleSection('style')} className="w-full flex items-center justify-between p-5 hover:bg-gray-50 transition-colors">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold text-gray-900">Style Rules</h2>
              {sectionBadge('style')}
            </div>
            <span className="text-gray-400">{sectionIcon('style')}</span>
          </button>
          {sections.style.expanded && (
            <div className="px-5 pb-5 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Emoji Allowance</label>
                  <select value={data?.emoji_allowance || ''} onChange={e => updateField('emoji_allowance', e.target.value || null)} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    <option value="">Not set</option>
                    <option value="none">None</option>
                    <option value="moderate">Moderate</option>
                    <option value="liberal">Liberal</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Profanity Level</label>
                  <select value={data?.profanity_level || ''} onChange={e => updateField('profanity_level', e.target.value || null)} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    <option value="">Not set</option>
                    <option value="none">None</option>
                    <option value="mild">Mild</option>
                    <option value="moderate">Moderate</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Formality Level</label>
                  <select value={data?.formality_level || ''} onChange={e => updateField('formality_level', e.target.value || null)} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    <option value="">Not set</option>
                    <option value="formal">Formal</option>
                    <option value="semi_formal">Semi-Formal</option>
                    <option value="casual">Casual</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Preferred CTA Style</label>
                  <input value={data?.preferred_cta_style || ''} onChange={e => updateField('preferred_cta_style', e.target.value || null)} placeholder="e.g., question-based" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Max Hashtag Count</label>
                  <input type="number" value={data?.max_hashtag_count ?? ''} onChange={e => updateField('max_hashtag_count', e.target.value ? parseInt(e.target.value) : null)} placeholder="e.g., 10" min={0} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Min Hashtag Count</label>
                  <input type="number" value={data?.min_hashtag_count ?? ''} onChange={e => updateField('min_hashtag_count', e.target.value ? parseInt(e.target.value) : null)} placeholder="e.g., 3" min={0} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Default Language</label>
                  <input value={data?.default_language || ''} onChange={e => updateField('default_language', e.target.value || null)} placeholder="e.g., en" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
              </div>
              <StringListEditor label="Allowed Languages" fieldKey="allowed_languages" placeholder="e.g., en" items={data?.allowed_languages || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
              <StringListEditor label="Forbidden CTA Styles" fieldKey="forbidden_cta_styles" placeholder="e.g., urgency-based" items={data?.forbidden_cta_styles || []} onUpdate={updateListField} onRemove={removeFromList} onAdd={addToList} />
            </div>
          )}
        </div>

        {/* Examples */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <button onClick={() => toggleSection('examples')} className="w-full flex items-center justify-between p-5 hover:bg-gray-50 transition-colors">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold text-gray-900">Examples</h2>
              {sectionBadge('examples')}
            </div>
            <span className="text-gray-400">{sectionIcon('examples')}</span>
          </button>
          {sections.examples.expanded && (
            <div className="px-5 pb-5 space-y-6">
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-700">Posts the Brand Likes</label>
                {(data?.example_posts_liked || []).length === 0 && <p className="text-xs text-gray-400">None added.</p>}
                {(data?.example_posts_liked || []).map((post, i) => (
                  <div key={`example_posts_liked-${i}`} className="flex gap-2">
                    <div className="flex-1 space-y-2">
                      <textarea
                        value={post.caption || ''}
                        onChange={e => {
                          const arr = [...(data?.example_posts_liked || [])]
                          arr[i] = { ...arr[i], caption: e.target.value }
                          updateField('example_posts_liked', arr)
                        }}
                        placeholder="Paste example caption..."
                        rows={2}
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                      <input
                        value={post.notes || ''}
                        onChange={e => {
                          const arr = [...(data?.example_posts_liked || [])]
                          arr[i] = { ...arr[i], notes: e.target.value }
                          updateField('example_posts_liked', arr)
                        }}
                        placeholder="Why this works..."
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                    </div>
                    <button onClick={() => {
                      const arr = [...(data?.example_posts_liked || [])]
                      arr.splice(i, 1)
                      updateField('example_posts_liked', arr)
                    }} className="p-1.5 hover:bg-red-50 rounded-lg text-gray-400 hover:text-red-500 self-start">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                <button onClick={() => updateField('example_posts_liked', [...(data?.example_posts_liked || []), { caption: '', notes: '' }])} className="text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1">
                  <Plus className="w-3.5 h-3.5" /> Add example
                </button>
              </div>
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-700">Posts the Brand Dislikes</label>
                {(data?.example_posts_disliked || []).length === 0 && <p className="text-xs text-gray-400">None added.</p>}
                {(data?.example_posts_disliked || []).map((post, i) => (
                  <div key={`example_posts_disliked-${i}`} className="flex gap-2">
                    <div className="flex-1 space-y-2">
                      <textarea
                        value={post.caption || ''}
                        onChange={e => {
                          const arr = [...(data?.example_posts_disliked || [])]
                          arr[i] = { ...arr[i], caption: e.target.value }
                          updateField('example_posts_disliked', arr)
                        }}
                        placeholder="Paste example caption..."
                        rows={2}
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                      <input
                        value={post.notes || ''}
                        onChange={e => {
                          const arr = [...(data?.example_posts_disliked || [])]
                          arr[i] = { ...arr[i], notes: e.target.value }
                          updateField('example_posts_disliked', arr)
                        }}
                        placeholder="Why this doesn't work..."
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                    </div>
                    <button onClick={() => {
                      const arr = [...(data?.example_posts_disliked || [])]
                      arr.splice(i, 1)
                      updateField('example_posts_disliked', arr)
                    }} className="p-1.5 hover:bg-red-50 rounded-lg text-gray-400 hover:text-red-500 self-start">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                <button onClick={() => updateField('example_posts_disliked', [...(data?.example_posts_disliked || []), { caption: '', notes: '' }])} className="text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1">
                  <Plus className="w-3.5 h-3.5" /> Add example
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
