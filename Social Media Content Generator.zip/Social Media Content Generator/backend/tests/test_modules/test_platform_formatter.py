from __future__ import annotations

import pytest

from app.modules.platform_formatter import (
    PLATFORMS,
    format_for_platform,
    get_content_type_options,
    get_hashtag_count,
)


class TestPlatformFormatter:
    def test_all_platforms_defined(self) -> None:
        assert "instagram" in PLATFORMS
        assert "linkedin" in PLATFORMS
        assert "tiktok" in PLATFORMS
        assert "facebook" in PLATFORMS
        assert "x" in PLATFORMS

    def test_format_for_platform_no_truncation_needed(self) -> None:
        caption = "Short caption"
        result = format_for_platform(caption, "instagram")
        assert result == caption

    def test_format_for_platform_truncation(self) -> None:
        caption = "X " * 200
        result = format_for_platform(caption, "x")
        assert len(result) <= 280

    def test_get_content_type_options(self) -> None:
        types = get_content_type_options("instagram")
        assert "reel" in types
        assert "carousel" in types

    def test_get_hashtag_count(self) -> None:
        count = get_hashtag_count("instagram")
        assert 20 <= count <= 30

    def test_invalid_platform_raises_error(self) -> None:
        with pytest.raises(ValueError, match="Unsupported platform"):
            format_for_platform("text", "InvalidPlatform")
