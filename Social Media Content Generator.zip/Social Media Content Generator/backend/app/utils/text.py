from __future__ import annotations


def truncate_text(text: str, max_chars: int, suffix: str = "...") -> str:
    if len(text) <= max_chars:
        return text

    cutoff = max_chars - len(suffix)
    return text[:cutoff].rsplit(" ", 1)[0] + suffix


def truncate_for_x(raw_caption: str, max_chars: int = 280, buffer: int = 10) -> str:
    sentences = raw_caption.replace(". ", ".").split(".")
    truncated: list[str] = []
    total = 0

    for s in sentences:
        if total + len(s) + 1 > max_chars - buffer:
            break
        truncated.append(s)
        total += len(s) + 1

    return ". ".join(truncated).rstrip(".") + "..."
