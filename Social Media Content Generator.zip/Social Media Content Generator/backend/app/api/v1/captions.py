from __future__ import annotations

from fastapi import APIRouter, Depends

from app.api.deps import get_caption_service
from app.exceptions import CaptionGenerationError
from app.logging_config import get_logger
from app.models.schemas import CaptionRequest, CaptionResponse
from app.services.caption_service import CaptionService
from app.utils.validators import validate_platform, validate_tone

router = APIRouter(tags=["Captions"])

logger = get_logger("api.captions")


@router.post("/generate-caption", response_model=CaptionResponse)
def create_caption(
    request: CaptionRequest,
    caption_service: CaptionService = Depends(get_caption_service),
):
    validate_platform(request.platform)
    validate_tone(request.tone)

    logger.info("create_caption", platform=request.platform, tone=request.tone)

    try:
        caption = caption_service.generate_caption(
            post_idea=request.post_idea,
            platform=request.platform,
            tone=request.tone,
            brand_details=request.brand_details,
        )

        hashtags = caption_service.generate_hashtags(
            niche=request.brand_details.get("niche", "general"),
            platform=request.platform,
            campaign_goal=request.brand_details.get("campaignGoal", "engagement"),
            brand_name=request.brand_details.get("brandName", ""),
        )

        return {"caption": caption, "hashtags": hashtags}
    except CaptionGenerationError as e:
        raise e
