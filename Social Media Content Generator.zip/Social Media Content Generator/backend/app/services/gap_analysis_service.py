from __future__ import annotations

import re
from collections import Counter

from sqlalchemy.orm import Session

from app.models.db_models import Campaign, CompetitorProfile, ContentGapReport


def normalize_topic(topic: str) -> str:
    t = topic.lower().strip()
    t = t.replace("_", " ")
    t = t.replace("-", " ")
    t = re.sub(r"\s+", " ", t)
    return t.strip()


class GapAnalysisService:
    def __init__(self, db: Session):
        self.db = db

    def _collect_brand_theme_counts(self, brand_id: int) -> dict[str, int]:
        counts: dict[str, int] = {}
        campaigns = self.db.query(Campaign).filter(Campaign.brand_profile_id == brand_id).all()
        for c in campaigns:
            for post in c.posts:
                if post.content_theme:
                    theme = normalize_topic(post.content_theme)
                    counts[theme] = counts.get(theme, 0) + 1
        return counts

    def _compute_brand_coverage(self, topic: str, brand_themes: dict[str, int]) -> int:
        total = 0
        for theme, cnt in brand_themes.items():
            if topic in theme or theme in topic:
                total += cnt
        return total

    def analyze(self, brand_id: int, user_id: int) -> dict:
        brand_themes = self._collect_brand_theme_counts(brand_id)

        competitors = self.db.query(CompetitorProfile).filter(CompetitorProfile.brand_id == brand_id).all()

        topic_post_map: dict[str, set] = {}
        topic_comp_map: dict[str, set] = {}
        topic_comp_details: dict[str, list[dict]] = {}

        comp_content_types: dict[str, Counter] = {}

        all_posts_count = 0
        all_topics_set: set = set()

        for comp in competitors:
            comp_name = comp.name
            if comp_name not in comp_content_types:
                comp_content_types[comp_name] = Counter()

            for post in comp.posts:
                all_posts_count += 1
                if post.topics:
                    seen_in_post = set()
                    for raw_topic in post.topics:
                        t = normalize_topic(raw_topic)
                        all_topics_set.add(t)

                        if t not in seen_in_post:
                            seen_in_post.add(t)

                            if t not in topic_post_map:
                                topic_post_map[t] = set()
                            topic_post_map[t].add(post.id)

                            if t not in topic_comp_map:
                                topic_comp_map[t] = set()
                            topic_comp_map[t].add(comp_name)

                            if t not in topic_comp_details:
                                topic_comp_details[t] = []
                            topic_comp_details[t].append(
                                {
                                    "competitor": comp_name,
                                    "competitor_id": comp.id,
                                    "post_id": post.id,
                                    "content_type": post.content_type,
                                }
                            )

                if post.content_type:
                    comp_content_types[comp_name][post.content_type] += 1

        topic_coverage = []
        for topic, post_ids in topic_post_map.items():
            topic_coverage.append(
                {
                    "topic": topic,
                    "post_count": len(post_ids),
                    "competitor_count": len(topic_comp_map.get(topic, set())),
                    "competitors": sorted(topic_comp_map.get(topic, set())),
                }
            )
        topic_coverage.sort(key=lambda x: x["post_count"], reverse=True)

        content_mix = []
        for comp_name, type_counter in comp_content_types.items():
            content_mix.append(
                {
                    "competitor": comp_name,
                    "content_types": dict(type_counter),
                }
            )

        opportunities = []
        for topic, post_ids in topic_post_map.items():
            comp_cov = len(post_ids)
            brand_cov = self._compute_brand_coverage(topic, brand_themes)

            if brand_cov >= comp_cov:
                continue

            if comp_cov >= 2 and brand_cov == 0:
                priority = "high"
            elif brand_cov == 0:
                priority = "medium"
            else:
                priority = "low"

            type_counter: Counter = Counter()
            for detail in topic_comp_details.get(topic, []):
                if detail["content_type"]:
                    type_counter[detail["content_type"]] += 1
            suggested_format = type_counter.most_common(1)[0][0] if type_counter else None

            opportunities.append(
                {
                    "topic": topic,
                    "competitor_coverage": comp_cov,
                    "brand_coverage": brand_cov,
                    "competitors": sorted(topic_comp_map.get(topic, set())),
                    "priority": priority,
                    "suggested_format": suggested_format,
                    "selected_for_generation": False,
                }
            )

        opportunities.sort(
            key=lambda x: (
                0 if x["priority"] == "high" else 1 if x["priority"] == "medium" else 2,
                -x["competitor_coverage"],
            )
        )

        summary = {
            "competitors_analyzed": len(competitors),
            "posts_analyzed": all_posts_count,
            "unique_topics": len(all_topics_set),
            "opportunities_found": len(opportunities),
        }

        recommendations = []
        for opp in opportunities:
            recommendations.append(
                f"Consider creating content about '{opp['topic']}' - covered by {', '.join(opp['competitors'])}"
            )

        report_data = {
            "summary": summary,
            "topic_coverage": topic_coverage[:12],
            "content_mix": content_mix,
            "opportunities": opportunities,
            "recommendations": recommendations,
            "gaps_found": len(opportunities),
            "brand_themes_count": len(brand_themes),
            "competitor_topics_count": len(topic_post_map),
            "gaps": [
                {
                    "topic": opp["topic"],
                    "competitors_covering": opp["competitors"],
                    "platforms": [],
                }
                for opp in opportunities
            ],
        }

        report = ContentGapReport(
            brand_id=brand_id,
            status="completed",
            report_data=report_data,
        )
        self.db.add(report)
        self.db.commit()
        self.db.refresh(report)

        return report_data
