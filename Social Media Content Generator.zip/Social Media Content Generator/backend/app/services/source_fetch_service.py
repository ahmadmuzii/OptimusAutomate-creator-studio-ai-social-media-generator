from __future__ import annotations

import ipaddress
import re
from urllib.parse import urlparse

import httpx

PRIVATE_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
]

ALLOWED_SCHEMES = frozenset({"http", "https"})


def _is_private_url(url: str) -> str | None:
    """Check if a URL resolves to a private/internal IP. Returns an error message or None."""
    parsed = urlparse(url)
    if parsed.scheme not in ALLOWED_SCHEMES:
        return f"URL scheme '{parsed.scheme}' is not allowed"

    host = parsed.hostname
    if not host:
        return "URL has no hostname"

    if host in ("localhost", "localhost.localdomain", "127.0.0.1", "::1", "0.0.0.0"):
        return f"URL host '{host}' is a local address"

    if host.endswith(".local") or host.endswith(".internal"):
        return f"URL host '{host}' appears to be an internal address"

    try:
        ip = ipaddress.ip_address(host)
        for net in PRIVATE_NETWORKS:
            if ip in net:
                return f"URL host '{host}' is a private/reserved address"
    except ValueError:
        pass

    return None


class SourceFetchService:
    CATEGORY_KEYWORDS: dict[str, list[str]] = {
        "product_features": [
            "feature",
            "built-in",
            "comes with",
            "includes",
            "equipped",
            "specification",
            "dimension",
            "capacity",
            "speed",
            "power",
            "battery",
            "material",
            "design",
            "color",
            "size",
        ],
        "brand_voice": [
            "mission",
            "vision",
            "values",
            "we believe",
            "our goal",
            "committed to",
            "dedicated to",
            "proud to",
            "heritage",
            "founded",
            "story",
            "journey",
            "purpose",
        ],
        "pain_points": [
            "struggle",
            "difficult",
            "challenging",
            "problem",
            "issue",
            "frustrat",
            "annoying",
            "waste of time",
            "too complicated",
            "complex",
            "hard to",
            "can't",
            "cannot",
            "pain point",
            "common mistake",
            "overwhelming",
            "stress",
        ],
        "value_props": [
            "save time",
            "save money",
            "increase",
            "boost",
            "improve",
            "enhance",
            "streamline",
            "simplify",
            "easy to use",
            "cost-effective",
            "efficient",
            "fast",
            "reliable",
            "scalable",
            "flexible",
            "secure",
            "benefit",
            "advantage",
            "result",
            "outcome",
            "roi",
        ],
        "testimonials": [
            "testimonial",
            "review",
            "rating",
            "stars",
            "customer says",
            "customer said",
            "user says",
            "user said",
            "recommend",
            "love it",
            "works great",
            "game changer",
            "life saver",
            "best",
            "excellent",
            "amazing",
            "fantastic",
            "love this",
            '"',
            "\u201c",
        ],
        "case_studies": [
            "case study",
            "success story",
            "before and after",
            "we helped",
            "our client",
            "client achieved",
            "percent increase",
            "percent decrease",
            "x growth",
            "quarter",
            "year over year",
            "results showed",
        ],
    }

    async def fetch_url(self, url: str) -> dict:
        error = _is_private_url(url)
        if error:
            return {"title": "", "text": "", "error": error}

        try:
            async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
                resp = await client.get(url, headers={"User-Agent": "Mozilla/5.0"})
                resp.raise_for_status()
                html = resp.text
        except httpx.TimeoutException:
            return {"title": "", "text": "", "error": "Request timed out"}
        except httpx.HTTPStatusError as e:
            return {"title": "", "text": "", "error": f"HTTP {e.response.status_code}"}
        except httpx.RequestError as e:
            return {"title": "", "text": "", "error": str(e)}

        title = self._extract_title(html)
        text = self._extract_text(html)
        return {"title": title, "text": text}

    def _extract_title(self, html: str) -> str:
        match = re.search(r"<title[^>]*>(.*?)</title>", html, re.IGNORECASE | re.DOTALL)
        if match:
            return match.group(1).strip()
        return ""

    def _extract_text(self, html: str) -> str:
        text = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL | re.IGNORECASE)
        text = re.sub(r"<script[^>]*>.*?</script>", "", text, flags=re.DOTALL | re.IGNORECASE)
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text[:10000]

    def extract_facts(self, text: str, title: str) -> list[dict]:
        facts: list[dict] = []

        if title:
            facts.append(
                {
                    "category": "brand_voice",
                    "label": "Page title",
                    "value": title,
                    "source_section": "title",
                    "confidence": 0.9,
                }
            )

        seen_sentences: set[str] = set()

        sentences = re.split(r"(?<=[.!?])\s+", text)
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) < 15 or len(sentence) > 500:
                continue

            lower = sentence.lower()
            if lower in seen_sentences:
                continue
            seen_sentences.add(lower)

            matched_categories = []
            for category, keywords in self.CATEGORY_KEYWORDS.items():
                for kw in keywords:
                    if kw in lower:
                        matched_categories.append(category)
                        break

            if matched_categories:
                primary = matched_categories[0]
                label = sentence[:80].rstrip(".,!?")
                facts.append(
                    {
                        "category": primary,
                        "label": label,
                        "value": sentence,
                        "source_section": "body",
                        "confidence": 0.6,
                    }
                )

        return facts

    async def process_source(
        self,
        source_type: str,
        url: str | None = None,
        text: str | None = None,
    ) -> dict:
        title = ""
        extracted_text = ""

        if source_type == "url" and url:
            result = await self.fetch_url(url)
            if result.get("error"):
                return {"title": "", "text": "", "facts": [], "error": result["error"]}
            title = result["title"]
            extracted_text = result["text"]
        elif source_type == "text" and text:
            extracted_text = text

        facts = self.extract_facts(extracted_text, title)
        return {"title": title, "text": extracted_text, "facts": facts}
