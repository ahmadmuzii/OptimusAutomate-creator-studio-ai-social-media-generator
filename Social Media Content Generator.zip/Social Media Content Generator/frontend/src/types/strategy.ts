export interface StrategyTemplate {
  id: number
  brand_id: number
  name: string
  description: string | null
  funnel_stage: string
  campaign_goal: string
  recommended_ctas: string[]
  content_mix: string[]
  post_frequency: string
  platform_focus: string
  icon: string | null
  is_default: boolean
}

export interface StrategyTemplateCreate {
  name: string
  description?: string | null
  funnel_stage: string
  campaign_goal: string
  recommended_ctas?: string[]
  content_mix?: string[]
  post_frequency?: string
  platform_focus?: string
  icon?: string | null
  is_default?: boolean
}

export interface StrategyTemplateUpdate {
  name?: string
  description?: string | null
  funnel_stage?: string
  campaign_goal?: string
  recommended_ctas?: string[]
  content_mix?: string[]
  post_frequency?: string
  platform_focus?: string
  icon?: string | null
  is_default?: boolean
}

export interface ApplyStrategyRequest {
  template_id: number
  campaign_id: number
}
