export const env = {
  apiUrl: import.meta.env.VITE_API_URL ?? 'http://localhost:8000',
  appName: import.meta.env.VITE_APP_NAME ?? 'Social Media Content Generator',
} as const
