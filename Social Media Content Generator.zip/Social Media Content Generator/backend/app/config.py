from __future__ import annotations

import json
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    app_name: str = Field(default="Social Media Content Generator", alias="APP_NAME")
    app_version: str = Field(default="1.0.0", alias="APP_VERSION")
    app_debug: bool = Field(default=True, alias="APP_DEBUG")
    app_env: Literal["development", "staging", "production"] = Field(default="development", alias="APP_ENV")

    host: str = Field(default="0.0.0.0", alias="HOST")
    port: int = Field(default=8000, ge=1, le=65535, alias="PORT")

    cors_origins: list[str] = Field(default=["*"], alias="CORS_ORIGINS")
    frontend_origins: list[str] = Field(
        default=["http://localhost:5173", "http://localhost:4173"], alias="FRONTEND_ORIGINS"
    )

    groq_api_key: str = Field(default="", alias="GROQ_API_KEY")
    groq_model: str = Field(default="llama-3.3-70b-versatile", alias="GROQ_MODEL")
    groq_timeout_seconds: int = Field(default=60, alias="GROQ_TIMEOUT_SECONDS")
    groq_max_retries: int = Field(default=2, alias="GROQ_MAX_RETRIES")
    groq_enabled: bool = Field(default=True, alias="GROQ_ENABLED")
    groq_tpm_budget: int = Field(default=5000, alias="GROQ_TPM_BUDGET")
    groq_strategy_max_output_tokens: int = Field(default=700, alias="GROQ_STRATEGY_MAX_OUTPUT_TOKENS")
    groq_campaign_max_output_tokens: int = Field(default=2800, alias="GROQ_CAMPAIGN_MAX_OUTPUT_TOKENS")
    groq_context_max_source_facts: int = Field(default=15, alias="GROQ_CONTEXT_MAX_SOURCE_FACTS")
    groq_context_max_recent_campaigns: int = Field(default=2, alias="GROQ_CONTEXT_MAX_RECENT_CAMPAIGNS")
    groq_context_max_performance_insights: int = Field(default=3, alias="GROQ_CONTEXT_MAX_PERFORMANCE_INSIGHTS")
    groq_context_max_experiment_learnings: int = Field(default=3, alias="GROQ_CONTEXT_MAX_EXPERIMENT_LEARNINGS")
    groq_context_max_competitor_opportunities: int = Field(default=3, alias="GROQ_CONTEXT_MAX_COMPETITOR_OPPORTUNITIES")
    groq_context_max_freshness_warnings: int = Field(default=3, alias="GROQ_CONTEXT_MAX_FRESHNESS_WARNINGS")

    database_url: str = Field(default="sqlite:///./social_media.db", alias="DATABASE_URL")
    secret_key: str = Field(default="change-me-in-production", alias="SECRET_KEY")
    jwt_algorithm: str = Field(default="HS256", alias="JWT_ALGORITHM")
    access_token_expire_minutes: int = Field(default=15, alias="ACCESS_TOKEN_EXPIRE_MINUTES")
    refresh_token_expire_days: int = Field(default=7, alias="REFRESH_TOKEN_EXPIRE_DAYS")

    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    log_format: Literal["json", "console"] = Field(default="json", alias="LOG_FORMAT")

    upload_dir: str = Field(default="uploads", alias="UPLOAD_DIR")
    max_upload_size_mb: int = Field(default=5, alias="MAX_UPLOAD_SIZE_MB")
    allowed_upload_extensions: list[str] = Field(
        default=["jpg", "jpeg", "png", "webp"], alias="ALLOWED_UPLOAD_EXTENSIONS"
    )

    enable_brand_guardrails: bool = Field(default=True, alias="ENABLE_BRAND_GUARDRAILS")
    enable_audience_personas: bool = Field(default=True, alias="ENABLE_AUDIENCE_PERSONAS")
    enable_conversion_paths: bool = Field(default=True, alias="ENABLE_CONVERSION_PATHS")
    enable_source_to_campaign: bool = Field(default=True, alias="ENABLE_SOURCE_TO_CAMPAIGN")
    enable_source_facts: bool = Field(default=True, alias="ENABLE_SOURCE_FACTS")
    enable_content_packs: bool = Field(default=True, alias="ENABLE_CONTENT_PACKS")
    enable_campaign_freshness: bool = Field(default=True, alias="ENABLE_CAMPAIGN_FRESHNESS")
    enable_strategy_modes: bool = Field(default=True, alias="ENABLE_STRATEGY_MODES")
    enable_performance_memory: bool = Field(default=True, alias="ENABLE_PERFORMANCE_MEMORY")
    enable_experiments: bool = Field(default=True, alias="ENABLE_EXPERIMENTS")
    enable_regional_languages: bool = Field(default=True, alias="ENABLE_REGIONAL_LANGUAGES")
    enable_competitor_gaps: bool = Field(default=True, alias="ENABLE_COMPETITOR_GAPS")
    enable_collaboration: bool = Field(default=True, alias="ENABLE_COLLABORATION")

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def is_development(self) -> bool:
        return self.app_env == "development"

    @classmethod
    def _parse_list(cls, value: str) -> list[str]:
        if isinstance(value, str):
            try:
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    return parsed
            except (json.JSONDecodeError, TypeError):
                return [origin.strip() for origin in value.split(",") if origin.strip()]
        return value

    @classmethod
    def _parse_cors_origins(cls, value: str) -> list[str]:
        return cls._parse_list(value)

    @classmethod
    def _parse_frontend_origins(cls, value: str) -> list[str]:
        return cls._parse_list(value)


settings = Settings()
