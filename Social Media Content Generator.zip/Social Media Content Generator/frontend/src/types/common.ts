export type ToneId = 'professional' | 'funny' | 'luxury' | 'genz' | 'motivational' | 'casual' | 'bold'

export type CampaignGoal =
  | 'brand_awareness'
  | 'engagement'
  | 'sales'
  | 'education'
  | 'lead_generation'
  | 'community_building'

export interface BrandFormData {
  brandName: string
  brandDescription: string
  niche: string
  targetAudience: string
  campaignGoal: string
  brandId?: number | null
}

export type AsyncState<T> =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; data: T }
  | { status: 'error'; error: string }

export interface ToneResponse {
  tones: string[]
}

export type PlatformGradient =
  | 'from-pink-500 to-purple-600'
  | 'from-blue-600 to-blue-800'
  | 'from-black to-gray-800'
  | 'from-blue-500 to-blue-700'
  | 'from-gray-900 to-black'

export interface UserData {
  id: number
  email: string
  name: string
  brand_name: string | null
  niche: string | null
  bio: string | null
  avatar_url: string | null
  job_title?: string | null
  location?: string | null
  personal_website?: string | null
  theme_preference?: string
}

export interface BrandProfile {
  id: number
  name: string
  description: string | null
  niche: string | null
  target_audience: string | null
  website: string | null
  social_links: Record<string, string> | null
  logo_url?: string | null
  campaign_count?: number | null
}

export interface CampaignPost {
  id: number
  day: number
  content_theme: string
  post_idea: string
  content_type: string
  suggested_time: string
  platform: string
  caption: string
  call_to_action: string | null
  hashtags: string[] | null
  status: string
  scheduled_date: string | null
  tone_override?: string | null
}

export type RefinementAction =
  | 'regenerate_caption'
  | 'shorten_caption'
  | 'make_professional'
  | 'make_funnier'
  | 'change_tone'
  | 'improve_hook'
  | 'rewrite_cta'
  | 'regenerate_hashtags'
  | 'regenerate_complete_post'
  | 'custom'

export type SupportedTone =
  | 'professional'
  | 'funny'
  | 'luxury'
  | 'genz'
  | 'motivational'
  | 'casual'
  | 'bold'

export interface RefinementRequest {
  action: RefinementAction
  target_tone?: SupportedTone | null
  custom_instruction?: string | null
}

export interface RefinedPostData {
  id: number
  campaign_id: number
  day_number: number
  hook: string
  caption: string
  call_to_action: string | null
  hashtags: string[]
  content_theme: string
  post_idea: string
  content_type: string
  suggested_time: string | null
  tone: string | null
  updated_at: string
}

export interface RefinementResponse {
  post: RefinedPostData
  refinement: {
    action: string
    generation_source: string
    fallback_used: boolean
    warnings: string[]
  }
}

export interface BrandCheckBlock {
  status: 'blocked'
  message: string
  violations: Array<{ type: string; text: string }>
}

export interface PostRevision {
  id: number
  campaign_post_id: number
  revision_number: number
  action: string
  previous_caption: string
  previous_call_to_action: string | null
  previous_hashtags: string[]
  previous_tone: string | null
  generation_source: string
  created_at: string
}

export interface CampaignData {
  id: number
  name: string
  platform: string
  tone: string
  campaign_goal: string
  status: string
  brand_profile_id: number | null
  posts: CampaignPost[] | null
  created_at: string
  updated_at: string
}
