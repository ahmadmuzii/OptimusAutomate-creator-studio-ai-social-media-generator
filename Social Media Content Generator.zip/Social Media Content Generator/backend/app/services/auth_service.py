from __future__ import annotations

import datetime
import secrets
from datetime import timezone

from jose import ExpiredSignatureError, JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.config import settings
from app.models.db_models import User

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

RESET_TOKEN_EXPIRE_HOURS = 1
RESET_TOKEN_BYTES = 32


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


def _utcnow() -> datetime.datetime:
    return datetime.datetime.now(timezone.utc)


def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = _utcnow() + datetime.timedelta(minutes=settings.access_token_expire_minutes)
    to_encode.update({"exp": expire, "token_type": "access"})
    return jwt.encode(to_encode, settings.secret_key, algorithm=settings.jwt_algorithm)


def create_refresh_token(data: dict) -> str:
    to_encode = data.copy()
    expire = _utcnow() + datetime.timedelta(days=settings.refresh_token_expire_days)
    to_encode.update({"exp": expire, "token_type": "refresh"})
    return jwt.encode(to_encode, settings.secret_key, algorithm=settings.jwt_algorithm)


def decode_token(token: str, expected_type: str | None = None) -> dict | None:
    try:
        payload = jwt.decode(
            token,
            settings.secret_key,
            algorithms=[settings.jwt_algorithm],
            options={"require_exp": True},
        )
        if expected_type and payload.get("token_type") != expected_type:
            return None
        sub = payload.get("sub")
        if sub is None:
            return None
        try:
            int(sub)
        except (ValueError, TypeError):
            return None
        return payload
    except ExpiredSignatureError:
        return None
    except JWTError:
        return None


def decode_access_token(token: str) -> dict | None:
    return decode_token(token, expected_type="access")


def decode_refresh_token(token: str) -> dict | None:
    return decode_token(token, expected_type="refresh")


def get_user_by_email(db: Session, email: str) -> User | None:
    return db.query(User).filter(User.email == email).first()


def get_user_by_id(db: Session, user_id: int) -> User | None:
    return db.query(User).filter(User.id == user_id).first()


def create_user(db: Session, email: str, password: str, name: str) -> User:
    user = User(email=email, password_hash=hash_password(password), name=name)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def generate_reset_token() -> str:
    return secrets.token_urlsafe(RESET_TOKEN_BYTES)


def hash_reset_token(token: str) -> str:
    return pwd_context.hash(token)


def verify_reset_token(token: str, hashed: str) -> bool:
    return pwd_context.verify(token, hashed)
