import { BrowserRouter } from 'react-router-dom'
import { AppRoutes } from '@/routes'
import { AuthProvider } from '@/context/AuthContext'
import { GuestModeProvider } from '@/context/GuestModeContext'
import { ThemeProvider } from '@/context/ThemeContext'
import { ErrorBoundary } from '@/components/common/ErrorBoundary'
import { ToastProvider } from '@/components/ui/Toast'

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AuthProvider>
          <GuestModeProvider>
            <ThemeProvider>
              <ToastProvider>
                <AppRoutes />
              </ToastProvider>
            </ThemeProvider>
          </GuestModeProvider>
        </AuthProvider>
      </BrowserRouter>
    </ErrorBoundary>
  )
}
