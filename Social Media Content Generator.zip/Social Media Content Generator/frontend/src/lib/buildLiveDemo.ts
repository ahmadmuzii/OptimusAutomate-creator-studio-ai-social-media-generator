import type { LiveDemoCampaign, LiveDemoDay, LiveDemoCaption, PlatformKey, ToneKey } from '@/data/liveDemoBaseData'
import { BASE_DAYS } from '@/data/liveDemoBaseData'
import { getPlatformRule, getPlatformIdea } from '@/data/liveDemoPlatformRules'
import { getToneRule } from '@/data/liveDemoToneRules'

interface BuildLiveDemoInput {
  platform: PlatformKey
  tone: ToneKey
}

export function buildLiveDemo(input: BuildLiveDemoInput): LiveDemoCampaign {
  const { platform, tone } = input
  const platformRule = getPlatformRule(platform)
  const toneRule = getToneRule(tone)

  const days: LiveDemoDay[] = BASE_DAYS.map((base) => ({
    day: base.day,
    theme: base.theme,
    idea: getPlatformIdea(platform, base.day),
    contentType: platformRule.getContentType(base.day),
    postingTime: platformRule.getPostingTime(base.day),
  }))

  const rawCaptions: LiveDemoCaption[] = [1, 5].map((day) => {
    const raw = platformRule.buildCaption({
      day,
      toneModifier: toneRule.modifier,
    })
    return raw
  })

  const featuredCaptions: LiveDemoCaption[] = rawCaptions.map((c) => ({
    day: c.day,
    caption: toneRule.modifyCaption(c.caption),
    cta: toneRule.modifyCTA(c.cta),
  }))

  let hashtags = platformRule.getHashtags()
  hashtags = toneRule.modifyHashtags(hashtags)
  hashtags = hashtags.slice(0, 10)

  return {
    platform,
    tone,
    days,
    featuredCaptions,
    hashtags,
  }
}
