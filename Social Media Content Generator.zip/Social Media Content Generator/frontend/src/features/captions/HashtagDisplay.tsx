interface HashtagDisplayProps {
  hashtags: string[]
}

export function HashtagDisplay({ hashtags }: HashtagDisplayProps) {
  if (!hashtags?.length) return null

  return (
    <div className="flex flex-wrap gap-1.5">
      {hashtags.map((tag, i) => (
        <span
          key={i}
          className="px-2.5 py-1 rounded-md bg-gray-100 text-gray-600 text-xs font-medium"
        >
          {tag}
        </span>
      ))}
    </div>
  )
}
