"""
Create a clean distributable copy of the repository for deployment.

Usage:
    python scripts/create_clean_release.py [--output-dir ../release]

This copies the repository to a clean output directory, stripping:
  - .env files (templates/sample files are kept)
  - node_modules, __pycache__, .pytest_cache, .ruff_cache, .mypy_cache
  - *.db database files (except schema-only dumps if any)
  - uploads/ content (directory structure is preserved via .gitkeep)
  - IDE config (.vscode, .idea)
  - .git directory and .gitignore (the copy is not a git repo)
  - backup/ files
  - test files and temp scripts
"""

from __future__ import annotations

import argparse
import os
import shutil
from pathlib import Path

EXCLUDED_DIRS = frozenset({
    ".git",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    ".mypy_cache",
    ".vscode",
    ".idea",
    "backups",
    "uploads",
    ".venv",
    "venv",
    "env",
})

EXCLUDED_FILE_PATTERNS = frozenset({
    ".env",
    ".env.local",
    ".env.development",
    ".env.example",
})

EXCLUDED_EXTENSIONS = frozenset({
    ".pyc",
    ".pyo",
    ".db",
    ".sqlite3",
    ".log",
})


def _should_exclude(name: str, path: Path) -> bool:
    if name in EXCLUDED_DIRS:
        return True
    if any(name.startswith(pat) for pat in EXCLUDED_FILE_PATTERNS):
        return True
    if path.suffix.lower() in EXCLUDED_EXTENSIONS:
        return True
    return False


def create_release(source_dir: Path, output_dir: Path, verbose: bool = False) -> None:
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    copied = 0
    skipped = 0

    for root_str, dirs, files in os.walk(str(source_dir), topdown=True):
        root = Path(root_str)
        rel = root.relative_to(source_dir)

        # Prune excluded directories
        dirs[:] = [d for d in dirs if not _should_exclude(d, root / d)]

        # Create corresponding directory in output
        dest_dir = output_dir / rel
        dest_dir.mkdir(parents=True, exist_ok=True)

        for fname in files:
            src_path = root / fname
            if _should_exclude(fname, src_path):
                skipped += 1
                if verbose:
                    print(f"  [SKIP] {rel / fname}")
                continue

            shutil.copy2(str(src_path), str(dest_dir / fname))
            copied += 1

    print(f"\nRelease created at: {output_dir}")
    print(f"  Files copied: {copied}")
    print(f"  Files skipped: {skipped}")
    print(f"  Size: {_dir_size(output_dir) / 1024:.1f} KB")


def _dir_size(path: Path) -> int:
    total = 0
    for f in path.rglob("*"):
        if f.is_file():
            total += f.stat().st_size
    return total


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a clean distributable release copy.")
    parser.add_argument(
        "--output-dir",
        default="../release",
        help="Output directory for the clean release (default: ../release)",
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Show skipped files")
    args = parser.parse_args()

    source_dir = Path(__file__).resolve().parent.parent
    output_dir = Path(args.output_dir).resolve()

    print(f"Source: {source_dir}")
    print(f"Output: {output_dir}")
    create_release(source_dir, output_dir, verbose=args.verbose)


if __name__ == "__main__":
    main()
