import { useState, useCallback } from 'react'
import type {
  RefinementAction,
  SupportedTone,
  RefinementResponse,
  BrandCheckBlock,
  CampaignPost,
  PostRevision,
} from '@/types/common'
import { refinePost as apiRefinePost, undoPostRefinement, fetchPostRevisions } from '@/api/endpoints'

interface RefinementState {
  refining: boolean
  refiningPostId: number | null
  error: string | null
  blocked: BrandCheckBlock | null
  lastResult: RefinementResponse | null
}

export function useRefineCampaignPost(campaignId: number) {
  const [state, setState] = useState<RefinementState>({
    refining: false,
    refiningPostId: null,
    error: null,
    blocked: null,
    lastResult: null,
  })

  const refine = useCallback(
    async (
      post: CampaignPost,
      action: RefinementAction,
      targetTone?: SupportedTone | null,
      customInstruction?: string | null,
    ): Promise<CampaignPost | null> => {
      setState({
        refining: true,
        refiningPostId: post.id,
        error: null,
        blocked: null,
        lastResult: null,
      })

      try {
        const result = await apiRefinePost(campaignId, post.id, {
          action,
          target_tone: targetTone ?? null,
          custom_instruction: customInstruction ?? null,
        })

        if ((result as unknown as BrandCheckBlock).status === 'blocked') {
          const block = result as unknown as BrandCheckBlock
          setState({
            refining: false,
            refiningPostId: null,
            error: null,
            blocked: block,
            lastResult: null,
          })
          return null
        }

        const refined = result as RefinementResponse
        setState({
          refining: false,
          refiningPostId: null,
          error: null,
          blocked: null,
          lastResult: refined,
        })

        return {
          ...post,
          caption: refined.post.caption,
          call_to_action: refined.post.call_to_action,
          hashtags: refined.post.hashtags,
          content_theme: refined.post.content_theme,
          post_idea: refined.post.post_idea,
          content_type: refined.post.content_type,
          suggested_time: refined.post.suggested_time ?? post.suggested_time,
          tone_override: refined.post.tone,
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Refinement failed'
        setState({
          refining: false,
          refiningPostId: null,
          error: message,
          blocked: null,
          lastResult: null,
        })
        return null
      }
    },
    [campaignId],
  )

  const undo = useCallback(
    async (postId: number): Promise<CampaignPost | null> => {
      setState((prev) => ({
        ...prev,
        refining: true,
        refiningPostId: postId,
        error: null,
        blocked: null,
      }))

      try {
        const result = await undoPostRefinement(campaignId, postId)
        const restored = result.post as CampaignPost
        setState({
          refining: false,
          refiningPostId: null,
          error: null,
          blocked: null,
          lastResult: null,
        })
        return restored
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Undo failed'
        setState({
          refining: false,
          refiningPostId: null,
          error: message,
          blocked: null,
          lastResult: null,
        })
        return null
      }
    },
    [campaignId],
  )

  const fetchRevisions = useCallback(
    async (postId: number): Promise<PostRevision[]> => {
      try {
        return await fetchPostRevisions(campaignId, postId)
      } catch {
        return []
      }
    },
    [campaignId],
  )

  const clearError = useCallback(() => {
    setState((prev) => ({ ...prev, error: null, blocked: null }))
  }, [])

  return {
    ...state,
    refine,
    undo,
    fetchRevisions,
    clearError,
  }
}
