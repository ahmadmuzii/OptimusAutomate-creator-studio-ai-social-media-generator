import type { ToneKey } from './liveDemoBaseData'

export interface ToneRule {
  label: string
  modifier: string
  professional?: string
  funny?: string
  luxury?: string
  genz?: string
  getName: () => string
  modifyCaption: (caption: string) => string
  modifyCTA: (cta: string) => string
  modifyHashtags: (hashtags: string[]) => string[]
}

const TONE_RULES: Record<ToneKey, ToneRule> = {
  professional: {
    label: 'Professional',
    modifier: '',
    getName: () => 'Professional',
    modifyCaption: (c) => c,
    modifyCTA: (cta) => cta,
    modifyHashtags: (tags) => tags,
  },
  funny: {
    label: 'Funny',
    modifier: ' Also, it pairs surprisingly well with procrastination.',
    getName: () => 'Funny',
    modifyCaption: (c) => {
      const additions = [
        ' We promise this is not an ad. Mostly.',
        ' Science may or may not agree, but our taste buds definitely do.',
        ' No baristas were harmed in the making of this post.',
        ' Results may include uncontrollable smiling.',
        ' Warning: may cause spontaneous coffee cravings.',
      ]
      const idx = c.length % additions.length
      const add = additions[idx]
      if (c.endsWith('.') || c.endsWith('!') || c.endsWith('?')) {
        return c.slice(0, -1) + add
      }
      return c + add
    },
    modifyCTA: (cta) => {
      const funnyCTAs: Record<string, string> = {
        'Visit us downtown and taste the difference.': 'Come see us and pretend you are in a coffee commercial.',
        'Save this for your morning routine.': 'Save this and pretend you are a professional barista.',
        'Tag your coffee buddy in the comments.': 'Tag the friend who still owes you a coffee.',
        'Come see the roastery in action.': 'Watch beans become magic. We will not charge extra for the show.',
        'Grab a bag before it is gone.': 'Buy now before your inner coffee snob takes over.',
        'Drop your question below.': 'Ask us anything. We reserve the right to be hilarious.',
        'Link in bio to start your subscription.': 'Click the link and join the caffeine cult. Kidding. Mostly.',
      }
      return funnyCTAs[cta] ?? cta + ' (No seriously, do it.)'
    },
    modifyHashtags: (tags) => [...tags, '#CoffeeHumor', '#NoFilter'],
  },
  luxury: {
    label: 'Luxury',
    modifier: ' Every sip is an experience worth savoring.',
    getName: () => 'Luxury',
    modifyCaption: (c) => {
      const words = c.split(' ')
      const luxReplacements: Record<string, string> = {
        good: 'exceptional',
        great: 'extraordinary',
        nice: 'refined',
        best: 'finest',
        new: 'exclusive',
        special: 'distinguished',
        perfect: 'impeccable',
        amazing: 'breathtaking',
        love: 'cherish',
        delicious: 'exquisite',
        tasty: 'sublime',
        simple: 'effortless',
        clean: 'pristine',
        fresh: 'pristine',
      }
      return words.map((w) => luxReplacements[w.toLowerCase()] ?? w).join(' ')
    },
    modifyCTA: (cta) => {
      const luxuryCTAs: Record<string, string> = {
        'Visit us downtown and taste the difference.': 'Experience refinement at our downtown location.',
        'Save this for your morning routine.': 'Preserve this for your morning ritual.',
        'Tag your coffee buddy in the comments.': 'Share this with someone who appreciates the finer things.',
        'Come see the roastery in action.': 'Witness craftsmanship firsthand.',
        'Grab a bag before it is gone.': 'Acquire this limited offering while it remains.',
        'Drop your question below.': 'We welcome your thoughtful inquiries.',
        'Link in bio to start your subscription.': 'Begin your subscription through the link in our profile.',
      }
      return luxuryCTAs[cta] ?? cta
    },
    modifyHashtags: (tags) => {
      const luxTags = ['#ArtOfCoffee', '#SlowLuxury', '#PremiumExperience', '#RefinedPalate']
      return [...tags.filter((t) => !t.includes('Humor')), ...luxTags].slice(0, 8)
    },
  },
  genz: {
    label: 'Gen Z',
    modifier: ' It is honestly kind of life-changing.',
    getName: () => 'Gen Z',
    modifyCaption: (c) => {
      const words = c.split(' ')
      const finalWord = words[words.length - 1] ?? ''
      const punctuation = finalWord.endsWith('.') || finalWord.endsWith('!') || finalWord.endsWith('?')
        ? finalWord.slice(-1)
        : ''
      const base = punctuation ? words.slice(0, -1).join(' ') + ' ' + finalWord.slice(0, -1) : c
      const additions = [
        ' Honestly, it hits different.',
        ' No cap, this is the real deal.',
        ' The vibe is immaculate.',
        ' It is giving main character energy.',
        ' We are obsessed and you will be too.',
      ]
      const idx = c.length % additions.length
      const add = additions[idx]
      return base + ' ' + add
    },
    modifyCTA: (cta) => {
      const genZCTAs: Record<string, string> = {
        'Visit us downtown and taste the difference.': 'Come through downtown and see what the hype is about.',
        'Save this for your morning routine.': 'Save this for later, bestie.',
        'Tag your coffee buddy in the comments.': 'Tag the friend who always steals your coffee.',
        'Come see the roastery in action.': 'Pull up and see how the magic happens.',
        'Grab a bag before it is gone.': 'Snag one before they sell out (no pressure).',
        'Drop your question below.': 'Drop your Q in the comments, we got you.',
        'Link in bio to start your subscription.': 'Link in bio to never run out of good coffee again.',
      }
      return genZCTAs[cta] ?? cta
    },
    modifyHashtags: (tags) => [...tags, '#MainCharacter', '#CoffeeTok', '#Vibes'],
  },
}

export function getToneRule(tone: ToneKey): ToneRule {
  return TONE_RULES[tone]
}
