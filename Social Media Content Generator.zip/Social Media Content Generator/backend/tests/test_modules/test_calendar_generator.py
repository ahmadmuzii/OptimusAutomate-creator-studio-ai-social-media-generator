from __future__ import annotations

from typing import Any
from unittest.mock import patch

from app.modules.calendar_generator import (
    FALLBACK_THEMES,
    _build_fallback_calendar,
    _validate_ai_response,
    generate_calendar,
)


def _valid_ai_response(days: int = 7) -> dict[str, Any]:
    return {
        "calendar": [
            {
                "day": d,
                "contentTheme": f"Theme {d}",
                "postIdea": f"Idea {d}",
                "contentType": "carousel",
                "suggestedTime": "9:00 AM",
                "platform": "instagram",
                "caption": f"Caption {d}",
                "callToAction": "Follow us",
                "hashtags": ["#tag"],
            }
            for d in range(1, days + 1)
        ]
    }


class TestFallbackCalendar:
    def test_returns_7_days_by_default(self) -> None:
        result = _build_fallback_calendar(
            brand_name="TestBrand",
            brand_description="A test brand",
            niche="tech",
            target_audience="devs",
            platform="instagram",
            tone="professional",
            campaign_goal="brand_awareness",
        )
        assert len(result) == 7

    def test_returns_variable_days(self) -> None:
        result = _build_fallback_calendar(
            brand_name="TestBrand",
            brand_description="A test brand",
            niche="tech",
            target_audience="devs",
            platform="instagram",
            tone="professional",
            campaign_goal="brand_awareness",
            days=3,
        )
        assert len(result) == 3
        for i, day in enumerate(result, start=1):
            assert day["day"] == i

    def test_cycles_themes_for_more_than_7_days(self) -> None:
        result = _build_fallback_calendar(
            brand_name="TestBrand",
            brand_description="A test brand",
            niche="tech",
            target_audience="devs",
            platform="instagram",
            tone="professional",
            campaign_goal="brand_awareness",
            days=10,
        )
        assert len(result) == 10
        assert result[0]["contentTheme"] == FALLBACK_THEMES[0]
        assert result[7]["contentTheme"] == FALLBACK_THEMES[0]

    def test_each_day_has_required_fields(self) -> None:
        required = {
            "day",
            "contentTheme",
            "postIdea",
            "contentType",
            "suggestedTime",
            "platform",
            "caption",
            "callToAction",
            "hashtags",
        }
        result = _build_fallback_calendar(
            brand_name="TestBrand",
            brand_description="A test brand",
            niche="tech",
            target_audience="devs",
            platform="linkedin",
            tone="professional",
            campaign_goal="brand_awareness",
        )
        for day in result:
            assert required.issubset(day.keys())
            assert isinstance(day["hashtags"], list)

    def test_different_platforms(self) -> None:
        for platform in ["instagram", "linkedin", "tiktok", "facebook", "x"]:
            result = _build_fallback_calendar(
                brand_name="TestBrand",
                brand_description="Test",
                niche="tech",
                target_audience="devs",
                platform=platform,
                tone="casual",
                campaign_goal="engagement",
            )
            assert len(result) == 7
            assert all(d["platform"] == platform for d in result)


class TestValidateAiResponse:
    def test_returns_calendar_for_valid_response(self) -> None:
        data = _valid_ai_response(7)
        result = _validate_ai_response(data, days=7)
        assert result is not None
        assert len(result) == 7

    def test_returns_none_for_non_dict(self) -> None:
        assert _validate_ai_response("not a dict") is None

    def test_returns_none_for_missing_calendar_key(self) -> None:
        assert _validate_ai_response({"foo": "bar"}) is None

    def test_returns_none_for_wrong_day_count(self) -> None:
        data = _valid_ai_response(3)
        result = _validate_ai_response(data, days=7)
        assert result is None

    def test_returns_none_for_missing_fields(self) -> None:
        data = {"calendar": [{"day": 1}]}
        result = _validate_ai_response(data)
        assert result is None

    def test_returns_none_for_empty_caption(self) -> None:
        data = _valid_ai_response(7)
        data["calendar"][0]["caption"] = ""
        result = _validate_ai_response(data)
        assert result is None

    def test_returns_none_for_non_list_hashtags(self) -> None:
        data = _valid_ai_response(7)
        data["calendar"][0]["hashtags"] = "not a list"
        result = _validate_ai_response(data)
        assert result is None


class TestGenerateCalendar:
    def test_returns_fallback_source_when_ai_fails(self) -> None:
        with patch("app.modules.calendar_generator.call_groq", return_value=None):
            calendar, source = generate_calendar(
                brand_name="TestBrand",
                brand_description="A test brand",
                niche="tech",
                target_audience="devs",
                platform="instagram",
                tone="professional",
                campaign_goal="brand_awareness",
            )
            assert source == "fallback"
            assert len(calendar) == 7

    def test_returns_groq_source_when_ai_succeeds(self) -> None:
        with patch(
            "app.modules.calendar_generator.call_groq",
            return_value=_valid_ai_response(7),
        ):
            calendar, source = generate_calendar(
                brand_name="TestBrand",
                brand_description="A test brand",
                niche="tech",
                target_audience="devs",
                platform="instagram",
                tone="professional",
                campaign_goal="brand_awareness",
                days=7,
            )
            assert source == "groq"
            assert len(calendar) == 7

    def test_returns_fallback_when_ai_returns_invalid_data(self) -> None:
        with patch(
            "app.modules.calendar_generator.call_groq",
            return_value={"calendar": [{"day": 1}]},
        ):
            calendar, source = generate_calendar(
                brand_name="TestBrand",
                brand_description="A test brand",
                niche="tech",
                target_audience="devs",
                platform="instagram",
                tone="professional",
                campaign_goal="brand_awareness",
            )
            assert source == "fallback"
            assert len(calendar) == 7

    def test_returns_correct_day_count_with_3_days(self) -> None:
        with patch("app.modules.calendar_generator.call_groq", return_value=None):
            calendar, source = generate_calendar(
                brand_name="TestBrand",
                brand_description="A test brand",
                niche="tech",
                target_audience="devs",
                platform="instagram",
                tone="professional",
                campaign_goal="brand_awareness",
                days=3,
            )
            assert len(calendar) == 3
            assert source == "fallback"
