export function Footer() {
  return (
    <footer className="border-t border-gray-100 bg-white py-6">
      <div className="max-w-6xl mx-auto px-4 text-center text-sm text-gray-400">
        Social Media Content Generator &mdash; Plan smarter, post better.
      </div>
    </footer>
  )
}
