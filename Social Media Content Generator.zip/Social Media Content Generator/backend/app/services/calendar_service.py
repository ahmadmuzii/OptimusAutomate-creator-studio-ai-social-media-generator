from __future__ import annotations

from typing import Any

from structlog.stdlib import BoundLogger

from app.exceptions import CalendarGenerationError
from app.modules.calendar_generator import generate_calendar as _generate_calendar


class CalendarService:
    def __init__(self, logger: BoundLogger | None = None) -> None:
        self._logger = logger

    def generate_calendar(
        self,
        brand_name: str,
        brand_description: str,
        niche: str,
        target_audience: str,
        platform: str,
        tone: str,
        campaign_goal: str,
        days: int = 7,
    ) -> dict[str, Any]:
        try:
            calendar, source = _generate_calendar(
                brand_name=brand_name,
                brand_description=brand_description,
                niche=niche,
                target_audience=target_audience,
                platform=platform,
                tone=tone,
                campaign_goal=campaign_goal,
                days=days,
            )
            if self._logger:
                self._logger.info(
                    "calendar_generated",
                    platform=platform,
                    tone=tone,
                    days=len(calendar),
                    generation_source=source,
                )
            return {"calendar": calendar, "generation_source": source}
        except ValueError as e:
            raise CalendarGenerationError(str(e))
