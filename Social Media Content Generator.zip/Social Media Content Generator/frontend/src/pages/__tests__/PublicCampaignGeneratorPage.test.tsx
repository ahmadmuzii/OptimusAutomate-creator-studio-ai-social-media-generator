import { render, screen } from '@testing-library/react'
import { BrowserRouter } from 'react-router-dom'
import { describe, it, expect, vi } from 'vitest'
import { PublicCampaignGeneratorPage } from '@/pages/PublicCampaignGeneratorPage'

vi.mock('@/context/AuthContext', () => ({
  useAuth: () => ({
    isAuthenticated: false,
    user: null,
    isLoading: false,
  }),
}))

function renderPage() {
  return render(
    <BrowserRouter>
      <PublicCampaignGeneratorPage />
    </BrowserRouter>,
  )
}

describe('PublicCampaignGeneratorPage', () => {
  it('renders without crashing', () => {
    renderPage()
    expect(document.body).toBeDefined()
  })

  it('renders the demo heading', () => {
    renderPage()
    expect(screen.getByText('Try the Campaign Generator')).toBeDefined()
  })

  it('renders brand name input', () => {
    renderPage()
    expect(screen.getByLabelText('Brand Name')).toBeDefined()
  })

  it('renders niche selector', () => {
    renderPage()
    expect(screen.getByLabelText('Niche')).toBeDefined()
  })

  it('renders campaign goal selector', () => {
    renderPage()
    expect(screen.getByLabelText('Campaign Goal')).toBeDefined()
  })

  it('renders sign in links', () => {
    renderPage()
    expect(screen.getByText('Sign In')).toBeDefined()
  })

  it('renders create free account link', () => {
    renderPage()
    expect(screen.getByText('Create Free Account')).toBeDefined()
  })

  it('renders quick fill demo brand buttons', () => {
    renderPage()
    expect(screen.getByText('Brew & Bean')).toBeDefined()
    expect(screen.getByText('Flowboard')).toBeDefined()
  })
})
