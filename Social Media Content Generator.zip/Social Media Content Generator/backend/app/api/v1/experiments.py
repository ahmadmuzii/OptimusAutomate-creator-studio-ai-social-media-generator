from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.api.deps_features import require_feature
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.db_models import (
    BrandProfile,
    CampaignExperiment,
    ExperimentVariant,
    User,
)
from app.models.experiment_schemas import (
    DeclareWinnerRequest,
    ExperimentCreate,
    ExperimentResponse,
    ExperimentUpdate,
    ExperimentVariantCreate,
    ExperimentVariantResponse,
    ExperimentVariantResultUpdate,
)

router = APIRouter(
    prefix="/brands/{brand_id}/experiments",
    tags=["Experiments"],
    dependencies=[require_feature("experiments")],
)


def _get_brand_or_404(db: Session, brand_id: int, user_id: int) -> BrandProfile:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != user_id:
        raise NotFoundError("Brand not found")
    return brand


def _variant_to_response(v: ExperimentVariant) -> ExperimentVariantResponse:
    return ExperimentVariantResponse(
        id=v.id,
        label=v.label,
        variable_value=v.variable_value,
        content_value=v.content_value,
        status=v.status,
        impressions=v.impressions,
        clicks=v.clicks,
        engagement=v.engagement,
        conversions=v.conversions,
        is_winner=v.is_winner,
    )


def _experiment_to_response(e: CampaignExperiment) -> ExperimentResponse:
    return ExperimentResponse(
        id=e.id,
        brand_id=e.brand_id,
        campaign_id=e.campaign_id,
        name=e.name,
        variable_tested=e.variable_tested,
        success_metric=e.success_metric,
        status=e.status,
        variants=[_variant_to_response(v) for v in e.variants] if e.variants else [],
        created_at=e.created_at,
    )


@router.get("", response_model=list[ExperimentResponse])
def list_experiments(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    experiments = (
        db.query(CampaignExperiment)
        .filter(CampaignExperiment.brand_id == brand_id)
        .order_by(CampaignExperiment.created_at.desc())
        .all()
    )
    return [_experiment_to_response(e) for e in experiments]


@router.post("", response_model=ExperimentResponse)
def create_experiment(
    brand_id: int,
    request: ExperimentCreate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)

    experiment = CampaignExperiment(
        brand_id=brand_id,
        campaign_id=request.campaign_id,
        name=request.name,
        variable_tested=request.variable_tested,
        success_metric=request.success_metric,
        status="draft",
    )
    db.add(experiment)
    db.flush()

    for v in request.variants:
        variant = ExperimentVariant(
            experiment_id=experiment.id,
            label=v.label,
            variable_value=v.variable_value,
            content_value=v.content_value,
            status="draft",
        )
        db.add(variant)

    db.commit()
    db.refresh(experiment)
    return _experiment_to_response(experiment)


@router.get("/{exp_id}", response_model=ExperimentResponse)
def get_experiment(
    brand_id: int,
    exp_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    experiment = (
        db.query(CampaignExperiment)
        .filter(CampaignExperiment.id == exp_id, CampaignExperiment.brand_id == brand_id)
        .first()
    )
    if not experiment:
        raise NotFoundError("Experiment not found")
    return _experiment_to_response(experiment)


@router.put("/{exp_id}", response_model=ExperimentResponse)
def update_experiment(
    brand_id: int,
    exp_id: int,
    request: ExperimentUpdate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    experiment = (
        db.query(CampaignExperiment)
        .filter(CampaignExperiment.id == exp_id, CampaignExperiment.brand_id == brand_id)
        .first()
    )
    if not experiment:
        raise NotFoundError("Experiment not found")

    update_data = request.model_dump(exclude_none=True)
    for key, value in update_data.items():
        setattr(experiment, key, value)
    db.commit()
    db.refresh(experiment)
    return _experiment_to_response(experiment)


@router.delete("/{exp_id}")
def delete_experiment(
    brand_id: int,
    exp_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    experiment = (
        db.query(CampaignExperiment)
        .filter(CampaignExperiment.id == exp_id, CampaignExperiment.brand_id == brand_id)
        .first()
    )
    if not experiment:
        raise NotFoundError("Experiment not found")
    db.delete(experiment)
    db.commit()
    return {"detail": "Experiment deleted"}


@router.post("/{exp_id}/variants", response_model=ExperimentVariantResponse)
def add_variant(
    brand_id: int,
    exp_id: int,
    request: ExperimentVariantCreate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    experiment = (
        db.query(CampaignExperiment)
        .filter(CampaignExperiment.id == exp_id, CampaignExperiment.brand_id == brand_id)
        .first()
    )
    if not experiment:
        raise NotFoundError("Experiment not found")

    variant = ExperimentVariant(
        experiment_id=experiment.id,
        label=request.label,
        variable_value=request.variable_value,
        content_value=request.content_value,
        status="draft",
    )
    db.add(variant)
    db.commit()
    db.refresh(variant)
    return _variant_to_response(variant)


@router.patch("/variants/{variant_id}", response_model=ExperimentVariantResponse)
def update_variant_results(
    brand_id: int,
    variant_id: int,
    request: ExperimentVariantResultUpdate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    variant = (
        db.query(ExperimentVariant)
        .join(CampaignExperiment)
        .filter(
            ExperimentVariant.id == variant_id,
            CampaignExperiment.brand_id == brand_id,
        )
        .first()
    )
    if not variant:
        raise NotFoundError("Variant not found")

    update_data = request.model_dump(exclude_none=True)
    for key, value in update_data.items():
        setattr(variant, key, value)
    db.commit()
    db.refresh(variant)
    return _variant_to_response(variant)


@router.post("/{exp_id}/declare-winner", response_model=ExperimentResponse)
def declare_winner(
    brand_id: int,
    exp_id: int,
    payload: DeclareWinnerRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    experiment = (
        db.query(CampaignExperiment)
        .filter(CampaignExperiment.id == exp_id, CampaignExperiment.brand_id == brand_id)
        .first()
    )
    if not experiment:
        raise NotFoundError("Experiment not found")

    winner = (
        db.query(ExperimentVariant)
        .filter(ExperimentVariant.id == payload.variant_id, ExperimentVariant.experiment_id == exp_id)
        .first()
    )
    if not winner:
        raise NotFoundError("Variant not found in this experiment")

    db.query(ExperimentVariant).filter(ExperimentVariant.experiment_id == exp_id).update({"is_winner": False})

    winner.is_winner = True
    experiment.status = "completed"
    db.commit()
    db.refresh(experiment)
    return _experiment_to_response(experiment)
