import { useState, useCallback } from 'react'

interface UseClipboardReturn {
  copiedId: number | string | null
  copy: (text: string, id: number | string) => Promise<void>
}

export function useClipboard(resetMs = 2000): UseClipboardReturn {
  const [copiedId, setCopiedId] = useState<number | string | null>(null)

  const copy = useCallback(async (text: string, id: number | string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedId(id)
      setTimeout(() => setCopiedId(null), resetMs)
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }, [resetMs])

  return { copiedId, copy }
}
