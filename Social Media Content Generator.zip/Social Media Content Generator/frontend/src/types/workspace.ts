export interface Workspace {
  id: number
  name: string
  owner_id: number
  memberships: WorkspaceMembership[]
  created_at: string
}

export interface WorkspaceCreate {
  name: string
}

export interface WorkspaceUpdate {
  name?: string
}

export interface WorkspaceMembership {
  id: number
  user_id: number
  workspace_id: number
  role: string
  user_email: string | null
  created_at: string
}

export interface AddMemberRequest {
  user_id: number
  role?: string
}

export interface UpdateMemberRoleRequest {
  role: string
}

export interface ApprovalRequest {
  id: number
  campaign_id: number
  requested_by_id: number
  status: string
  decisions: ApprovalDecision[]
  created_at: string
}

export interface ApprovalDecision {
  id: number
  approval_request_id: number
  reviewer_id: number
  decision: string
  comment: string | null
  created_at: string
}

export interface ApprovalDecisionCreate {
  decision: 'approved' | 'rejected'
  comment?: string | null
}

export interface PostVersion {
  id: number
  post_id: number
  version_number: number
  change_reason: string | null
  caption: string | null
  call_to_action: string | null
  hashtags: string[] | null
  created_at: string
}

export interface CampaignComment {
  id: number
  campaign_id: number
  post_id: number | null
  author_id: number
  content: string
  is_resolved: boolean
  parent_id: number | null
  created_at: string
}
