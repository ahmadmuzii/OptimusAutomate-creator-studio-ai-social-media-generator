from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.api.deps_features import require_feature
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.db_models import BrandProfile, BrandRegionalSettings, User

router = APIRouter(
    prefix="/brands/{brand_id}/regional-settings",
    tags=["Regional"],
    dependencies=[require_feature("regional_languages")],
)

DEFAULT_REGIONAL_SETTINGS = {
    "default_language": "en",
    "supported_languages": ["en", "ur", "hi", "ar"],
    "support_roman_urdu": True,
    "support_bilingual_posts": True,
    "support_rtl_layout": True,
}


class RegionalSettingsUpdate(BaseModel):
    default_language: str | None = None
    supported_languages: list[str] | None = None
    support_roman_urdu: bool | None = None
    support_bilingual_posts: bool | None = None
    support_rtl_layout: bool | None = None


class RegionalSettingsResponse(BaseModel):
    default_language: str
    supported_languages: list[str]
    support_roman_urdu: bool
    support_bilingual_posts: bool
    support_rtl_layout: bool

    model_config = ConfigDict(from_attributes=True)


def _get_brand_or_404(db: Session, brand_id: int, user_id: int) -> BrandProfile:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != user_id:
        raise NotFoundError("Brand not found")
    return brand


@router.get("", response_model=RegionalSettingsResponse)
def get_regional_settings(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    settings = db.query(BrandRegionalSettings).filter(BrandRegionalSettings.brand_id == brand_id).first()
    if settings is None:
        return RegionalSettingsResponse(**DEFAULT_REGIONAL_SETTINGS)
    return settings


@router.put("", response_model=RegionalSettingsResponse)
def update_regional_settings(
    brand_id: int,
    settings: RegionalSettingsUpdate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    existing = db.query(BrandRegionalSettings).filter(BrandRegionalSettings.brand_id == brand_id).first()
    if existing:
        update_data = settings.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(existing, field, value)
        db.commit()
        db.refresh(existing)
        return existing
    new_settings = BrandRegionalSettings(
        brand_id=brand_id,
        **settings.model_dump(exclude_unset=True),
    )
    db.add(new_settings)
    db.commit()
    db.refresh(new_settings)
    return new_settings
