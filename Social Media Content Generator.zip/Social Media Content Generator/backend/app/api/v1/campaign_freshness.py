from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.api.deps_features import require_feature
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.db_models import BrandProfile, User
from app.services.campaign_freshness_service import CampaignFreshnessService

router = APIRouter(
    prefix="/brands/{brand_id}/freshness",
    tags=["Campaign Freshness"],
    dependencies=[require_feature("campaign_freshness")],
)


def _get_brand_or_404(db: Session, brand_id: int, user_id: int) -> BrandProfile:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != user_id:
        raise NotFoundError("Brand not found")
    return brand


@router.get("")
def analyze_fatigue(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    service = CampaignFreshnessService(db)
    return service.analyze_brand_fatigue(brand_id)


@router.get("/for-campaign/{campaign_id}")
def recommendations_for_campaign(
    brand_id: int,
    campaign_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    service = CampaignFreshnessService(db)
    return {"recommendations": service.get_freshness_recommendations(campaign_id)}
