"""
Safely repair campaign-brand links where brand_profile_id is NULL
but a matching brand exists for the same user.

Only repairs when:
  - The user IDs match
  - The brand name matches exactly after safe normalization
  - There is only one unambiguous matching brand
"""

import sqlite3
import sys


def normalize(name: str) -> str:
    return name.strip().lower()


def main(db_path: str):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # Find campaigns with NULL brand_profile_id
    cur.execute("SELECT id, name, user_id FROM campaigns WHERE brand_profile_id IS NULL")
    null_campaigns = cur.fetchall()

    if not null_campaigns:
        print("No campaigns with NULL brand_profile_id found. Nothing to repair.")
        return

    print(f"Found {len(null_campaigns)} campaign(s) with NULL brand_profile_id:")

    repaired = 0
    skipped = 0

    for cid, cname, cuid in null_campaigns:
        print(f"\n  Campaign ID={cid}, name='{cname}', user_id={cuid}")

        # Find matching brands for the same user
        cur.execute(
            "SELECT id, name FROM brand_profiles WHERE user_id = ?",
            (cuid,),
        )
        brands = cur.fetchall()

        if not brands:
            print(f"    -> SKIP: user {cuid} has no saved brands")
            skipped += 1
            continue

        # Try to find an exact normalized match
        cname_norm = normalize(cname)
        # Extract brand name from campaign name (campaign names are like "Instagram - Luxury Campaign")
        # Try using the campaign name directly, then try matching against brand names
        matches = []
        for bid, bname in brands:
            if normalize(bname) == cname_norm:
                matches.append((bid, bname))
            # Also check if brand name appears within campaign name
            # (common pattern since campaign titles include brand name)
            elif normalize(bname) in cname_norm or cname_norm in normalize(bname):
                matches.append((bid, bname))

        if len(matches) == 0:
            # If there's exactly one brand for this user, it's safe to link
            if len(brands) == 1:
                bid, bname = brands[0]
                print(f"    -> FALLBACK REPAIR: only brand for user is '{bname}', linking campaign")
                matches.append((bid, bname))
            else:
                print(f"    -> SKIP: no matching brand found for user {cuid} (has {len(brands)} brands)")
                skipped += 1
                continue

        if len(matches) > 1:
            print(f"    -> SKIP: ambiguous - multiple matching brands: {[m[1] for m in matches]}")
            skipped += 1
            continue

        bid, bname = matches[0]
        print(f"    -> REPAIR: setting brand_profile_id={bid} (brand='{bname}')")
        cur.execute(
            "UPDATE campaigns SET brand_profile_id = ? WHERE id = ?",
            (bid, cid),
        )
        repaired += 1

    conn.commit()
    conn.close()

    print(f"\n{'=' * 40}")
    print(f"Repaired: {repaired}")
    print(f"Skipped:  {skipped}")
    print(f"{'=' * 40}")


if __name__ == "__main__":
    db_path = sys.argv[1] if len(sys.argv) > 1 else "social_media.db"
    main(db_path)
