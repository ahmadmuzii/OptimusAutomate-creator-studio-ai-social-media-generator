export interface AudiencePersona {
  id: number
  brand_id: number
  name: string
  description: string | null
  age_range: string | null
  location_market: string | null
  main_problem: string | null
  desired_outcome: string | null
  objections: string | null
  preferred_tone: string | null
  preferred_platform: string | null
  buying_stage: string | null
  content_interests: string[] | null
  common_questions: string[] | null
  main_motivation: string | null
  cta_preference: string | null
  language_preference: string | null
  notes: string | null
  is_primary: boolean
  created_at: string | null
}
