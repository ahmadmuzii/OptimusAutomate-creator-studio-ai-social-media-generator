import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { render, screen, fireEvent, act } from '@testing-library/react'
import { ToastProvider, useToast } from './Toast'

function TestConsumer({ message, variant }: { message: string; variant?: 'success' | 'error' | 'info' | 'warning' }) {
  const { showToast } = useToast()
  return <button onClick={() => showToast(message, variant)}>Show Toast</button>
}

function renderWithProvider(ui: React.ReactElement) {
  return render(<ToastProvider>{ui}</ToastProvider>)
}

beforeEach(() => {
  vi.useFakeTimers()
})

afterEach(() => {
  vi.useRealTimers()
})

describe('ToastProvider', () => {
  it('renders children', () => {
    renderWithProvider(<p>Hello</p>)
    expect(screen.getByText('Hello')).toBeInTheDocument()
  })
})

describe('useToast', () => {
  it('throws when used outside ToastProvider', () => {
    expect(() => render(<TestConsumer message="test" />)).toThrow(
      'useToast must be used within ToastProvider',
    )
  })
})

describe('showToast', () => {
  it('displays a toast when showToast is called', () => {
    renderWithProvider(<TestConsumer message="Operation successful" variant="success" />)
    fireEvent.click(screen.getByText('Show Toast'))
    expect(screen.getByText('Operation successful')).toBeInTheDocument()
  })

  it('displays multiple toasts', () => {
    renderWithProvider(
      <div>
        <TestConsumer message="First" />
        <TestConsumer message="Second" />
      </div>,
    )
    const [firstBtn, secondBtn] = screen.getAllByText('Show Toast')
    fireEvent.click(firstBtn!)
    fireEvent.click(secondBtn!)
    expect(screen.getByText('First')).toBeInTheDocument()
    expect(screen.getByText('Second')).toBeInTheDocument()
  })
})

describe('toast variants', () => {
function testVariantRendering(variant: 'success' | 'error' | 'info' | 'warning', bgClass: string) {
  const { container } = renderWithProvider(<TestConsumer message={variant} variant={variant} />)
  fireEvent.click(screen.getByText('Show Toast'))
  expect(screen.getByText(variant)).toBeInTheDocument()
  const toastEl = container.querySelector(`[class*="${bgClass}"]`)
  expect(toastEl).not.toBeNull()
}

it('renders success variant', () => testVariantRendering('success', 'bg-green'))
it('renders error variant', () => testVariantRendering('error', 'bg-red'))
it('renders info variant', () => testVariantRendering('info', 'bg-blue'))
it('renders warning variant', () => testVariantRendering('warning', 'bg-yellow'))
})

describe('toast dismiss', () => {
  it('removes toast when dismiss button is clicked', () => {
    renderWithProvider(<TestConsumer message="Dismiss me" />)
    fireEvent.click(screen.getByText('Show Toast'))
    expect(screen.getByText('Dismiss me')).toBeInTheDocument()
    const dismissBtn = screen.getByText('Dismiss me').closest('div')?.querySelector('button')
    expect(dismissBtn).not.toBeNull()
    if (dismissBtn) {
      fireEvent.click(dismissBtn)
      act(() => {
        vi.advanceTimersByTime(400)
      })
      expect(screen.queryByText('Dismiss me')).not.toBeInTheDocument()
    }
  })
})

describe('toast auto-dismiss', () => {
  it('auto-dismisses after 4 seconds', () => {
    renderWithProvider(<TestConsumer message="Auto dismiss" />)
    fireEvent.click(screen.getByText('Show Toast'))
    expect(screen.getByText('Auto dismiss')).toBeInTheDocument()
    act(() => {
      vi.advanceTimersByTime(4300)
    })
    expect(screen.queryByText('Auto dismiss')).not.toBeInTheDocument()
  })
})
