import { useState, useEffect, useRef } from 'react'
import { X, Clock, RotateCcw, Loader2 } from 'lucide-react'
import type { PostRevision } from '@/types/common'

interface PostRevisionHistoryProps {
  revisions: PostRevision[]
  isLoading: boolean
  onRestore: (revision: PostRevision) => void
  onClose: () => void
}

export function PostRevisionHistory({ revisions, isLoading, onRestore, onClose }: PostRevisionHistoryProps) {
  const overlayRef = useRef<HTMLDivElement>(null)
  const [restoringId, setRestoringId] = useState<number | null>(null)

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', handleKeyDown)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.body.style.overflow = ''
    }
  }, [onClose])

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === overlayRef.current) onClose()
  }

  const handleRestore = (revision: PostRevision) => {
    setRestoringId(revision.id)
    onRestore(revision)
  }

  const actionLabel = (action: string) => action.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())

  return (
    <div
      ref={overlayRef}
      onClick={handleOverlayClick}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40"
    >
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[85vh] overflow-y-auto m-4">
        <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-purple-600" />
            <h2 className="text-lg font-semibold text-gray-900">Version History</h2>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-lg">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="p-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-purple-600" />
            </div>
          ) : revisions.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-8">No revisions yet.</p>
          ) : (
            <div className="space-y-3">
              {revisions.map((revision) => (
                <div
                  key={revision.id}
                  className="border border-gray-100 rounded-xl p-4 hover:border-gray-200 transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <span className="text-sm font-medium text-gray-800">
                        {actionLabel(revision.action)}
                      </span>
                      <p className="text-xs text-gray-400 mt-0.5">
                        Revision #{revision.revision_number} &middot;{' '}
                        {new Date(revision.created_at).toLocaleDateString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>
                    <button
                      onClick={() => handleRestore(revision)}
                      disabled={restoringId === revision.id}
                      className="flex items-center gap-1.5 text-xs font-medium text-purple-700 bg-purple-50 px-3 py-1.5 rounded-lg hover:bg-purple-100 transition-colors disabled:opacity-50"
                    >
                      {restoringId === revision.id ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <RotateCcw className="w-3.5 h-3.5" />
                      )}
                      Restore
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 line-clamp-2">{revision.previous_caption}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
