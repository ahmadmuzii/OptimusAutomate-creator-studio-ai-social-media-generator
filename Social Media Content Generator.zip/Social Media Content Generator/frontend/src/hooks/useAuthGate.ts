import { useState, useCallback } from 'react'
import { useAuth } from '@/context/AuthContext'
import { useGuestMode } from '@/context/GuestModeContext'

export function useAuthGate() {
  const { isAuthenticated } = useAuth()
  const { isGuestMode } = useGuestMode()
  const [authModalOpen, setAuthModalOpen] = useState(false)
  const [authModalRedirect, setAuthModalRedirect] = useState<string>('')

  const guard = useCallback(
    (redirectTo?: string) => {
      if (isAuthenticated) return true
      if (isGuestMode && redirectTo) {
        setAuthModalRedirect(redirectTo)
        setAuthModalOpen(true)
      }
      return false
    },
    [isAuthenticated, isGuestMode],
  )

  const openAuthModal = useCallback((redirectTo: string) => {
    setAuthModalRedirect(redirectTo)
    setAuthModalOpen(true)
  }, [])

  const closeAuthModal = useCallback(() => {
    setAuthModalOpen(false)
    setAuthModalRedirect('')
  }, [])

  const isLocked = !isAuthenticated && isGuestMode

  return {
    isGuest: !isAuthenticated && isGuestMode,
    isLocked,
    showAuthModal: authModalOpen,
    authModalRedirect,
    guard,
    openAuthModal,
    closeAuthModal,
  }
}
