import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { Outlet, useParams, Link } from 'react-router-dom'
import { ArrowLeft, Loader2, AlertCircle } from 'lucide-react'
import * as api from '@/api/endpoints'
import type { BrandProfile } from '@/types/common'
import { ROUTES } from '@/routes/paths'

export type BrandWorkspaceContext = {
  brandId: number
  brand: BrandProfile
  refetchBrand: () => Promise<void>
}

const BrandWorkspaceCtx = createContext<BrandWorkspaceContext | null>(null)

export function useBrandWorkspace(): BrandWorkspaceContext {
  const ctx = useContext(BrandWorkspaceCtx)
  if (!ctx) {
    throw new Error('useBrandWorkspace must be used within BrandWorkspaceLayout')
  }
  return ctx
}

export function BrandWorkspaceLayout() {
  const { brandId: brandIdParam } = useParams<{ brandId: string }>()
  const brandId = Number(brandIdParam)

  const [brand, setBrand] = useState<BrandProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const isValidNumber = Number.isInteger(brandId) && brandId > 0

  const loadBrand = useCallback(async () => {
    if (!isValidNumber) {
      setError('This brand link is invalid.')
      setLoading(false)
      return
    }
    setLoading(true)
    setError(null)
    try {
      const data = await api.fetchBrand(brandId)
      setBrand(data)
    } catch {
      setError('Brand not found.')
    } finally {
      setLoading(false)
    }
  }, [isValidNumber, brandId])

  useEffect(() => { loadBrand() }, [loadBrand])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 animate-spin text-purple-600" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="max-w-2xl mx-auto text-center py-20">
        <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
        <p className="text-gray-900 font-semibold mb-2">{error}</p>
        <Link
          to={ROUTES.brands}
          className="inline-flex items-center gap-2 text-sm text-purple-600 hover:text-purple-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Brands
        </Link>
      </div>
    )
  }

  return (
    <BrandWorkspaceCtx.Provider value={{ brandId, brand: brand!, refetchBrand: loadBrand }}>
      <Outlet />
    </BrandWorkspaceCtx.Provider>
  )
}
