from __future__ import annotations

from sqlalchemy.orm import Session

from app.models.db_models import PerformanceInsight, PostPerformanceRecord
from app.models.performance_schemas import PerformanceRecordResponse, PerformanceSummary


class InsightService:
    def __init__(self, db: Session):
        self.db = db

    def generate_insights(self, brand_id: int, user_id: int) -> list[PerformanceInsight]:
        records = self.db.query(PostPerformanceRecord).filter(PostPerformanceRecord.brand_id == brand_id).all()

        if not records:
            return []

        insights = []

        content_type_stats = {}
        for r in records:
            ct = r.content_type or "unknown"
            if ct not in content_type_stats:
                content_type_stats[ct] = {"count": 0, "total_engagement": 0}
            content_type_stats[ct]["count"] += 1
            engagement = (r.likes or 0) + (r.comments or 0) + (r.saves or 0) + (r.shares or 0)
            content_type_stats[ct]["total_engagement"] += engagement

        for ct, stats in content_type_stats.items():
            avg_eng = stats["total_engagement"] / max(stats["count"], 1)
            if stats["count"] >= 3:
                insight = PerformanceInsight(
                    user_id=user_id,
                    brand_id=brand_id,
                    pattern_type="best_content_type",
                    content_type=ct,
                    finding=f"Content type '{ct}' averages {avg_eng:.1f} engagements per post.",
                    supporting_metric=f"avg_engagement:{avg_eng:.1f}",
                    sample_size=stats["count"],
                    confidence="high" if stats["count"] >= 10 else "medium",
                )
                self.db.add(insight)
                insights.append(insight)

        platform_stats = {}
        for r in records:
            pl = r.platform or "unknown"
            if pl not in platform_stats:
                platform_stats[pl] = {"count": 0, "total_engagement": 0}
            platform_stats[pl]["count"] += 1
            engagement = (r.likes or 0) + (r.comments or 0) + (r.saves or 0) + (r.shares or 0)
            platform_stats[pl]["total_engagement"] += engagement

        for pl, stats in platform_stats.items():
            avg_eng = stats["total_engagement"] / max(stats["count"], 1)
            if stats["count"] >= 3:
                insight = PerformanceInsight(
                    user_id=user_id,
                    brand_id=brand_id,
                    pattern_type="best_platform",
                    platform=pl,
                    finding=f"Platform '{pl}' averages {avg_eng:.1f} engagements per post.",
                    supporting_metric=f"avg_engagement:{avg_eng:.1f}",
                    sample_size=stats["count"],
                    confidence="high" if stats["count"] >= 10 else "medium",
                )
                self.db.add(insight)
                insights.append(insight)

        self.db.commit()
        for ins in insights:
            self.db.refresh(ins)
        return insights

    def get_summary(self, brand_id: int) -> PerformanceSummary:
        records = self.db.query(PostPerformanceRecord).filter(PostPerformanceRecord.brand_id == brand_id).all()

        if not records:
            return PerformanceSummary(total_posts=0, avg_impressions=0, avg_engagement_rate=0)

        total_posts = len(records)
        total_impressions = sum(r.impressions or 0 for r in records)
        avg_impressions = total_impressions / total_posts

        total_engagement_rate = 0.0
        for r in records:
            imp = r.impressions or 0
            if imp > 0:
                eng = (r.likes or 0) + (r.comments or 0) + (r.saves or 0) + (r.shares or 0)
                total_engagement_rate += (eng / imp) * 100
        avg_engagement_rate = total_engagement_rate / total_posts if total_posts > 0 else 0.0

        platform_engagement = {}
        for r in records:
            pl = r.platform or "unknown"
            if pl not in platform_engagement:
                platform_engagement[pl] = {"total_eng": 0, "count": 0}
            eng = (r.likes or 0) + (r.comments or 0) + (r.saves or 0) + (r.shares or 0)
            platform_engagement[pl]["total_eng"] += eng
            platform_engagement[pl]["count"] += 1

        best_platform = None
        best_avg_eng = 0
        for pl, stats in platform_engagement.items():
            avg = stats["total_eng"] / max(stats["count"], 1)
            if avg > best_avg_eng:
                best_avg_eng = avg
                best_platform = pl

        content_type_engagement = {}
        for r in records:
            ct = r.content_type or "unknown"
            if ct not in content_type_engagement:
                content_type_engagement[ct] = {"total_eng": 0, "count": 0}
            eng = (r.likes or 0) + (r.comments or 0) + (r.saves or 0) + (r.shares or 0)
            content_type_engagement[ct]["total_eng"] += eng
            content_type_engagement[ct]["count"] += 1

        best_content_type = None
        best_ct_avg = 0
        for ct, stats in content_type_engagement.items():
            avg = stats["total_eng"] / max(stats["count"], 1)
            if avg > best_ct_avg:
                best_ct_avg = avg
                best_content_type = ct

        sorted_records = sorted(
            records,
            key=lambda r: (r.likes or 0) + (r.comments or 0) + (r.saves or 0) + (r.shares or 0),
            reverse=True,
        )[:5]

        top_performers = [
            PerformanceRecordResponse(
                id=r.id,
                platform=r.platform,
                content_type=r.content_type,
                impressions=r.impressions,
                reach=r.reach,
                likes=r.likes,
                comments=r.comments,
                saves=r.saves,
                shares=r.shares,
                link_clicks=r.link_clicks,
                publication_date=r.publication_date,
                persona_id=r.persona_id,
            )
            for r in sorted_records
        ]

        insights_list = []
        insights_db = (
            self.db.query(PerformanceInsight)
            .filter(
                PerformanceInsight.brand_id == brand_id,
                PerformanceInsight.is_accepted.is_(True),
                PerformanceInsight.is_archived.is_(False),
            )
            .all()
        )
        insights_list = [i.finding for i in insights_db]

        return PerformanceSummary(
            total_posts=total_posts,
            avg_impressions=avg_impressions,
            avg_engagement_rate=avg_engagement_rate,
            best_platform=best_platform,
            best_content_type=best_content_type,
            top_performers=top_performers,
            insights=insights_list,
        )
