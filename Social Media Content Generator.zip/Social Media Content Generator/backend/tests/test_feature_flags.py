from __future__ import annotations


class TestFeatureFlags:
    """Test feature flag infrastructure."""

    def test_get_all_feature_flags(self, client):
        response = client.get("/api/v1/feature-flags")
        assert response.status_code == 200
        assert response.json() == {
            "brandGuardrails": True,
            "audiencePersonas": True,
            "conversionPaths": True,
            "sourceToCampaign": True,
            "sourceFacts": True,
            "contentPacks": True,
            "campaignFreshness": True,
            "strategyModes": True,
            "performanceMemory": True,
            "experiments": True,
            "regionalLanguages": True,
            "competitorGaps": True,
            "collaboration": True,
        }

    def test_default_enabled_route_works(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.get(
            f"/api/v1/brands/{brand_id}/conversion-paths",
            headers=auth_headers,
        )
        assert response.status_code == 200

    def test_disabled_conversion_paths_returns_404(self, monkeypatch, client, auth_headers, created_brand):
        monkeypatch.setattr("app.api.deps_features.settings.enable_conversion_paths", False)
        from app.api.deps_features import is_feature_enabled

        is_feature_enabled.cache_clear()

        brand_id = created_brand["id"]
        response = client.get(
            f"/api/v1/brands/{brand_id}/conversion-paths",
            headers=auth_headers,
        )
        assert response.status_code == 404
        assert response.json()["detail"] == "This feature is currently disabled"

    def test_multiple_features_independently_disabled(self, monkeypatch, client, auth_headers, created_brand):
        monkeypatch.setattr("app.api.deps_features.settings.enable_conversion_paths", False)
        monkeypatch.setattr("app.api.deps_features.settings.enable_campaign_freshness", False)
        from app.api.deps_features import is_feature_enabled

        is_feature_enabled.cache_clear()

        brand_id = created_brand["id"]

        response = client.get(
            f"/api/v1/brands/{brand_id}/conversion-paths",
            headers=auth_headers,
        )
        assert response.status_code == 404

        response = client.get(
            f"/api/v1/brands/{brand_id}/freshness",
            headers=auth_headers,
        )
        assert response.status_code == 404

    def test_feature_flags_reflect_correct_state_after_disabling(self, monkeypatch, client):
        monkeypatch.setattr("app.api.deps_features.settings.enable_brand_guardrails", False)
        monkeypatch.setattr("app.api.deps_features.settings.enable_experiments", False)

        response = client.get("/api/v1/feature-flags")
        assert response.status_code == 200
        data = response.json()
        assert data["brandGuardrails"] is False
        assert data["experiments"] is False
        assert data["conversionPaths"] is True
