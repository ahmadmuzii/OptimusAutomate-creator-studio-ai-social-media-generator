"""Safe migration: add persona columns to campaign_posts table.

Adds persona_id, persona_name, audience_problem, and desired_action
columns to the campaign_posts table if they do not already exist.

Preserves all existing data. Safe to run multiple times.
"""

import os
import sqlite3
import sys

COLUMNS = [
    ("persona_id", "INTEGER"),
    ("persona_name", "VARCHAR(255)"),
    ("audience_problem", "TEXT"),
    ("desired_action", "TEXT"),
]


def get_db_path() -> str:
    db_dir = os.path.dirname(os.path.abspath(__file__))
    backend_dir = os.path.dirname(db_dir)
    return os.path.join(backend_dir, "social_media.db")


def get_existing_columns(cursor: sqlite3.Cursor, table: str) -> set[str]:
    cursor.execute(f"PRAGMA table_info({table})")
    return {row[1] for row in cursor.fetchall()}


def run_migration(db_path: str) -> None:
    if not os.path.exists(db_path):
        print(f"Database not found: {db_path}")
        sys.exit(1)

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    existing = get_existing_columns(cursor, "campaign_posts")
    added: list[str] = []
    skipped: list[str] = []

    for col_name, col_type in COLUMNS:
        if col_name in existing:
            skipped.append(col_name)
        else:
            cursor.execute(
                f"ALTER TABLE campaign_posts ADD COLUMN {col_name} {col_type}"
            )
            added.append(col_name)

    conn.commit()
    conn.close()

    if added:
        print(f"Added columns: {', '.join(added)}")
    if skipped:
        print(f"Skipped (already exist): {', '.join(skipped)}")
    if not added and not skipped:
        print("No migration needed.")
    print("Migration complete.")


if __name__ == "__main__":
    run_migration(get_db_path())
