import { useState } from 'react'
import { Check, Plus } from 'lucide-react'
import type { OpportunityItem } from '@/types/competitor'

interface Props {
  data: OpportunityItem[]
  onSelect?: (topic: string) => void
}

const priorityStyles: Record<string, string> = {
  high: 'bg-red-50 text-red-700',
  medium: 'bg-yellow-50 text-yellow-700',
  low: 'bg-blue-50 text-blue-700',
}

export function OpportunityTable({ data, onSelect }: Props) {
  const [selected, setSelected] = useState<Set<string>>(new Set())

  if (data.length === 0) return null

  const handleToggle = (topic: string) => {
    setSelected(prev => {
      const next = new Set(prev)
      if (next.has(topic)) next.delete(topic)
      else next.add(topic)
      return next
    })
    onSelect?.(topic)
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="p-5 pb-3">
        <h3 className="text-sm font-semibold text-gray-900">Top Opportunities</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-t border-gray-50 bg-gray-50/50">
              <th className="text-left font-medium text-gray-500 px-5 py-3">Topic</th>
              <th className="text-left font-medium text-gray-500 px-4 py-3">Competitor posts</th>
              <th className="text-left font-medium text-gray-500 px-4 py-3">Brand posts</th>
              <th className="text-left font-medium text-gray-500 px-4 py-3">Competitors</th>
              <th className="text-left font-medium text-gray-500 px-4 py-3">Priority</th>
              <th className="text-left font-medium text-gray-500 px-4 py-3">Suggested Format</th>
              <th className="text-left font-medium text-gray-500 px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {data.map(opp => (
              <tr key={opp.topic} className="border-t border-gray-50 hover:bg-gray-50/30 transition-colors">
                <td className="px-5 py-3 font-medium text-gray-900 capitalize">{opp.topic}</td>
                <td className="px-4 py-3 text-gray-600">{opp.competitor_coverage} posts</td>
                <td className="px-4 py-3 text-gray-600">{opp.brand_coverage} posts</td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-1">
                    {opp.competitors.map(c => (
                      <span key={c} className="text-xs bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">
                        {c}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${priorityStyles[opp.priority] || ''}`}>
                    {opp.priority.charAt(0).toUpperCase() + opp.priority.slice(1)}
                  </span>
                </td>
                <td className="px-4 py-3 text-gray-600 capitalize">
                  {opp.suggested_format?.replace(/_/g, ' ') || '-'}
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => handleToggle(opp.topic)}
                    className={`inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg transition-colors ${
                      selected.has(opp.topic)
                        ? 'bg-green-50 text-green-700 hover:bg-green-100'
                        : 'bg-purple-50 text-purple-700 hover:bg-purple-100'
                    }`}
                  >
                    {selected.has(opp.topic) ? (
                      <><Check className="w-3 h-3" /> Selected</>
                    ) : (
                      <><Plus className="w-3 h-3" /> Use in Campaign</>
                    )}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
