import { useEffect, useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ChevronLeft, ChevronRight, X,
} from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useGuestMode } from '@/context/GuestModeContext'
import * as api from '@/api/endpoints'
import type { CampaignData, CampaignPost, RefinementAction, SupportedTone } from '@/types/common'
import { guestCampaigns } from '@/data/guestDemoData'
import { useToast } from '@/components/ui/Toast'
import { Skeleton, CalendarSkeleton } from '@/components/ui/Skeleton'
import { PostRefinementMenu } from '@/components/common/PostRefinementMenu'
import { InlineRefinementError } from '@/components/common/InlineRefinementError'
import { useRefineCampaignPost } from '@/hooks/useRefineCampaignPost'

interface PostWithMeta extends CampaignPost {
  campaignName: string
  campaignId: number
  campaignPlatform: string
  campaignTone: string
}

const statusColors: Record<string, string> = {
  draft: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  scheduled: 'bg-blue-100 text-blue-700 border-blue-200',
  published: 'bg-green-100 text-green-700 border-green-200',
}

export function CalendarPage() {
  const { showToast } = useToast()
  const { isAuthenticated } = useAuth()
  const { isGuestMode } = useGuestMode()
  const isDemo = isGuestMode && !isAuthenticated
  const [campaigns, setCampaigns] = useState<CampaignData[]>([])
  const [loading, setLoading] = useState(true)
  const [monthOffset, setMonthOffset] = useState(0)
  const [selectedStatus, setSelectedStatus] = useState<string>('all')
  const [selectedPost, setSelectedPost] = useState<PostWithMeta | null>(null)
  const [refinementCampaignId, setRefinementCampaignId] = useState<number | null>(null)

  const {
    refining,
    refiningPostId,
    error: refineError,
    refine,
    clearError: clearRefineError,
  } = useRefineCampaignPost(refinementCampaignId ?? 0)

  useEffect(() => {
    if (isDemo) {
      setCampaigns(guestCampaigns)
      setLoading(false)
      return
    }
    api.fetchCampaigns()
      .then(setCampaigns)
      .catch(() => setCampaigns([]))
      .finally(() => setLoading(false))
  }, [isDemo])

  const now = new Date()
  const year = now.getFullYear()
  const month = now.getMonth() + monthOffset
  const adjustedDate = new Date(year, month, 1)
  const monthName = adjustedDate.toLocaleString('default', { month: 'long', year: 'numeric' })

  const yearNum = adjustedDate.getFullYear()
  const monthNum = adjustedDate.getMonth()
  const daysInMonth = new Date(yearNum, monthNum + 1, 0).getDate()
  const firstDay = adjustedDate.getDay()

  const allPosts = useMemo(() =>
    campaigns.flatMap((c) =>
      (c.posts || []).map((p) => ({
        ...p,
        campaignName: c.name,
        campaignId: c.id,
        campaignPlatform: c.platform,
        campaignTone: c.tone,
      }))
    ), [campaigns])

  const filteredPosts = selectedStatus === 'all'
    ? allPosts
    : allPosts.filter((p) => p.status === selectedStatus)

  const postsByDay: Record<number, PostWithMeta[]> = {}
  filteredPosts.forEach((p) => {
    if (p.day >= 1 && p.day <= daysInMonth) {
      (postsByDay[p.day] ??= []).push(p)
    }
  })

  const handleCopy = async (post: PostWithMeta) => {
    const text = `${post.caption}\n\n${post.call_to_action || ''}\n\n${(post.hashtags || []).map((h) => `#${h}`).join(' ')}`
    try {
      await navigator.clipboard.writeText(text)
      showToast('Copied to clipboard', 'success')
    } catch {
      showToast('Failed to copy.', 'error')
    }
  }

  const handleRefine = async (action: RefinementAction, targetTone?: SupportedTone | null, customInstruction?: string | null) => {
    if (!selectedPost) return
    setRefinementCampaignId(selectedPost.campaignId)
    const updated = await refine(selectedPost, action, targetTone, customInstruction)
    if (updated) {
      setCampaigns((prev) =>
        prev.map((c) =>
          c.id === selectedPost.campaignId
            ? { ...c, posts: (c.posts || []).map((p) => (p.id === updated.id ? updated : p)) }
            : c,
        ),
      )
      setSelectedPost((prev) => (prev && prev.id === updated.id ? { ...prev, ...updated } : prev))
      showToast('Post updated successfully', 'success')
    }
  }

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto space-y-6">
        <Skeleton className="h-7 w-24" />
        <Skeleton className="h-4 w-36" />
        <CalendarSkeleton />
      </div>
    )
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Calendar</h1>
          <p className="text-gray-500 mt-1">View and manage your campaign schedule.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setMonthOffset((p) => p - 1)}
            className="p-2 rounded-lg hover:bg-gray-100 text-gray-600"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-sm font-medium text-gray-700 min-w-[140px] text-center">{monthName}</span>
          <button
            onClick={() => setMonthOffset((p) => p + 1)}
            className="p-2 rounded-lg hover:bg-gray-100 text-gray-600"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Status filter */}
      <div className="flex items-center gap-2">
        {['all', 'draft', 'scheduled', 'published'].map((s) => (
          <button
            key={s}
            onClick={() => setSelectedStatus(s)}
            className={`text-xs font-medium px-3 py-1.5 rounded-full border transition-all ${
              selectedStatus === s
                ? 'bg-purple-50 text-purple-700 border-purple-200'
                : 'bg-white text-gray-500 border-gray-200 hover:border-purple-200'
            }`}
          >
            {s.charAt(0).toUpperCase() + s.slice(1)}
          </button>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="grid grid-cols-7 border-b border-gray-100">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
            <div key={d} className="px-3 py-2 text-xs font-medium text-gray-500 text-center border-r border-gray-50 last:border-r-0">
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {Array.from({ length: firstDay }).map((_, i) => (
            <div key={`empty-${i}`} className="min-h-[100px] border-b border-r border-gray-50 p-2" />
          ))}
          {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((day) => {
            const dayPosts = postsByDay[day] || []
            return (
              <div
                key={day}
                className={`min-h-[100px] border-b border-r border-gray-50 p-2 hover:bg-gray-50/50 transition-colors ${
                  dayPosts.length > 0 ? 'bg-purple-50/30' : ''
                }`}
              >
                <span className={`text-xs font-medium ${dayPosts.length > 0 ? 'text-purple-700' : 'text-gray-400'}`}>
                  {day}
                </span>
                <div className="mt-1 space-y-1">
                  {dayPosts.slice(0, 3).map((p) => (
                    <button
                      key={p.id}
                      onClick={() => { setSelectedPost(p) }}
                      className={`block w-full text-left text-[10px] px-1.5 py-0.5 rounded border truncate transition-all hover:opacity-80 ${
                        statusColors[p.status] || statusColors.draft
                      }`}
                      title={`${p.campaignName} - ${p.post_idea}`}
                    >
                      {p.content_type}
                    </button>
                  ))}
                  {dayPosts.length > 3 && (
                    <div className="text-[10px] text-gray-400 px-1">+{dayPosts.length - 3} more</div>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Post detail drawer (read-only for guests, full for authenticated) */}
      <AnimatePresence>
        {selectedPost && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/30 z-40"
              onClick={() => setSelectedPost(null)}
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed right-0 top-0 h-full w-full max-w-md bg-white shadow-xl z-50 overflow-y-auto"
            >
              <div className="sticky top-0 bg-white border-b border-gray-100 px-5 py-4 flex items-center justify-between z-10">
                <h2 className="font-semibold text-gray-900 text-sm">Post Details</h2>
                <button onClick={() => setSelectedPost(null)}
                  className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-5 space-y-5">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="bg-purple-50 text-purple-700 px-2 py-0.5 rounded-full font-medium">
                    Day {selectedPost.day}
                  </span>
                  <span className="text-gray-500">{selectedPost.platform}</span>
                  <span className="text-gray-300">&middot;</span>
                  <span className="text-gray-600 font-medium">{selectedPost.campaignName}</span>
                </div>

                <p className="text-sm font-medium text-gray-900">{selectedPost.content_theme}</p>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">Status:</span>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${
                    statusColors[selectedPost.status] || statusColors.draft
                  }`}>
                    {selectedPost.status}
                  </span>
                </div>

                <div>
                  <div className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap mb-3">
                    {selectedPost.caption}
                  </div>
                  {selectedPost.call_to_action && (
                    <p className="text-sm text-purple-600 font-medium mb-2">CTA: {selectedPost.call_to_action}</p>
                  )}
                  {selectedPost.hashtags && selectedPost.hashtags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {selectedPost.hashtags.map((h, i) => (
                        <span key={i} className="text-xs bg-gray-50 text-gray-600 px-2 py-0.5 rounded-full">#{h}</span>
                      ))}
                    </div>
                  )}
                </div>

                {refineError && (
                  <InlineRefinementError message={refineError} onDismiss={clearRefineError} />
                )}

                {!isDemo && (
                  <div className="flex items-center gap-1 pt-2 border-t border-gray-100">
                    <button onClick={() => handleCopy(selectedPost)}
                      className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-xl hover:bg-gray-100 text-gray-600 transition-colors">
                      Copy
                    </button>
                    <PostRefinementMenu
                      post={selectedPost}
                      isRefining={refining && refiningPostId === selectedPost.id}
                      hasRevisions={false}
                      onRefine={handleRefine}
                      onUndo={() => {}}
                      onShowHistory={() => {}}
                    />
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
