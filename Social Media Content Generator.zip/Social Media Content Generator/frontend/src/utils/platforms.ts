import { Instagram, Linkedin, Music2, Facebook, Twitter, MessageSquare, type LucideIcon } from 'lucide-react'

export interface PlatformInfo {
  id: string
  name: string
  icon: LucideIcon
  gradient: string
}

const platforms: PlatformInfo[] = [
  { id: 'instagram', name: 'Instagram', icon: Instagram, gradient: 'from-pink-500 to-purple-600' },
  { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, gradient: 'from-blue-600 to-blue-800' },
  { id: 'tiktok', name: 'TikTok', icon: Music2, gradient: 'from-black to-gray-800' },
  { id: 'facebook', name: 'Facebook', icon: Facebook, gradient: 'from-blue-500 to-blue-700' },
  { id: 'twitter', name: 'X / Twitter', icon: Twitter, gradient: 'from-gray-900 to-black' },
]

const platformMap = new Map<string, PlatformInfo>()
platforms.forEach((p) => {
  platformMap.set(p.id, p)
  platformMap.set(p.id.toLowerCase(), p)
  platformMap.set(p.name.toLowerCase(), p)
  platformMap.set(p.name, p)
})

const platformApiMap: Record<string, string> = {
  instagram: 'Instagram',
  linkedin: 'LinkedIn',
  tiktok: 'TikTok',
  facebook: 'Facebook',
  twitter: 'X',
}

export type PlatformKey = 'instagram' | 'linkedin' | 'tiktok' | 'facebook' | 'x'

export function normalizePlatform(value: string | null | undefined): PlatformKey | null {
  if (!value) return null
  const normalized = value.trim().toLowerCase().replace(/\s+/g, ' ')
  const aliases: Record<string, PlatformKey> = {
    instagram: 'instagram',
    linkedin: 'linkedin',
    tiktok: 'tiktok',
    facebook: 'facebook',
    x: 'x',
    twitter: 'x',
    'x / twitter': 'x',
    'x/twitter': 'x',
  }
  return aliases[normalized] ?? null
}

export function getPlatformInfo(value: string): PlatformInfo {
  const key = value.toLowerCase().replace(/\s*\/\s*/g, '/')
  if (key === 'x' || key === 'x/twitter' || key === 'twitter') {
    return platformMap.get('twitter')!
  }
  const normalized = platformMap.get(value) ?? platformMap.get(key)
  if (normalized) return normalized
  return { id: value, name: value, icon: MessageSquare, gradient: 'from-purple-600 to-purple-800' }
}

export function getPlatformIcon(value: string): LucideIcon {
  return getPlatformInfo(value).icon
}

export function getPlatformGradient(value: string): string {
  return getPlatformInfo(value).gradient
}

export function getPlatformDisplayName(value: string): string {
  return getPlatformInfo(value).name
}

export function mapPlatformToApi(platformId: string): string {
  return platformApiMap[platformId] ?? platformId
}

export { platforms, platformApiMap }
