import { type ReactElement } from 'react'
import { useAuth } from '@/context/AuthContext'
import { useGuestMode } from '@/context/GuestModeContext'

interface ProtectedActionProps {
  children: ReactElement<{ onClick?: (...args: unknown[]) => void }>
  redirectTo?: string
  onAuthRequired?: (redirectTo: string) => void
}

export function ProtectedAction({ children, redirectTo, onAuthRequired }: ProtectedActionProps) {
  const { isAuthenticated } = useAuth()
  const { isGuestMode } = useGuestMode()

  const isLocked = !isAuthenticated && isGuestMode

  if (!isLocked) {
    return children
  }

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    onAuthRequired?.(redirectTo || '/dashboard')
  }

  return (
    <button type="button" onClick={handleClick} className="w-full text-left">
      {children}
    </button>
  )
}
