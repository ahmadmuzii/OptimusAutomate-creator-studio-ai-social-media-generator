from __future__ import annotations

from collections.abc import AsyncGenerator

from structlog.stdlib import BoundLogger

from app.logging_config import get_logger


async def get_logger_dependency() -> AsyncGenerator[BoundLogger, None]:
    yield get_logger(__name__)
