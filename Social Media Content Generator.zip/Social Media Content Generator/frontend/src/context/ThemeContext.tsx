import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react'
import * as api from '@/api/endpoints'

interface ThemeState {
  theme: string
  effectiveTheme: 'light' | 'dark'
  setTheme: (t: string) => Promise<void>
}

const ThemeContext = createContext<ThemeState | null>(null)

function resolveTheme(pref: string): 'light' | 'dark' {
  if (pref === 'dark') return 'dark'
  if (pref === 'system') {
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
  }
  return 'light'
}

export function ThemeProvider({ initial, children }: { initial?: string; children: ReactNode }) {
  const [theme, setThemeState] = useState(initial || 'light')
  const effectiveTheme = resolveTheme(theme)

  useEffect(() => {
    const root = document.documentElement
    if (effectiveTheme === 'dark') {
      root.classList.add('dark')
    } else {
      root.classList.remove('dark')
    }
  }, [effectiveTheme])

  useEffect(() => {
    if (theme !== 'system') return
    const mq = window.matchMedia('(prefers-color-scheme: dark)')
    const handler = () => {
      const root = document.documentElement
      if (mq.matches) {
        root.classList.add('dark')
      } else {
        root.classList.remove('dark')
      }
    }
    mq.addEventListener('change', handler)
    return () => mq.removeEventListener('change', handler)
  }, [theme])

  const setTheme = useCallback(async (t: string) => {
    setThemeState(t)
    try {
      const res = await api.updateUserSettings({ theme_preference: t })
      setThemeState(res.theme_preference || t)
    } catch {
      /* ignore - theme still applied locally */
    }
  }, [])

  return (
    <ThemeContext.Provider value={{ theme, effectiveTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme(): ThemeState {
  const ctx = useContext(ThemeContext)
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider')
  return ctx
}
