export interface PerformanceImportRow {
  external_post_id?: string
  platform?: string
  content_type?: string
  publication_date?: string | null
  impressions?: number
  reach?: number
  likes?: number
  comments?: number
  saves?: number
  shares?: number
  link_clicks?: number
  watch_time?: number
  video_views?: number
  profile_visits?: number
  followers_gained?: number
  conversion_count?: number
  caption?: string
  persona_id?: number | null
  funnel_stage?: string | null
  cta_type?: string | null
}

export interface PerformanceImportRequest {
  brand_id?: number | null
  rows: PerformanceImportRow[]
}

export interface ImportBatch {
  id: number
  filename: string | null
  total_rows: number
  valid_rows: number
  invalid_rows: number
  status: string
  created_at: string
}

export interface PerformanceRecord {
  id: number
  platform: string | null
  content_type: string | null
  impressions: number | null
  reach: number | null
  likes: number | null
  comments: number | null
  saves: number | null
  shares: number | null
  link_clicks: number | null
  engagement_rate: number | null
  publication_date: string | null
  persona_id: number | null
}

export interface PerformanceSummary {
  total_posts: number
  avg_impressions: number
  avg_engagement_rate: number
  best_platform: string | null
  best_content_type: string | null
  top_performers: PerformanceRecord[]
  insights: string[]
}

export interface PerformanceInsight {
  id: number
  pattern_type: string
  platform: string | null
  persona_id: number | null
  content_type: string | null
  finding: string
  supporting_metric: string | null
  sample_size: number | null
  confidence: string | null
  is_accepted: boolean
  is_archived: boolean
  affect_future_generation: boolean
  created_at: string
}

export interface InsightUpdate {
  is_accepted?: boolean
  is_archived?: boolean
  affect_future_generation?: boolean
}
