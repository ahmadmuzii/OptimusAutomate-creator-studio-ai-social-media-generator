import { useCallback, useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Wand2, AlertCircle, Sparkles, ArrowDown, Loader2 } from 'lucide-react'
import { BrandForm } from '@/features/brand-form/BrandForm'
import { PlatformSelector } from '@/features/platform-selector/PlatformSelector'
import { ToneSelector } from '@/features/tone-selector/ToneSelector'
import { IntelligencePanel } from '@/features/intelligence-panel'
import { CalendarCards } from '@/features/calendar/CalendarCards'
import { CaptionSection } from '@/features/captions/CaptionSection'
import { PageTransition } from '@/components/layout/PageTransition'
import { useGenerateCalendar } from '@/hooks/useGenerateCalendar'
import { useToast } from '@/components/ui/Toast'
import { isFormValid } from '@/utils/validators'
import type { BrandFormData, BrandProfile } from '@/types/common'
import * as api from '@/api/endpoints'

export function GenerateCampaignPage() {
  const { showToast } = useToast()
  const [searchParams] = useSearchParams()
  const resultsRef = useRef<HTMLDivElement>(null)
  const [formData, setFormData] = useState<BrandFormData>({
    brandName: '',
    brandDescription: '',
    niche: '',
    targetAudience: '',
    campaignGoal: '',
    brandId: null,
  })
  const [selectedBrandId, setSelectedBrandId] = useState<number | null>(null)
  const [selectedPlatform, setSelectedPlatform] = useState('')
  const [selectedTone, setSelectedTone] = useState('')
  const [selectedSourceIds, setSelectedSourceIds] = useState<number[]>([])
  const { state, generate } = useGenerateCalendar()

  // Read brandId query param on mount
  useEffect(() => {
    const brandIdParam = searchParams.get('brandId')
    if (brandIdParam) {
      const id = Number(brandIdParam)
      if (id) {
        api.fetchBrand(id).then((brand: BrandProfile) => {
          setSelectedBrandId(brand.id)
          setFormData({
            brandName: brand.name,
            brandDescription: brand.description || '',
            niche: brand.niche || '',
            targetAudience: brand.target_audience || '',
            campaignGoal: '',
            brandId: brand.id,
          })
        }).catch(() => {
          showToast('Could not load the selected brand.', 'error')
        })
      }
    }
  }, [searchParams, showToast])

  // Read platform query param on mount and preselect
  useEffect(() => {
    const platformParam = searchParams.get('platform')
    if (platformParam) {
      const supported: readonly string[] = ['instagram', 'linkedin', 'tiktok', 'facebook', 'x']
      if (supported.includes(platformParam)) {
        const id = platformParam === 'x' ? 'twitter' : platformParam
        setSelectedPlatform(id)
      }
    }
  }, [searchParams])

  const handleFormChange = useCallback((field: keyof BrandFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }, [])

  const handleSelectBrand = useCallback((brand: BrandProfile | null) => {
    setSelectedBrandId(brand?.id ?? null)
  }, [])

  const handleGenerate = useCallback(async () => {
    if (!isFormValid(formData, selectedPlatform, selectedTone)) {
      return
    }
    const result = await generate(formData, selectedPlatform, selectedTone, selectedSourceIds)
    if (result && !result.saved) {
      showToast('Campaign generated but not saved — please log in to save campaigns.', 'warning')
    }
    setTimeout(() => {
      resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }, 200)
  }, [formData, selectedPlatform, selectedTone, selectedSourceIds, generate, showToast])

  return (
    <PageTransition>
      <div className="mx-auto max-w-3xl space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Generate Campaign</h1>
          <p className="text-gray-500 mt-1">Create a 7-day AI-powered content campaign.</p>
        </div>

        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 md:p-8">
          <BrandForm
            formData={formData}
            onChange={handleFormChange}
            onSelectBrand={handleSelectBrand}
            selectedBrandId={selectedBrandId}
          />
        </section>

        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 md:p-8">
          <PlatformSelector selected={selectedPlatform} onSelect={setSelectedPlatform} />
        </section>

        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 md:p-8">
          <ToneSelector selected={selectedTone} onSelect={setSelectedTone} />
        </section>

        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 md:p-8">
          <IntelligencePanel
            brandId={selectedBrandId}
            selectedIds={selectedSourceIds}
            onChange={setSelectedSourceIds}
          />
        </section>

        <div className="flex flex-col items-center gap-4">
          <button
            onClick={handleGenerate}
            disabled={state.status === 'loading'}
            className="bg-gradient-to-r from-purple-600 via-purple-700 to-purple-900 text-white font-semibold px-8 py-3.5 rounded-xl shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center gap-3 text-lg w-full md:w-auto justify-center"
          >
            {state.status === 'loading' ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Generating your campaign...
              </>
            ) : (
              <>
                <Wand2 className="w-5 h-5" />
                Generate 7-Day Campaign
              </>
            )}
          </button>
          {state.status === 'loading' && (
            <p className="text-sm text-gray-400 animate-pulse">
              Our AI is crafting your content calendar...
            </p>
          )}
        </div>

        <AnimatePresence>
          {state.status === 'error' && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-3 p-4 rounded-xl bg-red-50 border border-red-100 text-red-700"
            >
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p className="text-sm">{state.error}</p>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {state.status === 'success' && (
            <motion.div
              ref={resultsRef}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="mt-16 space-y-12"
            >
              <motion.div className="flex flex-col items-center gap-2 text-gray-400">
                <Sparkles className="w-5 h-5 text-purple-500" />
                <p className="text-sm font-medium">Your campaign is ready!</p>
                <ArrowDown className="w-4 h-4 animate-bounce" />
              </motion.div>
              <CalendarCards data={state.data.calendar} />
              <CaptionSection captions={state.data.captions} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </PageTransition>
  )
}
