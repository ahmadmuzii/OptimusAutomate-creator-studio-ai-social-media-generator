import { useState, useCallback } from 'react'
import { Loader2, Save, Eye, EyeOff, AlertTriangle, Trash2, Check, X } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useTheme } from '@/context/ThemeContext'
import { useToast } from '@/components/ui/Toast'
import * as api from '@/api/endpoints'

export function SettingsPage() {
  const { logout } = useAuth()
  const { theme, setTheme } = useTheme()
  const { showToast } = useToast()

  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [changingPassword, setChangingPassword] = useState(false)
  const [showCurrent, setShowCurrent] = useState(false)
  const [showNew, setShowNew] = useState(false)

  const [deleteConfirm, setDeleteConfirm] = useState(false)
  const [deleteText, setDeleteText] = useState('')
  const [deleting, setDeleting] = useState(false)

  const handleChangePassword = useCallback(async () => {
    if (newPassword !== confirmPassword) {
      showToast('Passwords do not match.', 'error')
      return
    }
    if (newPassword.length < 6) {
      showToast('New password must be at least 6 characters.', 'error')
      return
    }
    setChangingPassword(true)
    try {
      await api.changePassword({ current_password: currentPassword, new_password: newPassword })
      showToast('Password updated.', 'success')
      setCurrentPassword('')
      setNewPassword('')
      setConfirmPassword('')
    } catch {
      showToast('Failed to update password.', 'error')
    }
    setChangingPassword(false)
  }, [currentPassword, newPassword, confirmPassword, showToast])

  const handleDeleteAccount = useCallback(async () => {
    setDeleting(true)
    try {
      await api.deleteMyAccount()
      showToast('Account deleted.', 'success')
      setTimeout(() => logout(), 500)
    } catch {
      showToast('Failed to delete account.', 'error')
    }
    setDeleting(false)
  }, [logout, showToast])

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-500 mt-1">Manage your account and preferences.</p>
      </div>

      {/* Appearance */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm space-y-4">
        <h2 className="text-lg font-semibold text-gray-900">Appearance</h2>
        <p className="text-sm text-gray-500">Choose your theme preference.</p>
        <div className="flex items-center gap-3">
          {(['light', 'dark', 'system'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTheme(t)}
              className={`px-4 py-2 rounded-xl text-sm font-medium border transition-all ${
                theme === t
                  ? 'bg-purple-50 text-purple-700 border-purple-200 shadow-sm'
                  : 'bg-white text-gray-500 border-gray-200 hover:border-purple-200 hover:text-purple-600'
              }`}
            >
              {t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Security */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm space-y-4">
        <h2 className="text-lg font-semibold text-gray-900">Security</h2>
        <p className="text-sm text-gray-500">Change your password.</p>
        <div className="space-y-4">
          <div className="relative">
            <label className="block text-xs font-medium text-gray-700 mb-1">Current Password</label>
            <input type={showCurrent ? 'text' : 'password'} value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="w-full px-3 py-2 pr-10 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-sm" />
            <button onClick={() => setShowCurrent(!showCurrent)}
              className="absolute right-3 top-[34px] text-gray-400 hover:text-gray-600">
              {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <div className="relative">
            <label className="block text-xs font-medium text-gray-700 mb-1">New Password</label>
            <input type={showNew ? 'text' : 'password'} value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full px-3 py-2 pr-10 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-sm" />
            <button onClick={() => setShowNew(!showNew)}
              className="absolute right-3 top-[34px] text-gray-400 hover:text-gray-600">
              {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">Confirm New Password</label>
            <input type="password" value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-sm" />
          </div>
          <div className="flex justify-end">
            <button
              onClick={handleChangePassword}
              disabled={!currentPassword || !newPassword || !confirmPassword || changingPassword}
              className="px-4 py-2 text-sm font-semibold text-white bg-purple-600 rounded-xl hover:bg-purple-700 disabled:opacity-50 transition-colors flex items-center gap-2"
            >
              {changingPassword ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Update Password
            </button>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-white rounded-2xl border border-red-100 p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-500" />
          <h2 className="text-lg font-semibold text-red-700">Danger Zone</h2>
        </div>
        <p className="text-sm text-gray-600">Permanently delete your account and all associated data. This cannot be undone.</p>
        {!deleteConfirm ? (
          <button onClick={() => setDeleteConfirm(true)}
            className="px-4 py-2 text-sm font-semibold text-white bg-red-600 rounded-xl hover:bg-red-700 transition-colors flex items-center gap-2">
            <Trash2 className="w-4 h-4" /> Delete Account
          </button>
        ) : (
          <div className="space-y-3">
            <p className="text-sm font-medium text-red-700">
              Type <strong>DELETE</strong> to confirm.
            </p>
            <input
              value={deleteText}
              onChange={(e) => setDeleteText(e.target.value)}
              placeholder='Type DELETE to confirm'
              className="w-full px-3 py-2 rounded-xl border border-red-200 focus:outline-none focus:ring-2 focus:ring-red-500/50 text-sm"
            />
            <div className="flex gap-2">
              <button onClick={() => { setDeleteConfirm(false); setDeleteText('') }}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900 transition-colors flex items-center gap-1">
                <X className="w-4 h-4" /> Cancel
              </button>
              <button
                onClick={handleDeleteAccount}
                disabled={deleteText !== 'DELETE' || deleting}
                className="px-4 py-2 text-sm font-semibold text-white bg-red-600 rounded-xl hover:bg-red-700 disabled:opacity-50 transition-colors flex items-center gap-2"
              >
                {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                Confirm Delete
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
