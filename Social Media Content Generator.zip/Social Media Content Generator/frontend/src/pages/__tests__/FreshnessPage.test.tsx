import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import { BrowserRouter } from 'react-router-dom'
import { normalizeFreshness, FreshnessPage } from '@/pages/FreshnessPage'

const mockGetBrandFatigue = vi.fn()

vi.mock('@/api/endpoints', () => ({
  getBrandFatigue: (...args: unknown[]) => mockGetBrandFatigue(...args),
}))

vi.mock('@/components/layout/BrandWorkspaceLayout', () => ({
  useBrandWorkspace: () => ({
    brandId: 1,
    brand: { id: 1, name: 'Test Brand' },
    refetchBrand: vi.fn(),
  }),
}))

function renderPage() {
  return render(
    <BrowserRouter>
      <FreshnessPage />
    </BrowserRouter>,
  )
}

// ---------- normalizeFreshness pure-function tests ----------

describe('normalizeFreshness', () => {
  it('returns defaults for null input', () => {
    const result = normalizeFreshness(null)
    expect(result.fatigue_score).toBe(0)
    expect(result.total_campaigns).toBe(0)
    expect(result.total_posts).toBe(0)
    expect(result.repeated_themes).toEqual({})
    expect(result.cta_diversity).toBe(0)
    expect(result.recommendations).toEqual([])
    expect(result.status).toBeUndefined()
  })

  it('returns defaults for undefined input', () => {
    const result = normalizeFreshness(undefined)
    expect(result.fatigue_score).toBe(0)
    expect(result.total_campaigns).toBe(0)
    expect(result.repeated_themes).toEqual({})
    expect(result.recommendations).toEqual([])
  })

  it('passes through complete response', () => {
    const data = {
      status: undefined,
      fatigue_score: 0.45,
      total_campaigns: 5,
      total_posts: 23,
      repeated_themes: { promo: 4, educational: 3 },
      cta_diversity: 3,
      recommendations: ['Vary your CTAs more'],
    }
    const result = normalizeFreshness(data as unknown as Record<string, unknown>)
    expect(result.fatigue_score).toBe(0.45)
    expect(result.total_campaigns).toBe(5)
    expect(result.total_posts).toBe(23)
    expect(result.repeated_themes).toEqual({ promo: 4, educational: 3 })
    expect(result.cta_diversity).toBe(3)
    expect(result.recommendations).toEqual(['Vary your CTAs more'])
  })

  it('fills missing arrays with []', () => {
    const result = normalizeFreshness({ fatigue_score: 0 } as unknown as Record<string, unknown>)
    expect(result.recommendations).toEqual([])
  })

  it('fills missing object maps with {}', () => {
    const result = normalizeFreshness({ fatigue_score: 0 } as unknown as Record<string, unknown>)
    expect(result.repeated_themes).toEqual({})
  })

  it('handles null values in response', () => {
    const result = normalizeFreshness({
      fatigue_score: null,
      total_campaigns: null,
      total_posts: null,
      repeated_themes: null,
      cta_diversity: null,
      recommendations: null,
    } as unknown as Record<string, unknown>)
    expect(result.fatigue_score).toBe(0)
    expect(result.total_campaigns).toBe(0)
    expect(result.total_posts).toBe(0)
    expect(result.repeated_themes).toEqual({})
    expect(result.cta_diversity).toBe(0)
    expect(result.recommendations).toEqual([])
  })

  it('handles non-object repeated_themes gracefully', () => {
    const result = normalizeFreshness({
      repeated_themes: 'string',
    } as unknown as Record<string, unknown>)
    expect(result.repeated_themes).toEqual({})
  })

  it('handles non-array recommendations gracefully', () => {
    const result = normalizeFreshness({
      recommendations: 'string',
    } as unknown as Record<string, unknown>)
    expect(result.recommendations).toEqual([])
  })

  it('preserves insufficient_data status', () => {
    const result = normalizeFreshness({
      status: 'insufficient_data',
      fatigue_score: 0,
      recommendations: ['No data'],
    } as unknown as Record<string, unknown>)
    expect(result.status).toBe('insufficient_data')
    expect(result.recommendations).toEqual(['No data'])
  })
})

// ---------- FreshnessPage integration tests ----------

describe('FreshnessPage', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('shows loading spinner initially', () => {
    mockGetBrandFatigue.mockReturnValue(new Promise(() => {}))
    renderPage()
    const spinner = document.querySelector('.animate-spin')
    expect(spinner).toBeInTheDocument()
  })

  it('renders analysis data on complete response', async () => {
    mockGetBrandFatigue.mockResolvedValue({
      fatigue_score: 0.3,
      total_campaigns: 5,
      total_posts: 20,
      repeated_themes: { promo: 3 },
      cta_diversity: 4,
      recommendations: ['Good diversity'],
    })
    renderPage()
    await waitFor(() => {
      expect(screen.getByText('30%')).toBeInTheDocument()
    })
    expect(screen.getByText('5')).toBeInTheDocument()
    expect(screen.getByText('20')).toBeInTheDocument()
    expect(screen.getByText('Good diversity')).toBeInTheDocument()
  })

  it('renders insufficient data state for status insufficient_data', async () => {
    mockGetBrandFatigue.mockResolvedValue({
      status: 'insufficient_data',
      fatigue_score: 0,
      total_campaigns: 0,
      total_posts: 0,
      repeated_themes: {},
      cta_diversity: 0,
      recommendations: ['No campaign history yet — start with fresh content'],
    })
    renderPage()
    await waitFor(() => {
      expect(screen.getByText('Not enough campaign history yet')).toBeInTheDocument()
    })
    expect(
      screen.getByText('No campaign history yet — start with fresh content'),
    ).toBeInTheDocument()
  })

  it('does not crash on partial response with only fatigue_score and recommendations', async () => {
    mockGetBrandFatigue.mockResolvedValue({
      fatigue_score: 0.0,
      recommendations: ['No campaign history yet — start with fresh content'],
    })
    renderPage()
    await waitFor(() => {
      expect(screen.getAllByText('0%').length).toBeGreaterThanOrEqual(1)
    })
    expect(screen.getByText('No campaign history yet — start with fresh content')).toBeInTheDocument()
  })

  it('shows Retry on backend failure', async () => {
    mockGetBrandFatigue.mockRejectedValue(new Error('Network error'))
    renderPage()
    await waitFor(() => {
      expect(screen.getByText('Retry')).toBeInTheDocument()
    })
    expect(screen.getByText('Could not load fatigue analysis.')).toBeInTheDocument()
  })

  it('200 insufficient_data response does not trigger error boundary', async () => {
    mockGetBrandFatigue.mockResolvedValue({
      status: 'insufficient_data',
      fatigue_score: 0,
      total_campaigns: 0,
      total_posts: 0,
      repeated_themes: {},
      cta_diversity: 0,
      recommendations: ['Not enough data'],
    })
    renderPage()
    await waitFor(() => {
      expect(screen.getByText('Not enough campaign history yet')).toBeInTheDocument()
    })
    expect(screen.queryByText('Retry')).not.toBeInTheDocument()
    expect(screen.queryByText('Something went wrong')).not.toBeInTheDocument()
  })

  it('renders empty recommendations safely', async () => {
    mockGetBrandFatigue.mockResolvedValue({
      fatigue_score: 0.5,
      total_campaigns: 3,
      total_posts: 10,
      repeated_themes: {},
      cta_diversity: 5,
      recommendations: [],
    })
    renderPage()
    await waitFor(() => {
      expect(screen.getByText('50%')).toBeInTheDocument()
    })
    expect(screen.getByText('No recommendations available.')).toBeInTheDocument()
  })

  it('renders empty repeated themes safely', async () => {
    mockGetBrandFatigue.mockResolvedValue({
      fatigue_score: 0.2,
      total_campaigns: 2,
      total_posts: 5,
      repeated_themes: {},
      cta_diversity: 3,
      recommendations: ['Keep it up'],
    })
    renderPage()
    await waitFor(() => {
      expect(screen.getByText('20%')).toBeInTheDocument()
    })
    expect(screen.getByText('No repeated themes detected.')).toBeInTheDocument()
  })
})
