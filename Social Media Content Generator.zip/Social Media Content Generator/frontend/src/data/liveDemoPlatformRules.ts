import type { PlatformKey, LiveDemoCaption } from './liveDemoBaseData'

interface PlatformRule {
  label: string
  getContentType: (day: number) => string
  getPostingTime: (day: number) => string
  getHashtags: () => string[]
  rewriteIdea: (baseIdea: string) => string
  buildCaption: (params: { day: number; toneModifier: string }) => LiveDemoCaption
}

const PLATFORM_LABELS: Record<PlatformKey, string> = {
  instagram: 'Instagram',
  linkedin: 'LinkedIn',
  tiktok: 'TikTok',
  facebook: 'Facebook',
  x: 'X',
}

export function getPlatformLabel(key: PlatformKey): string {
  return PLATFORM_LABELS[key]
}

const INSTAGRAM_TYPES: Record<number, string> = {
  1: 'Carousel',
  2: 'Reel',
  3: 'Static Post',
  4: 'Reel',
  5: 'Carousel',
  6: 'Static Post',
  7: 'Carousel',
}

const INSTAGRAM_TIMES: Record<number, string> = {
  1: '9:00 AM',
  2: '10:00 AM',
  3: '12:00 PM',
  4: '2:00 PM',
  5: '11:00 AM',
  6: '5:00 PM',
  7: '9:00 AM',
}

const LINKEDIN_TYPES: Record<number, string> = {
  1: 'Industry Insight',
  2: 'Document Carousel',
  3: 'Founder Story',
  4: 'Case Study',
  5: 'Professional Update',
  6: 'Thought Leadership',
  7: 'Article',
}

const LINKEDIN_TIMES: Record<number, string> = {
  1: '8:30 AM',
  2: '10:00 AM',
  3: '12:00 PM',
  4: '9:00 AM',
  5: '11:00 AM',
  6: '1:00 PM',
  7: '9:30 AM',
}

const TIKTOK_TYPES: Record<number, string> = {
  1: 'Short Video',
  2: 'Quick Tutorial',
  3: 'POV',
  4: 'Behind the Scenes',
  5: 'Trend-Led Concept',
  6: 'Q&A Video',
  7: 'Conversion Video',
}

const TIKTOK_TIMES: Record<number, string> = {
  1: '7:00 AM',
  2: '11:00 AM',
  3: '3:00 PM',
  4: '5:00 PM',
  5: '12:00 PM',
  6: '6:00 PM',
  7: '8:00 AM',
}

const FACEBOOK_TYPES: Record<number, string> = {
  1: 'Community Post',
  2: 'Educational Post',
  3: 'Customer Story',
  4: 'Photo Update',
  5: 'Event Post',
  6: 'Discussion Post',
  7: 'Announcement',
}

const FACEBOOK_TIMES: Record<number, string> = {
  1: '9:00 AM',
  2: '10:00 AM',
  3: '1:00 PM',
  4: '3:00 PM',
  5: '11:00 AM',
  6: '5:00 PM',
  7: '9:00 AM',
}

const X_TYPES: Record<number, string> = {
  1: 'Post',
  2: 'Thread',
  3: 'Quick Take',
  4: 'Behind the Scenes',
  5: 'Announcement',
  6: 'Poll',
  7: 'Conversion Post',
}

const X_TIMES: Record<number, string> = {
  1: '8:00 AM',
  2: '10:00 AM',
  3: '1:00 PM',
  4: '3:00 PM',
  5: '11:00 AM',
  6: '5:00 PM',
  7: '9:00 AM',
}

const INSTAGRAM_HASHTAGS = [
  '#UrbanBrewStudio',
  '#SpecialtyCoffee',
  '#CoffeeCulture',
  '#StudyCafe',
  '#LiveMusic',
  '#CafeLife',
  '#ColdBrew',
  '#ArtisanCoffee',
]

const LINKEDIN_HASHTAGS = [
  '#Hospitality',
  '#CustomerExperience',
  '#LocalBusiness',
  '#CoffeeIndustry',
  '#SmallBusiness',
]

const TIKTOK_HASHTAGS = [
  '#CafeTok',
  '#CoffeeTok',
  '#UrbanBrewStudio',
  '#StudySpot',
  '#CoffeeLovers',
]

const FACEBOOK_HASHTAGS = [
  '#UrbanBrewStudio',
  '#LocalCafe',
  '#Community',
  '#CoffeeTime',
]

const X_HASHTAGS = [
  '#UrbanBrewStudio',
  '#CoffeeCulture',
]

const INSTAGRAM_IDEAS: Record<number, string> = {
  1: 'The origin of our roasting philosophy in a visual story',
  2: 'How to brew the perfect cold brew at home',
  3: 'Feature a regular customer and their morning ritual',
  4: 'Roasting process and quality control behind the scenes',
  5: 'New seasonal blend launch with tasting notes',
  6: 'Q&A session invitation for coffee lovers',
  7: 'Subscription service announcement with benefits',
}

const LINKEDIN_IDEAS: Record<number, string> = {
  1: 'Building a coffee brand that values relationships over transactions',
  2: 'The economics of specialty coffee and what drives quality',
  3: 'How a local café became a community hub for professionals',
  4: 'Sourcing ethics and direct trade partnerships explained',
  5: 'Lessons from scaling a small-batch roastery',
  6: 'Why third spaces matter for urban productivity',
  7: 'A new approach to coffee subscriptions for businesses',
}

const TIKTOK_IDEAS: Record<number, string> = {
  1: 'POV walking into your new favorite coffee spot',
  2: '30-second guide to pouring the perfect latte art',
  3: 'Meet the barista who knows your order by heart',
  4: 'What happens inside a roastery every morning',
  5: 'Tasting three seasonal blends blindfolded',
  6: 'Answering your most asked coffee questions',
  7: 'Why our subscription is worth every penny',
}

const FACEBOOK_IDEAS: Record<number, string> = {
  1: 'What makes Urban Brew Studio different from other cafes',
  2: 'Tips for hosting a coffee tasting at home with friends',
  3: 'Share a customer story about finding community here',
  4: 'Photo gallery of our new autumn menu items',
  5: 'Announcing our upcoming acoustic night event',
  6: 'What is your go-to coffee order? Let us discuss',
  7: 'Join our Coffee Club for exclusive perks and events',
}

const X_IDEAS: Record<number, string> = {
  1: 'Why we source single-origin beans directly from farmers',
  2: 'A quick thread on everything we learned about roasting',
  3: 'Hot take: cold brew is a productivity ritual, not just a drink',
  4: 'A look inside our roastery this morning',
  5: 'New seasonal blend drops this Friday',
  6: 'Poll: oat milk or whole milk in your flat white',
  7: 'Our subscription is now available in all 50 states',
}

function buildInstagramCaption(day: number, toneModifier: string): LiveDemoCaption {
  const captions: Record<number, { caption: string; cta: string }> = {
    1: {
      caption: `Every cup at Urban Brew Studio starts with a single origin bean. Our master roasters travel directly to farms in Colombia and Ethiopia to source the finest specialty-grade coffee. We slow-roast in small batches to preserve the unique flavor profile of each region.${toneModifier}`,
      cta: 'Visit us downtown and taste the difference.',
    },
    2: {
      caption: `Master the pour-over in three simple steps. Start with 18g of freshly ground coffee. Heat your water to 96\u00b0C. Pour in slow spirals starting from the center outward. The result is a clean, bright cup that highlights every tasting note.${toneModifier}`,
      cta: 'Save this for your morning routine.',
    },
    3: {
      caption: `Meet Sarah. She has started every morning at Urban Brew Studio for the past two years. "It is my creative space," she says. "The oat milk latte and the natural light. That is where my best ideas come from."${toneModifier}`,
      cta: 'Tag your coffee buddy in the comments.',
    },
    4: {
      caption: `Behind the roastery doors. Every batch is tested for color, aroma, and extraction time before it reaches your cup. Our head roaster Marco has been perfecting this craft for 12 years. He still tastes every single batch.${toneModifier}`,
      cta: 'Come see the roastery in action.',
    },
    5: {
      caption: `Introducing our Autumn Harvest Blend. Tasting notes of dark chocolate, dried cherry, and a hint of cedar. This limited release is available for four weeks only. Pair it with our house-made oat milk for the ultimate fall experience.${toneModifier}`,
      cta: 'Grab a bag before it is gone.',
    },
    6: {
      caption: `You asked, we answer. This Friday at 3 PM, our head roaster Marco is hosting a live Q&A on everything coffee. Drop your questions in the comments and we will cover them during the session.${toneModifier}`,
      cta: 'Drop your question below.',
    },
    7: {
      caption: `Never run out of great coffee. Our new subscription delivers freshly roasted beans to your door every two weeks. Choose your blend, set your schedule, and enjoy 10% off every order.${toneModifier}`,
      cta: 'Link in bio to start your subscription.',
    },
  }
  return { day, ...(captions[day] ?? { caption: `Day ${day} content for Urban Brew Studio.${toneModifier}`, cta: 'Learn more.' }) }
}

function buildLinkedInCaption(day: number, toneModifier: string): LiveDemoCaption {
  const captions: Record<number, { caption: string; cta: string }> = {
    1: {
      caption: `Urban Brew Studio was designed around a simple idea: productive spaces should also feel human. By combining specialty coffee, flexible work areas, and live creative experiences, the cafe gives students and professionals a place to focus and connect.${toneModifier}`,
      cta: 'What makes a space genuinely work-friendly for you?',
    },
    2: {
      caption: `The specialty coffee industry has a transparency problem. Most drinkers do not know where their beans come from or how they were processed. Urban Brew Studio publishes every sourcing detail online. Farm name. Region. Elevation. Processing method. Price paid per pound.${toneModifier}`,
      cta: 'Share your thoughts on supply chain transparency.',
    },
    3: {
      caption: `Two years ago, we opened our doors with a simple mission: create a space where students and freelancers could work without buying overpriced coffee. Today, Urban Brew Studio hosts three open mic nights a week and serves over 500 regulars.${toneModifier}`,
      cta: 'Read our full story on the blog.',
    },
    4: {
      caption: `Direct trade is not just a label. It is a partnership. Urban Brew Studio works directly with farms in Colombia and Ethiopia, paying 30% above fair-trade prices. The result is higher quality coffee and sustainable livelihoods for growers.${toneModifier}`,
      cta: 'Learn more about our sourcing practices.',
    },
    5: {
      caption: `Launching a seasonal blend taught us more about our business than any quarterly report. Customer feedback came in within hours of release. The data shaped our purchasing, our menu design, and our staffing for the season.${toneModifier}`,
      cta: 'How does customer feedback shape your product decisions?',
    },
    6: {
      caption: `Third spaces are disappearing. Between remote work and digital isolation, the places where communities naturally form are vanishing. Urban Brew Studio is an experiment in reversing that trend, one espresso at a time.${toneModifier}`,
      cta: 'Why third spaces matter more than ever.',
    },
    7: {
      caption: `Introducing Urban Brew Studio Subscriptions. Freshly roasted coffee delivered to your home or office every two weeks. Customizable blend preferences. Flexible scheduling. Free shipping.${toneModifier}`,
      cta: 'Start your subscription today.',
    },
  }
  return { day, ...(captions[day] ?? { caption: `Professional insights from Urban Brew Studio.${toneModifier}`, cta: 'Join the discussion.' }) }
}

function buildTikTokCaption(day: number, toneModifier: string): LiveDemoCaption {
  const captions: Record<number, { caption: string; cta: string }> = {
    1: {
      caption: `POV: you just found the coffee spot where deadlines, playlists, and a proper cold brew finally make sense. Urban Brew Studio is your new study-break headquarters.${toneModifier}`,
      cta: 'Follow for more coffee content.',
    },
    2: {
      caption: `30 seconds to better coffee. Grind size matters. Water temperature matters. Pour technique matters. Watch until the end for the pro tip that changes everything.${toneModifier}`,
      cta: 'Save this for your next brew.',
    },
    3: {
      caption: `Meet Marco. He has been a barista for 12 years and still learns something new every week. This is what passion looks like.${toneModifier}`,
      cta: 'Comment your favorite coffee order.',
    },
    4: {
      caption: `Ever wonder what happens before your coffee reaches the cup? This is our roastery at 6 AM on a Tuesday. The smell is unreal.${toneModifier}`,
      cta: 'Stitch this with your coffee setup.',
    },
    5: {
      caption: `Trying three new seasonal blends so you do not have to. Spoiler: one of them tastes like liquid dark chocolate.${toneModifier}`,
      cta: 'Which one would you try?',
    },
    6: {
      caption: `Answering your most asked coffee questions in 60 seconds. Yes, cold brew has more caffeine. No, you should not store beans in the fridge.${toneModifier}`,
      cta: 'Drop your question for part two.',
    },
    7: {
      caption: `Fresh coffee. Delivered. Every two weeks. Our subscription is the easiest way to never run out of great beans.${toneModifier}`,
      cta: 'Link in bio to subscribe.',
    },
  }
  return { day, ...(captions[day] ?? { caption: `Urban Brew Studio TikTok content.${toneModifier}`, cta: 'Follow for more.' }) }
}

function buildFacebookCaption(day: number, toneModifier: string): LiveDemoCaption {
  const captions: Record<number, { caption: string; cta: string }> = {
    1: {
      caption: `We opened Urban Brew Studio because we believed a coffee shop could be more than a place to grab a drink. It could be a community hub. A workspace. A venue for local musicians. A place where people actually know your name. Two years later, we are proud to say it worked.${toneModifier}`,
      cta: 'Tell us about your favorite local spot below.',
    },
    2: {
      caption: `Hosting a coffee tasting at home is easier than you think. Pick three single-origin coffees. Use the same brewing method for each. Take notes on aroma, flavor, and finish. Invite friends and compare notes. It is a great way to learn what you actually like.${toneModifier}`,
      cta: 'Tag a friend who would love a coffee tasting night.',
    },
    3: {
      caption: `One of our favorite things about running Urban Brew Studio is watching regulars become friends. James started coming here during his PhD. Now he runs a study group that meets here every Saturday morning. Community happens naturally when you create the right space.${toneModifier}`,
      cta: 'Share your Urban Brew Studio story with us.',
    },
    4: {
      caption: `Our autumn menu is here and we are obsessed. New pumpkin spice cold brew, house-made cinnamon syrup, and a salted caramel latte that tastes like dessert. Come try them all.${toneModifier}`,
      cta: 'Tag someone you are bringing for a fall coffee date.',
    },
    5: {
      caption: `Acoustic Night is back. This Friday at 7 PM, join us for live performances from three local artists. Free entry. Great coffee. Good vibes. Bring your friends.${toneModifier}`,
      cta: 'Click going to save your spot.',
    },
    6: {
      caption: `Question for our Urban Brew Studio community: what is your go-to coffee order? We will feature the best answers in our next post. Extra points for creativity.${toneModifier}`,
      cta: 'Comment your order below.',
    },
    7: {
      caption: `Good news for everyone who wishes they could wake up to Urban Brew Studio every morning. Our Coffee Club subscription is live. Fresh beans every two weeks. Free shipping. Cancel anytime.${toneModifier}`,
      cta: 'Sign up through our page.',
    },
  }
  return { day, ...(captions[day] ?? { caption: `Urban Brew Studio community update.${toneModifier}`, cta: 'Share your thoughts below.' }) }
}

function buildXCaption(day: number, toneModifier: string): LiveDemoCaption {
  const captions: Record<number, { caption: string; cta: string }> = {
    1: {
      caption: `We travel to coffee farms so you do not have to. Direct trade means better beans and better relationships.${toneModifier}`,
      cta: 'Reply with your go-to coffee origin.',
    },
    2: {
      caption: `Thread: Everything we learned about roasting coffee in one place. 1/ Start with green beans that taste good raw. 2/ Profile each bean for optimal development. 3/ Rest for 3-5 days before brewing. 4/ Trust your palate over the numbers.${toneModifier}`,
      cta: 'Follow for part two.',
    },
    3: {
      caption: `Cold brew is not a summer drink. It is a productivity ritual that happens to be cold. Do not let anyone tell you otherwise.${toneModifier}`,
      cta: 'Repost if you agree.',
    },
    4: {
      caption: `6 AM at the roastery. The smell of freshly ground Ethiopian Yirgacheffe. This is how we start every day.${toneModifier}`,
      cta: 'Drop a coffee emoji if you get it.',
    },
    5: {
      caption: `New seasonal blend drops this Friday. Dark chocolate, dried cherry, cedar finish. Limited batch. First come, first served.${toneModifier}`,
      cta: 'Set a reminder.',
    },
    6: {
      caption: `Oat milk or whole milk in a flat white? We are settling this once and for all.${toneModifier}`,
      cta: 'Vote, then reply with your case.',
    },
    7: {
      caption: `Urban Brew Studio subscriptions now available nationwide. Fresh coffee, every two weeks, zero commitment.${toneModifier}`,
      cta: 'DM us for a discount code.',
    },
  }
  return { day, ...(captions[day] ?? { caption: `Urban Brew Studio update.${toneModifier}`, cta: 'Reply to this post.' }) }
}

const PLATFORM_RULES: Record<PlatformKey, PlatformRule> = {
  instagram: {
    label: 'Instagram',
    getContentType: (day) => INSTAGRAM_TYPES[day] ?? 'Static Post',
    getPostingTime: (day) => INSTAGRAM_TIMES[day] ?? '9:00 AM',
    getHashtags: () => [...INSTAGRAM_HASHTAGS],
    rewriteIdea: (base) => base,
    buildCaption: (params) => buildInstagramCaption(params.day, params.toneModifier),
  },
  linkedin: {
    label: 'LinkedIn',
    getContentType: (day) => LINKEDIN_TYPES[day] ?? 'Industry Insight',
    getPostingTime: (day) => LINKEDIN_TIMES[day] ?? '9:00 AM',
    getHashtags: () => [...LINKEDIN_HASHTAGS],
    rewriteIdea: (base) => base,
    buildCaption: (params) => buildLinkedInCaption(params.day, params.toneModifier),
  },
  tiktok: {
    label: 'TikTok',
    getContentType: (day) => TIKTOK_TYPES[day] ?? 'Short Video',
    getPostingTime: (day) => TIKTOK_TIMES[day] ?? '8:00 AM',
    getHashtags: () => [...TIKTOK_HASHTAGS],
    rewriteIdea: (base) => base,
    buildCaption: (params) => buildTikTokCaption(params.day, params.toneModifier),
  },
  facebook: {
    label: 'Facebook',
    getContentType: (day) => FACEBOOK_TYPES[day] ?? 'Community Post',
    getPostingTime: (day) => FACEBOOK_TIMES[day] ?? '9:00 AM',
    getHashtags: () => [...FACEBOOK_HASHTAGS],
    rewriteIdea: (base) => base,
    buildCaption: (params) => buildFacebookCaption(params.day, params.toneModifier),
  },
  x: {
    label: 'X',
    getContentType: (day) => X_TYPES[day] ?? 'Post',
    getPostingTime: (day) => X_TIMES[day] ?? '8:00 AM',
    getHashtags: () => [...X_HASHTAGS],
    rewriteIdea: (base) => base,
    buildCaption: (params) => buildXCaption(params.day, params.toneModifier),
  },
}

const PLATFORM_IDEAS: Record<PlatformKey, Record<number, string>> = {
  instagram: INSTAGRAM_IDEAS,
  linkedin: LINKEDIN_IDEAS,
  tiktok: TIKTOK_IDEAS,
  facebook: FACEBOOK_IDEAS,
  x: X_IDEAS,
}

export function getPlatformRule(platform: PlatformKey): PlatformRule {
  return PLATFORM_RULES[platform]
}

export function getPlatformIdea(platform: PlatformKey, day: number): string {
  return PLATFORM_IDEAS[platform]?.[day] ?? `Day ${day} content.`
}
