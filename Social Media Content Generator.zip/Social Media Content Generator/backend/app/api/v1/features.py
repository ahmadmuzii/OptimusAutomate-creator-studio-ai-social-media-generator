from __future__ import annotations

from fastapi import APIRouter

from app.api.deps_features import get_public_feature_flags

router = APIRouter(tags=["Features"])


@router.get("/feature-flags")
def feature_flags():
    return get_public_feature_flags()
