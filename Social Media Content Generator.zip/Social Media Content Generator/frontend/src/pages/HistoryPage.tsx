import { useEffect, useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Clock, Trash2, Eye, Search, X, Copy,
  Download, AlertTriangle, Loader2,
} from 'lucide-react'
import * as api from '@/api/endpoints'
import type { CampaignData } from '@/types/common'
import { ROUTES } from '@/routes/paths'
import { PageTransition } from '@/components/layout/PageTransition'
import { useToast } from '@/components/ui/Toast'
import { Skeleton, CardSkeleton } from '@/components/ui/Skeleton'

const statusColors: Record<string, string> = {
  draft: 'bg-yellow-50 text-yellow-700 border-yellow-200',
  ready: 'bg-purple-50 text-purple-700 border-purple-200',
  scheduled: 'bg-blue-50 text-blue-700 border-blue-200',
  published: 'bg-green-50 text-green-700 border-green-200',
  archived: 'bg-gray-50 text-gray-600 border-gray-200',
}

export function HistoryPage() {
  const { showToast } = useToast()
  const [campaigns, setCampaigns] = useState<CampaignData[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [platformFilter, setPlatformFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [deleteTarget, setDeleteTarget] = useState<CampaignData | null>(null)
  const [deleting, setDeleting] = useState(false)
  const [duplicatingId, setDuplicatingId] = useState<number | null>(null)

  const load = () => {
    api.fetchCampaigns()
      .then(setCampaigns)
      .catch(() => setCampaigns([]))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const handleDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      await api.deleteCampaign(deleteTarget.id)
      setCampaigns((prev) => prev.filter((c) => c.id !== deleteTarget.id))
      showToast('Campaign deleted.', 'success')
      setDeleteTarget(null)
    } catch {
      showToast('Failed to delete campaign.', 'error')
    }
    setDeleting(false)
  }

  const handleDuplicate = async (c: CampaignData) => {
    setDuplicatingId(c.id)
    try {
      await api.createCampaign({
        name: `${c.name} (Copy)`,
        platform: c.platform,
        tone: c.tone,
        campaign_goal: c.campaign_goal,
        brand_profile_id: c.brand_profile_id,
        posts: c.posts?.map((p) => ({
          ...p,
        })) || null,
      })
      load()
      showToast('Campaign duplicated.', 'success')
    } catch {
      showToast('Failed to duplicate campaign.', 'error')
    }
    setDuplicatingId(null)
  }

  const handleExportJson = (c: CampaignData) => {
    const blob = new Blob([JSON.stringify(c, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${c.name.replace(/[^a-zA-Z0-9]/g, '_')}.json`
    a.click()
    URL.revokeObjectURL(url)
    showToast('Exported as JSON.', 'success')
  }

  const handleCopyAll = async (c: CampaignData) => {
    const text = c.posts?.map((p) =>
      `Day ${p.day}: ${p.content_theme}\n${p.caption}\n${p.call_to_action || ''}\n${(p.hashtags || []).join(' ')}`
    ).join('\n\n') || c.name
    try {
      await navigator.clipboard.writeText(text)
      showToast('Campaign content copied.', 'success')
    } catch {
      showToast('Failed to copy.', 'error')
    }
  }

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr)
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })
  }

  const platforms = useMemo(() => {
    const set = new Set(campaigns.map((c) => c.platform))
    return Array.from(set).sort()
  }, [campaigns])

  const filtered = useMemo(() => {
    let result = [...campaigns]
    if (search.trim()) {
      const q = search.toLowerCase()
      result = result.filter((c) =>
        c.name.toLowerCase().includes(q) ||
        c.campaign_goal.toLowerCase().includes(q)
      )
    }
    if (platformFilter) {
      result = result.filter((c) => c.platform === platformFilter)
    }
    if (statusFilter) {
      result = result.filter((c) => c.status === statusFilter)
    }
    return result
  }, [campaigns, search, platformFilter, statusFilter])

  if (loading) {
    return (
      <PageTransition>
        <div className="max-w-5xl mx-auto space-y-6">
          <Skeleton className="h-7 w-24 mb-2" />
          <Skeleton className="h-4 w-44" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {Array.from({ length: 4 }).map((_, i) => <CardSkeleton key={i} />)}
          </div>
        </div>
      </PageTransition>
    )
  }

  return (
    <PageTransition>
      <div className="max-w-5xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">History</h1>
          <p className="text-gray-500 mt-1">View and manage your past generated campaigns.</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search campaigns..."
              className="pl-9 pr-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm w-full"
            />
          </div>
          <select
            value={platformFilter}
            onChange={(e) => setPlatformFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-sm bg-white text-gray-700"
          >
            <option value="">All platforms</option>
            {platforms.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-sm bg-white text-gray-700"
          >
            <option value="">All statuses</option>
            <option value="draft">Draft</option>
            <option value="scheduled">Scheduled</option>
            <option value="published">Published</option>
          </select>
          {(search || platformFilter || statusFilter) && (
            <button
              onClick={() => { setSearch(''); setPlatformFilter(''); setStatusFilter('') }}
              className="flex items-center gap-1 text-xs text-gray-500 hover:text-gray-700 px-2 py-1"
            >
              <X className="w-3 h-3" /> Clear
            </button>
          )}
        </div>

        {/* Empty */}
        {filtered.length === 0 && (
          <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
            <Clock className="w-8 h-8 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-400 text-sm">
              {search || platformFilter || statusFilter ? 'No campaigns match your filters.' : 'No campaign history yet.'}
            </p>
          </div>
        )}

        {/* Campaign cards */}
        {filtered.length > 0 && (
          <div className="space-y-3">
            {filtered.map((c, i) => (
              <motion.div
                key={c.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03, duration: 0.25 }}
                className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-gray-900 text-sm truncate">{c.name}</h3>
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${statusColors[c.status] || statusColors.draft}`}>
                        {c.status}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-gray-400">
                      <span>{c.platform}</span>
                      <span className="text-gray-300">&middot;</span>
                      <span>{c.tone.replace(/_/g, ' ')}</span>
                      <span className="text-gray-300">&middot;</span>
                      <span>{c.posts?.length || 0} posts</span>
                      <span className="text-gray-300">&middot;</span>
                      <span>{formatDate(c.created_at)}</span>
                    </div>
                    <p className="text-xs text-gray-400 mt-1 line-clamp-1">Goal: {c.campaign_goal}</p>
                  </div>
                  <div className="flex items-center gap-1 ml-4 shrink-0">
                    <button
                      onClick={() => window.open(ROUTES.calendar, '_blank')}
                      className="p-2 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-purple-600 transition-colors"
                      title="View in Calendar"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleCopyAll(c)}
                      className="p-2 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-blue-600 transition-colors"
                      title="Copy all content"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleExportJson(c)}
                      className="p-2 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-green-600 transition-colors"
                      title="Export as JSON"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDuplicate(c)}
                      disabled={duplicatingId === c.id}
                      className="p-2 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-purple-600 transition-colors disabled:opacity-50"
                      title="Duplicate"
                    >
                      {duplicatingId === c.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Copy className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={() => setDeleteTarget(c)}
                      className="p-2 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-red-600 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Delete confirmation modal */}
        <AnimatePresence>
          {deleteTarget && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40"
              onClick={() => setDeleteTarget(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-xl"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
                    <AlertTriangle className="w-5 h-5 text-red-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 text-sm">Delete campaign?</h3>
                    <p className="text-xs text-gray-500 mt-0.5">This action cannot be undone.</p>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  Are you sure you want to delete <strong>{deleteTarget.name}</strong>?
                </p>
                <div className="flex justify-end gap-3">
                  <button
                    onClick={() => setDeleteTarget(null)}
                    className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900 rounded-xl hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleDelete}
                    disabled={deleting}
                    className="px-4 py-2 text-sm font-semibold text-white bg-red-600 rounded-xl hover:bg-red-700 transition-colors disabled:opacity-50 flex items-center gap-2"
                  >
                    {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                    Delete
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </PageTransition>
  )
}
