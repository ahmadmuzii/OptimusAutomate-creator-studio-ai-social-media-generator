import { motion } from 'framer-motion'
import { Building2, SlidersHorizontal, CalendarCheck } from 'lucide-react'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { staggerContainer, listItem } from '@/lib/animation'

const steps = [
  {
    step: 1,
    icon: Building2,
    title: 'Define your brand',
    desc: 'Enter your brand name, niche, audience, and campaign goal. Or select a saved brand profile with all your preferences ready.',
    gradient: 'from-purple-500 to-purple-600',
    preview: (
      <div className="bg-white rounded-xl border border-gray-100 p-3 space-y-2">
        <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider">Brand Brief</div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center">
            <span className="text-white text-[8px] font-bold">CS</span>
          </div>
          <div>
            <div className="text-xs font-medium text-gray-900">Creator Studio</div>
            <div className="text-[9px] text-gray-400">Software &middot; SaaS</div>
          </div>
        </div>
        <div className="text-[10px] text-gray-500">Target: SaaS founders &amp; marketers</div>
      </div>
    ),
  },
  {
    step: 2,
    icon: SlidersHorizontal,
    title: 'Choose your strategy',
    desc: 'Select the platform, tone, audience, and campaign goal. The AI builds a strategy around your choices.',
    gradient: 'from-violet-500 to-purple-600',
    preview: (
      <div className="bg-white rounded-xl border border-gray-100 p-3 space-y-2">
        <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider">Campaign Settings</div>
        <div className="flex gap-1.5">
          {['Professional', 'Casual', 'Bold'].map((t) => (
            <span key={t} className="text-[9px] px-2 py-0.5 rounded-full bg-purple-100 text-purple-600">{t}</span>
          ))}
        </div>
        <div className="flex gap-1.5">
          {['Instagram', 'LinkedIn', 'TikTok'].map((p) => (
            <span key={p} className="text-[9px] px-2 py-0.5 rounded-full bg-gray-100 text-gray-500">{p}</span>
          ))}
        </div>
      </div>
    ),
  },
  {
    step: 3,
    icon: CalendarCheck,
    title: 'Launch your content week',
    desc: 'Review the 7-day calendar, edit captions, adjust post ideas, and manage your campaign from one dashboard.',
    gradient: 'from-fuchsia-500 to-purple-600',
    preview: (
      <div className="bg-white rounded-xl border border-gray-100 p-3 space-y-2">
        <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider">Campaign Preview</div>
        <div className="grid grid-cols-3 gap-1.5">
          {['Brand Story', 'Educational', 'Showcase'].map((t, i) => (
            <div key={i} className="bg-gray-50 rounded-lg p-1.5 text-center">
              <div className="text-[8px] font-bold text-purple-600">Day {i + 1}</div>
              <div className="text-[8px] text-gray-600 truncate">{t}</div>
            </div>
          ))}
        </div>
        <div className="text-[9px] text-gray-400">+ 4 more days &middot; Full calendar ready</div>
      </div>
    ),
  },
]

export function ProductWalkthrough() {
  const reduced = useReducedMotionPreference()

  return (
    <section id="features" className="py-20 bg-gray-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            Three steps to a complete campaign
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            No complex setup. No training required.
          </p>
        </div>

        <motion.div
          variants={reduced ? undefined : staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          className="grid md:grid-cols-3 gap-8"
        >
          {steps.map((s) => (
            <motion.div
              key={s.step}
              variants={reduced ? undefined : listItem}
              className="relative"
            >
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm h-full">
                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${s.gradient} flex items-center justify-center shadow-md`}>
                    <s.icon className="w-5 h-5 text-white" />
                  </div>
                  <div className="w-6 h-6 rounded-full bg-gray-100 text-gray-400 text-xs font-bold flex items-center justify-center">
                    {s.step}
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{s.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed mb-4">{s.desc}</p>
                {s.preview}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
