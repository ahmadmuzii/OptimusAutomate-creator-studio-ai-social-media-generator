import axios, { type AxiosInstance, type AxiosError, type InternalAxiosRequestConfig } from 'axios'
import { env } from '@/config/env'
import { API_ENDPOINTS } from '@/config/constants'

const client: AxiosInstance = axios.create({
  baseURL: env.apiUrl,
  headers: { 'Content-Type': 'application/json' },
  timeout: 30000,
  withCredentials: true,
})

let isRefreshing = false
let failedQueue: Array<{
  resolve: (token: string) => void
  reject: (error: unknown) => void
}> = []
let onLogout: (() => void) | null = null

function processQueue(error: unknown, token: string | null = null) {
  failedQueue.forEach((prom) => {
    if (error) {
      prom.reject(error)
    } else if (token) {
      prom.resolve(token)
    }
  })
  failedQueue = []
}

export function setLogoutHandler(handler: () => void) {
  onLogout = handler
}

function getAccessToken(): string | null {
  return localStorage.getItem('token')
}

function setAccessToken(access: string) {
  localStorage.setItem('token', access)
}

function clearToken() {
  localStorage.removeItem('token')
}

client.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = getAccessToken()
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error),
)

client.interceptors.response.use(
  (response) => response,
  async (error: AxiosError<{ detail?: string }>) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean }

    if (!originalRequest || originalRequest._retry) {
      const message = error.response?.data?.detail ?? error.message ?? 'Something went wrong'
      return Promise.reject(new Error(message))
    }

    if (error.response?.status !== 401) {
      const message = error.response?.data?.detail ?? error.message ?? 'Something went wrong'
      return Promise.reject(new Error(message))
    }

    if (isRefreshing) {
      return new Promise<string>((resolve, reject) => {
        failedQueue.push({ resolve, reject })
      }).then((token) => {
        originalRequest.headers.Authorization = `Bearer ${token}`
        return client(originalRequest)
      }).catch((err) => {
        return Promise.reject(err)
      })
    }

    originalRequest._retry = true
    isRefreshing = true

    try {
      const { data } = await axios.post(
        `${env.apiUrl}${API_ENDPOINTS.auth}/refresh`,
        {},
        { withCredentials: true },
      )
      const { access_token } = data
      setAccessToken(access_token)
      processQueue(null, access_token)
      originalRequest.headers.Authorization = `Bearer ${access_token}`
      return client(originalRequest)
    } catch (refreshError) {
      processQueue(refreshError, null)
      clearToken()
      onLogout?.()
      return Promise.reject(new Error('Session expired. Please sign in again.'))
    } finally {
      isRefreshing = false
    }
  },
)

export function getClient(): AxiosInstance {
  return client
}

export { setAccessToken, clearToken, getAccessToken }

export default client
