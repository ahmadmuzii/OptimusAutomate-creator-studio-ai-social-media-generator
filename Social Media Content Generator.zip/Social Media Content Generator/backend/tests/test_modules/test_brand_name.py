from __future__ import annotations

from app.utils.brand_name import (
    format_campaign_title,
    preserve_brand_name,
    validate_campaign_texts,
)


class TestPreserveBrandName:
    def test_exact_preservation(self):
        result = preserve_brand_name(
            "Welcome to Nescafe Basement! Follow Nescafe Basement for more.",
            "Nescafe Basement",
        )
        assert "Nescafe Basement" in result
        assert result.count("Nescafe Basement") == 2

    def test_fixes_minor_typo(self):
        result = preserve_brand_name(
            "Welcome to Necafe Basement! Follow Necafe Basement for more.",
            "Nescafe Basement",
        )
        assert "Nescafe Basement" in result

    def test_multi_word_brand(self):
        result = preserve_brand_name(
            "Check out Coca Cola Company news.",
            "Coca-Cola Company",
        )
        assert "Coca-Cola Company" in result

    def test_mixed_case_preservation(self):
        result = preserve_brand_name(
            "iPhone is amazing. Get iPhone today.",
            "iPhone",
        )
        assert result == "iPhone is amazing. Get iPhone today."

    def test_brand_with_numbers(self):
        result = preserve_brand_name(
            "Windows 10 Pro is the best OS from Windows 10 Pro.",
            "Windows 10 Pro",
        )
        assert "Windows 10 Pro" in result

    def test_brand_with_punctuation(self):
        result = preserve_brand_name(
            "AT&T provides great service. Choose AT&T.",
            "AT&T",
        )
        assert "AT&T" in result

    def test_does_not_change_unrelated_words(self):
        text = "The company provides great service and products."
        result = preserve_brand_name(text, "Nescafe Basement")
        assert result == text

    def test_empty_brand_name(self):
        text = "Some text without brand."
        result = preserve_brand_name(text, "")
        assert result == text

    def test_empty_text(self):
        result = preserve_brand_name("", "Nescafe Basement")
        assert result == ""

    def test_brand_not_in_text(self):
        text = "This is completely unrelated content."
        result = preserve_brand_name(text, "SomeBrand")
        assert result == text

    def test_single_word_fix(self):
        result = preserve_brand_name("Follow Necafe", "Nescafe Basement")
        assert result == "Follow Nescafe"


class TestFormatCampaignTitle:
    def test_basic_format(self):
        result = format_campaign_title("Nescafe Basement", "instagram", "professional")
        assert result == "Nescafe Basement · Instagram · Professional Campaign"

    def test_tone_with_underscore(self):
        result = format_campaign_title("TestBrand", "linkedin", "brand_awareness")
        assert "Brand Awareness Campaign" in result

    def test_gen_z_tone(self):
        result = format_campaign_title("Brand", "tiktok", "gen_z")
        assert result == "Brand · TikTok · Gen Z Campaign"


class TestValidateCampaignTexts:
    def test_validates_all_text_fields(self):
        calendar = [
            {
                "day": 1,
                "contentTheme": "Introduction to Necafe",
                "postIdea": "Tell the story of Necafe",
                "caption": "Welcome to Necafe Basement!",
                "callToAction": "Follow Necafe",
                "contentType": "carousel",
                "suggestedTime": "9:00 AM",
                "platform": "instagram",
                "hashtags": ["#coffee"],
            },
        ]
        result = validate_campaign_texts(calendar, "Nescafe Basement")
        assert "Nescafe Basement" in result[0]["caption"]
        assert "Nescafe" in result[0]["callToAction"]
        assert "Necafe" not in result[0]["callToAction"]
        assert "Nescafe" in result[0]["contentTheme"]
        assert "Nescafe" in result[0]["postIdea"]

    def test_handles_non_text_fields(self):
        calendar = [
            {
                "day": 1,
                "hashtags": ["#test"],
                "contentTheme": "Theme",
                "postIdea": "Idea",
                "caption": "Caption",
                "callToAction": "CTA",
                "contentType": "carousel",
                "suggestedTime": "9:00 AM",
                "platform": "instagram",
            },
        ]
        result = validate_campaign_texts(calendar, "Brand")
        assert result == calendar

    def test_empty_calendar(self):
        result = validate_campaign_texts([], "Brand")
        assert result == []
