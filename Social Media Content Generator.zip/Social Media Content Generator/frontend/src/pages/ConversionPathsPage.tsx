import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'
import { ArrowLeft, Plus, Trash2, ExternalLink, Power, PowerOff, Navigation } from 'lucide-react'
import { ErrorState } from '@/components/ui/ErrorState'
import { LoadingSpinner } from '@/components/ui/LoadingSpinner'
import * as api from '@/api/endpoints'
import type { ConversionPath } from '@/types/conversion'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'

const DESTINATION_TYPES = ['website', 'landing_page', 'app', 'phone', 'email', 'social_profile']

const EMPTY_PATH = {
  name: '', destination_type: 'website', destination_value: '',
  primary_action: '', cta_keyword: '', campaign_goal: '',
  tracking_label: '', utm_source: '', utm_medium: '', utm_campaign: '',
  is_active: true,
}

export function ConversionPathsPage() {
  const { brandId, brand } = useBrandWorkspace()

  const [loading, setLoading] = useState(true)

  const [paths, setPaths] = useState<ConversionPath[]>([])
  const [editingId, setEditingId] = useState<number | 'new' | null>(null)
  const [form, setForm] = useState<Record<string, unknown>>({ ...EMPTY_PATH })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    const data = await api.fetchConversionPaths(brandId)
    setPaths(data as ConversionPath[])
  }, [brandId])

  useEffect(() => {
    load().catch(() => setError('Could not load conversion paths.')).finally(() => setLoading(false))
  }, [brandId, load])

  const startEdit = (path?: ConversionPath) => {
    if (path) {
      setEditingId(path.id)
      setForm({
        name: path.name, destination_type: path.destination_type,
        destination_value: path.destination_value, primary_action: path.primary_action || '',
        cta_keyword: path.cta_keyword || '', campaign_goal: path.campaign_goal || '',
        tracking_label: path.tracking_label || '', utm_source: path.utm_source || '',
        utm_medium: path.utm_medium || '', utm_campaign: path.utm_campaign || '',
        is_active: path.is_active,
      })
    } else {
      setEditingId('new')
      setForm({ ...EMPTY_PATH })
    }
  }

  const cancelEdit = () => { setEditingId(null); setForm({ ...EMPTY_PATH }) }

  const handleSave = async () => {
    setSaving(true)
    try {
      if (editingId === 'new') {
        await api.createConversionPath(brandId, form)
      } else {
        await api.updateConversionPath(brandId, editingId as number, form)
      }
      await load()
      cancelEdit()
    } catch { setError('Failed to save.') }
    finally { setSaving(false) }
  }

  const handleDelete = async (pathId: number) => {
    try {
      await api.deleteConversionPath(brandId, pathId)
      setPaths(prev => prev.filter(p => p.id !== pathId))
    } catch { setError('Failed to delete.') }
  }

  const toggleActive = async (path: ConversionPath) => {
    try {
      await api.updateConversionPath(brandId, path.id, { is_active: !path.is_active })
      setPaths(prev => prev.map(p => p.id === path.id ? { ...p, is_active: !p.is_active } : p))
    } catch { setError('Failed to update status.') }
  }

  if (loading) return <LoadingSpinner />

  if (error) return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>
      <ErrorState message={error} onRetry={load} />
    </div>
  )

  if (paths.length === 0) return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Navigation className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Conversion Paths</h1>
        </div>
        <Button onClick={() => startEdit()} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add Path
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Define conversion paths for {brand.name}. Each path links a CTA keyword to a destination, enabling trackable customer journeys.
      </p>

      <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
        <Navigation className="w-8 h-8 text-gray-300 mx-auto mb-3" />
        <p className="text-gray-400 text-sm mb-4">No conversion paths created yet.</p>
        <Button onClick={() => startEdit()} className="mx-auto flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Your First Path
        </Button>
      </div>

      {editingId !== null && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={cancelEdit}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">{editingId === 'new' ? 'New Conversion Path' : 'Edit Conversion Path'}</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Name *</label>
                  <input value={form.name as string} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} placeholder="e.g., Book a Demo" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Destination Type *</label>
                  <select value={form.destination_type as string} onChange={e => setForm(prev => ({ ...prev, destination_type: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    {DESTINATION_TYPES.map(t => <option key={t} value={t}>{t.replace('_', ' ')}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Destination Value *</label>
                  <input value={form.destination_value as string} onChange={e => setForm(prev => ({ ...prev, destination_value: e.target.value }))} placeholder="e.g., https://..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Primary Action</label>
                  <input value={form.primary_action as string} onChange={e => setForm(prev => ({ ...prev, primary_action: e.target.value }))} placeholder="e.g., Click to Book" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">CTA Keyword</label>
                  <input value={form.cta_keyword as string} onChange={e => setForm(prev => ({ ...prev, cta_keyword: e.target.value }))} placeholder="e.g., bookdemo" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Campaign Goal</label>
                  <input value={form.campaign_goal as string} onChange={e => setForm(prev => ({ ...prev, campaign_goal: e.target.value }))} placeholder="e.g., Lead generation" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Tracking Label</label>
                  <input value={form.tracking_label as string} onChange={e => setForm(prev => ({ ...prev, tracking_label: e.target.value }))} placeholder="e.g., demo-cta-b1" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
              </div>
              <fieldset className="border border-gray-100 rounded-lg p-4 space-y-3">
                <legend className="text-sm font-medium text-gray-700 px-1">UTM Parameters</legend>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs text-gray-500">UTM Source</label>
                    <input value={form.utm_source as string} onChange={e => setForm(prev => ({ ...prev, utm_source: e.target.value }))} placeholder="e.g., instagram" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500">UTM Medium</label>
                    <input value={form.utm_medium as string} onChange={e => setForm(prev => ({ ...prev, utm_medium: e.target.value }))} placeholder="e.g., social" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500">UTM Campaign</label>
                    <input value={form.utm_campaign as string} onChange={e => setForm(prev => ({ ...prev, utm_campaign: e.target.value }))} placeholder="e.g., summer_sale" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                  </div>
                </div>
              </fieldset>
              <div className="flex items-center gap-3 pt-2">
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={form.is_active as boolean} onChange={e => setForm(prev => ({ ...prev, is_active: e.target.checked }))} className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" />
                  <span className="text-sm text-gray-700">Active</span>
                </label>
              </div>
              <div className="flex items-center gap-3 pt-4 border-t border-gray-100">
                <Button onClick={handleSave} disabled={saving || !form.name || !form.destination_value}>{saving ? 'Saving...' : 'Save'}</Button>
                <button onClick={cancelEdit} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )

  return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Navigation className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Conversion Paths</h1>
        </div>
        <Button onClick={() => startEdit()} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add Path
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Define conversion paths for {brand.name}. Each path links a CTA keyword to a destination, enabling trackable customer journeys.
      </p>

      {/* Editor Modal */}
      {editingId !== null && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={cancelEdit}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">{editingId === 'new' ? 'New Conversion Path' : 'Edit Conversion Path'}</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Name *</label>
                  <input value={form.name as string} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} placeholder="e.g., Book a Demo" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Destination Type *</label>
                  <select value={form.destination_type as string} onChange={e => setForm(prev => ({ ...prev, destination_type: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    {DESTINATION_TYPES.map(t => <option key={t} value={t}>{t.replace('_', ' ')}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Destination Value *</label>
                  <input value={form.destination_value as string} onChange={e => setForm(prev => ({ ...prev, destination_value: e.target.value }))} placeholder="e.g., https://..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Primary Action</label>
                  <input value={form.primary_action as string} onChange={e => setForm(prev => ({ ...prev, primary_action: e.target.value }))} placeholder="e.g., Click to Book" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">CTA Keyword</label>
                  <input value={form.cta_keyword as string} onChange={e => setForm(prev => ({ ...prev, cta_keyword: e.target.value }))} placeholder="e.g., bookdemo" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Campaign Goal</label>
                  <input value={form.campaign_goal as string} onChange={e => setForm(prev => ({ ...prev, campaign_goal: e.target.value }))} placeholder="e.g., Lead generation" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Tracking Label</label>
                  <input value={form.tracking_label as string} onChange={e => setForm(prev => ({ ...prev, tracking_label: e.target.value }))} placeholder="e.g., demo-cta-b1" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
              </div>
              <fieldset className="border border-gray-100 rounded-lg p-4 space-y-3">
                <legend className="text-sm font-medium text-gray-700 px-1">UTM Parameters</legend>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs text-gray-500">UTM Source</label>
                    <input value={form.utm_source as string} onChange={e => setForm(prev => ({ ...prev, utm_source: e.target.value }))} placeholder="e.g., instagram" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500">UTM Medium</label>
                    <input value={form.utm_medium as string} onChange={e => setForm(prev => ({ ...prev, utm_medium: e.target.value }))} placeholder="e.g., social" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500">UTM Campaign</label>
                    <input value={form.utm_campaign as string} onChange={e => setForm(prev => ({ ...prev, utm_campaign: e.target.value }))} placeholder="e.g., summer_sale" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                  </div>
                </div>
              </fieldset>
              <div className="flex items-center gap-3 pt-2">
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={form.is_active as boolean} onChange={e => setForm(prev => ({ ...prev, is_active: e.target.checked }))} className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" />
                  <span className="text-sm text-gray-700">Active</span>
                </label>
              </div>
              <div className="flex items-center gap-3 pt-4 border-t border-gray-100">
                <Button onClick={handleSave} disabled={saving || !form.name || !form.destination_value}>{saving ? 'Saving...' : 'Save'}</Button>
                <button onClick={cancelEdit} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Paths Table */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-100 bg-gray-50/50">
              <th className="text-left px-4 py-3 font-semibold text-gray-600">Name</th>
              <th className="text-left px-4 py-3 font-semibold text-gray-600">Destination</th>
              <th className="text-left px-4 py-3 font-semibold text-gray-600">CTA Keyword</th>
              <th className="text-left px-4 py-3 font-semibold text-gray-600">Status</th>
              <th className="text-right px-4 py-3 font-semibold text-gray-600">Actions</th>
            </tr>
          </thead>
          <tbody>
            {paths.map(path => (
              <tr key={path.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                <td className="px-4 py-3">
                  <span className="font-medium text-gray-900">{path.name}</span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{path.destination_type.replace('_', ' ')}</span>
                    <span className="text-gray-400 text-xs truncate max-w-[160px]">{path.destination_value}</span>
                    {path.destination_value.startsWith('http') && (
                      <a href={path.destination_value} target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-purple-500">
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </td>
                <td className="px-4 py-3 text-gray-600">{path.cta_keyword || '-'}</td>
                <td className="px-4 py-3">
                  <button onClick={() => toggleActive(path)} className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full transition-colors ${path.is_active ? 'bg-green-50 text-green-700 hover:bg-green-100' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
                    {path.is_active ? <Power className="w-3 h-3" /> : <PowerOff className="w-3 h-3" />}
                    {path.is_active ? 'Active' : 'Inactive'}
                  </button>
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => startEdit(path)} className="p-1.5 rounded-lg hover:bg-purple-50 text-gray-400 hover:text-purple-600 text-xs font-medium" title="Edit">Edit</button>
                    <button onClick={() => handleDelete(path.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500" title="Delete">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
