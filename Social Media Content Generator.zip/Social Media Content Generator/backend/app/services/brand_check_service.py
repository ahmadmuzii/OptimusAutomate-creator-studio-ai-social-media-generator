from __future__ import annotations

import re

from app.models.db_models import BrandGuardrail, BrandProfile
from app.models.guardrail_schemas import BrandCheckItem, BrandCheckResult, BrandCheckSummary


class BrandCheckService:
    """Evaluates generated campaign content against brand guardrails."""

    def check_guardrails(
        self,
        brand: BrandProfile,
        guardrail: BrandGuardrail | None,
        campaign_data: list[dict] | None = None,
    ) -> BrandCheckResult:
        checks: list[BrandCheckItem] = []
        passed = 0
        warnings = 0
        blocked = 0

        texts_to_check: list[dict] = campaign_data or []

        if not guardrail:
            passed = 11  # default passes for all basic checks
            checks = [
                BrandCheckItem(
                    code="brand_name_preserved",
                    label="Brand name preserved",
                    status="passed",
                    message="The official brand name was preserved.",
                ),
                BrandCheckItem(
                    code="required_phrases",
                    label="Required phrases",
                    status="passed",
                    message="No required phrases configured.",
                ),
                BrandCheckItem(
                    code="forbidden_words",
                    label="Forbidden words",
                    status="passed",
                    message="No forbidden words configured.",
                ),
                BrandCheckItem(
                    code="competitor_mentions",
                    label="Competitor mentions",
                    status="passed",
                    message="No competitors configured.",
                ),
                BrandCheckItem(
                    code="restricted_claims",
                    label="Restricted claims",
                    status="passed",
                    message="No restricted claims configured.",
                ),
                BrandCheckItem(
                    code="emoji_rules", label="Emoji rules", status="passed", message="No emoji rules configured."
                ),
                BrandCheckItem(
                    code="hashtag_count",
                    label="Hashtag count",
                    status="passed",
                    message="No hashtag limits configured.",
                ),
                BrandCheckItem(
                    code="tone_match", label="Tone match", status="passed", message="No tone rules configured."
                ),
                BrandCheckItem(
                    code="formality_match",
                    label="Formality match",
                    status="passed",
                    message="No formality rules configured.",
                ),
                BrandCheckItem(
                    code="cta_variety", label="CTA variety", status="passed", message="No CTA rules configured."
                ),
                BrandCheckItem(
                    code="legal_disclaimer",
                    label="Legal disclaimer",
                    status="passed",
                    message="No legal disclaimer configured.",
                ),
            ]
            overall = "passed"
        else:
            checks = self._run_all_checks(brand, guardrail, texts_to_check)
            for c in checks:
                if c.status == "passed":
                    passed += 1
                elif c.status == "warning":
                    warnings += 1
                elif c.status == "blocked":
                    blocked += 1
            overall = "blocked" if blocked > 0 else ("warning" if warnings > 0 else "passed")

        return BrandCheckResult(
            status=overall,
            summary=BrandCheckSummary(passed=passed, warnings=warnings, blocked=blocked),
            checks=checks,
        )

    def _run_all_checks(
        self,
        brand: BrandProfile,
        guardrail: BrandGuardrail,
        texts: list[dict],
    ) -> list[BrandCheckItem]:
        checks: list[BrandCheckItem] = []

        all_text = (
            " ".join(
                t.get("caption", "")
                + " "
                + t.get("callToAction", "")
                + " "
                + t.get("contentTheme", "")
                + " "
                + t.get("postIdea", "")
                for t in texts
            )
            if texts
            else ""
        )

        all_captions = [t.get("caption", "") for t in texts] if texts else []
        all_ctas = [t.get("callToAction", "") for t in texts] if texts else []

        # 1. Brand name preservation
        checks.append(self._check_brand_name(brand.name, all_text, texts))

        # 2. Required phrases
        if guardrail.required_phrases:
            checks.append(self._check_required_phrases(guardrail.required_phrases, all_text))
        else:
            checks.append(
                BrandCheckItem(
                    code="required_phrases",
                    label="Required phrases",
                    status="passed",
                    message="No required phrases configured.",
                )
            )

        # 3. Forbidden words
        if guardrail.forbidden_words:
            checks.append(self._check_forbidden_words(guardrail.forbidden_words, all_text, texts))
        else:
            checks.append(
                BrandCheckItem(
                    code="forbidden_words",
                    label="Forbidden words",
                    status="passed",
                    message="No forbidden words configured.",
                )
            )

        # 4. Competitor mentions
        if guardrail.competitors_never_mention:
            checks.append(self._check_competitors(guardrail.competitors_never_mention, all_text, texts))
        else:
            checks.append(
                BrandCheckItem(
                    code="competitor_mentions",
                    label="Competitor mentions",
                    status="passed",
                    message="No competitors configured.",
                )
            )

        # 5. Restricted claims
        if guardrail.restricted_claims:
            checks.append(self._check_restricted_claims(guardrail.restricted_claims, all_text, texts))
        else:
            checks.append(
                BrandCheckItem(
                    code="restricted_claims",
                    label="Restricted claims",
                    status="passed",
                    message="No restricted claims configured.",
                )
            )

        # 6. Emoji allowance
        if guardrail.emoji_allowance:
            checks.append(self._check_emoji_rules(guardrail.emoji_allowance, all_captions))
        else:
            checks.append(
                BrandCheckItem(
                    code="emoji_rules", label="Emoji rules", status="passed", message="No emoji rules configured."
                )
            )

        # 7. Hashtag count
        if guardrail.max_hashtag_count is not None:
            checks.append(self._check_hashtag_count(guardrail.max_hashtag_count, guardrail.min_hashtag_count, texts))
        else:
            checks.append(
                BrandCheckItem(
                    code="hashtag_count",
                    label="Hashtag count",
                    status="passed",
                    message="No hashtag limits configured.",
                )
            )

        # 8. CTA variety
        checks.append(self._check_cta_variety(all_ctas))

        # 9. Legal disclaimer
        if guardrail.required_legal_disclaimer:
            checks.append(self._check_legal_disclaimer(guardrail.required_legal_disclaimer, all_captions))
        else:
            checks.append(
                BrandCheckItem(
                    code="legal_disclaimer",
                    label="Legal disclaimer",
                    status="passed",
                    message="No legal disclaimer configured.",
                )
            )

        # 10. Allowed claims
        if guardrail.allowed_claims:
            checks.append(self._check_allowed_claims(guardrail.allowed_claims, all_text))
        else:
            checks.append(
                BrandCheckItem(
                    code="allowed_claims",
                    label="Allowed claims",
                    status="passed",
                    message="No allowed claims configured.",
                )
            )

        # 11. Preferred spellings
        if guardrail.preferred_spellings:
            checks.append(self._check_preferred_spellings(guardrail.preferred_spellings, all_text, texts))
        else:
            checks.append(
                BrandCheckItem(
                    code="preferred_spellings",
                    label="Preferred spellings",
                    status="passed",
                    message="No preferred spellings configured.",
                )
            )

        return checks

    def _check_brand_name(self, brand_name: str, all_text: str, texts: list[dict]) -> BrandCheckItem:
        if not brand_name or not texts:
            return BrandCheckItem(
                code="brand_name_preserved",
                label="Brand name preserved",
                status="passed",
                message="No brand name or content to check.",
            )

        brand_lower = brand_name.lower()
        for i, t in enumerate(texts):
            for field in ("caption", "callToAction", "contentTheme", "postIdea"):
                val = t.get(field, "")
                if not isinstance(val, str):
                    continue
                words = re.findall(r"[A-Za-z0-9]+(?:[.'&][A-Za-z0-9]+)*", val)
                for w in words:
                    if w.lower() == brand_lower and w != brand_name:
                        return BrandCheckItem(
                            code="brand_name_preserved",
                            label="Brand name preserved",
                            status="warning",
                            message=f'The brand name "{brand_name}" appears with incorrect capitalization.',
                            field=field,
                            post_id=t.get("day", i + 1),
                            matched_text=w,
                        )

        return BrandCheckItem(
            code="brand_name_preserved",
            label="Brand name preserved",
            status="passed",
            message="The official brand name was preserved.",
        )

    def _check_required_phrases(self, phrases: list[str], all_text: str) -> BrandCheckItem:
        if not phrases:
            return BrandCheckItem(
                code="required_phrases",
                label="Required phrases",
                status="passed",
                message="No required phrases configured.",
            )

        missing = [p for p in phrases if p.lower() not in all_text.lower()]
        if missing:
            return BrandCheckItem(
                code="required_phrases",
                label="Required phrases",
                status="warning",
                message=f"Missing required phrase(s): {', '.join(missing)}",
            )
        return BrandCheckItem(
            code="required_phrases", label="Required phrases", status="passed", message="All required phrases present."
        )

    def _check_forbidden_words(self, words: list[str], all_text: str, texts: list[dict]) -> BrandCheckItem:
        if not words:
            return BrandCheckItem(
                code="forbidden_words",
                label="Forbidden words",
                status="passed",
                message="No forbidden words configured.",
            )

        all_lower = all_text.lower()
        found = [w for w in words if w.lower() in all_lower]
        if found:
            return BrandCheckItem(
                code="forbidden_words",
                label="Forbidden words",
                status="blocked",
                message=f"Forbidden word(s) detected: {', '.join(found)}",
                matched_text=found[0],
            )
        return BrandCheckItem(
            code="forbidden_words", label="Forbidden words", status="passed", message="No forbidden words detected."
        )

    def _check_competitors(self, competitors: list[str], all_text: str, texts: list[dict]) -> BrandCheckItem:
        if not competitors:
            return BrandCheckItem(
                code="competitor_mentions",
                label="Competitor mentions",
                status="passed",
                message="No competitors configured.",
            )

        all_lower = all_text.lower()
        found = [c for c in competitors if c.lower() in all_lower]
        if found:
            return BrandCheckItem(
                code="competitor_mentions",
                label="Competitor mentions",
                status="blocked",
                message=f"Competitor mention(s) detected: {', '.join(found)}",
                matched_text=found[0],
            )
        return BrandCheckItem(
            code="competitor_mentions",
            label="Competitor mentions",
            status="passed",
            message="No competitor mentions detected.",
        )

    def _check_restricted_claims(self, claims: list[str], all_text: str, texts: list[dict]) -> BrandCheckItem:
        if not claims:
            return BrandCheckItem(
                code="restricted_claims",
                label="Restricted claims",
                status="passed",
                message="No restricted claims configured.",
            )

        all_lower = all_text.lower()
        found = [c for c in claims if c.lower() in all_lower]
        if found:
            return BrandCheckItem(
                code="restricted_claims",
                label="Restricted claims",
                status="blocked",
                message=f"Restricted claim(s) detected: {', '.join(found)}",
                matched_text=found[0],
            )
        return BrandCheckItem(
            code="restricted_claims",
            label="Restricted claims",
            status="passed",
            message="No restricted claims detected.",
        )

    def _check_allowed_claims(self, claims: list[str], all_text: str) -> BrandCheckItem:
        if not claims:
            return BrandCheckItem(
                code="allowed_claims", label="Allowed claims", status="passed", message="No allowed claims configured."
            )

        all_lower = all_text.lower()
        used = [c for c in claims if c.lower() in all_lower]
        if used:
            return BrandCheckItem(
                code="allowed_claims",
                label="Allowed claims",
                status="passed",
                message=f"Allowed claim(s) used: {', '.join(used)}.",
            )
        return BrandCheckItem(
            code="allowed_claims", label="Allowed claims", status="passed", message="No allowed claims used in content."
        )

    def _check_preferred_spellings(self, spellings: dict[str, str], all_text: str, texts: list[dict]) -> BrandCheckItem:
        if not spellings:
            return BrandCheckItem(
                code="preferred_spellings",
                label="Preferred spellings",
                status="passed",
                message="No preferred spellings configured.",
            )

        for i, t in enumerate(texts):
            for field in ("caption", "callToAction", "contentTheme", "postIdea"):
                val = t.get(field, "")
                if not isinstance(val, str):
                    continue
                for incorrect, correct in spellings.items():
                    if incorrect.lower() in val.lower():
                        return BrandCheckItem(
                            code="preferred_spellings",
                            label="Preferred spellings",
                            status="warning",
                            message=f'"{incorrect}" should be "{correct}".',
                            field=field,
                            post_id=t.get("day", i + 1),
                            matched_text=incorrect,
                        )
        return BrandCheckItem(
            code="preferred_spellings",
            label="Preferred spellings",
            status="passed",
            message="All spellings match preferences.",
        )

    def _check_emoji_rules(self, allowance: str, captions: list[str]) -> BrandCheckItem:
        if not allowance or not captions:
            return BrandCheckItem(
                code="emoji_rules", label="Emoji rules", status="passed", message="No emoji rules or content to check."
            )

        emoji_pattern = re.compile(
            "["
            "\U0001f600-\U0001f64f"
            "\U0001f300-\U0001f5ff"
            "\U0001f680-\U0001f6ff"
            "\U0001f1e0-\U0001f1ff"
            "\u2600-\u26ff"
            "\u2700-\u27bf"
            "]"
        )
        total_emojis = sum(len(emoji_pattern.findall(c)) for c in captions)

        if allowance == "none" and total_emojis > 0:
            return BrandCheckItem(
                code="emoji_rules",
                label="Emoji rules",
                status="warning",
                message=f"Emojis are not allowed, but {total_emojis} were found.",
            )
        if allowance == "moderate" and total_emojis > 10:
            return BrandCheckItem(
                code="emoji_rules",
                label="Emoji rules",
                status="warning",
                message=f"Emoji count ({total_emojis}) exceeds moderate allowance.",
            )
        if allowance == "liberal" and total_emojis > 25:
            return BrandCheckItem(
                code="emoji_rules",
                label="Emoji rules",
                status="warning",
                message=f"Emoji count ({total_emojis}) is very high.",
            )

        return BrandCheckItem(
            code="emoji_rules", label="Emoji rules", status="passed", message="Emoji usage within guidelines."
        )

    def _check_hashtag_count(self, max_count: int, min_count: int | None, texts: list[dict]) -> BrandCheckItem:
        if not texts:
            return BrandCheckItem(
                code="hashtag_count", label="Hashtag count", status="passed", message="No content to check."
            )

        for t in texts:
            hashtags = t.get("hashtags", [])
            if isinstance(hashtags, list):
                count = len(hashtags)
                if max_count and count > max_count:
                    return BrandCheckItem(
                        code="hashtag_count",
                        label="Hashtag count",
                        status="warning",
                        message=f"Post has {count} hashtags, maximum is {max_count}.",
                        field="hashtags",
                        post_id=t.get("day"),
                    )
                if min_count and count < min_count:
                    return BrandCheckItem(
                        code="hashtag_count",
                        label="Hashtag count",
                        status="warning",
                        message=f"Post has {count} hashtags, minimum is {min_count}.",
                        field="hashtags",
                        post_id=t.get("day"),
                    )
        return BrandCheckItem(
            code="hashtag_count", label="Hashtag count", status="passed", message="Hashtag counts within limits."
        )

    def _check_cta_variety(self, ctas: list[str]) -> BrandCheckItem:
        if not ctas:
            return BrandCheckItem(code="cta_variety", label="CTA variety", status="passed", message="No CTAs to check.")

        unique = set(c.lower().strip() for c in ctas if c)
        duplicates = len(ctas) - len(unique) if ctas else 0

        if duplicates > 2:
            return BrandCheckItem(
                code="cta_variety",
                label="CTA variety",
                status="warning",
                message=f"The same CTA appears {duplicates + 1} times across posts.",
            )
        return BrandCheckItem(code="cta_variety", label="CTA variety", status="passed", message="CTA variety is good.")

    def _check_legal_disclaimer(self, disclaimer: str, captions: list[str]) -> BrandCheckItem:
        if not disclaimer:
            return BrandCheckItem(
                code="legal_disclaimer",
                label="Legal disclaimer",
                status="passed",
                message="No legal disclaimer configured.",
            )

        if not captions:
            return BrandCheckItem(
                code="legal_disclaimer",
                label="Legal disclaimer",
                status="warning",
                message="Required legal disclaimer is missing.",
                field="caption",
            )

        disclaimer_normalized = disclaimer.lower().strip()
        found = any(disclaimer_normalized in c.lower() for c in captions if c)
        if not found:
            return BrandCheckItem(
                code="legal_disclaimer",
                label="Legal disclaimer",
                status="blocked",
                message="Required legal disclaimer is missing from all posts.",
                field="caption",
            )
        return BrandCheckItem(
            code="legal_disclaimer", label="Legal disclaimer", status="passed", message="Legal disclaimer present."
        )
