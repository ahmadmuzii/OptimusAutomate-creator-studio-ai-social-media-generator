import { Link } from 'react-router-dom'
import { Container } from '@/components/layout/Container'
import { PageLayout } from '@/components/layout/PageLayout'

export function NotFoundPage() {
  return (
    <PageLayout>
      <Container>
        <div className="flex flex-col items-center justify-center text-center py-20">
          <h1 className="text-6xl font-extrabold text-gray-900 mb-4">404</h1>
          <p className="text-lg text-gray-500 mb-8">Page not found</p>
          <Link
            to="/"
            className="px-6 py-3 bg-purple-600 text-white rounded-xl font-medium hover:bg-purple-700 transition-colors"
          >
            Go home
          </Link>
        </div>
      </Container>
    </PageLayout>
  )
}
