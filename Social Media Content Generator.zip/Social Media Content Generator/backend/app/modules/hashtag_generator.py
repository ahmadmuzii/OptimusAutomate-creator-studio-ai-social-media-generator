from __future__ import annotations

import random

from app.modules.platform_formatter import PLATFORMS

BROAD_HASHTAGS: dict[str, list[str]] = {
    "fitness": ["#fitness", "#health", "#wellness", "#workout", "#fitlife", "#active"],
    "tech": ["#tech", "#technology", "#innovation", "#startup", "#digital", "#future"],
    "fashion": ["#fashion", "#style", "#ootd", "#beauty", "#trending", "#aesthetic"],
    "food": ["#food", "#foodie", "#cooking", "#recipe", "#delicious", "#tasty"],
    "finance": ["#finance", "#money", "#investing", "#wealth", "#business", "#financialfreedom"],
    "education": ["#education", "#learning", "#study", "#knowledge", "#growth", "#skills"],
    "travel": ["#travel", "#wanderlust", "#adventure", "#explore", "#vacation", "#destination"],
    "lifestyle": ["#lifestyle", "#life", "#daily", "#vibes", "#routine", "#inspo"],
    "beauty": ["#beauty", "#skincare", "#makeup", "#selfcare", "#glow", "#beautytips"],
    "gaming": ["#gaming", "#gamer", "#games", "#gameplay", "#streaming", "#esports"],
    "music": ["#music", "#musician", "#newmusic", "#song", "#singer", "#producer"],
    "real estate": ["#realestate", "#property", "#home", "#housing", "#investment", "#realtor"],
    "health": ["#health", "#mentalhealth", "#healthylifestyle", "#wellbeing", "#mindfulness", "#nutrition"],
    "marketing": ["#marketing", "#digitalmarketing", "#socialmedia", "#branding", "#contentcreator", "#growth"],
    "coffee": ["#coffee", "#coffeelover", "#coffeetime", "#specialtycoffee", "#coldbrew", "#coffeeaesthetic"],
    "general": ["#trending", "#viral", "#fyp", "#explore", "#daily", "#content", "#inspo", "#goals"],
}


def _normalize_niche(niche: str) -> str:
    niche_lower = niche.lower().strip()
    for key in BROAD_HASHTAGS:
        if key in niche_lower or niche_lower in key:
            return key
    return "general"


def _make_branded_tags(brand_name: str) -> list[str]:
    if not brand_name:
        return []
    clean = brand_name.replace(" ", "").replace("-", "").replace("_", "").replace(".", "").lower()
    return [f"#{clean}", f"#{clean}official", f"#{clean}community"]


def _topic_tags(topic: str) -> list[str]:
    words = topic.lower().replace("&", "").split()
    tags = []
    for w in words:
        if len(w) > 2 and w not in ("the", "and", "for", "with", "that", "this", "your", "what"):
            tags.append(f"#{w}")
    return tags


def _audience_tags(audience: str) -> list[str]:
    parts = [p.strip() for p in audience.replace(",", "").split()]
    tags = []
    for p in parts[:4]:
        clean = p.replace(" ", "").lower()
        if len(clean) > 2:
            tags.append(f"#{clean}")
    return tags


def _goal_tags(goal: str) -> list[str]:
    mapping = {
        "brand_awareness": ["#discover", "#brandstory", "#newbrand", "#getnoticed"],
        "engagement": ["#community", "#joinus", "#letsconnect", "#shareyourstory"],
        "sales": ["#shopnow", "#musthave", "#exclusive", "#limited"],
        "education": ["#learn", "#didyouknow", "#tipsandtricks", "#howto"],
        "lead_generation": ["#freeresource", "#signup", "#exclusiveaccess", "#joinnow"],
        "community_building": ["#communitylove", "#together", "#ourpeople", "#belong"],
    }
    return mapping.get(goal, ["#grow", "#momentum", "#build", "#nextlevel"])


def generate_hashtags(
    niche: str,
    platform: str,
    campaign_goal: str,
    brand_name: str = "",
    count: int = 8,
    post_topic: str = "",
    target_audience: str = "",
) -> list[str]:
    if platform not in PLATFORMS:
        raise ValueError(f"Unsupported platform: {platform}")

    normalized = _normalize_niche(niche)

    broad_pool = BROAD_HASHTAGS.get(normalized, BROAD_HASHTAGS["general"])

    tags: list[str] = []

    branded = _make_branded_tags(brand_name)
    tags.extend(branded[:2])

    broad_sample = random.sample(broad_pool, min(3, len(broad_pool)))
    tags.extend(broad_sample)

    if post_topic:
        topic = _topic_tags(post_topic)
        tags.extend(topic[:2])

    if target_audience:
        audience = _audience_tags(target_audience)
        tags.extend(audience[:2])

    goal = _goal_tags(campaign_goal)
    tags.extend(goal[:2])

    random.shuffle(tags)
    return tags[:count]
