import type { CalendarRequest, CalendarResponse } from '@/types/calendar'
import type { CaptionRequest, CaptionResponse } from '@/types/caption'
import type { PlatformResponse } from '@/types/platform'
import type { UserData, BrandProfile, CampaignData, RefinementRequest, RefinementResponse, PostRevision } from '@/types/common'
import type { ExtractRequest, ExtractResponse } from '@/types/source'
import { API_ENDPOINTS } from '@/config/constants'
import client from './client'

export async function fetchPlatforms(): Promise<PlatformResponse> {
  const { data } = await client.get<PlatformResponse>(API_ENDPOINTS.platforms)
  return data
}

export async function fetchTones(): Promise<{ tones: string[] }> {
  const { data } = await client.get<{ tones: string[] }>(API_ENDPOINTS.tones)
  return data
}

export async function postGenerateCalendar(
  payload: CalendarRequest,
): Promise<CalendarResponse> {
  const { data } = await client.post<CalendarResponse>(
    API_ENDPOINTS.generateCalendar,
    payload,
  )
  return data
}

/* Captions - standalone endpoint kept for regenerate functionality */
export async function postGenerateCaption(
  payload: CaptionRequest,
): Promise<CaptionResponse> {
  const { data } = await client.post<CaptionResponse>(
    API_ENDPOINTS.generateCaption,
    payload,
  )
  return data
}

/* Brand Guardrails */
export async function fetchGuardrails(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/guardrails`)
  return data
}

export async function updateGuardrails(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.put(API_ENDPOINTS.brands + `/${brandId}/guardrails`, payload)
  return data
}

export async function resetGuardrails(brandId: number) {
  const { data } = await client.delete(API_ENDPOINTS.brands + `/${brandId}/guardrails`)
  return data
}

export async function runBrandCheck(brandId: number) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/guardrails/check`)
  return data
}

/* Auth */
export async function signup(email: string, password: string, name: string) {
  const { data } = await client.post<{ access_token: string; user: UserData }>(
    API_ENDPOINTS.auth + '/signup',
    { email, password, name },
  )
  return data
}

export async function login(email: string, password: string) {
  const { data } = await client.post<{ access_token: string; user: UserData }>(
    API_ENDPOINTS.auth + '/login',
    { email, password },
  )
  return data
}

export async function uploadFile(file: File, type: 'avatar' | 'logo') {
  const formData = new FormData()
  formData.append('file', file)
  formData.append('type', type)
  const { data } = await client.post<{ url: string }>(API_ENDPOINTS.upload, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
  return data
}

export async function fetchMe() {
  const { data } = await client.get<UserData>(API_ENDPOINTS.auth + '/me')
  return data
}

export async function updateProfile(payload: Partial<UserData>) {
  const { data } = await client.put<UserData>(API_ENDPOINTS.auth + '/me', payload)
  return data
}

export async function forgotPassword(email: string) {
  const { data } = await client.post<{ message: string }>(API_ENDPOINTS.auth + '/forgot-password', { email })
  return data
}

export async function resetPassword(token: string, newPassword: string) {
  const { data } = await client.post<{ message: string }>(API_ENDPOINTS.auth + '/reset-password', {
    token,
    new_password: newPassword,
  })
  return data
}

/* Personas */
export async function fetchPersonas(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/personas`)
  return data
}

export async function createPersona(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/personas`, payload)
  return data
}

export async function updatePersona(brandId: number, personaId: number, payload: Record<string, unknown>) {
  const { data } = await client.put(API_ENDPOINTS.brands + `/${brandId}/personas/${personaId}`, payload)
  return data
}

export async function deletePersona(brandId: number, personaId: number) {
  const { data } = await client.delete(API_ENDPOINTS.brands + `/${brandId}/personas/${personaId}`)
  return data
}

/* Brands */
export async function fetchBrands() {
  const { data } = await client.get<BrandProfile[]>(API_ENDPOINTS.brands)
  return data
}

export async function fetchBrand(id: number) {
  const { data } = await client.get<BrandProfile>(API_ENDPOINTS.brands + `/${id}`)
  return data
}

export async function createBrand(payload: Partial<BrandProfile>) {
  const { data } = await client.post<BrandProfile>(API_ENDPOINTS.brands, payload)
  return data
}

export async function updateBrand(id: number, payload: Partial<BrandProfile>) {
  const { data } = await client.put<BrandProfile>(API_ENDPOINTS.brands + `/${id}`, payload)
  return data
}

export async function deleteBrand(id: number) {
  const { data } = await client.delete(API_ENDPOINTS.brands + `/${id}`)
  return data
}

/* Campaigns */
export async function fetchCampaigns(brandId?: number | null) {
  const params = brandId ? { brand_id: brandId } : {}
  const { data } = await client.get<CampaignData[]>(API_ENDPOINTS.campaigns, { params })
  return data
}

export async function getCampaign(id: number) {
  const { data } = await client.get<CampaignData>(API_ENDPOINTS.campaigns + `/${id}`)
  return data
}

export async function createCampaign(payload: Partial<CampaignData>) {
  const { data } = await client.post<CampaignData>(API_ENDPOINTS.campaigns, payload)
  return data
}

export async function deleteCampaign(id: number) {
  const { data } = await client.delete(API_ENDPOINTS.campaigns + `/${id}`)
  return data
}

export async function updateCampaign(id: number, payload: Partial<CampaignData>) {
  const { data } = await client.put<CampaignData>(API_ENDPOINTS.campaigns + `/${id}`, payload)
  return data
}

export async function updatePostStatus(campaignId: number, postId: number, payload: { status?: string; scheduled_date?: string }) {
  const { data } = await client.put(API_ENDPOINTS.campaigns + `/${campaignId}/posts/${postId}`, payload)
  return data
}

export async function deletePost(campaignId: number, postId: number) {
  const { data } = await client.delete(API_ENDPOINTS.campaigns + `/${campaignId}/posts/${postId}`)
  return data
}

export async function updateUserSettings(payload: { theme_preference: string }) {
  const { data } = await client.put(API_ENDPOINTS.auth + '/settings', payload)
  return data
}

export async function changePassword(payload: { current_password: string; new_password: string }) {
  const { data } = await client.put(API_ENDPOINTS.auth + '/password', payload)
  return data
}

export async function deleteMyAccount() {
  const { data } = await client.delete(API_ENDPOINTS.auth + '/me')
  return data
}

export async function regeneratePostCaption(campaignId: number, postId: number, payload: {
  post_idea: string
  content_theme?: string
  platform: string
  tone: string
  brand_details: Record<string, string>
}) {
  const { data } = await client.post<{ detail: string; caption: string; hashtags: string[] }>(
    API_ENDPOINTS.campaigns + `/${campaignId}/posts/${postId}/regenerate`,
    payload,
  )
  return data
}

/* Conversion Paths */
export async function fetchConversionPaths(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/conversion-paths`)
  return data
}

export async function createConversionPath(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/conversion-paths`, payload)
  return data
}

export async function getConversionPath(brandId: number, pathId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/conversion-paths/${pathId}`)
  return data
}

export async function updateConversionPath(brandId: number, pathId: number, payload: Record<string, unknown>) {
  const { data } = await client.put(API_ENDPOINTS.brands + `/${brandId}/conversion-paths/${pathId}`, payload)
  return data
}

export async function deleteConversionPath(brandId: number, pathId: number) {
  const { data } = await client.delete(API_ENDPOINTS.brands + `/${brandId}/conversion-paths/${pathId}`)
  return data
}

/* Source Documents */
export async function fetchSourceDocuments(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/source-documents`)
  return data
}

export async function createSourceDocument(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/source-documents`, payload)
  return data
}

export async function getSourceDocument(brandId: number, docId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/source-documents/${docId}`)
  return data
}

export async function reExtractDocument(brandId: number, docId: number) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/source-documents/${docId}/extract`)
  return data
}

export async function updateSourceFact(brandId: number, factId: number, payload: Record<string, unknown>) {
  const { data } = await client.patch(API_ENDPOINTS.brands + `/${brandId}/source-documents/facts/${factId}`, payload)
  return data
}

export async function deleteSourceDocument(brandId: number, docId: number) {
  const { data } = await client.delete(API_ENDPOINTS.brands + `/${brandId}/source-documents/${docId}`)
  return data
}

export async function extractSourceDocument(brandId: number, payload: ExtractRequest): Promise<ExtractResponse> {
  const { data } = await client.post<ExtractResponse>(API_ENDPOINTS.brands + `/${brandId}/source-documents/extract`, payload)
  return data
}

/* Content Packs */
export async function fetchContentPackTemplates(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/content-packs`)
  return data
}

export async function createContentPackTemplate(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/content-packs`, payload)
  return data
}

export async function getContentPackTemplate(brandId: number, templateId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/content-packs/${templateId}`)
  return data
}

export async function updateContentPackTemplate(brandId: number, templateId: number, payload: Record<string, unknown>) {
  const { data } = await client.put(API_ENDPOINTS.brands + `/${brandId}/content-packs/${templateId}`, payload)
  return data
}

export async function deleteContentPackTemplate(brandId: number, templateId: number) {
  const { data } = await client.delete(API_ENDPOINTS.brands + `/${brandId}/content-packs/${templateId}`)
  return data
}

export async function exportContentPack(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/content-packs/export`, payload)
  return data
}

/* Campaign Freshness */
export async function getBrandFatigue(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/freshness`)
  return data
}

export async function getCampaignFreshnessRecommendations(brandId: number, campaignId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/freshness/for-campaign/${campaignId}`)
  return data
}

/* Strategy Templates */
export async function fetchStrategyTemplates(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/strategies`)
  return data
}

export async function createStrategyTemplate(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/strategies`, payload)
  return data
}

export async function getStrategyTemplate(brandId: number, templateId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/strategies/${templateId}`)
  return data
}

export async function updateStrategyTemplate(brandId: number, templateId: number, payload: Record<string, unknown>) {
  const { data } = await client.put(API_ENDPOINTS.brands + `/${brandId}/strategies/${templateId}`, payload)
  return data
}

export async function deleteStrategyTemplate(brandId: number, templateId: number) {
  const { data } = await client.delete(API_ENDPOINTS.brands + `/${brandId}/strategies/${templateId}`)
  return data
}

export async function applyStrategy(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/strategies/apply`, payload)
  return data
}

/* Performance */
export async function getPerformanceSummary(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/performance/summary`)
  return data
}

export async function importPerformanceData(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/performance/import`, payload)
  return data
}

export async function fetchImportBatches(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/performance/imports`)
  return data
}

export async function fetchPerformanceRecords(brandId: number, params?: Record<string, unknown>) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/performance/records`, { params })
  return data
}

export async function fetchPerformanceInsights(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/performance/insights`)
  return data
}

export async function updatePerformanceInsight(brandId: number, insightId: number, payload: Record<string, unknown>) {
  const { data } = await client.patch(API_ENDPOINTS.brands + `/${brandId}/performance/insights/${insightId}`, payload)
  return data
}

export async function generatePerformanceInsights(brandId: number) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/performance/insights/generate`)
  return data
}

/* Experiments */
export async function fetchExperiments(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/experiments`)
  return data
}

export async function createExperiment(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/experiments`, payload)
  return data
}

export async function getExperiment(brandId: number, expId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/experiments/${expId}`)
  return data
}

export async function updateExperiment(brandId: number, expId: number, payload: Record<string, unknown>) {
  const { data } = await client.put(API_ENDPOINTS.brands + `/${brandId}/experiments/${expId}`, payload)
  return data
}

export async function deleteExperiment(brandId: number, expId: number) {
  const { data } = await client.delete(API_ENDPOINTS.brands + `/${brandId}/experiments/${expId}`)
  return data
}

export async function addExperimentVariant(brandId: number, expId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/experiments/${expId}/variants`, payload)
  return data
}

export async function updateVariantResult(brandId: number, variantId: number, payload: Record<string, unknown>) {
  const { data } = await client.patch(API_ENDPOINTS.brands + `/${brandId}/experiments/variants/${variantId}`, payload)
  return data
}

export async function declareWinner(brandId: number, expId: number, payload: { variant_id: number }) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/experiments/${expId}/declare-winner`, payload)
  return data
}

/* Regional Settings */
export async function getRegionalSettings(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/regional-settings`)
  return data
}

export async function updateRegionalSettings(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.put(API_ENDPOINTS.brands + `/${brandId}/regional-settings`, payload)
  return data
}

/* Competitors */
export async function fetchCompetitors(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/competitors`)
  return data
}

export async function createCompetitor(brandId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/competitors`, payload)
  return data
}

export async function getCompetitor(brandId: number, compId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/competitors/${compId}`)
  return data
}

export async function updateCompetitor(brandId: number, compId: number, payload: Record<string, unknown>) {
  const { data } = await client.put(API_ENDPOINTS.brands + `/${brandId}/competitors/${compId}`, payload)
  return data
}

export async function deleteCompetitor(brandId: number, compId: number) {
  const { data } = await client.delete(API_ENDPOINTS.brands + `/${brandId}/competitors/${compId}`)
  return data
}

export async function fetchCompetitorPosts(brandId: number, compId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/competitors/${compId}/posts`)
  return data
}

export async function addCompetitorPost(brandId: number, compId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/competitors/${compId}/posts`, payload)
  return data
}

export async function deleteCompetitorPost(brandId: number, postId: number) {
  const { data } = await client.delete(API_ENDPOINTS.brands + `/${brandId}/competitors/posts/${postId}`)
  return data
}

export async function analyzeGaps(brandId: number) {
  const { data } = await client.post(API_ENDPOINTS.brands + `/${brandId}/competitors/analyze-gaps`)
  return data
}

export async function fetchGapReports(brandId: number) {
  const { data } = await client.get(API_ENDPOINTS.brands + `/${brandId}/competitors/gap-reports`)
  return data
}

/* Workspaces */
export async function fetchWorkspaces() {
  const { data } = await client.get(API_ENDPOINTS.workspaces)
  return data
}

export async function createWorkspace(payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.workspaces, payload)
  return data
}

export async function getWorkspace(workspaceId: number) {
  const { data } = await client.get(API_ENDPOINTS.workspaces + `/${workspaceId}`)
  return data
}

export async function updateWorkspace(workspaceId: number, payload: Record<string, unknown>) {
  const { data } = await client.put(API_ENDPOINTS.workspaces + `/${workspaceId}`, payload)
  return data
}

export async function deleteWorkspace(workspaceId: number) {
  const { data } = await client.delete(API_ENDPOINTS.workspaces + `/${workspaceId}`)
  return data
}

export async function addWorkspaceMember(workspaceId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.workspaces + `/${workspaceId}/members`, payload)
  return data
}

export async function updateMemberRole(workspaceId: number, membershipId: number, payload: Record<string, unknown>) {
  const { data } = await client.put(API_ENDPOINTS.workspaces + `/${workspaceId}/members/${membershipId}`, payload)
  return data
}

export async function removeWorkspaceMember(workspaceId: number, membershipId: number) {
  const { data } = await client.delete(API_ENDPOINTS.workspaces + `/${workspaceId}/members/${membershipId}`)
  return data
}

/* Collaboration */
export async function createApprovalRequest(campaignId: number) {
  const { data } = await client.post(API_ENDPOINTS.campaigns + `/${campaignId}/approval-requests`)
  return data
}

export async function fetchApprovalRequests(campaignId: number) {
  const { data } = await client.get(API_ENDPOINTS.campaigns + `/${campaignId}/approval-requests`)
  return data
}

export async function addApprovalDecision(campaignId: number, reqId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.campaigns + `/${campaignId}/approval-requests/${reqId}/decisions`, payload)
  return data
}

export async function fetchCampaignComments(campaignId: number) {
  const { data } = await client.get(API_ENDPOINTS.campaigns + `/${campaignId}/comments`)
  return data
}

export async function addCampaignComment(campaignId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.campaigns + `/${campaignId}/comments`, payload)
  return data
}

export async function updateCampaignComment(campaignId: number, commentId: number, payload: Record<string, unknown>) {
  const { data } = await client.put(API_ENDPOINTS.campaigns + `/${campaignId}/comments/${commentId}`, payload)
  return data
}

export async function deleteCampaignComment(campaignId: number, commentId: number) {
  const { data } = await client.delete(API_ENDPOINTS.campaigns + `/${campaignId}/comments/${commentId}`)
  return data
}

export async function fetchPostVersions(campaignId: number, postId: number) {
  const { data } = await client.get(API_ENDPOINTS.campaigns + `/${campaignId}/versions/${postId}`)
  return data
}

export async function createPostVersion(campaignId: number, postId: number, payload: Record<string, unknown>) {
  const { data } = await client.post(API_ENDPOINTS.campaigns + `/${campaignId}/versions/${postId}`, payload)
  return data
}

export async function restorePostVersion(campaignId: number, versionId: number) {
  const { data } = await client.post(API_ENDPOINTS.campaigns + `/${campaignId}/versions/${versionId}/restore`)
  return data
}

/* Post Refinement */
export async function refinePost(
  campaignId: number,
  postId: number,
  payload: RefinementRequest,
): Promise<RefinementResponse> {
  const { data } = await client.post<RefinementResponse>(
    API_ENDPOINTS.campaigns + `/${campaignId}/posts/${postId}/refine`,
    payload,
  )
  return data
}

export async function fetchPostRevisions(campaignId: number, postId: number): Promise<PostRevision[]> {
  const { data } = await client.get<PostRevision[]>(
    API_ENDPOINTS.campaigns + `/${campaignId}/posts/${postId}/revisions`,
  )
  return data
}

export async function undoPostRefinement(campaignId: number, postId: number) {
  const { data } = await client.post(
    API_ENDPOINTS.campaigns + `/${campaignId}/posts/${postId}/undo`,
  )
  return data
}
