import { AlertCircle, X } from 'lucide-react'

interface InlineRefinementErrorProps {
  message: string
  onDismiss?: () => void
}

export function InlineRefinementError({ message, onDismiss }: InlineRefinementErrorProps) {
  return (
    <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
      <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
      <p className="flex-1">{message}</p>
      {onDismiss && (
        <button onClick={onDismiss} className="flex-shrink-0 hover:opacity-70">
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  )
}
