from __future__ import annotations

from functools import lru_cache

from fastapi import Depends, HTTPException, Request

from app.config import settings

FEATURE_FLAG_MAP: dict[str, str] = {
    "brand_guardrails": "enable_brand_guardrails",
    "audience_personas": "enable_audience_personas",
    "conversion_paths": "enable_conversion_paths",
    "source_to_campaign": "enable_source_to_campaign",
    "source_facts": "enable_source_facts",
    "content_packs": "enable_content_packs",
    "campaign_freshness": "enable_campaign_freshness",
    "strategy_modes": "enable_strategy_modes",
    "performance_memory": "enable_performance_memory",
    "experiments": "enable_experiments",
    "regional_languages": "enable_regional_languages",
    "competitor_gaps": "enable_competitor_gaps",
    "collaboration": "enable_collaboration",
}


@lru_cache
def is_feature_enabled(feature_name: str) -> bool:
    attr = FEATURE_FLAG_MAP.get(feature_name)
    if attr is None:
        return True
    return getattr(settings, attr, True)


def require_feature(feature_name: str):
    def checker(request: Request) -> None:
        if not is_feature_enabled(feature_name):
            raise HTTPException(
                status_code=404,
                detail="This feature is currently disabled",
            )

    return Depends(checker)


def get_public_feature_flags() -> dict:
    return {
        "brandGuardrails": settings.enable_brand_guardrails,
        "audiencePersonas": settings.enable_audience_personas,
        "conversionPaths": settings.enable_conversion_paths,
        "sourceToCampaign": settings.enable_source_to_campaign,
        "sourceFacts": settings.enable_source_facts,
        "contentPacks": settings.enable_content_packs,
        "campaignFreshness": settings.enable_campaign_freshness,
        "strategyModes": settings.enable_strategy_modes,
        "performanceMemory": settings.enable_performance_memory,
        "experiments": settings.enable_experiments,
        "regionalLanguages": settings.enable_regional_languages,
        "competitorGaps": settings.enable_competitor_gaps,
        "collaboration": settings.enable_collaboration,
    }
