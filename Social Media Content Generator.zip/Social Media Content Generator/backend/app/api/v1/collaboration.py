from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.api.deps_features import require_feature
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.db_models import (
    ApprovalDecision,
    ApprovalRequest,
    Campaign,
    CampaignComment,
    CampaignPost,
    PostVersion,
    User,
)
from app.models.workspace_schemas import (
    ApprovalDecisionCreate,
    ApprovalRequestCreate,
    ApprovalRequestResponse,
    PostVersionResponse,
)

router = APIRouter(
    prefix="/campaigns/{campaign_id}",
    tags=["Collaboration"],
    dependencies=[require_feature("collaboration")],
)


def _get_campaign_or_404(db: Session, campaign_id: int, user_id: int) -> Campaign:
    campaign = db.query(Campaign).filter(Campaign.id == campaign_id).first()
    if not campaign or campaign.user_id != user_id:
        raise NotFoundError("Campaign not found")
    return campaign


@router.post("/approval-requests", response_model=ApprovalRequestResponse)
def create_approval_request(
    campaign_id: int,
    request: ApprovalRequestCreate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_campaign_or_404(db, campaign_id, current_user.id)

    approval = ApprovalRequest(
        campaign_id=campaign_id,
        requested_by_id=current_user.id,
        status="pending",
    )
    db.add(approval)
    db.commit()
    db.refresh(approval)
    return approval


@router.get("/approval-requests", response_model=list[ApprovalRequestResponse])
def list_approval_requests(
    campaign_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_campaign_or_404(db, campaign_id, current_user.id)
    requests = (
        db.query(ApprovalRequest)
        .filter(ApprovalRequest.campaign_id == campaign_id)
        .order_by(ApprovalRequest.created_at.desc())
        .all()
    )
    return requests


@router.post("/approval-requests/{req_id}/decisions")
def add_approval_decision(
    campaign_id: int,
    req_id: int,
    request: ApprovalDecisionCreate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_campaign_or_404(db, campaign_id, current_user.id)

    approval = (
        db.query(ApprovalRequest)
        .filter(ApprovalRequest.id == req_id, ApprovalRequest.campaign_id == campaign_id)
        .first()
    )
    if not approval:
        raise NotFoundError("Approval request not found")

    decision = ApprovalDecision(
        approval_request_id=approval.id,
        reviewer_id=current_user.id,
        decision=request.decision,
        comment=request.comment,
    )
    db.add(decision)

    approval.status = request.decision
    db.commit()

    return {"detail": f"Decision recorded: {request.decision}"}


@router.get("/comments")
def list_comments(
    campaign_id: int,
    post_id: int | None = None,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_campaign_or_404(db, campaign_id, current_user.id)

    query = db.query(CampaignComment).filter(CampaignComment.campaign_id == campaign_id)
    if post_id is not None:
        query = query.filter(CampaignComment.post_id == post_id)
    comments = query.order_by(CampaignComment.created_at.asc()).all()

    result = []
    for c in comments:
        result.append(
            {
                "id": c.id,
                "campaign_id": c.campaign_id,
                "post_id": c.post_id,
                "author_id": c.author_id,
                "author_name": c.author.name if c.author else None,
                "content": c.content,
                "is_resolved": c.is_resolved,
                "parent_id": c.parent_id,
                "created_at": c.created_at.isoformat() if c.created_at else None,
            }
        )
    return result


@router.post("/comments")
def add_comment(
    campaign_id: int,
    content: str,
    post_id: int | None = None,
    parent_id: int | None = None,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_campaign_or_404(db, campaign_id, current_user.id)

    comment = CampaignComment(
        campaign_id=campaign_id,
        post_id=post_id,
        author_id=current_user.id,
        content=content,
        parent_id=parent_id,
    )
    db.add(comment)
    db.commit()
    db.refresh(comment)

    return {
        "id": comment.id,
        "campaign_id": comment.campaign_id,
        "post_id": comment.post_id,
        "author_id": comment.author_id,
        "author_name": current_user.name,
        "content": comment.content,
        "parent_id": comment.parent_id,
        "created_at": comment.created_at.isoformat() if comment.created_at else None,
    }


@router.put("/comments/{comment_id}")
def edit_comment(
    campaign_id: int,
    comment_id: int,
    content: str,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_campaign_or_404(db, campaign_id, current_user.id)

    comment = (
        db.query(CampaignComment)
        .filter(
            CampaignComment.id == comment_id,
            CampaignComment.campaign_id == campaign_id,
            CampaignComment.author_id == current_user.id,
        )
        .first()
    )
    if not comment:
        raise NotFoundError("Comment not found")

    comment.content = content
    db.commit()
    db.refresh(comment)

    return {
        "id": comment.id,
        "content": comment.content,
        "updated": True,
    }


@router.delete("/comments/{comment_id}")
def delete_comment(
    campaign_id: int,
    comment_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_campaign_or_404(db, campaign_id, current_user.id)

    comment = (
        db.query(CampaignComment)
        .filter(
            CampaignComment.id == comment_id,
            CampaignComment.campaign_id == campaign_id,
            CampaignComment.author_id == current_user.id,
        )
        .first()
    )
    if not comment:
        raise NotFoundError("Comment not found")

    db.delete(comment)
    db.commit()
    return {"detail": "Comment deleted"}


@router.get("/versions", response_model=list[PostVersionResponse])
def list_versions(
    campaign_id: int,
    post_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_campaign_or_404(db, campaign_id, current_user.id)

    post = db.query(CampaignPost).filter(CampaignPost.id == post_id, CampaignPost.campaign_id == campaign_id).first()
    if not post:
        raise NotFoundError("Post not found")

    versions = (
        db.query(PostVersion).filter(PostVersion.post_id == post_id).order_by(PostVersion.version_number.desc()).all()
    )
    return versions


@router.post("/versions", response_model=PostVersionResponse)
def create_version(
    campaign_id: int,
    post_id: int,
    change_reason: str | None = None,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_campaign_or_404(db, campaign_id, current_user.id)

    post = db.query(CampaignPost).filter(CampaignPost.id == post_id, CampaignPost.campaign_id == campaign_id).first()
    if not post:
        raise NotFoundError("Post not found")

    last_version = (
        db.query(PostVersion).filter(PostVersion.post_id == post_id).order_by(PostVersion.version_number.desc()).first()
    )
    next_number = (last_version.version_number + 1) if last_version else 1

    version = PostVersion(
        post_id=post_id,
        version_number=next_number,
        changed_by_id=current_user.id,
        change_reason=change_reason,
        caption=post.caption,
        call_to_action=post.call_to_action,
        hashtags=post.hashtags,
    )
    db.add(version)
    db.commit()
    db.refresh(version)
    return version


@router.post("/versions/{version_id}/restore")
def restore_version(
    campaign_id: int,
    version_id: int,
    post_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_campaign_or_404(db, campaign_id, current_user.id)

    post = db.query(CampaignPost).filter(CampaignPost.id == post_id, CampaignPost.campaign_id == campaign_id).first()
    if not post:
        raise NotFoundError("Post not found")

    version = db.query(PostVersion).filter(PostVersion.id == version_id, PostVersion.post_id == post_id).first()
    if not version:
        raise NotFoundError("Version not found")

    last_version = (
        db.query(PostVersion).filter(PostVersion.post_id == post_id).order_by(PostVersion.version_number.desc()).first()
    )
    next_number = (last_version.version_number + 1) if last_version else 1

    new_version = PostVersion(
        post_id=post_id,
        version_number=next_number,
        changed_by_id=current_user.id,
        change_reason=f"Restored from version {version.version_number}",
        caption=post.caption,
        call_to_action=post.call_to_action,
        hashtags=post.hashtags,
    )
    db.add(new_version)

    post.caption = version.caption
    post.call_to_action = version.call_to_action
    post.hashtags = version.hashtags
    db.commit()

    return {"detail": f"Post restored to version {version.version_number}"}
