import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Instagram, Linkedin, Music2, Facebook, Twitter } from 'lucide-react'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { cn } from '@/utils/cn'

interface PlatformContent {
  id: string
  name: string
  icon: typeof Instagram
  gradient: string
  caption: string
  contentType: string
  ctaStyle: string
  hashtagCount: string
}

const platformContent: PlatformContent[] = [
  {
    id: 'instagram',
    name: 'Instagram',
    icon: Instagram,
    gradient: 'from-pink-500 to-purple-600',
    caption: 'Meet the cold brew that started it all. Single-origin Colombian beans, slow-steeped for 20 hours, served over ice with a touch of oat milk. This is not your corner store iced coffee. This is craft in a cup.',
    contentType: 'Carousel or Reel',
    ctaStyle: 'Visual-first CTA (link in bio, save, share)',
    hashtagCount: '8-12 hashtags',
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    icon: Linkedin,
    gradient: 'from-blue-600 to-blue-800',
    caption: 'We spent two years perfecting our cold brew process. Not because it is complicated, but because the details matter. From bean origin to steep time to filtration, every variable affects the taste. Here is what we learned about building a product that demands patience.',
    contentType: 'Article or Carousel',
    ctaStyle: 'Thought-leadership CTA (share your experience)',
    hashtagCount: '3-5 hashtags',
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    icon: Music2,
    gradient: 'from-black to-gray-800',
    caption: 'POV: You just made the best cold brew of your life in 30 seconds. Drop a follow for more coffee hacks that actually work.',
    contentType: 'Short-form Video',
    ctaStyle: 'Hook-first CTA (follow, duet, comment)',
    hashtagCount: '4-6 hashtags',
  },
  {
    id: 'facebook',
    name: 'Facebook',
    icon: Facebook,
    gradient: 'from-blue-500 to-blue-700',
    caption: 'What is your go-to coffee order? Ours is a cold brew with oat milk and a shot of vanilla. Comment yours below and we will feature the best answers in our next post. Let us build this community one cup at a time.',
    contentType: 'Community Post',
    ctaStyle: 'Discussion-focused CTA (comment, share)',
    hashtagCount: '4-7 hashtags',
  },
  {
    id: 'twitter',
    name: 'X',
    icon: Twitter,
    gradient: 'from-gray-900 to-black',
    caption: 'hot take: cold brew is not just a summer drink. it is a productivity ritual. fight me.',
    contentType: 'Short Thread',
    ctaStyle: 'Conversation-starter CTA (reply, retweet)',
    hashtagCount: '1-3 hashtags',
  },
]

export function PlatformLens() {
  const [active, setActive] = useState(platformContent[0]?.id || 'instagram')
  const reduced = useReducedMotionPreference()

  const current = platformContent.find((p) => p.id === active)

  if (!current) return null

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            One campaign. Native content for every platform.
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            The same campaign idea adapts to each platform's format, audience, and best practices.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {platformContent.map((p) => {
            const Icon = p.icon
            return (
              <button
                key={p.id}
                onClick={() => setActive(p.id)}
                className={cn(
                  'flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium border transition-all duration-200',
                  active === p.id
                    ? 'border-purple-600 bg-purple-50 text-purple-700 shadow-sm'
                    : 'border-gray-200 bg-white text-gray-600 hover:border-purple-300 hover:text-purple-700',
                )}
              >
                <div className={cn('w-6 h-6 rounded-md bg-gradient-to-br flex items-center justify-center', p.gradient)}>
                  <Icon className="w-3 h-3 text-white" />
                </div>
                {p.name}
              </button>
            )
          })}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={reduced ? undefined : { opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={reduced ? undefined : { opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="max-w-4xl mx-auto"
          >
            <div className="grid md:grid-cols-5 gap-6">
              <div className="md:col-span-3 bg-gray-50 rounded-2xl p-6 border border-gray-100">
                <div className="flex items-center gap-2 mb-4">
                  <div className={cn('w-8 h-8 rounded-lg bg-gradient-to-br flex items-center justify-center', current.gradient)}>
                    <current.icon className="w-4 h-4 text-white" />
                  </div>
                  <span className="font-semibold text-gray-900">{current.name}</span>
                  <span className="text-xs text-gray-400 ml-auto">{current.contentType}</span>
                </div>
                <p className="text-sm text-gray-700 leading-relaxed">{current.caption}</p>
              </div>

              <div className="md:col-span-2 space-y-4">
                <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
                  <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Content Type</span>
                  <p className="text-sm font-medium text-gray-900 mt-1">{current.contentType}</p>
                </div>
                <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
                  <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">CTA Style</span>
                  <p className="text-sm font-medium text-gray-900 mt-1">{current.ctaStyle}</p>
                </div>
                <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
                  <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Hashtags</span>
                  <p className="text-sm font-medium text-gray-900 mt-1">{current.hashtagCount}</p>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  )
}
