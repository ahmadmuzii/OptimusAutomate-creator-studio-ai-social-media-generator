from __future__ import annotations


class TestStrategyModes:
    """Test strategy template CRUD and apply endpoints."""

    STRATEGY_PAYLOAD = {
        "name": "Awareness Push",
        "description": "Top-of-funnel awareness campaign",
        "funnel_stage": "awareness",
        "campaign_goal": "brand_awareness",
        "recommended_ctas": ["Learn More", "Sign Up"],
        "content_mix": ["educational", "entertainment"],
        "post_frequency": "5x_week",
        "platform_focus": "instagram",
        "icon": "bullhorn",
        "is_default": False,
    }

    def test_create_strategy(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.post(
            f"/api/v1/brands/{brand_id}/strategies",
            json=self.STRATEGY_PAYLOAD,
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Awareness Push"
        assert data["funnel_stage"] == "awareness"
        assert data["campaign_goal"] == "brand_awareness"
        assert data["post_frequency"] == "5x_week"
        assert data["platform_focus"] == "instagram"
        assert data["is_default"] is False

    def test_list_strategies(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        client.post(f"/api/v1/brands/{brand_id}/strategies", json=self.STRATEGY_PAYLOAD, headers=auth_headers)
        client.post(
            f"/api/v1/brands/{brand_id}/strategies",
            json={**self.STRATEGY_PAYLOAD, "name": "Retargeting Flow", "funnel_stage": "retention"},
            headers=auth_headers,
        )
        response = client.get(f"/api/v1/brands/{brand_id}/strategies", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2

    def test_get_strategy(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(
            f"/api/v1/brands/{brand_id}/strategies", json=self.STRATEGY_PAYLOAD, headers=auth_headers
        ).json()
        response = client.get(f"/api/v1/brands/{brand_id}/strategies/{created['id']}", headers=auth_headers)
        assert response.status_code == 200
        assert response.json()["name"] == "Awareness Push"

    def test_update_strategy(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(
            f"/api/v1/brands/{brand_id}/strategies", json=self.STRATEGY_PAYLOAD, headers=auth_headers
        ).json()
        response = client.put(
            f"/api/v1/brands/{brand_id}/strategies/{created['id']}",
            json={"name": "Updated Strategy", "post_frequency": "1x_week"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Updated Strategy"
        assert data["post_frequency"] == "1x_week"

    def test_delete_strategy(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(
            f"/api/v1/brands/{brand_id}/strategies", json=self.STRATEGY_PAYLOAD, headers=auth_headers
        ).json()
        response = client.delete(f"/api/v1/brands/{brand_id}/strategies/{created['id']}", headers=auth_headers)
        assert response.status_code == 200
        assert response.json()["detail"] == "Strategy template deleted"
        get_resp = client.get(f"/api/v1/brands/{brand_id}/strategies", headers=auth_headers)
        assert len(get_resp.json()) == 0

    def test_apply_strategy_to_campaign(self, client, auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        template = client.post(
            f"/api/v1/brands/{brand_id}/strategies", json=self.STRATEGY_PAYLOAD, headers=auth_headers
        ).json()
        campaign_id = created_campaign["id"]
        response = client.post(
            f"/api/v1/brands/{brand_id}/strategies/apply",
            json={"template_id": template["id"], "campaign_id": campaign_id},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["detail"] == "Strategy applied to campaign"
        assert data["campaign_id"] == campaign_id
        assert data["template_name"] == "Awareness Push"

    def test_cannot_access_other_users_strategy(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(
            f"/api/v1/brands/{brand_id}/strategies", json=self.STRATEGY_PAYLOAD, headers=auth_headers
        ).json()
        response = client.get(f"/api/v1/brands/{brand_id}/strategies/{created['id']}", headers=second_auth_headers)
        assert response.status_code == 404
