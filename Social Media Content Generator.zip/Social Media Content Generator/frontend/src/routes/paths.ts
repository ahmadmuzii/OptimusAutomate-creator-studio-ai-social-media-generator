export const ROUTES = {
  home: '/',
  login: '/login',
  signup: '/signup',
  forgotPassword: '/forgot-password',
  resetPassword: '/reset-password',
  campaignGenerator: '/tools/campaign-generator',
  dashboard: '/dashboard',
  dashboardHome: '/dashboard',
  generate: '/dashboard/generate',
  calendar: '/dashboard/calendar',
  captions: '/dashboard/captions',
  brands: '/dashboard/brands',
  brandDetail: '/dashboard/brands/:brandId',
  brandGuardrails: '/dashboard/brands/:brandId/guardrails',
  brandPersonas: '/dashboard/brands/:brandId/personas',
  brandConversionPaths: '/dashboard/brands/:brandId/conversion-paths',
  brandSourceDocuments: '/dashboard/brands/:brandId/source-documents',
  brandContentPacks: '/dashboard/brands/:brandId/content-packs',
  brandFreshness: '/dashboard/brands/:brandId/freshness',
  brandStrategies: '/dashboard/brands/:brandId/strategies',
  brandPerformance: '/dashboard/brands/:brandId/performance',
  brandExperiments: '/dashboard/brands/:brandId/experiments',
  brandRegional: '/dashboard/brands/:brandId/regional',
  brandCompetitors: '/dashboard/brands/:brandId/competitors',
  workspaces: '/dashboard/workspaces',
  collaboration: '/dashboard/campaigns/:campaignId/collaboration',
  shareCampaign: '/dashboard/campaigns/:campaignId/share',
  history: '/dashboard/history',
  profile: '/dashboard/profile',
  settings: '/dashboard/settings',
  notFound: '*',
} as const

export function getGenerateCampaignRoute(platform?: string): string {
  if (!platform) {
    return ROUTES.generate
  }
  return `${ROUTES.generate}?platform=${encodeURIComponent(platform)}`
}
