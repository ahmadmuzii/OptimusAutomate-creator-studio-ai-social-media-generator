import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { GapSummaryCards } from '../GapSummaryCards'
import { TopicCoverageChart } from '../TopicCoverageChart'
import { CompetitorContentMixChart } from '../CompetitorContentMixChart'
import { ContentOpportunityChart } from '../ContentOpportunityChart'
import { OpportunityTable } from '../OpportunityTable'
import type { GapReportSummary, TopicCoverageItem, ContentMixItem, OpportunityItem } from '@/types/competitor'

const mockSummary: GapReportSummary = {
  competitors_analyzed: 3,
  posts_analyzed: 6,
  unique_topics: 22,
  opportunities_found: 14,
}

const mockTopicCoverage: TopicCoverageItem[] = [
  { topic: 'coffee culture', post_count: 3, competitor_count: 2, competitors: ['CompA', 'CompB'] },
  { topic: 'seasonal drinks', post_count: 3, competitor_count: 2, competitors: ['CompA', 'CompB'] },
  { topic: 'iced coffee', post_count: 2, competitor_count: 2, competitors: ['CompA', 'CompB'] },
]

const mockContentMix: ContentMixItem[] = [
  { competitor: 'CompA', content_types: { carousel: 2, reel: 1 } },
  { competitor: 'CompB', content_types: { reel: 2, static_post: 1 } },
]

const mockOpportunities: OpportunityItem[] = [
  {
    topic: 'seasonal drinks',
    competitor_coverage: 3,
    brand_coverage: 0,
    competitors: ['CompA', 'CompB'],
    priority: 'high',
    suggested_format: 'Reel',
    selected_for_generation: false,
  },
  {
    topic: 'coffee culture',
    competitor_coverage: 2,
    brand_coverage: 0,
    competitors: ['CompA', 'CompB'],
    priority: 'high',
    suggested_format: 'Carousel',
    selected_for_generation: false,
  },
  {
    topic: 'café ambience',
    competitor_coverage: 2,
    brand_coverage: 1,
    competitors: ['CompA'],
    priority: 'medium',
    suggested_format: null,
    selected_for_generation: false,
  },
]

describe('GapSummaryCards', () => {
  it('renders all four summary cards with correct counts', () => {
    render(<GapSummaryCards summary={mockSummary} />)
    expect(screen.getByText('3')).toBeInTheDocument()
    expect(screen.getByText('6')).toBeInTheDocument()
    expect(screen.getByText('22')).toBeInTheDocument()
    expect(screen.getByText('14')).toBeInTheDocument()
    expect(screen.getByText('Competitors analyzed')).toBeInTheDocument()
    expect(screen.getByText('Posts analyzed')).toBeInTheDocument()
    expect(screen.getByText('Unique topics detected')).toBeInTheDocument()
    expect(screen.getByText('Content opportunities found')).toBeInTheDocument()
  })
})

describe('TopicCoverageChart', () => {
  it('renders chart title for topic data', () => {
    render(<TopicCoverageChart data={mockTopicCoverage} />)
    expect(screen.getByText('Most Covered Competitor Topics')).toBeInTheDocument()
  })

  it('returns null for empty data', () => {
    const { container } = render(<TopicCoverageChart data={[]} />)
    expect(container.innerHTML).toBe('')
  })
})

describe('CompetitorContentMixChart', () => {
  it('renders chart title with competitor data', () => {
    render(<CompetitorContentMixChart data={mockContentMix} />)
    expect(screen.getByText('Competitor Content Mix')).toBeInTheDocument()
  })

  it('returns null for empty data', () => {
    const { container } = render(<CompetitorContentMixChart data={[]} />)
    expect(container.innerHTML).toBe('')
  })
})

describe('ContentOpportunityChart', () => {
  it('renders chart title comparing competitor and brand coverage', () => {
    render(<ContentOpportunityChart data={mockOpportunities} />)
    expect(screen.getByText('Content Gap Opportunities')).toBeInTheDocument()
  })

  it('returns null for empty data', () => {
    const { container } = render(<ContentOpportunityChart data={[]} />)
    expect(container.innerHTML).toBe('')
  })
})

describe('OpportunityTable', () => {
  it('renders opportunities with priority badges', () => {
    render(<OpportunityTable data={mockOpportunities} />)
    expect(screen.getByText('Top Opportunities')).toBeInTheDocument()
    expect(screen.getByText('seasonal drinks')).toBeInTheDocument()
    expect(screen.getByText('coffee culture')).toBeInTheDocument()
    expect(screen.getByText('café ambience')).toBeInTheDocument()
    expect(screen.getAllByText('High').length).toBe(2)
    expect(screen.getByText('Medium')).toBeInTheDocument()
  })

  it('shows Use in Campaign buttons', () => {
    render(<OpportunityTable data={mockOpportunities} />)
    const buttons = screen.getAllByText('Use in Campaign')
    expect(buttons.length).toBe(3)
  })

  it('returns null for empty data', () => {
    const { container } = render(<OpportunityTable data={[]} />)
    expect(container.innerHTML).toBe('')
  })
})
