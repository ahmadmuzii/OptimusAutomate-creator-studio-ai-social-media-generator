import { render, screen } from '@testing-library/react'
import { BrowserRouter } from 'react-router-dom'
import { describe, it, expect, vi } from 'vitest'
import { LandingPage } from '@/pages/LandingPage'

vi.mock('@/context/AuthContext', () => ({
  useAuth: () => ({
    isAuthenticated: false,
    user: null,
    isLoading: false,
  }),
}))

function renderLanding() {
  return render(
    <BrowserRouter>
      <LandingPage />
    </BrowserRouter>,
  )
}

describe('LandingPage', () => {
  it('renders without crashing', () => {
    renderLanding()
    expect(document.body).toBeDefined()
  })

  it('renders the navbar with Creator Studio logo', () => {
    renderLanding()
    const logos = screen.getAllByText('Creator Studio')
    expect(logos.length).toBeGreaterThan(0)
  })

  it('renders the hero section with main heading', () => {
    renderLanding()
    expect(screen.getByText('One brand brief.')).toBeDefined()
  })

  it('renders sign in links', () => {
    renderLanding()
    const signInLinks = screen.getAllByText('Sign In')
    expect(signInLinks.length).toBeGreaterThan(0)
  })

  it('renders start free buttons', () => {
    renderLanding()
    const startFree = screen.getAllByText('Start Free')
    expect(startFree.length).toBeGreaterThan(0)
  })

  it('renders FAQ section', () => {
    renderLanding()
    expect(screen.getByText('Frequently asked questions')).toBeDefined()
  })

  it('renders footer with copyright', () => {
    renderLanding()
    const year = new Date().getFullYear()
    expect(screen.getByText(`© ${year} Creator Studio. All rights reserved.`)).toBeDefined()
  })
})
