from __future__ import annotations

from collections.abc import Callable
from functools import lru_cache


def async_lru_cache(maxsize: int = 128):
    def decorator(func: Callable):
        return lru_cache(maxsize=maxsize)(func)

    return decorator
