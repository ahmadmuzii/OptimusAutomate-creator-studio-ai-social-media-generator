from __future__ import annotations

import os

import pytest
from fastapi.testclient import TestClient


@pytest.mark.skipif(not os.environ.get("GROQ_API_KEY"), reason="GROQ_API_KEY not set")
class TestCalendarGroq:
    def test_generate_calendar_success(self, client: TestClient, sample_calendar_payload: dict) -> None:
        response = client.post("/api/v1/generate-calendar", json=sample_calendar_payload)
        assert response.status_code == 200
        data = response.json()
        assert "calendar" in data
        assert len(data["calendar"]) >= 1
        for day in data["calendar"]:
            assert "day" in day
            assert "contentTheme" in day
            assert "postIdea" in day
            assert "platform" in day
            assert "suggestedTime" in day
            assert "contentType" in day
            assert "caption" in day
            assert "hashtags" in day

    def test_generate_calendar_invalid_platform(self, client: TestClient, sample_calendar_payload: dict) -> None:
        payload = {**sample_calendar_payload, "platform": "MySpace"}
        response = client.post("/api/v1/generate-calendar", json=payload)
        assert response.status_code == 400

    def test_generate_calendar_invalid_tone(self, client: TestClient, sample_calendar_payload: dict) -> None:
        payload = {**sample_calendar_payload, "tone": "aggressive"}
        response = client.post("/api/v1/generate-calendar", json=payload)
        assert response.status_code == 400


class TestCalendarFallback:
    def test_generate_calendar_returns_generation_source(
        self, client: TestClient, sample_calendar_payload: dict
    ) -> None:
        response = client.post("/api/v1/generate-calendar", json=sample_calendar_payload)
        assert response.status_code == 200
        data = response.json()
        assert "generationSource" in data
        assert data["generationSource"] == "fallback"
        assert "saved" in data
        assert data["saved"] is False

    def test_generate_calendar_returns_7_days(self, client: TestClient, sample_calendar_payload: dict) -> None:
        response = client.post("/api/v1/generate-calendar", json=sample_calendar_payload)
        assert response.status_code == 200
        data = response.json()
        assert len(data["calendar"]) == 7

    def test_groq_status_endpoint(self, client: TestClient) -> None:
        response = client.get("/api/v1/groq-status")
        assert response.status_code == 200
        data = response.json()
        assert "enabled" in data
        assert "key_configured" in data
        assert "model" in data

    def test_generate_calendar_saves_with_brand_profile_id(
        self, client, auth_headers, created_brand, sample_calendar_payload
    ):
        payload = {
            **sample_calendar_payload,
            "brandProfileId": created_brand["id"],
        }
        response = client.post("/api/v1/generate-calendar", json=payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["saved"] is True

        # Verify campaign was saved with the brand's ID
        camp_response = client.get("/api/v1/campaigns", headers=auth_headers)
        assert camp_response.status_code == 200
        campaigns = camp_response.json()
        matching = [c for c in campaigns if c["brand_profile_id"] == created_brand["id"]]
        assert len(matching) >= 1
        assert matching[0]["brand_profile_id"] == created_brand["id"]

    def test_generate_calendar_rejects_other_users_brand(
        self, client, second_auth_headers, created_brand, sample_calendar_payload
    ):
        payload = {
            **sample_calendar_payload,
            "brandProfileId": created_brand["id"],
        }
        response = client.post("/api/v1/generate-calendar", json=payload, headers=second_auth_headers)
        assert response.status_code == 404

    def test_generate_calendar_without_brand_id_creates_campaign_with_null_brand(
        self, client, auth_headers, sample_calendar_payload
    ):
        response = client.post("/api/v1/generate-calendar", json=sample_calendar_payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["saved"] is True

        camp_response = client.get("/api/v1/campaigns", headers=auth_headers)
        campaigns = camp_response.json()
        # The most recent campaign should have null brand_profile_id
        latest = campaigns[0]
        assert latest["brand_profile_id"] is None
