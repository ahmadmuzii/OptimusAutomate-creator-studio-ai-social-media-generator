from fastapi import APIRouter

from app.api.v1.auth import router as auth_router
from app.api.v1.brand_guardrails import router as brand_guardrails_router
from app.api.v1.brands import router as brands_router
from app.api.v1.calendar import router as calendar_router
from app.api.v1.campaign_freshness import router as campaign_freshness_router
from app.api.v1.campaigns import router as campaigns_router
from app.api.v1.captions import router as captions_router
from app.api.v1.collaboration import router as collaboration_router
from app.api.v1.competitors import router as competitors_router
from app.api.v1.content_packs import router as content_packs_router
from app.api.v1.conversion_paths import router as conversion_router
from app.api.v1.experiments import router as experiments_router
from app.api.v1.features import router as features_router
from app.api.v1.health import router as health_router
from app.api.v1.performance import router as performance_router
from app.api.v1.personas import router as personas_router
from app.api.v1.platforms import router as platforms_router
from app.api.v1.regional import router as regional_router
from app.api.v1.source_documents import router as source_router
from app.api.v1.strategy_modes import router as strategy_modes_router
from app.api.v1.uploads import router as uploads_router
from app.api.v1.workspaces import router as workspaces_router

router = APIRouter(prefix="/api/v1")
router.include_router(auth_router)
router.include_router(features_router)
router.include_router(uploads_router)
router.include_router(brand_guardrails_router)
router.include_router(brands_router)
router.include_router(personas_router)
router.include_router(campaigns_router)
router.include_router(health_router)
router.include_router(platforms_router)
router.include_router(calendar_router)
router.include_router(captions_router)
router.include_router(conversion_router)
router.include_router(source_router)
router.include_router(content_packs_router)
router.include_router(campaign_freshness_router)
router.include_router(strategy_modes_router)
router.include_router(performance_router)
router.include_router(experiments_router)
router.include_router(regional_router)
router.include_router(competitors_router)
router.include_router(workspaces_router)
router.include_router(collaboration_router)
