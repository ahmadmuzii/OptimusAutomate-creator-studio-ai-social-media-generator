from __future__ import annotations

import os

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import sessionmaker

os.environ["APP_ENV"] = "development"
os.environ["DATABASE_URL"] = "sqlite:///./test_social_media.db"
os.environ["SECRET_KEY"] = "test-secret-key-for-testing-only"
os.environ["ACCESS_TOKEN_EXPIRE_MINUTES"] = "15"
os.environ["REFRESH_TOKEN_EXPIRE_DAYS"] = "7"
os.environ["GROQ_API_KEY"] = ""
os.environ["CORS_ORIGINS"] = '["*"]'

from app.database import Base, engine  # noqa: E402
from app.main import create_app  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def setup_database():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)
    engine.dispose()
    try:
        os.remove("test_social_media.db")
    except FileNotFoundError:
        pass


@pytest.fixture
def app():
    return create_app()


@pytest.fixture
def client(app):
    return TestClient(app)


@pytest.fixture
def db_session():
    session = sessionmaker(bind=engine)()
    try:
        yield session
    finally:
        session.rollback()
        session.close()


@pytest.fixture
def user_payload():
    return {
        "email": "test@example.com",
        "password": "testpass123",
        "name": "Test User",
    }


def _register_or_login(client, payload):
    response = client.post("/api/v1/auth/signup", json=payload)
    if response.status_code == 409:
        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": payload["email"],
                "password": payload["password"],
            },
        )
    assert response.status_code == 200
    data = response.json()
    refresh_token = response.cookies.get("refresh_token")
    assert refresh_token, "refresh_token cookie not set"
    return {
        "id": data["user"]["id"],
        "email": data["user"]["email"],
        "name": data["user"]["name"],
        "access_token": data["access_token"],
        "refresh_token": refresh_token,
    }


@pytest.fixture
def registered_user(client):
    return _register_or_login(
        client,
        {
            "email": "registered@example.com",
            "password": "testpass123",
            "name": "Registered User",
        },
    )


@pytest.fixture
def second_user(client):
    return _register_or_login(
        client,
        {
            "email": "other@example.com",
            "password": "otherpass123",
            "name": "Other User",
        },
    )


@pytest.fixture
def auth_headers(registered_user):
    return {"Authorization": f"Bearer {registered_user['access_token']}"}


@pytest.fixture
def second_auth_headers(second_user):
    return {"Authorization": f"Bearer {second_user['access_token']}"}


@pytest.fixture
def sample_brand_payload():
    return {
        "name": "TestBrand",
        "description": "A test brand",
        "niche": "technology",
        "target_audience": "Developers",
        "website": "https://testbrand.com",
    }


@pytest.fixture
def created_brand(client, auth_headers, sample_brand_payload):
    response = client.post("/api/v1/brands", json=sample_brand_payload, headers=auth_headers)
    assert response.status_code == 200
    return response.json()


@pytest.fixture
def sample_campaign_payload(created_brand):
    return {
        "name": "Test Campaign",
        "platform": "instagram",
        "tone": "professional",
        "campaign_goal": "brand_awareness",
        "brand_profile_id": created_brand["id"],
        "posts": [
            {
                "day": 1,
                "contentTheme": "Brand Story",
                "postIdea": "Introduction post",
                "contentType": "carousel",
                "suggestedTime": "9:00 AM",
                "platform": "instagram",
                "caption": "Welcome to our brand!",
                "callToAction": "Follow us",
                "hashtags": ["#brand", "#story"],
            },
            {
                "day": 2,
                "contentTheme": "Value Post",
                "postIdea": "Educational content",
                "contentType": "static_post",
                "suggestedTime": "12:00 PM",
                "platform": "instagram",
                "caption": "Here's a tip for you",
                "callToAction": "Share this",
                "hashtags": ["#tips", "#value"],
            },
        ],
    }


@pytest.fixture
def created_campaign(client, auth_headers, sample_campaign_payload):
    response = client.post("/api/v1/campaigns", json=sample_campaign_payload, headers=auth_headers)
    assert response.status_code == 200
    return response.json()


@pytest.fixture
def sample_calendar_payload():
    return {
        "brand_name": "TestBrand",
        "brand_description": "A test brand",
        "niche": "technology",
        "target_audience": "Developers",
        "platform": "instagram",
        "tone": "professional",
        "campaign_goal": "brand_awareness",
    }


@pytest.fixture
def sample_caption_payload():
    return {
        "post_idea": "Introduction post",
        "platform": "instagram",
        "tone": "professional",
        "brand_details": {
            "brandName": "TestBrand",
            "niche": "technology",
            "campaignGoal": "engagement",
        },
    }
