import { Link } from 'react-router-dom'
import { Sparkles } from 'lucide-react'

const productLinks = [
  { label: 'Features', href: '#features-grid' },
  { label: 'How It Works', href: '#how-it-works' },
  { label: 'Examples', href: '#live-example' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Campaign Generator', href: '/tools/campaign-generator' },
]

const resourceLinks = [
  { label: 'Sign In', href: '/login' },
  { label: 'Create Account', href: '/signup' },
]

export function LandingFooter() {
  const year = new Date().getFullYear()

  const handleSmoothScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (href.startsWith('#')) {
      e.preventDefault()
      const id = href.replace('#', '')
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <footer className="bg-gray-900 text-gray-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <Link to="/" className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="text-base font-bold text-white">Creator Studio</span>
            </Link>
            <p className="text-sm text-gray-500 max-w-sm leading-relaxed">
              Turn one brand brief into a complete seven-day social media campaign with platform-ready captions, CTAs, hashtags, and a visual content calendar.
            </p>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-gray-300 uppercase tracking-wider mb-4">Product</h3>
            <ul className="space-y-3">
              {productLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.href}
                    onClick={(e) => handleSmoothScroll(e, link.href)}
                    className="text-sm text-gray-500 hover:text-white transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-gray-300 uppercase tracking-wider mb-4">Account</h3>
            <ul className="space-y-3">
              {resourceLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.href}
                    className="text-sm text-gray-500 hover:text-white transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-gray-600">
            &copy; {year} Creator Studio. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <span className="text-xs text-gray-600">Terms</span>
            <span className="text-xs text-gray-600">Privacy</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
