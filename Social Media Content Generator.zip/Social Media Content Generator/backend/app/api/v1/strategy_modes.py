from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.api.deps_features import require_feature
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.db_models import BrandProfile, Campaign, User
from app.models.strategy_db import StrategyTemplate
from app.models.strategy_schemas import (
    ApplyStrategyRequest,
    StrategyTemplateCreate,
    StrategyTemplateUpdate,
)
from app.models.strategy_schemas import (
    StrategyTemplate as StrategyTemplateSchema,
)

router = APIRouter(
    prefix="/brands/{brand_id}/strategies",
    tags=["Strategy Modes"],
    dependencies=[require_feature("strategy_modes")],
)


def _get_brand_or_404(db: Session, brand_id: int, user_id: int) -> BrandProfile:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != user_id:
        raise NotFoundError("Brand not found")
    return brand


def _template_to_schema(t: StrategyTemplate) -> StrategyTemplateSchema:
    return StrategyTemplateSchema(
        id=t.id,
        brand_id=t.brand_id,
        name=t.name,
        description=t.description,
        funnel_stage=t.funnel_stage,
        campaign_goal=t.campaign_goal,
        recommended_ctas=t.recommended_ctas or [],
        content_mix=t.content_mix or [],
        post_frequency=t.post_frequency,
        platform_focus=t.platform_focus,
        icon=t.icon,
        is_default=t.is_default,
    )


@router.get("", response_model=list[StrategyTemplateSchema])
def list_strategies(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    templates = db.query(StrategyTemplate).filter(StrategyTemplate.brand_id == brand_id).all()
    return [_template_to_schema(t) for t in templates]


@router.post("", response_model=StrategyTemplateSchema)
def create_strategy(
    brand_id: int,
    request: StrategyTemplateCreate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    brand = _get_brand_or_404(db, brand_id, current_user.id)

    template = StrategyTemplate(
        brand_id=brand.id,
        name=request.name,
        description=request.description,
        funnel_stage=request.funnel_stage,
        campaign_goal=request.campaign_goal,
        recommended_ctas=request.recommended_ctas,
        content_mix=request.content_mix,
        post_frequency=request.post_frequency,
        platform_focus=request.platform_focus,
        icon=request.icon,
        is_default=request.is_default,
    )
    db.add(template)
    db.commit()
    db.refresh(template)
    return _template_to_schema(template)


@router.get("/{template_id}", response_model=StrategyTemplateSchema)
def get_strategy(
    brand_id: int,
    template_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    template = (
        db.query(StrategyTemplate)
        .filter(
            StrategyTemplate.id == template_id,
            StrategyTemplate.brand_id == brand_id,
        )
        .first()
    )
    if not template:
        raise NotFoundError("Strategy template not found")
    return _template_to_schema(template)


@router.put("/{template_id}", response_model=StrategyTemplateSchema)
def update_strategy(
    brand_id: int,
    template_id: int,
    request: StrategyTemplateUpdate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    template = (
        db.query(StrategyTemplate)
        .filter(
            StrategyTemplate.id == template_id,
            StrategyTemplate.brand_id == brand_id,
        )
        .first()
    )
    if not template:
        raise NotFoundError("Strategy template not found")

    update_data = request.model_dump(exclude_none=True)
    for key, value in update_data.items():
        setattr(template, key, value)
    db.commit()
    db.refresh(template)
    return _template_to_schema(template)


@router.delete("/{template_id}")
def delete_strategy(
    brand_id: int,
    template_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    template = (
        db.query(StrategyTemplate)
        .filter(
            StrategyTemplate.id == template_id,
            StrategyTemplate.brand_id == brand_id,
        )
        .first()
    )
    if not template:
        raise NotFoundError("Strategy template not found")
    db.delete(template)
    db.commit()
    return {"detail": "Strategy template deleted"}


@router.post("/apply")
def apply_strategy(
    brand_id: int,
    request: ApplyStrategyRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)

    template = (
        db.query(StrategyTemplate)
        .filter(
            StrategyTemplate.id == request.template_id,
            StrategyTemplate.brand_id == brand_id,
        )
        .first()
    )
    if not template:
        raise NotFoundError("Strategy template not found")

    campaign = (
        db.query(Campaign)
        .filter(
            Campaign.id == request.campaign_id,
            Campaign.brand_profile_id == brand_id,
        )
        .first()
    )
    if not campaign:
        raise NotFoundError("Campaign not found")

    campaign.campaign_goal = template.campaign_goal

    for post in campaign.posts:
        if template.recommended_ctas:
            post.call_to_action = template.recommended_ctas[0]

    db.commit()
    db.refresh(campaign)

    return {
        "detail": "Strategy applied to campaign",
        "campaign_id": campaign.id,
        "template_name": template.name,
    }
