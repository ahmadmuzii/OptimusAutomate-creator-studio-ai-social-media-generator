from __future__ import annotations


class TestPosts:
    def test_list_posts_in_campaign(self, client, auth_headers, created_campaign):
        response = client.get(f"/api/v1/campaigns/{created_campaign['id']}", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert len(data["posts"]) == 2

    def test_update_post_status(self, client, auth_headers, created_campaign):
        post_id = created_campaign["posts"][0]["id"]
        response = client.put(
            f"/api/v1/campaigns/{created_campaign['id']}/posts/{post_id}",
            json={"status": "scheduled"},
            headers=auth_headers,
        )
        assert response.status_code == 200

    def test_reject_invalid_status(self, client, auth_headers, created_campaign):
        post_id = created_campaign["posts"][0]["id"]
        response = client.put(
            f"/api/v1/campaigns/{created_campaign['id']}/posts/{post_id}",
            json={"status": "invalid_status"},
            headers=auth_headers,
        )
        assert response.status_code == 400

    def test_cannot_access_other_users_post(self, client, second_auth_headers, created_campaign):
        post_id = created_campaign["posts"][0]["id"]
        response = client.put(
            f"/api/v1/campaigns/{created_campaign['id']}/posts/{post_id}",
            json={"status": "published"},
            headers=second_auth_headers,
        )
        assert response.status_code == 404

    def test_regenerate_caption(self, client, auth_headers, created_campaign):
        post = created_campaign["posts"][0]
        response = client.post(
            f"/api/v1/campaigns/{created_campaign['id']}/posts/{post['id']}/regenerate",
            json={
                "post_id": post["id"],
                "post_idea": "New post idea",
                "content_theme": "Updated theme",
                "platform": "instagram",
                "tone": "professional",
                "brand_details": {
                    "brandName": "TestBrand",
                    "niche": "technology",
                    "targetAudience": "Developers",
                    "campaignGoal": "brand_awareness",
                },
            },
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert "caption" in data
        assert len(data["caption"]) > 0
        assert isinstance(data["hashtags"], list)
