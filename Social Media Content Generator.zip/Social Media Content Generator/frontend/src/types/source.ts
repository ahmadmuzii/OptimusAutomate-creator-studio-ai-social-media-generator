export interface SourceFact {
  id: number
  category: string
  label: string
  value: string
  source_section: string | null
  confidence: number | null
  approved_by_user: boolean
  excluded_by_user: boolean
}

export interface SourceDocument {
  id: number
  user_id: number
  brand_id: number | null
  source_type: string
  original_url: string | null
  pasted_text: string | null
  title: string | null
  extracted_text: string | null
  facts: SourceFact[]
  created_at: string
}

export interface SourceDocumentCreate {
  source_type: 'url' | 'text'
  original_url?: string | null
  pasted_text?: string | null
  brand_id?: number | null
}

export interface ExtractRequest {
  url?: string
  text?: string
}

export interface ExtractResponse {
  document: SourceDocument
}
