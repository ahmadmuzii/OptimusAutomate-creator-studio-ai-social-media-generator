import { useState, useCallback } from 'react'
import type { BrandFormData, AsyncState } from '@/types/common'
import type { CalendarCardData, DayPlan } from '@/types/calendar'
import type { CaptionCardData } from '@/types/caption'
import { platformApiValues } from '@/config/platforms'
import { toneApiMap } from '@/config/tones'
import { isFormValid } from '@/utils/validators'
import { postGenerateCalendar } from '@/api/endpoints'

interface GenerateResult {
  calendar: CalendarCardData[]
  captions: CaptionCardData[]
  saved: boolean
}

interface UseGenerateCalendarReturn {
  state: AsyncState<GenerateResult>
  generate: (
    formData: BrandFormData,
    platform: string,
    tone: string,
    sourceDocumentIds?: number[],
  ) => Promise<{ saved: boolean } | undefined>
  reset: () => void
}

function dayPlanToCardData(plan: DayPlan): CalendarCardData {
  return {
    day: plan.day,
    contentTheme: plan.contentTheme,
    postIdea: plan.postIdea,
    contentType: plan.contentType,
    suggestedTime: plan.suggestedTime,
    platform: plan.platform,
    caption: plan.caption,
    callToAction: plan.callToAction,
    hashtags: plan.hashtags,
  }
}

function dayPlanToCaptionCardData(plan: DayPlan): CaptionCardData {
  return {
    id: plan.day,
    day: plan.day,
    platform: plan.platform,
    caption: plan.caption,
    callToAction: plan.callToAction,
    hashtags: plan.hashtags,
  }
}

export function useGenerateCalendar(): UseGenerateCalendarReturn {
  const [state, setState] = useState<AsyncState<GenerateResult>>({ status: 'idle' })

  const generate = useCallback(
    async (formData: BrandFormData, platform: string, tone: string, sourceDocumentIds?: number[]) => {
      if (!isFormValid(formData, platform, tone)) {
        setState({ status: 'error', error: 'Please fill in all fields and select a platform and tone.' })
        return
      }

      setState({ status: 'loading' })

      try {
        const mappedPlatform = platformApiValues[platform] ?? platform
        const mappedTone = toneApiMap[tone] ?? tone

        const trimmed: BrandFormData = {
          brandName: formData.brandName.trim(),
          brandDescription: formData.brandDescription.trim(),
          niche: formData.niche.trim(),
          targetAudience: formData.targetAudience.trim(),
          campaignGoal: formData.campaignGoal.trim(),
        }

        const normalizedBrandProfileId =
          formData.brandId !== null &&
          formData.brandId !== undefined
            ? Number(formData.brandId)
            : null

        const response = await postGenerateCalendar({
          brandName: trimmed.brandName,
          brandDescription: trimmed.brandDescription,
          niche: trimmed.niche,
          targetAudience: trimmed.targetAudience,
          platform: mappedPlatform,
          tone: mappedTone,
          campaignGoal: trimmed.campaignGoal,
          brandProfileId:
            normalizedBrandProfileId !== null && !isNaN(normalizedBrandProfileId)
              ? normalizedBrandProfileId
              : null,
          sourceDocumentIds: sourceDocumentIds?.length ? sourceDocumentIds : null,
        })

        const calendar = response.calendar.map(dayPlanToCardData)
        const captions = response.calendar.map(dayPlanToCaptionCardData)
        const saved = response.saved ?? false

        setState({ status: 'success', data: { calendar, captions, saved } })
        return { saved }
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to generate content. Please try again.'
        setState({ status: 'error', error: message })
      }
    },
    [],
  )

  const reset = useCallback(() => {
    setState({ status: 'idle' })
  }, [])

  return { state, generate, reset }
}
