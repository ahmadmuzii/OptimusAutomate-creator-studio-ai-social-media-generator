import sqlite3
import sys

db_path = sys.argv[1] if len(sys.argv) > 1 else "social_media.db"
conn = sqlite3.connect(db_path)
cur = conn.cursor()

stmts = [
    "ALTER TABLE users ADD COLUMN job_title VARCHAR(255)",
    "ALTER TABLE users ADD COLUMN location VARCHAR(255)",
    "ALTER TABLE users ADD COLUMN personal_website VARCHAR(500)",
    'ALTER TABLE users ADD COLUMN theme_preference VARCHAR(20) NOT NULL DEFAULT "light"',
]

for s in stmts:
    try:
        cur.execute(s)
        print(f"OK: {s}")
    except Exception as e:
        print(f"SKIP ({e})")

conn.commit()
conn.close()
print("Migration complete.")
