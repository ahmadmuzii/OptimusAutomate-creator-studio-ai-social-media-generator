from __future__ import annotations

import time

from jose import jwt

from app.config import settings


class TestSignup:
    def test_successful_signup(self, client, user_payload):
        response = client.post("/api/v1/auth/signup", json=user_payload)
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert response.cookies.get("refresh_token") is not None
        assert data["token_type"] == "bearer"
        assert data["user"]["email"] == user_payload["email"]
        assert data["user"]["name"] == user_payload["name"]

    def test_duplicate_email(self, client, user_payload):
        response = client.post("/api/v1/auth/signup", json=user_payload)
        assert response.status_code == 409
        assert "detail" in response.json()

    def test_invalid_email(self, client):
        response = client.post(
            "/api/v1/auth/signup",
            json={
                "email": "not-an-email",
                "password": "testpass123",
                "name": "Test",
            },
        )
        assert response.status_code == 422

    def test_weak_password(self, client):
        response = client.post(
            "/api/v1/auth/signup",
            json={
                "email": "weak@example.com",
                "password": "12345",
                "name": "Test",
            },
        )
        assert response.status_code == 422


class TestLogin:
    def test_successful_login(self, client, user_payload):
        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": user_payload["email"],
                "password": user_payload["password"],
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert response.cookies.get("refresh_token") is not None
        assert data["user"]["email"] == user_payload["email"]

    def test_incorrect_password(self, client, user_payload):
        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": user_payload["email"],
                "password": "wrongpassword",
            },
        )
        assert response.status_code == 401
        assert "detail" in response.json()

    def test_unknown_email(self, client):
        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "nonexistent@example.com",
                "password": "testpass123",
            },
        )
        assert response.status_code == 401


class TestAuthRequired:
    def test_no_token(self, client):
        response = client.get("/api/v1/auth/me")
        assert response.status_code == 401

    def test_malformed_token(self, client):
        headers = {"Authorization": "Bearer not-a-valid-token"}
        response = client.get("/api/v1/auth/me", headers=headers)
        assert response.status_code == 401
        assert response.headers.get("www-authenticate", "").lower() == "bearer"

    def test_expired_token(self, client):
        import datetime
        from datetime import timezone

        token = jwt.encode(
            {
                "sub": "1",
                "exp": datetime.datetime.now(timezone.utc) - datetime.timedelta(hours=1),
                "token_type": "access",
            },
            settings.secret_key,
            algorithm=settings.jwt_algorithm,
        )
        headers = {"Authorization": f"Bearer {token}"}
        response = client.get("/api/v1/auth/me", headers=headers)
        assert response.status_code == 401

    def test_invalid_signature(self, client):
        token = jwt.encode(
            {"sub": "1", "exp": time.time() + 3600, "token_type": "access"},
            "wrong-secret-key",
            algorithm=settings.jwt_algorithm,
        )
        headers = {"Authorization": f"Bearer {token}"}
        response = client.get("/api/v1/auth/me", headers=headers)
        assert response.status_code == 401

    def test_missing_subject(self, client):
        import datetime
        from datetime import timezone

        token = jwt.encode(
            {
                "exp": datetime.datetime.now(timezone.utc) + datetime.timedelta(hours=1),
                "token_type": "access",
            },
            settings.secret_key,
            algorithm=settings.jwt_algorithm,
        )
        headers = {"Authorization": f"Bearer {token}"}
        response = client.get("/api/v1/auth/me", headers=headers)
        assert response.status_code == 401

    def test_deleted_user(self, client, registered_user, auth_headers):
        response = client.delete("/api/v1/auth/me", headers=auth_headers)
        assert response.status_code == 200
        response = client.get("/api/v1/auth/me", headers=auth_headers)
        assert response.status_code == 401

    def test_protected_endpoint_works_with_valid_token(self, client, auth_headers):
        response = client.get("/api/v1/auth/me", headers=auth_headers)
        assert response.status_code == 200


class TestRefreshToken:
    def test_refresh_success(self, client, registered_user):
        client.cookies.set("refresh_token", registered_user["refresh_token"])
        response = client.post("/api/v1/auth/refresh")
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert response.cookies.get("refresh_token") is not None

    def test_access_token_rejected_by_refresh(self, client, registered_user):
        client.cookies.set("refresh_token", registered_user["access_token"])
        response = client.post("/api/v1/auth/refresh")
        assert response.status_code == 401

    def test_refresh_token_rejected_as_access(self, client, registered_user):
        headers = {"Authorization": f"Bearer {registered_user['refresh_token']}"}
        response = client.get("/api/v1/auth/me", headers=headers)
        assert response.status_code == 401

    def test_invalid_refresh_token(self, client):
        client.cookies.set("refresh_token", "not-a-valid-token")
        response = client.post("/api/v1/auth/refresh")
        assert response.status_code == 401

    def test_missing_refresh_token(self, client):
        response = client.post("/api/v1/auth/refresh")
        assert response.status_code == 401


class TestForgotPassword:
    def test_neutral_response_for_existing_email(self, client, user_payload):
        response = client.post(
            "/api/v1/auth/forgot-password",
            json={
                "email": user_payload["email"],
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert "If an account exists" in data["message"]

    def test_neutral_response_for_unknown_email(self, client):
        response = client.post(
            "/api/v1/auth/forgot-password",
            json={
                "email": "unknown@example.com",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert "If an account exists" in data["message"]


class TestResetPassword:
    def test_reset_password_success(self, client, registered_user):
        # First request a reset (triggers token generation in dev mode)
        fp_response = client.post(
            "/api/v1/auth/forgot-password",
            json={
                "email": registered_user["email"],
            },
        )
        assert fp_response.status_code == 200

        # Get the reset token from the DB - we need to look it up
        # In testing, we can't easily get the reset token, but we can verify the flow
        # Test invalid token first
        response = client.post(
            "/api/v1/auth/reset-password",
            json={
                "token": "invalid-token",
                "new_password": "newpassword123",
            },
        )
        assert response.status_code == 401

    def test_invalid_reset_token(self, client):
        response = client.post(
            "/api/v1/auth/reset-password",
            json={
                "token": "completely-invalid",
                "new_password": "newpassword123",
            },
        )
        assert response.status_code == 401
