import { describe, it, expect } from 'vitest'
import { extractApiError } from './api-errors'

function createAxiosError(overrides: Record<string, unknown>): Record<string, unknown> {
  return {
    response: undefined,
    request: undefined,
    code: undefined,
    message: 'Something went wrong',
    ...overrides,
  }
}

describe('extractApiError', () => {
  it('returns fallback for null/undefined', () => {
    expect(extractApiError(null)).toEqual({ message: 'An unexpected error occurred', status: null })
    expect(extractApiError(undefined)).toEqual({ message: 'An unexpected error occurred', status: null })
  })

  it('handles 401', () => {
    const error = createAxiosError({ response: { status: 401, data: {} } })
    const result = extractApiError(error)
    expect(result.status).toBe(401)
    expect(result.message).toContain('Session expired')
  })

  it('handles 403', () => {
    const error = createAxiosError({ response: { status: 403, data: {} } })
    const result = extractApiError(error)
    expect(result.status).toBe(403)
    expect(result.message).toContain('permission')
  })

  it('handles 404', () => {
    const error = createAxiosError({ response: { status: 404, data: {} } })
    const result = extractApiError(error)
    expect(result.status).toBe(404)
    expect(result.message).toContain('not found')
  })

  it('handles 409 with detail string', () => {
    const error = createAxiosError({ response: { status: 409, data: { detail: 'Email already registered' } } })
    const result = extractApiError(error)
    expect(result.status).toBe(409)
    expect(result.message).toBe('Email already registered')
  })

  it('handles 409 without detail', () => {
    const error = createAxiosError({ response: { status: 409, data: {} } })
    const result = extractApiError(error)
    expect(result.status).toBe(409)
    expect(result.message).toContain('already exists')
  })

  it('handles 422 with field errors', () => {
    const error = createAxiosError({
      response: {
        status: 422,
        data: { errors: { email: ['Invalid email format'], password: ['Too short'] } },
      },
    })
    const result = extractApiError(error)
    expect(result.status).toBe(422)
    expect(result.message).toBe('Invalid email format')
    expect(result.fieldErrors).toEqual({ email: 'Invalid email format', password: 'Too short' })
  })

  it('handles 422 without field errors falls back to detail', () => {
    const error = createAxiosError({ response: { status: 422, data: { detail: 'Validation failed' } } })
    const result = extractApiError(error)
    expect(result.status).toBe(422)
    expect(result.message).toBe('Validation failed')
  })

  it('handles 500', () => {
    const error = createAxiosError({ response: { status: 500, data: {} } })
    const result = extractApiError(error)
    expect(result.status).toBe(500)
    expect(result.message).toContain('server error')
  })

  it('handles generic error response with detail', () => {
    const error = createAxiosError({ response: { status: 400, data: { detail: 'Bad request' } } })
    const result = extractApiError(error)
    expect(result.status).toBe(400)
    expect(result.message).toBe('Bad request')
  })

  it('handles generic error response without detail', () => {
    const error = createAxiosError({ response: { status: 418, data: {} } })
    const result = extractApiError(error)
    expect(result.status).toBe(418)
    expect(result.message).toBe('Request failed with status 418')
  })

  it('handles timeout (ECONNABORTED)', () => {
    const error = createAxiosError({ code: 'ECONNABORTED' })
    const result = extractApiError(error)
    expect(result.status).toBeNull()
    expect(result.message).toContain('timed out')
  })

  it('handles network error (no response, but request sent)', () => {
    const error = createAxiosError({ request: {} })
    const result = extractApiError(error)
    expect(result.status).toBeNull()
    expect(result.message).toContain('Could not reach the server')
  })

  it('handles generic Error instance', () => {
    const error = new Error('Something broke')
    const result = extractApiError(error)
    expect(result.status).toBeNull()
    expect(result.message).toBe('Something broke')
  })

  it('handles unknown error type', () => {
    const result = extractApiError('just a string')
    expect(result.status).toBeNull()
    expect(result.message).toBe('An unexpected error occurred')
  })
})
