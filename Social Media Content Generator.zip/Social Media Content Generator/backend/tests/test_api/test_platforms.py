from __future__ import annotations

from fastapi.testclient import TestClient

from app.enums import Platform, Tone


class TestPlatforms:
    def test_get_platforms(self, client: TestClient) -> None:
        response = client.get("/api/v1/platforms")
        assert response.status_code == 200
        data = response.json()
        assert "platforms" in data
        for platform in Platform:
            assert platform.value in data["platforms"]

    def test_get_tones(self, client: TestClient) -> None:
        response = client.get("/api/v1/tones")
        assert response.status_code == 200
        data = response.json()
        assert "tones" in data
        for tone in Tone:
            assert tone.value in data["tones"]
