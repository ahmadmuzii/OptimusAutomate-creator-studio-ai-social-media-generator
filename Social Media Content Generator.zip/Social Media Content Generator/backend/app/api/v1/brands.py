from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.database import get_db
from app.exceptions import AppError
from app.models.db_models import BrandProfile, Campaign, User

router = APIRouter(prefix="/brands", tags=["Brands"])


class BrandCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    niche: str | None = None
    target_audience: str | None = None
    website: str | None = None
    social_links: dict | None = None
    logo_url: str | None = None


class BrandUpdateRequest(BaseModel):
    name: str | None = None
    description: str | None = None
    niche: str | None = None
    target_audience: str | None = None
    website: str | None = None
    social_links: dict | None = None
    logo_url: str | None = None


class BrandResponse(BaseModel):
    id: int
    name: str
    description: str | None
    niche: str | None
    target_audience: str | None
    website: str | None
    social_links: dict | None
    logo_url: str | None = None
    campaign_count: int = 0

    model_config = {"from_attributes": True}


def _brand_to_response(brand: BrandProfile, campaign_count: int = 0) -> BrandResponse:
    return BrandResponse(
        id=brand.id,
        name=brand.name,
        description=brand.description,
        niche=brand.niche,
        target_audience=brand.target_audience,
        website=brand.website,
        social_links=brand.social_links,
        logo_url=brand.logo_url,
        campaign_count=campaign_count,
    )


def _get_campaign_counts(db: Session, user_id: int) -> dict[int, int]:
    results = (
        db.query(Campaign.brand_profile_id, func.count(Campaign.id))
        .filter(Campaign.user_id == user_id, Campaign.brand_profile_id.isnot(None))
        .group_by(Campaign.brand_profile_id)
        .all()
    )
    return {row[0]: row[1] for row in results}


@router.get("", response_model=list[BrandResponse])
def list_brands(
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    brands = db.query(BrandProfile).filter(BrandProfile.user_id == current_user.id).all()
    campaign_counts = _get_campaign_counts(db, current_user.id)
    return [_brand_to_response(b, campaign_counts.get(b.id, 0)) for b in brands]


@router.post("", response_model=BrandResponse)
def create_brand(
    request: BrandCreateRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    brand = BrandProfile(
        user_id=current_user.id,
        name=request.name,
        description=request.description,
        niche=request.niche,
        target_audience=request.target_audience,
        website=request.website,
        social_links=request.social_links,
        logo_url=request.logo_url,
    )
    db.add(brand)
    db.commit()
    db.refresh(brand)
    return _brand_to_response(brand)


@router.get("/{brand_id}", response_model=BrandResponse)
def get_brand(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != current_user.id:
        raise AppError(status_code=404, detail="Brand not found")
    count = (
        db.query(func.count(Campaign.id))
        .filter(
            Campaign.brand_profile_id == brand.id,
            Campaign.user_id == current_user.id,
        )
        .scalar()
        or 0
    )
    return _brand_to_response(brand, count)


@router.put("/{brand_id}", response_model=BrandResponse)
def update_brand(
    brand_id: int,
    request: BrandUpdateRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != current_user.id:
        raise AppError(status_code=404, detail="Brand not found")
    if request.name is not None:
        brand.name = request.name
    if request.description is not None:
        brand.description = request.description
    if request.niche is not None:
        brand.niche = request.niche
    if request.target_audience is not None:
        brand.target_audience = request.target_audience
    if request.website is not None:
        brand.website = request.website
    if request.social_links is not None:
        brand.social_links = request.social_links
    if request.logo_url is not None:
        brand.logo_url = request.logo_url
    db.commit()
    db.refresh(brand)
    count = (
        db.query(func.count(Campaign.id))
        .filter(
            Campaign.brand_profile_id == brand.id,
            Campaign.user_id == current_user.id,
        )
        .scalar()
        or 0
    )
    return _brand_to_response(brand, count)


@router.delete("/{brand_id}")
def delete_brand(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != current_user.id:
        raise AppError(status_code=404, detail="Brand not found")
    db.delete(brand)
    db.commit()
    return {"detail": "Brand deleted"}
