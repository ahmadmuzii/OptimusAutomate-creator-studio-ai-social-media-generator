import { useState, useRef, useEffect } from 'react'
import { ChevronRight } from 'lucide-react'
import type { SupportedTone } from '@/types/common'

const TONES: { value: SupportedTone; label: string; description: string }[] = [
  { value: 'professional', label: 'Professional', description: 'Polished, credible, structured' },
  { value: 'funny', label: 'Funny', description: 'Light, natural humour' },
  { value: 'luxury', label: 'Luxury', description: 'Premium, sophisticated' },
  { value: 'genz', label: 'Gen Z', description: 'Casual, trend-aware, relatable' },
  { value: 'motivational', label: 'Motivational', description: 'Inspiring, aspirational' },
  { value: 'casual', label: 'Casual', description: 'Relaxed, conversational' },
  { value: 'bold', label: 'Bold', description: 'Confident, direct, impactful' },
]

interface ToneSelectionMenuProps {
  onSelect: (tone: SupportedTone) => void
  onClose: () => void
}

export function ToneSelectionMenu({ onSelect, onClose }: ToneSelectionMenuProps) {
  const [focusedIndex, setFocusedIndex] = useState(0)
  const listRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    listRef.current?.focus()
  }, [])

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose()
      return
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setFocusedIndex((i) => Math.min(i + 1, TONES.length - 1))
      return
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      setFocusedIndex((i) => Math.max(i - 1, 0))
      return
    }
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault()
      const tone = TONES[focusedIndex]
      if (tone) onSelect(tone.value)
    }
  }

  return (
    <div
      ref={listRef}
      tabIndex={-1}
      onKeyDown={handleKeyDown}
      className="absolute left-full top-0 ml-1 bg-white border border-purple-100 rounded-xl shadow-xl z-50 w-56 py-1 focus:outline-none"
    >
      <div className="px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider border-b border-gray-100">
        Select tone
      </div>
      {TONES.map((tone, index) => (
        <button
          key={tone.value}
          onClick={() => onSelect(tone.value)}
          onMouseEnter={() => setFocusedIndex(index)}
          className={`w-full flex items-center justify-between px-3 py-2 text-sm text-left transition-colors ${
            index === focusedIndex ? 'bg-purple-50 text-purple-700' : 'text-gray-700 hover:bg-gray-50'
          }`}
        >
          <div>
            <span className="font-medium">{tone.label}</span>
            <p className="text-xs text-gray-400 mt-0.5">{tone.description}</p>
          </div>
          <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
        </button>
      ))}
    </div>
  )
}
