export interface BrandGuardrail {
  id: number
  brand_id: number
  required_phrases: string[] | null
  forbidden_words: string[] | null
  competitors_never_mention: string[] | null
  approved_product_descriptions: string[] | null
  allowed_claims: string[] | null
  restricted_claims: string[] | null
  preferred_spellings: Record<string, string> | null
  preferred_capitalizations: string[] | null
  product_names: string[] | null
  service_names: string[] | null
  brand_name_aliases: string[] | null
  required_legal_disclaimer: string | null
  example_posts_liked: ExamplePost[] | null
  example_posts_disliked: ExamplePost[] | null
  emoji_allowance: string | null
  profanity_level: string | null
  formality_level: string | null
  max_hashtag_count: number | null
  min_hashtag_count: number | null
  allowed_languages: string[] | null
  default_language: string | null
  preferred_cta_style: string | null
  forbidden_cta_styles: string[] | null
  restricted_topics: string[] | null
  sensitive_topics_requiring_review: string[] | null
  created_at: string | null
  updated_at: string | null
}

export interface ExamplePost {
  caption?: string
  notes?: string
}

export interface BrandCheckItem {
  code: string
  label: string
  status: 'passed' | 'warning' | 'blocked'
  message: string
  field?: string | null
  post_id?: number | null
  matched_text?: string | null
}

export interface BrandCheckSummary {
  passed: number
  warnings: number
  blocked: number
}

export interface BrandCheckResult {
  status: 'passed' | 'warning' | 'blocked'
  summary: BrandCheckSummary
  checks: BrandCheckItem[]
  campaign_id?: number | null
  brand_check_version: string
}
