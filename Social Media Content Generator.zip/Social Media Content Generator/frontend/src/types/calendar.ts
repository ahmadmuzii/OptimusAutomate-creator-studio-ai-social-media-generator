export interface DayPlan {
  day: number
  contentTheme: string
  postIdea: string
  contentType: string
  suggestedTime: string
  platform: string
  caption: string
  callToAction: string
  hashtags: string[]
}

export interface CalendarResponse {
  calendar: DayPlan[]
  generationSource?: string
  saved?: boolean
}

export interface CalendarRequest {
  brandName: string
  brandDescription: string
  niche: string
  targetAudience: string
  platform: string
  tone: string
  campaignGoal: string
  brandProfileId?: number | null
  sourceDocumentIds?: number[] | null
}

export type CalendarDayColor =
  | 'from-purple-500 to-purple-600'
  | 'from-violet-500 to-purple-600'
  | 'from-fuchsia-500 to-purple-600'
  | 'from-purple-600 to-indigo-600'
  | 'from-indigo-500 to-purple-600'
  | 'from-purple-500 to-violet-600'
  | 'from-fuchsia-600 to-purple-700'

export interface CalendarCardData {
  day: number
  contentTheme: string
  postIdea: string
  contentType: string
  suggestedTime: string
  platform: string
  caption: string
  callToAction: string
  hashtags: string[]
}
