import { Sparkles } from 'lucide-react'

interface EmptyStateProps {
  title?: string
  description?: string
}

export function EmptyState({
  title = 'Ready to create your content calendar?',
  description = 'Fill in your brand details above, select a platform and tone, then click generate to see your 7-day campaign plan.',
}: EmptyStateProps) {
  return (
    <div className="mt-20 text-center">
      <div className="w-20 h-20 mx-auto mb-6 rounded-3xl bg-purple-50 flex items-center justify-center">
        <Sparkles className="w-10 h-10 text-purple-300" />
      </div>
      <h3 className="text-lg font-semibold text-gray-400 mb-2">
        {title}
      </h3>
      <p className="text-sm text-gray-400 max-w-md mx-auto">
        {description}
      </p>
    </div>
  )
}
