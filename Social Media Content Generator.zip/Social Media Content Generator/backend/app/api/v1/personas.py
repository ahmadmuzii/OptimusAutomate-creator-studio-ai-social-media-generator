from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.db_models import AudiencePersona, BrandProfile, User
from app.models.persona_schemas import (
    PersonaCreateRequest,
    PersonaResponse,
    PersonaUpdateRequest,
)

router = APIRouter(prefix="/brands/{brand_id}/personas", tags=["Personas"])


def _get_brand_or_404(db: Session, brand_id: int, user_id: int) -> BrandProfile:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != user_id:
        raise NotFoundError("Brand not found")
    return brand


def _persona_to_response(p: AudiencePersona) -> PersonaResponse:
    return PersonaResponse(
        id=p.id,
        brand_id=p.brand_id,
        name=p.name,
        description=p.description,
        age_range=p.age_range,
        location_market=p.location_market,
        main_problem=p.main_problem,
        desired_outcome=p.desired_outcome,
        objections=p.objections,
        preferred_tone=p.preferred_tone,
        preferred_platform=p.preferred_platform,
        buying_stage=p.buying_stage,
        content_interests=p.content_interests or [],
        common_questions=p.common_questions or [],
        main_motivation=p.main_motivation,
        cta_preference=p.cta_preference,
        language_preference=p.language_preference,
        notes=p.notes,
        is_primary=p.is_primary,
        created_at=p.created_at.isoformat() if p.created_at else None,
    )


@router.get("", response_model=list[PersonaResponse])
def list_personas(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    personas = db.query(AudiencePersona).filter(AudiencePersona.brand_id == brand_id).all()
    return [_persona_to_response(p) for p in personas]


@router.post("", response_model=PersonaResponse)
def create_persona(
    brand_id: int,
    request: PersonaCreateRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)

    if request.is_primary:
        db.query(AudiencePersona).filter(
            AudiencePersona.brand_id == brand_id, AudiencePersona.is_primary.is_(True)
        ).update({"is_primary": False})

    persona = AudiencePersona(brand_id=brand_id, **request.model_dump())
    db.add(persona)
    db.commit()
    db.refresh(persona)
    return _persona_to_response(persona)


@router.get("/{persona_id}", response_model=PersonaResponse)
def get_persona(
    brand_id: int,
    persona_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    persona = (
        db.query(AudiencePersona).filter(AudiencePersona.id == persona_id, AudiencePersona.brand_id == brand_id).first()
    )
    if not persona:
        raise NotFoundError("Persona not found")
    return _persona_to_response(persona)


@router.put("/{persona_id}", response_model=PersonaResponse)
def update_persona(
    brand_id: int,
    persona_id: int,
    request: PersonaUpdateRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    persona = (
        db.query(AudiencePersona).filter(AudiencePersona.id == persona_id, AudiencePersona.brand_id == brand_id).first()
    )
    if not persona:
        raise NotFoundError("Persona not found")

    update_data = request.model_dump(exclude_none=True)
    if "is_primary" in update_data and update_data["is_primary"]:
        db.query(AudiencePersona).filter(
            AudiencePersona.brand_id == brand_id, AudiencePersona.is_primary.is_(True)
        ).update({"is_primary": False})

    for key, value in update_data.items():
        setattr(persona, key, value)
    db.commit()
    db.refresh(persona)
    return _persona_to_response(persona)


@router.delete("/{persona_id}")
def delete_persona(
    brand_id: int,
    persona_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    persona = (
        db.query(AudiencePersona).filter(AudiencePersona.id == persona_id, AudiencePersona.brand_id == brand_id).first()
    )
    if not persona:
        raise NotFoundError("Persona not found")
    db.delete(persona)
    db.commit()
    return {"detail": "Persona deleted"}
