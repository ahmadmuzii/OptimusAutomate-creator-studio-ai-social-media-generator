from __future__ import annotations

import os

os.environ["APP_ENV"] = "development"
os.environ["DATABASE_URL"] = "sqlite:///./test_social_media.db"
os.environ["SECRET_KEY"] = "test-secret-key-for-testing-only"
os.environ["ACCESS_TOKEN_EXPIRE_MINUTES"] = "15"
os.environ["REFRESH_TOKEN_EXPIRE_DAYS"] = "7"
os.environ["CORS_ORIGINS"] = '["*"]'

from app.database import Base, engine

Base.metadata.create_all(bind=engine)

from fastapi.testclient import TestClient

from app.main import create_app

app = create_app()
client = TestClient(app)

resp = client.post(
    "/api/v1/auth/signup", json={"email": "test@example.com", "password": "testpass123", "name": "Test User"}
)
if resp.status_code == 409:
    resp = client.post("/api/v1/auth/login", json={"email": "test@example.com", "password": "testpass123"})

token = resp.json()["access_token"]
headers = {"Authorization": f"Bearer {token}"}
print(f"Auth: {resp.status_code}")

resp = client.post("/api/v1/brands", json={"name": "Test Brand", "niche": "Tech"}, headers=headers)
if resp.status_code != 200:
    resp = client.get("/api/v1/brands", headers=headers)
    brands = resp.json()
    if brands:
        brand = brands[0]
    else:
        print("No brand found")
        exit(1)
else:
    brand = resp.json()

brand_id = brand["id"]
print(f"Brand ID: {brand_id}")

endpoints = [
    ("GET", f"/api/v1/brands/{brand_id}/conversion-paths", "Conversion Paths"),
    ("GET", f"/api/v1/brands/{brand_id}/source-documents", "Source Documents"),
    ("GET", f"/api/v1/brands/{brand_id}/content-packs", "Content Packs"),
    ("GET", f"/api/v1/brands/{brand_id}/freshness", "Freshness"),
    ("GET", f"/api/v1/brands/{brand_id}/strategies", "Strategy Templates"),
    ("GET", f"/api/v1/brands/{brand_id}/experiments", "Experiments"),
    ("GET", f"/api/v1/brands/{brand_id}/regional-settings", "Regional Settings"),
    ("GET", f"/api/v1/brands/{brand_id}/competitors", "Competitors"),
]

for method, url, name in endpoints:
    try:
        resp = client.get(url, headers=headers, timeout=10)
        print(f"{name}: status={resp.status_code}, body={resp.text[:300]}")
    except Exception as e:
        print(f"{name}: ERROR: {e}")

print("\nDone!")
