from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field


class GenerationTraceData(BaseModel):
    groq_used: bool = False
    groq_model: str | None = None
    generation_source: str = "unknown"
    brand_id: int | None = None
    persona_ids: list[int] = Field(default_factory=list)
    conversion_path_id: int | None = None
    source_fact_ids: list[int] = Field(default_factory=list)
    strategy_id: int | None = None
    performance_insight_ids: list[int] = Field(default_factory=list)
    experiment_learning_ids: list[int] = Field(default_factory=list)
    competitor_opportunity_ids: list[int] = Field(default_factory=list)
    guardrail_version: int | None = None
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


def save_generation_trace(
    db: Any,
    campaign_id: int,
    trace: GenerationTraceData,
) -> None:
    from app.models.db_models import GenerationTrace as TraceModel

    record = TraceModel(
        campaign_id=campaign_id,
        groq_used=trace.groq_used,
        groq_model=trace.groq_model,
        generation_source=trace.generation_source,
        brand_id=trace.brand_id,
        persona_ids=trace.persona_ids,
        conversion_path_id=trace.conversion_path_id,
        source_fact_ids=trace.source_fact_ids,
        strategy_id=trace.strategy_id,
        performance_insight_ids=trace.performance_insight_ids,
        experiment_learning_ids=trace.experiment_learning_ids,
        competitor_opportunity_ids=trace.competitor_opportunity_ids,
        guardrail_version=trace.guardrail_version,
    )
    db.add(record)
    db.commit()
