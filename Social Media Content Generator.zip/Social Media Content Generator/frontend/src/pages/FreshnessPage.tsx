import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'
import { ArrowLeft, RefreshCw, BarChart3, Layers, Repeat, Lightbulb, Hash, Megaphone } from 'lucide-react'
import { ErrorState } from '@/components/ui/ErrorState'
import { LoadingSpinner } from '@/components/ui/LoadingSpinner'
import * as api from '@/api/endpoints'
import type { FatigueAnalysis } from '@/types/freshness'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'

function scoreColor(score: number): string {
  if (score < 0.3) return 'text-green-500'
  if (score < 0.6) return 'text-yellow-500'
  return 'text-red-500'
}

function scoreLabel(score: number): string {
  if (score < 0.3) return 'Low Fatigue'
  if (score < 0.6) return 'Moderate Fatigue'
  return 'High Fatigue'
}

export function normalizeFreshness(
  raw: Record<string, unknown> | null | undefined,
): FatigueAnalysis {
  return {
    status: typeof raw?.status === 'string' ? raw.status : undefined,
    fatigue_score: typeof raw?.fatigue_score === 'number' ? raw.fatigue_score : 0,
    total_campaigns: typeof raw?.total_campaigns === 'number' ? raw.total_campaigns : 0,
    total_posts: typeof raw?.total_posts === 'number' ? raw.total_posts : 0,
    repeated_themes:
      raw?.repeated_themes &&
      typeof raw.repeated_themes === 'object' &&
      !Array.isArray(raw.repeated_themes)
        ? (raw.repeated_themes as Record<string, number>)
        : {},
    cta_diversity: typeof raw?.cta_diversity === 'number' ? raw.cta_diversity : 0,
    recommendations: Array.isArray(raw?.recommendations)
      ? (raw.recommendations as string[])
      : [],
  }
}

export function FreshnessPage() {
  const { brandId, brand } = useBrandWorkspace()

  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const [analysis, setAnalysis] = useState<FatigueAnalysis | null>(null)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    setError(null)
    setLoading(true)
    try {
      const data = await api.getBrandFatigue(brandId)
      setAnalysis(normalizeFreshness(data as Record<string, unknown>))
    } catch {
      setError('Could not load fatigue analysis.')
    } finally {
      setLoading(false)
    }
  }, [brandId])

  useEffect(() => {
    load()
  }, [brandId, load])

  const handleRefresh = async () => {
    setRefreshing(true)
    setError(null)
    try {
      const data = await api.getBrandFatigue(brandId)
      setAnalysis(normalizeFreshness(data as Record<string, unknown>))
    } catch {
      setError('Failed to refresh analysis.')
    } finally {
      setRefreshing(false)
    }
  }

  if (loading) return <LoadingSpinner />

  if (error) return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>
      <ErrorState message={error} onRetry={load} />
    </div>
  )

  if (analysis?.status === 'insufficient_data') return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <RefreshCw className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Content Freshness</h1>
        </div>
        <Button onClick={handleRefresh} disabled={refreshing} className="flex items-center gap-2">
          <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          {refreshing ? 'Refreshing...' : 'Refresh Analysis'}
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Analyze content fatigue for {brand.name}. High scores indicate repetitive content that may need refreshing.
      </p>

      <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
        <RefreshCw className="w-8 h-8 text-gray-300 mx-auto mb-3" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Not enough campaign history yet</h3>
        <p className="text-sm text-gray-500 mb-6 max-w-md mx-auto">
          Create more campaigns for this brand to unlock hook repetition, CTA variety, hashtag reuse, and content-balance analysis.
        </p>
        {analysis.recommendations.length > 0 && (
          <div className="text-left max-w-lg mx-auto">
            <h4 className="text-sm font-medium text-gray-700 mb-3">Recommendations</h4>
            <ul className="space-y-2">
              {analysis.recommendations.map((rec, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                  <span className="w-5 h-5 rounded-full bg-purple-50 text-purple-600 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">{i + 1}</span>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  )

  if (!analysis) return null

  const repeatedThemeEntries = Object.entries(analysis.repeated_themes ?? {})
    .sort(([, a], [, b]) => b - a)

  return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <RefreshCw className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Content Freshness</h1>
        </div>
        <Button onClick={handleRefresh} disabled={refreshing} className="flex items-center gap-2">
          <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          {refreshing ? 'Refreshing...' : 'Refresh Analysis'}
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Analyze content fatigue for {brand.name}. High scores indicate repetitive content that may need refreshing.
      </p>

      {analysis && (
        <>
          {/* Score Indicator */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <div className="flex items-center gap-6">
              <div className="relative w-24 h-24 shrink-0">
                <svg className="w-24 h-24 -rotate-90" viewBox="0 0 36 36">
                  <circle cx="18" cy="18" r="15.5" fill="none" stroke="#e5e7eb" strokeWidth="3" />
                  <circle cx="18" cy="18" r="15.5" fill="none" stroke="currentColor" strokeWidth="3" strokeDasharray={`${analysis.fatigue_score * 100} ${100 - analysis.fatigue_score * 100}`} strokeLinecap="round" className={scoreColor(analysis.fatigue_score)} />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className={`text-2xl font-bold ${scoreColor(analysis.fatigue_score)}`}>
                    {Math.round(analysis.fatigue_score * 100)}%
                  </span>
                </div>
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">
                  <span className={scoreColor(analysis.fatigue_score)}>{scoreLabel(analysis.fatigue_score)}</span>
                </h2>
                <p className="text-sm text-gray-500 mt-1">
                  Fatigue score of {analysis.fatigue_score.toFixed(2)} indicates how much of your content is repetitive.
                </p>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <div className="flex items-center gap-2 text-purple-600 mb-2">
                <Megaphone className="w-4 h-4" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{analysis.total_campaigns}</p>
              <p className="text-xs text-gray-500">Total Campaigns</p>
            </div>
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <div className="flex items-center gap-2 text-purple-600 mb-2">
                <BarChart3 className="w-4 h-4" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{analysis.total_posts}</p>
              <p className="text-xs text-gray-500">Total Posts</p>
            </div>
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <div className="flex items-center gap-2 text-purple-600 mb-2">
                <Layers className="w-4 h-4" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{Object.keys(analysis.repeated_themes ?? {}).length}</p>
              <p className="text-xs text-gray-500">Theme Diversity</p>
            </div>
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <div className="flex items-center gap-2 text-purple-600 mb-2">
                <Hash className="w-4 h-4" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{((analysis.cta_diversity ?? 0) * 100).toFixed(0)}%</p>
              <p className="text-xs text-gray-500">CTA Diversity</p>
            </div>
          </div>

          {/* Repeated Themes */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-5 pt-5 pb-3 border-b border-gray-100 flex items-center gap-2">
              <Repeat className="w-5 h-5 text-purple-600" />
              <h2 className="text-lg font-semibold text-gray-900">Repeated Themes</h2>
            </div>
            {repeatedThemeEntries.length === 0 ? (
              <div className="p-12 text-center">
                <p className="text-gray-400 text-sm">No repeated themes detected.</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-50">
                {repeatedThemeEntries.map(([theme, count]) => (
                  <div key={theme} className="flex items-center justify-between px-5 py-3">
                    <span className="text-sm font-medium text-gray-900 capitalize">{theme.replace(/_/g, ' ')}</span>
                    <div className="flex items-center gap-3">
                      <div className="w-32 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${count > 5 ? 'bg-red-500' : count > 2 ? 'bg-yellow-500' : 'bg-green-500'}`}
                          style={{ width: `${Math.min((count / Math.max(...repeatedThemeEntries.map(([, c]) => c))) * 100, 100)}%` }}
                        />
                      </div>
                      <span className="text-sm font-semibold text-gray-700 w-8 text-right">{count}x</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recommendations */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-5 pt-5 pb-3 border-b border-gray-100 flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-purple-600" />
              <h2 className="text-lg font-semibold text-gray-900">Recommendations</h2>
            </div>
            {(analysis.recommendations ?? []).length === 0 ? (
              <div className="p-12 text-center">
                <p className="text-gray-400 text-sm">No recommendations available.</p>
              </div>
            ) : (
              <ul className="divide-y divide-gray-50">
                {(analysis.recommendations ?? []).map((rec, i) => (
                  <li key={i} className="flex items-start gap-3 px-5 py-3">
                    <span className="w-6 h-6 rounded-full bg-purple-50 text-purple-600 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">{i + 1}</span>
                    <p className="text-sm text-gray-700">{rec}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </>
      )}

      {!analysis && (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
          <RefreshCw className="w-8 h-8 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-400 text-sm mb-4">No analysis data yet. Click "Refresh Analysis" to run a freshness check.</p>
          <Button onClick={handleRefresh} disabled={refreshing} className="mx-auto flex items-center gap-2">
            <RefreshCw className="w-4 h-4" /> Run Analysis
          </Button>
        </div>
      )}
    </div>
  )
}
