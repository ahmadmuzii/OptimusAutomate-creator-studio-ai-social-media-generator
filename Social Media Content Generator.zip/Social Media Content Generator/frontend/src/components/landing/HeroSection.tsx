import { useEffect, useRef, type ReactNode } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowRight, Play } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { InteractiveHeroDemo } from './InteractiveHeroDemo'
import { platforms } from '@/config/platforms'
import { cn } from '@/utils/cn'

function HeroAnimationWrapper({ children, label }: { children: ReactNode; label: string }) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          // visible
        }
      },
      { threshold: 0.3 },
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [])

  return (
    <div ref={ref} role="img" aria-label={label}>
      {children}
    </div>
  )
}

export function HeroSection() {
  const { isAuthenticated } = useAuth()
  const navigate = useNavigate()

  const handleGenerateCampaign = () => {
    if (isAuthenticated) {
      navigate('/dashboard/generate')
    } else {
      navigate('/login?redirect=' + encodeURIComponent('/dashboard/generate'))
    }
  }

  const handleDemo = () => {
    document.getElementById('live-example')?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section className="relative min-h-[calc(100vh-5rem)] flex items-center overflow-hidden bg-white pt-20 md:pt-28">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-50/40 via-white to-purple-50/20 pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-100 text-purple-700 text-sm font-medium mb-6">
              <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
              AI-powered campaign planning
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 tracking-tight leading-[1.1]">
              One brand brief.
              <br />
              <span className="bg-gradient-to-r from-purple-600 to-purple-900 bg-clip-text text-transparent">
                Seven days of content.
              </span>
            </h1>

            <p className="mt-6 text-lg text-gray-500 leading-relaxed">
              Generate a complete social media campaign with platform-ready captions, content ideas, CTAs, hashtags, and a visual calendar tailored to your brand.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                onClick={handleGenerateCampaign}
                className="btn-primary inline-flex items-center gap-2 text-base"
              >
                Generate My Campaign
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={handleDemo}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl border border-gray-200 text-gray-700 font-semibold hover:border-purple-300 hover:text-purple-700 transition-all duration-200 text-base"
              >
                <Play className="w-4 h-4" />
                See a Live Example
              </button>
            </div>

            <p className="mt-4 text-sm text-gray-400">
              No credit card required
            </p>

            <div className="mt-8 flex items-center gap-5">
              {platforms.map((p) => {
                const Icon = p.icon
                return (
                  <div
                    key={p.id}
                    className="flex flex-col items-center gap-1.5"
                    title={p.name}
                  >
                    <div className={cn('w-9 h-9 rounded-lg bg-gradient-to-br flex items-center justify-center', p.gradient)}>
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-[10px] text-gray-400 font-medium">{p.name}</span>
                  </div>
                )
              })}
            </div>
          </div>

          <div className="relative lg:pl-4">
            <HeroAnimationWrapper label="Interactive campaign preview">
              <InteractiveHeroDemo />
            </HeroAnimationWrapper>
          </div>
        </div>
      </div>
    </section>
  )
}
