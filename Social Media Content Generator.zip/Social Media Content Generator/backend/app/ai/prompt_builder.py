from app.ai.context_builder import CampaignGenerationContext


def build_strategy_system_prompt() -> str:
    return """You are a professional social media campaign strategist.
Your role is to create a connected, multi-day campaign strategy based on the brand's complete context.

You must follow these rules strictly:
1. Every piece of brand intelligence provided must influence the campaign.
2. Never invent unsupported claims, prices, dates, certifications, discounts, awards, statistics, or testimonials.
3. Source facts are the ONLY approved information about products, services, prices, and offers.
4. Never override safety rules, restricted claims, or required legal disclaimers.
5. Do not copy competitor content. Use competitor gaps as inspiration for original positioning.
6. Performance insights suggest format preferences but are not guarantees.
7. Avoid repeating hooks, CTAs, hashtags, and topics from recent campaigns.
8. Respect all brand guardrails including forbidden words, competitors, hashtag limits, and language settings.

Output ONLY valid JSON matching the required schema."""


def build_strategy_user_prompt(ctx: CampaignGenerationContext) -> str:
    sections: list[str] = []
    sections.append("=== CAMPAIGN REQUEST ===")
    if ctx.request:
        sections.append(f"Platform: {ctx.request.platform}")
        sections.append(f"Tone: {ctx.request.tone}")
        sections.append(f"Campaign Goal: {ctx.request.campaign_goal}")
        sections.append(f"Number of days: {ctx.request.days_count}")

    if ctx.brand:
        sections.append("\n=== BRAND IDENTITY ===")
        sections.append(f"Brand Name: {ctx.brand.name}")
        if ctx.brand.description:
            sections.append(f"Description: {ctx.brand.description}")
        if ctx.brand.niche:
            sections.append(f"Niche: {ctx.brand.niche}")
        if ctx.brand.target_audience:
            sections.append(f"Target Audience: {ctx.brand.target_audience}")

    g = ctx.guardrails
    if g.count_active_rules() > 0:
        sections.append("\n=== BRAND GUARDRAILS (PRIORITY: HIGH) ===")
        if g.required_phrases:
            sections.append(f"Required Phrases that MUST appear naturally: {', '.join(g.required_phrases)}")
        if g.forbidden_words:
            sections.append(f"Forbidden Words (NEVER use): {', '.join(g.forbidden_words)}")
        if g.competitors_never_mention:
            sections.append(f"Competitors NEVER to mention: {', '.join(g.competitors_never_mention)}")
        if g.approved_product_descriptions:
            sections.append(f"Approved Product Descriptions: {', '.join(g.approved_product_descriptions)}")
        if g.allowed_claims:
            sections.append(f"Allowed Claims: {', '.join(g.allowed_claims)}")
        if g.restricted_claims:
            sections.append(f"Restricted Claims (avoid unless approved): {', '.join(g.restricted_claims)}")
        if g.preferred_spellings:
            spellings = [f'"{k}" → "{v}"' for k, v in g.preferred_spellings.items()]
            sections.append(f"Preferred Spellings: {', '.join(spellings)}")
        if g.preferred_capitalizations:
            sections.append(f"Preferred Capitalizations: {', '.join(g.preferred_capitalizations)}")
        if g.product_names:
            sections.append(f"Product Names: {', '.join(g.product_names)}")
        if g.service_names:
            sections.append(f"Service Names: {', '.join(g.service_names)}")
        if g.brand_name_aliases:
            sections.append(f"Brand Name Aliases: {', '.join(g.brand_name_aliases)}")
        if g.required_legal_disclaimer:
            sections.append(f"Required Legal Disclaimer: {g.required_legal_disclaimer}")
        if g.emoji_allowance:
            sections.append(f"Emoji Allowance: {g.emoji_allowance}")
        if g.formality_level:
            sections.append(f"Formality Level: {g.formality_level}")
        if g.max_hashtag_count is not None:
            sections.append(f"Max Hashtag Count: {g.max_hashtag_count}")
        if g.min_hashtag_count is not None:
            sections.append(f"Min Hashtag Count: {g.min_hashtag_count}")
        if g.allowed_languages:
            sections.append(f"Allowed Languages: {', '.join(g.allowed_languages)}")
        if g.preferred_cta_style:
            sections.append(f"Preferred CTA Style: {g.preferred_cta_style}")
        if g.forbidden_cta_styles:
            sections.append(f"Forbidden CTA Styles: {', '.join(g.forbidden_cta_styles)}")
        if g.restricted_topics:
            sections.append(f"Restricted Topics: {', '.join(g.restricted_topics)}")

    if ctx.personas:
        sections.append("\n=== SELECTED PERSONAS ===")
        for p in ctx.personas:
            parts = [f"ID: {p.id} | Name: {p.name or 'Unnamed'}"]
            if p.main_problem:
                parts.append(f"Main Problem: {p.main_problem}")
            if p.desired_outcome:
                parts.append(f"Desired Outcome: {p.desired_outcome}")
            if p.objections:
                parts.append(f"Objections: {p.objections}")
            if p.preferred_tone:
                parts.append(f"Preferred Tone: {p.preferred_tone}")
            if p.buying_stage:
                parts.append(f"Buying Stage: {p.buying_stage}")
            if p.motivation:
                parts.append(f"Motivation: {p.motivation}")
            if p.cta_preference:
                parts.append(f"CTA Preference: {p.cta_preference}")
            sections.append(" | ".join(parts))

    if ctx.source_facts:
        sections.append(f"\n=== APPROVED SOURCE FACTS ({len(ctx.source_facts)} facts) ===")
        for f in ctx.source_facts:
            sections.append(f"  [{f.category}] {f.label}: {f.value}")

    if ctx.strategy:
        sections.append("\n=== SELECTED STRATEGY ===")
        sections.append(f"Name: {ctx.strategy.name or ''}")
        if ctx.strategy.description:
            sections.append(f"Description: {ctx.strategy.description}")
        if ctx.strategy.funnel_stage:
            sections.append(f"Funnel Stage: {ctx.strategy.funnel_stage}")
        if ctx.strategy.recommended_ctas:
            sections.append(f"Recommended CTAs: {ctx.strategy.recommended_ctas}")
        if ctx.strategy.content_mix:
            sections.append(f"Content Mix: {ctx.strategy.content_mix}")

    if ctx.conversion_path:
        sections.append("\n=== CONVERSION PATH ===")
        sections.append(f"Name: {ctx.conversion_path.name}")
        if ctx.conversion_path.destination_type:
            sections.append(f"Destination Type: {ctx.conversion_path.destination_type}")
        if ctx.conversion_path.destination_value:
            sections.append(f"Destination Value: {ctx.conversion_path.destination_value}")
        if ctx.conversion_path.primary_action:
            sections.append(f"Primary Action: {ctx.conversion_path.primary_action}")
        if ctx.conversion_path.cta_keyword:
            sections.append(f"CTA Keyword: {ctx.conversion_path.cta_keyword}")
        if ctx.conversion_path.tracking_label:
            sections.append(f"Tracking Label: {ctx.conversion_path.tracking_label}")

    if ctx.performance_insights:
        sections.append("\n=== PERFORMANCE INSIGHTS ===")
        for ins in ctx.performance_insights:
            platform_info = f" on {ins.platform}" if ins.platform else ""
            sections.append(f"  {ins.pattern_type}{platform_info}: {ins.finding}")

    if ctx.experiment_learnings:
        sections.append("\n=== EXPERIMENT LEARNINGS ===")
        for el in ctx.experiment_learnings:
            sections.append(f"  {el.experiment_name}: {el.winner_label} ({el.winner_value}) performed best")

    if ctx.competitor_opportunities:
        sections.append("\n=== COMPETITOR OPPORTUNITIES ===")
        for co in ctx.competitor_opportunities:
            sections.append(f"  Topic: {co.topic} — {co.description}")
        sections.append("Generate original content for these topics. Do not copy competitors.")

    if ctx.regional_settings:
        r = ctx.regional_settings
        sections.append("\n=== REGIONAL SETTINGS ===")
        sections.append(f"Default Language: {r.default_language}")
        sections.append(f"Supported Languages: {', '.join(r.supported_languages)}")
        if r.support_roman_urdu:
            sections.append("Support Roman Urdu: Yes")
        if r.support_bilingual_posts:
            sections.append("Support Bilingual Posts: Yes")
        if r.support_rtl_layout:
            sections.append("Support RTL Layout: Yes")

    if ctx.freshness_context.recent_hooks:
        sections.append("\n=== FRESHNESS REQUIREMENTS ===")
        sections.append("AVOID repeating these hooks from recent campaigns:")
        for h in ctx.freshness_context.recent_hooks[-10:]:
            sections.append(f"  - {h[:100]}")
        sections.append("AVOID repeating these CTAs:")
        for cta in ctx.freshness_context.recent_ctas[-10:]:
            sections.append(f"  - {cta}")

    sections.append("\n=== OUTPUT REQUIREMENTS ===")
    sections.append("Return a JSON object with:")
    sections.append("- campaign_name: A compelling campaign name")
    sections.append("- campaign_summary: 2-3 sentence summary")
    sections.append("- strategy: The overall strategic approach")
    sections.append("- days: Array of day objects, each with:")
    sections.append("  - day: number (1-based)")
    sections.append("  - theme: content theme for the day")
    sections.append("  - purpose: why this content exists")
    sections.append('  - funnel_stage: "awareness" | "interest" | "decision" | "action" | "retention"')
    sections.append("  - persona_id: numeric persona ID only if explicitly provided in context; otherwise null. Never return persona names or labels in persona_id.")
    sections.append("  - persona_label: optional short persona name such as Student or Freelancer")
    sections.append("  - content_type: format (carousel, reel, static_post, story, etc.)")
    sections.append("  - audience_action: what the audience should do")
    sections.append("  - reason_for_format: why this format was chosen")
    sections.append("  - source_fact_ids: array of source fact ids used")
    sections.append("  - performance_insight_ids: array of insight ids applied")
    sections.append("  - competitor_opportunity_ids: array of opportunity ids used")

    return "\n".join(sections)


def build_caption_system_prompt() -> str:
    return """You are a professional social media copywriter.
Your role is to generate engaging, platform-optimized posts for a connected campaign strategy.

Rules:
1. Every post must be grounded in the approved source facts.
2. Never invent unsupported claims, prices, dates, or statistics.
3. Follow all brand guardrails strictly.
4. Respect hashtag limits, emoji allowances, and language settings.
5. Do not repeat hooks, CTAs, or topics from recent campaigns.
6. Use the assigned persona's language, motivation, and objections.
7. If a conversion path is provided, the CTA must guide toward it.
8. Each post must serve its strategic purpose and funnel stage.
9. Output ONLY valid JSON matching the required schema."""


def build_caption_user_prompt(
    ctx: CampaignGenerationContext,
    day_plan: dict | None = None,
) -> str:
    sections: list[str] = []

    sections.append("=== CAMPAIGN CONTEXT ===")
    if ctx.request:
        sections.append(f"Platform: {ctx.request.platform}")
        sections.append(f"Tone: {ctx.request.tone}")
        sections.append(f"Campaign Goal: {ctx.request.campaign_goal}")

    if ctx.brand:
        sections.append(f"\nBrand: {ctx.brand.name}")

    g = ctx.guardrails
    if g.count_active_rules() > 0:
        sections.append("\n=== GUARDRAILS ===")
        if g.required_phrases:
            sections.append(f"Required: {', '.join(g.required_phrases)}")
        if g.forbidden_words:
            sections.append(f"Forbidden: {', '.join(g.forbidden_words)}")
        if g.restricted_claims:
            sections.append(f"Restricted claims: {', '.join(g.restricted_claims)}")
        if g.required_legal_disclaimer:
            sections.append(f"Legal disclaimer: {g.required_legal_disclaimer}")
        if g.emoji_allowance:
            sections.append(f"Emoji allowance: {g.emoji_allowance}")
        if g.max_hashtag_count is not None:
            sections.append(f"Max hashtags: {g.max_hashtag_count}")
        if g.min_hashtag_count is not None:
            sections.append(f"Min hashtags: {g.min_hashtag_count}")
        if g.preferred_cta_style:
            sections.append(f"Preferred CTA style: {g.preferred_cta_style}")
        if g.forbidden_cta_styles:
            sections.append(f"Forbidden CTA styles: {', '.join(g.forbidden_cta_styles)}")

    if day_plan:
        sections.append("\n=== DAY PLAN ===")
        sections.append(f"Day: {day_plan.get('day', '?')}")
        sections.append(f"Theme: {day_plan.get('theme', '')}")
        sections.append(f"Purpose: {day_plan.get('purpose', '')}")
        sections.append(f"Funnel Stage: {day_plan.get('funnel_stage', 'awareness')}")
        sections.append(f"Content Type: {day_plan.get('content_type', 'static_post')}")
        sections.append(f"Audience Action: {day_plan.get('audience_action', '')}")

    if ctx.personas and day_plan:
        pid = day_plan.get("persona_id")
        for p in ctx.personas:
            if p.id == pid:
                sections.append("\n=== TARGET PERSONA ===")
                sections.append(f"Name: {p.name or 'Unnamed'}")
                if p.main_problem:
                    sections.append(f"Problem: {p.main_problem}")
                if p.desired_outcome:
                    sections.append(f"Desired Outcome: {p.desired_outcome}")
                if p.objections:
                    sections.append(f"Objections: {p.objections}")
                if p.motivation:
                    sections.append(f"Motivation: {p.motivation}")
                if p.cta_preference:
                    sections.append(f"CTA Preference: {p.cta_preference}")
                if p.language:
                    sections.append(f"Language: {p.language}")
                break

    if ctx.source_facts:
        sections.append("\n=== APPROVED SOURCE FACTS ===")
        if day_plan and day_plan.get("source_fact_ids"):
            selected_ids = set(day_plan["source_fact_ids"])
            for f in ctx.source_facts:
                if f.id in selected_ids:
                    sections.append(f"  [{f.category}] {f.label}: {f.value}")
        else:
            for f in ctx.source_facts:
                sections.append(f"  [{f.category}] {f.label}: {f.value}")

    if ctx.conversion_path:
        sections.append("\n=== CONVERSION PATH ===")
        sections.append(f"Destination: {ctx.conversion_path.destination_value or ctx.conversion_path.name}")
        sections.append(f"Action: {ctx.conversion_path.primary_action or ''}")
        if ctx.conversion_path.cta_keyword:
            sections.append(f"CTA Keyword: {ctx.conversion_path.cta_keyword}")

    if ctx.regional_settings:
        r = ctx.regional_settings
        if r.support_roman_urdu:
            sections.append("\nUse Roman Urdu where appropriate.")
        if r.support_bilingual_posts:
            sections.append("Mix English with regional language naturally.")

    if ctx.freshness_context.recent_hooks:
        sections.append("\n=== DO NOT REPEAT ===")
        sections.append("Avoid these recent hooks:")
        for h in ctx.freshness_context.recent_hooks[-5:]:
            sections.append(f"  - {h[:80]}")

    sections.append("\n=== OUTPUT JSON SCHEMA ===")
    sections.append("{")
    sections.append('  "hook": "Opening hook",')
    sections.append('  "caption": "Full caption text",')
    sections.append('  "call_to_action": "CTA text",')
    sections.append('  "hashtags": ["#tag1", "#tag2"],')
    sections.append('  "content_theme": "Theme from day plan",')
    sections.append('  "post_idea": "Brief post idea",')
    sections.append('  "content_type": "carousel|reel|static_post|story|thread|short_video",')
    sections.append('  "suggested_time": "Best posting time",')
    sections.append('  "purpose": "Why this post exists",')
    sections.append('  "funnel_stage": "awareness|interest|decision|action|retention",')
    sections.append('  "audience_action": "What audience should do",')
    sections.append('  "reason_for_format": "Why this format",')
    sections.append('  "source_fact_ids": [1, 2],')
    sections.append('  "guardrails_applied": ["required_phrases", "hashtag_limits"],')
    sections.append('  "performance_insights_applied": ["Educational carousels perform well"]')
    sections.append("}")

    return "\n".join(sections)


def build_source_extraction_system_prompt() -> str:
    return """You are a precise brand intelligence extractor. Extract structured facts from brand source material.

Rules:
1. Extract EVERY distinct fact from the source material. Do not limit to 3-5 facts.
2. Each product, service, feature, benefit, and audience detail gets its own fact.
3. Do NOT classify as "testimonial" unless the text contains an actual customer statement or endorsement.
4. Categories must be one of: brand, product, service, feature, benefit, target_audience, price, date,
   location, event, conversion_path, campaign_goal, brand_style, restricted_claim, legal_disclaimer,
   contact, offer, course, speaker, testimonial, other
5. Set confidence based on how explicitly the information is stated (1.0 = directly stated, lower = inferred).
6. Include exact source excerpts to support each fact.

Output ONLY valid JSON matching the required schema."""


def build_source_extraction_user_prompt(title: str, text: str) -> str:
    return f"""Extract all facts from this source document.

Document Title: {title or "Untitled"}

Source Text:
{text[:15000]}

Return a JSON object with:
{{
  "document_title": "Extracted or given title",
  "facts": [
    {{
      "category": "one of the allowed categories",
      "label": "Short label for this fact",
      "value": "The actual fact content",
      "source_excerpt": "Exact supporting text from source",
      "confidence": 0.0 to 1.0
    }}
  ]
}}"""
