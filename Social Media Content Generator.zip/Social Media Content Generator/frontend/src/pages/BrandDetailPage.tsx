import { useCallback, useEffect, useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { Loader2, ArrowLeft, Clock, RotateCw, Trash2, Eye, Plus, Building2, Users, Globe, Shield, UserCircle, Target, FileText, Package, Activity, Lightbulb, BarChart3, FlaskConical, Languages, Swords, AlertCircle } from 'lucide-react'
import * as api from '@/api/endpoints'
import type { CampaignData } from '@/types/common'
import { ROUTES } from '@/routes/paths'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'

function getApiErrorMessage(err: unknown): string {
  if (err instanceof Error) return err.message
  return 'Failed to load campaigns'
}

export function BrandDetailPage() {
  const { brandId, brand } = useBrandWorkspace()
  const navigate = useNavigate()

  const [campaigns, setCampaigns] = useState<CampaignData[]>([])
  const [campaignsLoading, setCampaignsLoading] = useState(true)
  const [campaignsError, setCampaignsError] = useState<string | null>(null)

  const fetchCampaigns = useCallback(async () => {
    setCampaignsLoading(true)
    setCampaignsError(null)
    try {
      const data = await api.fetchCampaigns(brandId)
      setCampaigns(data)
    } catch (err) {
      setCampaignsError(getApiErrorMessage(err))
    } finally {
      setCampaignsLoading(false)
    }
  }, [brandId])

  useEffect(() => {
    fetchCampaigns()
  }, [fetchCampaigns])

  const handleDeleteCampaign = async (campaignId: number) => {
    try {
      await api.deleteCampaign(campaignId)
      setCampaigns((prev) => prev.filter((c) => c.id !== campaignId))
    } catch (_err) { /* silently ignore */ }
  }

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr)
    return d.toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric',
      hour: '2-digit', minute: '2-digit',
    })
  }

  return (
    <div className="w-full space-y-6">
      {/* Back link */}
      <Link
        to={ROUTES.brands}
        className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Brands
      </Link>

      {/* Brand header */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-xl overflow-hidden bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center text-white font-bold text-xl shrink-0">
            {brand.logo_url ? (
              <img src={brand.logo_url} alt="" className="w-full h-full object-cover" />
            ) : (
              brand.name.charAt(0).toUpperCase()
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-bold text-gray-900">{brand.name}</h1>
            {brand.niche && <p className="text-sm text-gray-500 mt-0.5">{brand.niche}</p>}
            {brand.description && (
              <p className="text-sm text-gray-600 mt-2">{brand.description}</p>
            )}
            <div className="flex items-center gap-4 mt-3 text-xs text-gray-400">
              {brand.target_audience && (
                <span className="flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5" />
                  {brand.target_audience}
                </span>
              )}
              {brand.website && (
                <a
                  href={brand.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 hover:text-purple-600 transition-colors"
                >
                  <Globe className="w-3.5 h-3.5" />
                  Website
                </a>
              )}
              <span className="flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5" />
                {campaignsLoading ? '-' : `${campaigns.length} campaign${campaigns.length !== 1 ? 's' : ''}`}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Brand tabs */}
      <div className="flex items-center gap-2 border-b border-gray-100 pb-3 overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-transparent">
        <Link
          to={`${ROUTES.brands}/${brand.id}`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg bg-purple-50 text-purple-700"
        >
          Campaigns
        </Link>
        <Link
          to={`${ROUTES.brands}/${brand.id}/guardrails`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors flex items-center gap-1.5"
        >
          <Shield className="w-3.5 h-3.5" />
          Guardrails
        </Link>
        <Link
          to={`${ROUTES.brands}/${brand.id}/personas`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors flex items-center gap-1.5"
        >
          <UserCircle className="w-3.5 h-3.5" />
          Personas
        </Link>
        <Link
          to={`${ROUTES.brands}/${brand.id}/conversion-paths`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors flex items-center gap-1.5"
        >
          <Target className="w-3.5 h-3.5" />
          Conversion Paths
        </Link>
        <Link
          to={`${ROUTES.brands}/${brand.id}/source-documents`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors flex items-center gap-1.5"
        >
          <FileText className="w-3.5 h-3.5" />
          Source Documents
        </Link>
        <Link
          to={`${ROUTES.brands}/${brand.id}/content-packs`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors flex items-center gap-1.5"
        >
          <Package className="w-3.5 h-3.5" />
          Content Packs
        </Link>
        <Link
          to={`${ROUTES.brands}/${brand.id}/freshness`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors flex items-center gap-1.5"
        >
          <Activity className="w-3.5 h-3.5" />
          Content Freshness
        </Link>
        <Link
          to={`${ROUTES.brands}/${brand.id}/strategies`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors flex items-center gap-1.5"
        >
          <Lightbulb className="w-3.5 h-3.5" />
          Strategy Templates
        </Link>
        <Link
          to={`${ROUTES.brands}/${brand.id}/performance`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors flex items-center gap-1.5"
        >
          <BarChart3 className="w-3.5 h-3.5" />
          Performance
        </Link>
        <Link
          to={`${ROUTES.brands}/${brand.id}/experiments`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors flex items-center gap-1.5"
        >
          <FlaskConical className="w-3.5 h-3.5" />
          Experiments
        </Link>
        <Link
          to={`${ROUTES.brands}/${brand.id}/regional`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors flex items-center gap-1.5"
        >
          <Languages className="w-3.5 h-3.5" />
          Regional Settings
        </Link>
        <Link
          to={`${ROUTES.brands}/${brand.id}/competitors`}
          className="shrink-0 whitespace-nowrap text-sm font-medium px-3 py-1.5 rounded-lg text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors flex items-center gap-1.5"
        >
          <Swords className="w-3.5 h-3.5" />
          Competitors
        </Link>
      </div>

      {/* Campaign list */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Campaign Plans</h2>
          <Link
            to={`${ROUTES.generate}?brandId=${brand.id}`}
            className="bg-gradient-to-r from-purple-600 to-purple-800 text-white text-sm font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 hover:scale-[1.02] transition-all duration-200 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Campaign
          </Link>
        </div>

        {campaignsLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-5 h-5 animate-spin text-purple-600" />
          </div>
        ) : campaignsError ? (
          <div className="bg-white rounded-2xl border border-red-100 p-8 text-center">
            <AlertCircle className="w-8 h-8 text-red-400 mx-auto mb-3" />
            <p className="text-gray-500 text-sm mb-4">{campaignsError}</p>
            <button
              onClick={fetchCampaigns}
              className="inline-flex items-center gap-2 text-sm font-semibold px-4 py-2 rounded-xl bg-red-50 text-red-700 hover:bg-red-100 transition-colors"
            >
              <RotateCw className="w-4 h-4" />
              Retry
            </button>
          </div>
        ) : campaigns.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
            <Clock className="w-8 h-8 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-400 text-sm mb-4">
              No campaign plans yet for this brand.
            </p>
            <Link
              to={`${ROUTES.generate}?brandId=${brand.id}`}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-purple-800 text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 hover:scale-[1.02] transition-all duration-200"
            >
              <Plus className="w-4 h-4" />
              Generate Your First Campaign
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {campaigns.map((c) => (
              <div
                key={c.id}
                className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-gray-900 text-sm truncate">{c.name}</h3>
                      <span
                        className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                          c.status === 'published'
                            ? 'bg-green-50 text-green-700'
                            : c.status === 'draft'
                              ? 'bg-yellow-50 text-yellow-700'
                              : 'bg-gray-50 text-gray-600'
                        }`}
                      >
                        {c.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                      <span>{c.platform}</span>
                      <span>&middot;</span>
                      <span>{c.tone}</span>
                      <span>&middot;</span>
                      <span>{c.posts?.length || 0} posts</span>
                      <span>&middot;</span>
                      <span>{formatDate(c.created_at)}</span>
                    </div>
                    <p className="text-xs text-gray-400 mt-1">Goal: {c.campaign_goal}</p>
                  </div>
                  <div className="flex items-center gap-1 ml-4">
                    <button
                      onClick={() => navigate(ROUTES.calendar)}
                      className="p-2 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-purple-600"
                      title="View in Calendar"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteCampaign(c.id)}
                      className="p-2 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-red-600"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
