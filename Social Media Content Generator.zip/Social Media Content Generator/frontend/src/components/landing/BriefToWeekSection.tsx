import { motion } from 'framer-motion'
import { FileText, Target, CalendarDays, Hash, ArrowDown } from 'lucide-react'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { staggerContainer, listItem } from '@/lib/animation'

const stages = [
  {
    icon: FileText,
    title: 'Brand Brief',
    desc: 'Enter your brand name, niche, audience, and campaign goal.',
    color: 'from-purple-500 to-purple-600',
    gradient: 'from-purple-50 to-purple-100/50',
  },
  {
    icon: Target,
    title: 'Campaign Strategy',
    desc: 'AI structures a 7-day content strategy around your goal.',
    color: 'from-violet-500 to-purple-600',
    gradient: 'from-violet-50 to-purple-100/50',
  },
  {
    icon: CalendarDays,
    title: '7-Day Calendar',
    desc: 'Each day gets a theme, post idea, content type, and time.',
    color: 'from-fuchsia-500 to-purple-600',
    gradient: 'from-fuchsia-50 to-purple-100/50',
  },
  {
    icon: Hash,
    title: 'Captions + CTAs + Hashtags',
    desc: 'Platform-ready text with calls to action and relevant tags.',
    color: 'from-purple-600 to-indigo-600',
    gradient: 'from-purple-50 to-indigo-100/50',
  },
]

export function BriefToWeekSection() {
  const reduced = useReducedMotionPreference()

  return (
    <section id="how-it-works" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            From a simple brief to a complete content week
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            Describe your brand once. The platform handles the rest.
          </p>
        </div>

        <motion.div
          variants={reduced ? undefined : staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          className="grid md:grid-cols-4 gap-6"
        >
          {stages.map((stage, i) => (
            <motion.div
              key={stage.title}
              variants={reduced ? undefined : listItem}
              className="relative"
            >
              <div className={`bg-gradient-to-br ${stage.gradient} rounded-2xl p-6 border border-gray-100 h-full`}>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stage.color} flex items-center justify-center shadow-lg mb-4`}>
                  <stage.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{stage.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{stage.desc}</p>
              </div>
              {i < stages.length - 1 && (
                <div className="hidden md:flex absolute -right-4 top-1/2 -translate-y-1/2 z-10">
                  <ArrowDown className="w-6 h-6 text-purple-300 -rotate-90" />
                </div>
              )}
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
