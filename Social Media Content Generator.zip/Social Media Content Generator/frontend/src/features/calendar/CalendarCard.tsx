import { Clock, Type, Lightbulb, ChevronRight } from 'lucide-react'
import { getDayColor } from '@/utils/formatters'
import { cn } from '@/utils/cn'

interface CalendarCardProps {
  day: number
  contentTheme: string
  platform: string
  suggestedTime: string
  contentType: string
  postIdea: string
}

export function CalendarCard({ day, contentTheme, platform, suggestedTime, contentType, postIdea }: CalendarCardProps) {
  return (
    <div className="calendar-card group h-full">
      <div className={cn('bg-gradient-to-r p-4', getDayColor(day))}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white font-bold text-lg">
              {day}
            </div>
            <div>
              <p className="text-white/80 text-xs font-medium uppercase tracking-wider">Day</p>
              <p className="text-white font-bold text-lg">{day}</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-white/60 group-hover:text-white group-hover:translate-x-1 transition-all" />
        </div>
      </div>

      <div className="p-5 space-y-4">
        <div>
          <p className="text-xs font-medium text-gray-400 uppercase tracking-wider mb-1">Content Theme</p>
          <p className="text-gray-900 font-semibold text-sm leading-snug">{contentTheme}</p>
        </div>

        <div className="space-y-2.5">
          <div className="flex items-center gap-2.5 text-sm">
            <div className="w-7 h-7 rounded-lg bg-purple-50 flex items-center justify-center">
              <Clock className="w-3.5 h-3.5 text-purple-600" />
            </div>
            <span className="text-gray-600">{suggestedTime}</span>
          </div>
          <div className="flex items-center gap-2.5 text-sm">
            <div className="w-7 h-7 rounded-lg bg-purple-50 flex items-center justify-center">
              <Type className="w-3.5 h-3.5 text-purple-600" />
            </div>
            <span className="text-gray-600">{contentType}</span>
          </div>
          <div className="flex items-center gap-2.5 text-sm">
            <div className="w-7 h-7 rounded-lg bg-purple-50 flex items-center justify-center">
              <Lightbulb className="w-3.5 h-3.5 text-purple-600" />
            </div>
            <span className="text-gray-600">{postIdea}</span>
          </div>
        </div>

        <div className="pt-3 border-t border-gray-100">
          <span className="inline-flex items-center px-3 py-1 rounded-full bg-purple-50 text-purple-700 text-xs font-medium">
            {platform}
          </span>
        </div>
      </div>
    </div>
  )
}
