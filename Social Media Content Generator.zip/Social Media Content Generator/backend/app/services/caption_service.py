from __future__ import annotations

from structlog.stdlib import BoundLogger

from app.exceptions import CaptionGenerationError
from app.modules.caption_generator import generate_caption as _generate_caption
from app.modules.hashtag_generator import generate_hashtags as _generate_hashtags


class CaptionService:
    def __init__(self, logger: BoundLogger | None = None) -> None:
        self._logger = logger

    def generate_caption(
        self,
        post_idea: str,
        platform: str,
        tone: str,
        brand_details: dict,
    ) -> str:
        try:
            caption = _generate_caption(
                post_idea=post_idea,
                platform=platform,
                tone=tone,
                brand_details=brand_details,
            )
            if self._logger:
                self._logger.info(
                    "caption_generated",
                    platform=platform,
                    tone=tone,
                    length=len(caption),
                )
            return caption
        except ValueError as e:
            raise CaptionGenerationError(str(e))

    def generate_hashtags(
        self,
        niche: str,
        platform: str,
        campaign_goal: str,
        brand_name: str = "",
    ) -> list[str]:
        try:
            hashtags = _generate_hashtags(
                niche=niche,
                platform=platform,
                campaign_goal=campaign_goal,
                brand_name=brand_name,
            )
            if self._logger:
                self._logger.info(
                    "hashtags_generated",
                    platform=platform,
                    count=len(hashtags),
                )
            return hashtags
        except ValueError as e:
            raise CaptionGenerationError(str(e))
