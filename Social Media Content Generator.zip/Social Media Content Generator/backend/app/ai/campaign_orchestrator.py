from typing import Any

import structlog
from sqlalchemy.orm import Session

from app.ai.context_builder import (
    CampaignGenerationContext,
    CampaignRequestContext,
    build_campaign_context,
)
from app.ai.fallback_service import (
    fallback_campaign_strategy,
    fallback_generate_post,
)
from app.ai.generation_trace import GenerationTraceData
from app.ai.groq_client import TokenEstimate, groq_json_chat
from app.ai.prompt_builder import (
    build_caption_system_prompt,
    build_caption_user_prompt,
    build_strategy_system_prompt,
    build_strategy_user_prompt,
)
from app.ai.response_schemas import (
    CampaignStrategy,
    GeneratedPost,
)
from app.config import settings
from app.models.db_models import BrandGuardrail, BrandProfile
from app.services.brand_check_service import BrandCheckService
from app.utils.brand_name import preserve_brand_name

logger = structlog.get_logger(__name__)


def generate_full_campaign(
    db: Session,
    user_id: int,
    brand_id: int,
    platform: str,
    tone: str,
    campaign_goal: str,
    days_count: int = 7,
    persona_ids: list[int] | None = None,
    conversion_path_id: int | None = None,
    strategy_id: int | None = None,
    performance_insight_ids: list[int] | None = None,
    experiment_learning_ids: list[int] | None = None,
    competitor_opportunity_ids: list[int] | None = None,
) -> dict[str, Any]:
    request = CampaignRequestContext(
        platform=platform,
        tone=tone,
        campaign_goal=campaign_goal,
        days_count=days_count,
        persona_ids=persona_ids or [],
        conversion_path_id=conversion_path_id,
        strategy_id=strategy_id,
        performance_insight_ids=performance_insight_ids or [],
        experiment_learning_ids=experiment_learning_ids or [],
        competitor_opportunity_ids=competitor_opportunity_ids or [],
    )

    ctx = build_campaign_context(db, brand_id, user_id, request)
    if not ctx.brand:
        return {
            "error": "Brand not found or unauthorized",
            "generation_source": "error",
        }

    brand_name = ctx.brand.name

    strategy_result = _plan_campaign_strategy(ctx)
    if strategy_result.get("generation_source") == "error":
        return strategy_result

    strategy_source = strategy_result["generation_source"]
    day_plans = strategy_result.get("day_plans", [])

    generated_posts, posts_source = _generate_all_seven_posts(ctx, day_plans)

    for post in generated_posts:
        post["caption"] = preserve_brand_name(post.get("caption", ""), brand_name)
        post["call_to_action"] = preserve_brand_name(
            post.get("call_to_action", ""),
            brand_name,
        )
        post["post_idea"] = preserve_brand_name(
            post.get("post_idea", ""),
            brand_name,
        )

    brand_model = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    guardrail = (
        db.query(BrandGuardrail).filter(BrandGuardrail.brand_id == brand_id).first()
        if brand_model
        else None
    )

    if brand_model and guardrail:
        check_service = BrandCheckService()
        calendar_for_check = _posts_to_calendar_format(generated_posts)

        try:
            check_result = check_service.check_guardrails(
                brand_model,
                guardrail,
                calendar_for_check,
            )

            if hasattr(check_result, "summary") and check_result.summary.blocked > 0:
                logger.warning(
                    "Brand check blocked some posts",
                    blocked=check_result.summary.blocked,
                )
        except Exception as e:
            logger.warning("Brand check failed during generation", error=str(e))

    final_source = (
        "groq"
        if strategy_source == "groq" and posts_source == "groq"
        else "fallback"
    )

    trace_data = GenerationTraceData(
        groq_used=(strategy_source == "groq" or posts_source == "groq"),
        groq_model=settings.groq_model,
        generation_source=final_source,
        brand_id=brand_id,
        persona_ids=request.persona_ids,
        conversion_path_id=request.conversion_path_id,
        source_fact_ids=[f.id for f in ctx.source_facts],
        strategy_id=request.strategy_id,
        performance_insight_ids=request.performance_insight_ids,
        experiment_learning_ids=request.experiment_learning_ids,
        competitor_opportunity_ids=request.competitor_opportunity_ids,
        guardrail_version=1,
    )

    return {
        "campaign_name": strategy_result.get(
            "campaign_name",
            f"{brand_name} Campaign",
        ),
        "campaign_summary": strategy_result.get("campaign_summary", ""),
        "strategy": strategy_result.get("strategy", ""),
        "posts": generated_posts,
        "generation_source": final_source,
        "strategy_source": strategy_source,
        "posts_source": posts_source,
        "fallback_used": final_source == "fallback",
        "generation_trace": trace_data.model_dump(),
        "intelligence_summary": _build_intelligence_summary(ctx),
    }


def _should_retry_groq_error(error: Exception) -> bool:
    """Determine if a Groq error should trigger a retry."""
    error_str = str(error).lower()

    if any(code in error_str for code in ["400", "401", "403", "404", "413"]):
        return False

    if any(code in error_str for code in ["408", "429", "500", "502", "503", "504"]):
        return True

    return True


def _compaction_needed(estimate: TokenEstimate) -> bool:
    """Return True if a request would exceed the token budget."""
    return estimate.estimated_total_tokens > settings.groq_tpm_budget


def _normalize_day_value(value: Any) -> int | None:
    if value is None:
        return None

    if isinstance(value, int):
        return value

    if isinstance(value, str):
        cleaned = value.strip().lower()

        if cleaned.isdigit():
            return int(cleaned)

        if cleaned.startswith("day "):
            number_part = cleaned.replace("day ", "", 1).strip()
            if number_part.isdigit():
                return int(number_part)

    return None


def _normalize_batched_post(post_data: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(post_data)

    if "day" not in normalized and "day_number" in normalized:
        normalized["day"] = normalized["day_number"]

    if "day" not in normalized and "Day" in normalized:
        normalized["day"] = normalized["Day"]

    normalized["day"] = _normalize_day_value(normalized.get("day"))

    if "generation_source" not in normalized:
        normalized["generation_source"] = "groq"

    if "source_fact_ids" not in normalized or normalized["source_fact_ids"] is None:
        normalized["source_fact_ids"] = []

    if "hashtags" not in normalized or normalized["hashtags"] is None:
        normalized["hashtags"] = []

    return normalized


def _validate_batch_response(
    raw_response: dict[str, Any],
    expected_days: int = 7,
) -> list[dict[str, Any]] | None:
    """Validate a batched post generation response."""
    try:
        if "posts" not in raw_response:
            logger.error("Batched response missing 'posts' field")
            return None

        posts = raw_response["posts"]
        if not isinstance(posts, list):
            logger.error("Batched posts response 'posts' is not a list")
            return None

        if len(posts) != expected_days:
            logger.error(
                "Batched response does not contain expected number of posts",
                received=len(posts),
                expected=expected_days,
            )
            return None

        validated_posts = []
        seen_days: set[int] = set()

        for raw_post in posts:
            if not isinstance(raw_post, dict):
                logger.error("Batched post is not an object", raw_post=raw_post)
                return None

            post_data = _normalize_batched_post(raw_post)
            day = _normalize_day_value(post_data.get("day"))

            if not isinstance(day, int):
                logger.error(
                    "Batched post has invalid day",
                    day=post_data.get("day"),
                    raw_post=raw_post,
                )
                return None

            if day < 1 or day > expected_days:
                logger.error("Batched post day out of range", day=day)
                return None

            if day in seen_days:
                logger.error("Duplicate day in batched posts", day=day)
                return None

            post_data["day"] = day

            validated = GeneratedPost(**post_data)
            dumped = validated.model_dump()
            dumped["day"] = day

            seen_days.add(day)
            validated_posts.append(dumped)

        expected_day_set = set(range(1, expected_days + 1))
        if seen_days != expected_day_set:
            logger.error(
                "Batched response missing required days",
                received=sorted(seen_days),
                expected=sorted(expected_day_set),
            )
            return None

        return sorted(validated_posts, key=lambda p: p.get("day", 0))
    except Exception as e:
        logger.error("Batched response validation failed", error=str(e))
        return None


def _build_user_prompt_compact(
    ctx: CampaignGenerationContext,
) -> str:
    """Build a compact user prompt for batched post generation."""
    sections = ["=== CAMPAIGN CONTEXT (COMPACT) ==="]

    if ctx.request:
        sections.append(f"Platform: {ctx.request.platform}")
        sections.append(f"Tone: {ctx.request.tone}")
        sections.append(f"Campaign Goal: {ctx.request.campaign_goal}")

    if ctx.brand:
        sections.append(f"Brand: {ctx.brand.name}")
        if ctx.brand.description:
            sections.append(f"Description: {ctx.brand.description}")

    g = ctx.guardrails
    if g.count_active_rules() > 0:
        sections.append("Safety Rules:")

        if g.required_phrases:
            sections.append(f"  Must include: {', '.join(g.required_phrases[:3])}")

        if g.forbidden_words:
            sections.append(f"  Must exclude: {', '.join(g.forbidden_words[:3])}")

        if g.restricted_claims:
            sections.append(
                f"  Restricted claims: {', '.join(g.restricted_claims[:3])}",
            )

        if g.required_legal_disclaimer:
            sections.append("  Legal disclaimer required")

    if ctx.personas:
        sections.append(f"Selected Personas ({len(ctx.personas)}):")
        for p in ctx.personas:
            sections.append(f"  - {p.name or f'Persona ID {p.id}'}")

    if ctx.source_facts:
        sections.append(f"Approved Source Facts ({len(ctx.source_facts)}):")
        for fact in ctx.source_facts[:5]:
            sections.append(f"  [{fact.category}] {fact.label}")

    if ctx.performance_insights:
        sections.append(f"Performance Insights ({len(ctx.performance_insights)}):")
        for ins in ctx.performance_insights[:2]:
            sections.append(f"  - {ins.pattern_type}: {ins.finding}")

    return "\n".join(sections)


def _plan_campaign_strategy(ctx: CampaignGenerationContext) -> dict[str, Any]:
    if not settings.groq_enabled:
        logger.info("Groq disabled, using fallback strategy")
        return _fallback_strategy(ctx)

    system_prompt = build_strategy_system_prompt()
    user_prompt = build_strategy_user_prompt(ctx)

    raw = groq_json_chat(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        temperature=0.7,
        max_tokens=settings.groq_strategy_max_output_tokens,
        retries=settings.groq_max_retries,
        request_type="strategy",
    )

    if raw is None:
        logger.info("Groq strategy returned None, using fallback")
        return _fallback_strategy(ctx)

    try:
        validated = CampaignStrategy(**raw)
        day_count = ctx.request.days_count if ctx.request else 7
        day_plans = validated.days[:day_count]

        return {
            "campaign_name": validated.campaign_name,
            "campaign_summary": validated.campaign_summary,
            "strategy": validated.strategy,
            "day_plans": [p.model_dump() for p in day_plans],
            "generation_source": "groq",
        }
    except Exception as e:
        logger.warning("Groq strategy validation failed, retrying", error=str(e))

        raw2 = groq_json_chat(
            system_prompt=system_prompt
            + "\n\nYour previous response failed validation. "
            "Ensure all required fields are present and valid. "
            "If persona_id is not a real numeric ID, return null.",
            user_prompt=user_prompt,
            temperature=0.7,
            max_tokens=settings.groq_strategy_max_output_tokens,
            retries=settings.groq_max_retries,
            request_type="strategy",
        )

        if raw2:
            try:
                validated = CampaignStrategy(**raw2)
                day_count = ctx.request.days_count if ctx.request else 7
                day_plans = validated.days[:day_count]

                return {
                    "campaign_name": validated.campaign_name,
                    "campaign_summary": validated.campaign_summary,
                    "strategy": validated.strategy,
                    "day_plans": [p.model_dump() for p in day_plans],
                    "generation_source": "groq",
                }
            except Exception as e2:
                logger.warning("Groq strategy retry also failed", error=str(e2))

    logger.info("Groq strategy failed, using fallback")
    return _fallback_strategy(ctx)


def _generate_all_seven_posts(
    ctx: CampaignGenerationContext,
    day_plans: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], str]:
    if not settings.groq_enabled:
        logger.info("Groq disabled, generating posts via fallback")
        posts = []

        for plan in day_plans:
            post = fallback_generate_post(ctx, plan)
            if post.get("generation_source") != "error":
                posts.append(post)

        return posts, "fallback"

    system_prompt = """
You are a professional social media copywriter. Generate exactly seven social media posts in JSON format.

Generate professional, engaging posts that:
- Follow the provided campaign strategy and persona
- Respect brand guardrails, tone, and platform requirements
- Are publish-ready and complete
- Stay within token budget constraints

Output ONLY valid JSON in this exact structure:

{
  "posts": [
    {
      "day": 1,
      "hook": "Opening hook",
      "caption": "Full caption text",
      "call_to_action": "CTA text",
      "hashtags": ["#tag1", "#tag2"],
      "content_theme": "Theme for this day's content",
      "content_type": "carousel",
      "post_idea": "Brief post idea",
      "suggested_time": "9:00 AM",
      "purpose": "Why this post matters",
      "funnel_stage": "awareness",
      "audience_action": "What we want readers to do",
      "reason_for_format": "Why this format was chosen",
      "source_fact_ids": [],
      "generation_source": "groq"
    }
  ]
}

CRITICAL REQUIREMENTS:
1. Exactly 7 posts.
2. Return days 1 through 7 exactly once.
3. The "day" field must be an integer, not "Day 1" text.
4. Do not use "day_number"; use "day".
5. All fields must be non-empty except source_fact_ids may be [].
6. Respect all brand guardrails.
7. Include approved source facts where relevant.
8. Match persona tone and voice.
9. Follow platform rules and hashtag limits.
10. Return ONLY valid JSON.

DO NOT include explanations, markdown, or text outside the JSON object.
"""

    user_prompt = _build_batched_posts_user_prompt(ctx, day_plans)

    raw = groq_json_chat(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        temperature=0.7,
        max_tokens=settings.groq_campaign_max_output_tokens,
        retries=settings.groq_max_retries,
        request_type="batched_posts",
    )

    if raw is None:
        logger.info("Groq batched post generation returned None, using fallback")
        posts = []

        for plan in day_plans:
            post = fallback_generate_post(ctx, plan)
            if post.get("generation_source") != "error":
                posts.append(post)

        return posts, "fallback"

    result = _validate_batched_posts_response(raw)
    if result is None:
        logger.warning("Batched posts validation failed")
        posts = []

        for plan in day_plans:
            post = fallback_generate_post(ctx, plan)
            if post.get("generation_source") != "error":
                posts.append(post)

        return posts, "fallback"

    return result["posts"], "groq"


def _validate_batched_posts_response(
    raw_response: dict[str, Any],
) -> dict[str, Any] | None:
    try:
        validated_posts = _validate_batch_response(raw_response, expected_days=7)
        if validated_posts is None:
            return None

        return {"posts": validated_posts}
    except Exception as e:
        logger.error("Batched posts response validation failed", error=str(e))
        return None


def _build_batched_posts_user_prompt(
    ctx: CampaignGenerationContext,
    day_plans: list[dict[str, Any]],
) -> str:
    sections = ["=== CAMPAIGN CONTEXT ==="]

    if ctx.request:
        sections.append(f"Platform: {ctx.request.platform}")
        sections.append(f"Tone: {ctx.request.tone}")
        sections.append(f"Campaign Goal: {ctx.request.campaign_goal}")

    if ctx.brand:
        sections.append("\n=== BRAND IDENTITY ===")
        sections.append(f"Name: {ctx.brand.name}")

        if ctx.brand.description:
            sections.append(f"Description: {ctx.brand.description}")

    if ctx.guardrails.count_active_rules() > 0:
        sections.append("\n=== GUARDRAILS ===")
        g = ctx.guardrails

        if g.required_phrases:
            sections.append(
                f"Required Phrases: {', '.join(g.required_phrases[:5])}",
            )

        if g.forbidden_words:
            sections.append(
                f"Forbidden Words: {', '.join(g.forbidden_words[:5])}",
            )

        if g.restricted_claims:
            sections.append(
                f"Restricted Claims: {', '.join(g.restricted_claims[:5])}",
            )

        if g.required_legal_disclaimer:
            sections.append(f"Legal Disclaimer: {g.required_legal_disclaimer}")

    if ctx.personas:
        sections.append("\n=== PERSONAS ===")

        for persona in ctx.personas[:2]:
            persona_line = f"- ID {persona.id}: {persona.name}"

            if persona.description:
                persona_line += f": {persona.description}"

            sections.append(persona_line)

    if ctx.source_facts:
        sections.append("\n=== APPROVED SOURCE FACTS ===")

        for fact in ctx.source_facts[:12]:
            sections.append(
                f"ID {fact.id}: [{fact.category}] {fact.label}: {fact.value}",
            )

    if ctx.performance_insights:
        sections.append("\n=== PERFORMANCE INSIGHTS ===")

        for insight in ctx.performance_insights[:3]:
            sections.append(f"- {insight.pattern_type}: {insight.finding}")

    if ctx.conversion_path:
        sections.append("\n=== CONVERSION PATH ===")
        sections.append(f"Name: {ctx.conversion_path.name}")

        if ctx.conversion_path.primary_action:
            sections.append(f"Primary Action: {ctx.conversion_path.primary_action}")

        if ctx.conversion_path.cta_keyword:
            sections.append(f"CTA Keyword: {ctx.conversion_path.cta_keyword}")

    sections.append("\n=== DAY PLANS ===")

    for plan in day_plans:
        day = _normalize_day_value(plan.get("day"))
        sections.append(f"Day {day}:")
        sections.append(f"  Theme: {plan.get('theme', '')}")
        sections.append(f"  Purpose: {plan.get('purpose', '')}")
        sections.append(f"  Funnel Stage: {plan.get('funnel_stage', '')}")
        sections.append(f"  Content Type: {plan.get('content_type', '')}")

    return "\n".join(sections)


def _generate_single_post(
    ctx: CampaignGenerationContext,
    day_plan: dict[str, Any],
) -> dict[str, Any]:
    if not settings.groq_enabled:
        return fallback_generate_post(ctx, day_plan)

    system_prompt = build_caption_system_prompt()
    user_prompt = build_caption_user_prompt(ctx, day_plan)

    raw = groq_json_chat(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        temperature=0.7,
        max_tokens=settings.groq_campaign_max_output_tokens,
        request_type="single_post",
    )

    if raw is None:
        logger.info("Groq post generation returned None, using fallback")
        return fallback_generate_post(ctx, day_plan)

    try:
        validated = GeneratedPost(**raw)
        result = validated.model_dump()
        result["generation_source"] = "groq"
        return result
    except Exception as e:
        logger.warning("Groq post validation failed, retrying", error=str(e))

        raw2 = groq_json_chat(
            system_prompt=system_prompt
            + "\n\nYour previous response failed validation. "
            "Ensure all required fields are present and valid.",
            user_prompt=user_prompt,
            temperature=0.7,
            max_tokens=settings.groq_campaign_max_output_tokens,
            request_type="single_post_retry",
        )

        if raw2:
            try:
                validated = GeneratedPost(**raw2)
                result = validated.model_dump()
                result["generation_source"] = "groq"
                return result
            except Exception as e2:
                logger.warning("Groq post retry also failed", error=str(e2))

    logger.info("Groq post generation failed, using fallback")
    return fallback_generate_post(ctx, day_plan)


def _fallback_strategy(ctx: CampaignGenerationContext) -> dict[str, Any]:
    return fallback_campaign_strategy(ctx)


def _posts_to_calendar_format(posts: list[dict[str, Any]]) -> list[dict[str, Any]]:
    calendar = []

    for i, post in enumerate(posts):
        calendar.append(
            {
                "day": i + 1,
                "contentTheme": post.get("content_theme", ""),
                "postIdea": post.get("post_idea", ""),
                "caption": post.get("caption", ""),
                "callToAction": post.get("call_to_action", ""),
                "hashtags": post.get("hashtags", []),
            },
        )

    return calendar


def _build_intelligence_summary(ctx: CampaignGenerationContext) -> dict[str, Any]:
    summary: dict[str, Any] = {}
    summary["brand"] = ctx.brand.name if ctx.brand else "Unknown"

    g = ctx.guardrails
    guardrail_rules = g.count_active_rules()

    if guardrail_rules > 0:
        summary["brand_guardrails"] = f"{guardrail_rules} rules"

    if ctx.personas:
        summary["personas"] = [p.name or f"Persona #{p.id}" for p in ctx.personas]

    if ctx.source_facts:
        summary["source_facts"] = f"{len(ctx.source_facts)} approved facts"

    if ctx.conversion_path:
        summary["conversion_path"] = ctx.conversion_path.name

    if ctx.strategy:
        summary["strategy"] = ctx.strategy.name

    if ctx.performance_insights:
        summary["performance_insights"] = f"{len(ctx.performance_insights)} insights"

    if ctx.experiment_learnings:
        summary["experiment_learnings"] = f"{len(ctx.experiment_learnings)} learnings"

    if ctx.freshness_context.recent_hooks:
        summary["freshness_rules"] = (
            f"{len(ctx.freshness_context.recent_hooks)} recent hooks avoided"
        )

    if ctx.competitor_opportunities:
        summary["competitor_opportunities"] = f"{len(ctx.competitor_opportunities)} gaps"

    r = ctx.regional_settings
    regional_info = r.default_language

    if r.support_roman_urdu:
        regional_info += " + Roman Urdu"

    if r.support_bilingual_posts:
        regional_info += " (Bilingual)"

    summary["regional_mode"] = regional_info

    return summary