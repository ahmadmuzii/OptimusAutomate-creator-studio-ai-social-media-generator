import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { AuthProvider, useAuth } from '../AuthContext'
import type { UserData } from '@/types/common'

const mockUser: UserData = {
  id: 1,
  email: 'test@example.com',
  name: 'Test User',
  brand_name: null,
  niche: null,
  bio: null,
  avatar_url: null,
}

vi.mock('@/api/endpoints', () => ({
  login: vi.fn(),
  signup: vi.fn(),
  fetchMe: vi.fn(),
  updateProfile: vi.fn(),
}))

vi.mock('@/api/client', () => ({
  setAccessToken: vi.fn(),
  clearToken: vi.fn(),
  setLogoutHandler: vi.fn(),
}))

import * as endpoints from '@/api/endpoints'
import * as clientModule from '@/api/client'

function TestAuthConsumer({ onReady }: { onReady?: (auth: ReturnType<typeof useAuth>) => void }) {
  const auth = useAuth()
  onReady?.(auth)
  return (
    <div>
      <span data-testid="is-authenticated">{auth.isAuthenticated ? 'true' : 'false'}</span>
      <span data-testid="is-loading">{auth.isLoading ? 'true' : 'false'}</span>
      <span data-testid="user-email">{auth.user?.email ?? ''}</span>
      <span data-testid="token">{auth.token ?? ''}</span>
      <button data-testid="login-btn" onClick={() => auth.login('test@example.com', 'pass123')}>Login</button>
      <button data-testid="signup-btn" onClick={() => auth.signup('new@example.com', 'pass123', 'New User')}>Signup</button>
      <button data-testid="logout-btn" onClick={() => auth.logout()}>Logout</button>
    </div>
  )
}

function renderWithProvider(ui: React.ReactElement) {
  return render(<AuthProvider>{ui}</AuthProvider>)
}

beforeEach(() => {
  vi.clearAllMocks()
  localStorage.clear()
  vi.mocked(endpoints.login).mockResolvedValue({
    access_token: 'access-token-123',
    user: mockUser,
  } as Awaited<ReturnType<typeof endpoints.login>>)
  vi.mocked(endpoints.signup).mockResolvedValue({
    access_token: 'access-token-789',
    user: { ...mockUser, id: 2, email: 'new@example.com', name: 'New User' },
  } as Awaited<ReturnType<typeof endpoints.signup>>)
  vi.mocked(endpoints.fetchMe).mockResolvedValue(mockUser)
})

describe('AuthProvider', () => {
  it('renders children', () => {
    renderWithProvider(<p>Hello</p>)
    expect(screen.getByText('Hello')).toBeInTheDocument()
  })
})

describe('useAuth', () => {
  it('throws when used outside AuthProvider', () => {
    expect(() => render(<TestAuthConsumer />)).toThrow(
      'useAuth must be used within an AuthProvider',
    )
  })
})

describe('initial state', () => {
  it('shows unauthenticated when no token', async () => {
    const authRef: { current?: ReturnType<typeof useAuth> } = {}
    renderWithProvider(<TestAuthConsumer onReady={(a) => { authRef.current = a }} />)
    await waitFor(() => expect(authRef.current?.isLoading).toBe(false))
    expect(authRef.current?.isAuthenticated).toBe(false)
    expect(authRef.current?.user).toBeNull()
    expect(authRef.current?.token).toBeNull()
  })

  it('fetches user when token exists', async () => {
    localStorage.setItem('token', 'existing-token')
    const authRef: { current?: ReturnType<typeof useAuth> } = {}
    renderWithProvider(<TestAuthConsumer onReady={(a) => { authRef.current = a }} />)
    await waitFor(() => expect(authRef.current?.isLoading).toBe(false))
    expect(endpoints.fetchMe).toHaveBeenCalled()
    expect(authRef.current?.isAuthenticated).toBe(true)
    expect(authRef.current?.user?.email).toBe('test@example.com')
  })

  it('clears auth when fetchMe fails', async () => {
    localStorage.setItem('token', 'invalid-token')
    vi.mocked(endpoints.fetchMe).mockRejectedValue(new Error('Unauthorized'))
    const authRef: { current?: ReturnType<typeof useAuth> } = {}
    renderWithProvider(<TestAuthConsumer onReady={(a) => { authRef.current = a }} />)
    await waitFor(() => expect(authRef.current?.isLoading).toBe(false))
    expect(authRef.current?.isAuthenticated).toBe(false)
    expect(authRef.current?.token).toBeNull()
  })
})

describe('login', () => {
  it('calls login API and updates auth state', async () => {
    const authRef: { current?: ReturnType<typeof useAuth> } = {}
    renderWithProvider(<TestAuthConsumer onReady={(a) => { authRef.current = a }} />)
    await waitFor(() => expect(authRef.current?.isLoading).toBe(false))
    fireEvent.click(screen.getByTestId('login-btn'))
    await waitFor(() => {
      expect(endpoints.login).toHaveBeenCalledWith('test@example.com', 'pass123')
    })
    expect(clientModule.setAccessToken).toHaveBeenCalledWith('access-token-123')
    expect(authRef.current?.isAuthenticated).toBe(true)
    expect(authRef.current?.user?.email).toBe('test@example.com')
    expect(authRef.current?.token).toBe('access-token-123')
  })
})

describe('signup', () => {
  it('calls signup API and updates auth state', async () => {
    const authRef: { current?: ReturnType<typeof useAuth> } = {}
    renderWithProvider(<TestAuthConsumer onReady={(a) => { authRef.current = a }} />)
    await waitFor(() => expect(authRef.current?.isLoading).toBe(false))
    fireEvent.click(screen.getByTestId('signup-btn'))
    await waitFor(() => {
      expect(endpoints.signup).toHaveBeenCalledWith('new@example.com', 'pass123', 'New User')
    })
    expect(clientModule.setAccessToken).toHaveBeenCalledWith('access-token-789')
    expect(authRef.current?.isAuthenticated).toBe(true)
    expect(authRef.current?.user?.email).toBe('new@example.com')
  })
})

describe('logout', () => {
  it('clears auth state', async () => {
    localStorage.setItem('token', 'existing-token')
    const authRef: { current?: ReturnType<typeof useAuth> } = {}
    renderWithProvider(<TestAuthConsumer onReady={(a) => { authRef.current = a }} />)
    await waitFor(() => expect(authRef.current?.isLoading).toBe(false))
    expect(authRef.current?.isAuthenticated).toBe(true)
    fireEvent.click(screen.getByTestId('logout-btn'))
    expect(clientModule.clearToken).toHaveBeenCalled()
    expect(authRef.current?.isAuthenticated).toBe(false)
    expect(authRef.current?.token).toBeNull()
    expect(authRef.current?.user).toBeNull()
  })
})
