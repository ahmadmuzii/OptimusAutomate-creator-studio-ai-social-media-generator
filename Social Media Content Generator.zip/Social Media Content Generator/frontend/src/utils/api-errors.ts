import type { AxiosError } from 'axios'

export interface ApiError {
  message: string
  status: number | null
  fieldErrors?: Record<string, string>
}

export function extractApiError(error: unknown): ApiError {
  if (!error) {
    return { message: 'An unexpected error occurred', status: null }
  }

  const axiosError = error as AxiosError<{ detail?: string | Record<string, unknown>; errors?: Record<string, string[]> }>

  if (axiosError.response) {
    const status = axiosError.response.status
    const data = axiosError.response.data

    if (status === 401) {
      return { message: 'Session expired. Please sign in again.', status }
    }

    if (status === 403) {
      return { message: 'You do not have permission to perform this action.', status }
    }

    if (status === 404) {
      return { message: 'The requested resource was not found.', status }
    }

    if (status === 409) {
      return { message: typeof data?.detail === 'string' ? data.detail : 'This resource already exists.', status }
    }

    if (status === 422 && data?.errors) {
      const fieldErrors: Record<string, string> = {}
      for (const [field, messages] of Object.entries(data.errors)) {
        fieldErrors[field] = (messages as string[]).join(', ')
      }
      const firstError = Object.values(fieldErrors)[0]
      return {
        message: firstError || 'Validation failed',
        status,
        fieldErrors,
      }
    }

    if (typeof data?.detail === 'string') {
      return { message: data.detail, status }
    }

    if (status === 500) {
      return { message: 'A server error occurred. Please try again later.', status }
    }

    return { message: `Request failed with status ${status}`, status }
  }

  if ((axiosError as AxiosError).code === 'ECONNABORTED') {
    return { message: 'Request timed out. Please check your connection and try again.', status: null }
  }

  if (!(axiosError as AxiosError).response && (axiosError as AxiosError).request) {
    return { message: 'Could not reach the server. Please check your connection.', status: null }
  }

  if (error instanceof Error) {
    return { message: error.message, status: null }
  }

  return { message: 'An unexpected error occurred', status: null }
}
