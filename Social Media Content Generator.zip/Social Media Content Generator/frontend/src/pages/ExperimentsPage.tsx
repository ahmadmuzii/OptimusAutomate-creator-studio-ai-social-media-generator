import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'
import { ArrowLeft, Plus, Trash2, FlaskConical, ChevronDown, ChevronRight, Trophy } from 'lucide-react'
import { ErrorState } from '@/components/ui/ErrorState'
import { LoadingSpinner } from '@/components/ui/LoadingSpinner'
import * as api from '@/api/endpoints'
import type { Experiment } from '@/types/experiment'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'

const STATUS_COLORS: Record<string, string> = {
  draft: 'bg-gray-100 text-gray-700',
  running: 'bg-green-100 text-green-700',
  completed: 'bg-blue-100 text-blue-700',
  analyzing: 'bg-purple-100 text-purple-700',
}

const SUCCESS_METRICS = ['impressions', 'clicks', 'engagement', 'conversions']

const EMPTY_VARIANT = { label: '', variable_value: '', content_value: '' }

export function ExperimentsPage() {
  const { brandId, brand } = useBrandWorkspace()

  const [loading, setLoading] = useState(true)

  const [experiments, setExperiments] = useState<Experiment[]>([])
  const [editingId, setEditingId] = useState<number | 'new' | null>(null)
  const [form, setForm] = useState<Record<string, unknown>>({ name: '', campaign_id: '', variable_tested: '', success_metric: 'impressions', variants: [{ ...EMPTY_VARIANT }] })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [expandedId, setExpandedId] = useState<number | null>(null)
  const [declareError, setDeclareError] = useState<string | null>(null)

  // Expanded experiment sub-forms
  const [newVariantForm, setNewVariantForm] = useState<Record<string, string>>({ ...EMPTY_VARIANT })
  const [addingVariant, setAddingVariant] = useState(false)
  const [resultForms, setResultForms] = useState<Record<number, Record<string, string>>>({})
  const [updatingResults, setUpdatingResults] = useState<Record<number, boolean>>({})

  const load = useCallback(async () => {
    const data = await api.fetchExperiments(brandId)
    setExperiments(data as Experiment[])
  }, [brandId])

  useEffect(() => {
    load().catch(() => setError('Could not load experiments.')).finally(() => setLoading(false))
  }, [brandId, load])

  const startEdit = () => {
    setEditingId('new')
    setForm({ name: '', campaign_id: '', variable_tested: '', success_metric: 'impressions', variants: [{ ...EMPTY_VARIANT }] })
  }

  const cancelEdit = () => { setEditingId(null); setForm({ name: '', campaign_id: '', variable_tested: '', success_metric: 'impressions', variants: [{ ...EMPTY_VARIANT }] }) }

  const handleSave = async () => {
    setSaving(true)
    try {
      const payload = {
        ...form,
        campaign_id: form.campaign_id ? Number(form.campaign_id) : null,
        variants: (form.variants as typeof EMPTY_VARIANT[]).filter(v => v.label && v.variable_value),
      }
      await api.createExperiment(brandId, payload)
      await load()
      cancelEdit()
    } catch { setError('Failed to save experiment.') }
    finally { setSaving(false) }
  }

  const handleDelete = async (expId: number) => {
    try {
      await api.deleteExperiment(brandId, expId)
      setExperiments(prev => prev.filter(e => e.id !== expId))
    } catch { setError('Failed to delete.') }
  }

  const updateVariantForm = (index: number, field: string, value: string) => {
    const variants = [...((form.variants as typeof EMPTY_VARIANT[]) || [])]
    variants[index] = { ...variants[index], [field]: value } as typeof EMPTY_VARIANT
    setForm(prev => ({ ...prev, variants }))
  }

  const addVariantRow = () => {
    const variants = [...((form.variants as typeof EMPTY_VARIANT[]) || []), { ...EMPTY_VARIANT }]
    setForm(prev => ({ ...prev, variants }))
  }

  const removeVariantRow = (index: number) => {
    const variants = [...((form.variants as typeof EMPTY_VARIANT[]) || [])]
    variants.splice(index, 1)
    setForm(prev => ({ ...prev, variants }))
  }

  const toggleExpand = async (expId: number) => {
    if (expandedId === expId) {
      setExpandedId(null)
      return
    }
    setExpandedId(expId)
    const experiment = experiments.find(e => e.id === expId)
    if (experiment && experiment.variants.length === 0) {
      try {
        const fresh = await api.getExperiment(brandId, expId)
        setExperiments(prev => prev.map(e => e.id === expId ? (fresh as Experiment) : e))
      } catch { /* ignore */ }
    }
    const frms: Record<number, Record<string, string>> = {}
    experiment?.variants.forEach(v => {
      frms[v.id] = {
        impressions: v.impressions?.toString() || '',
        clicks: v.clicks?.toString() || '',
        engagement: v.engagement?.toString() || '',
        conversions: v.conversions?.toString() || '',
      }
    })
    setResultForms(frms)
  }

  const handleAddVariant = async (expId: number) => {
    if (!newVariantForm.label || !newVariantForm.variable_value) return
    setAddingVariant(true)
    try {
      await api.addExperimentVariant(brandId, expId, newVariantForm)
      const fresh = await api.getExperiment(brandId, expId)
      setExperiments(prev => prev.map(e => e.id === expId ? (fresh as Experiment) : e))
      setNewVariantForm({ ...EMPTY_VARIANT })
    } catch { setError('Failed to add variant.') }
    finally { setAddingVariant(false) }
  }

  const handleUpdateResults = async (variantId: number) => {
    setUpdatingResults(prev => ({ ...prev, [variantId]: true }))
    try {
      const payload: Record<string, number> = {}
      Object.entries(resultForms[variantId] || {}).forEach(([k, v]) => {
        if (v) payload[k] = Number(v)
      })
      await api.updateVariantResult(brandId, variantId, payload)
      const exp = experiments.find(e => e.variants.some(v => v.id === variantId))
      if (exp) {
        const fresh = await api.getExperiment(brandId, exp.id)
        setExperiments(prev => prev.map(e => e.id === exp.id ? (fresh as Experiment) : e))
        const f = fresh as Experiment
        const frms = { ...resultForms }
        f.variants.forEach(v => {
          frms[v.id] = {
            impressions: v.impressions?.toString() || '',
            clicks: v.clicks?.toString() || '',
            engagement: v.engagement?.toString() || '',
            conversions: v.conversions?.toString() || '',
          }
        })
        setResultForms(frms)
      }
    } catch { setError('Failed to update results.') }
    finally { setUpdatingResults(prev => ({ ...prev, [variantId]: false })) }
  }

  const handleDeclareWinner = async (expId: number, variantId: number) => {
    setDeclareError(null)
    try {
      await api.declareWinner(brandId, expId, { variant_id: variantId })
      const fresh = await api.getExperiment(brandId, expId)
      setExperiments(prev => prev.map(e => e.id === expId ? (fresh as Experiment) : e))
    } catch { setDeclareError('Failed to declare winner.') }
  }

  const handleChangeStatus = async (expId: number, status: string) => {
    try {
      await api.updateExperiment(brandId, expId, { status })
      setExperiments(prev => prev.map(e => e.id === expId ? { ...e, status } as Experiment : e))
    } catch { setError('Failed to update status.') }
  }

  if (loading) return <LoadingSpinner />

  if (error) return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>
      <ErrorState message={error} onRetry={load} />
    </div>
  )

  if (experiments.length === 0) return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <FlaskConical className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">A/B Experiments</h1>
        </div>
        <Button onClick={startEdit} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Experiment
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Create and manage A/B experiments for {brand.name}. Test variables and declare winners based on performance.
      </p>

      <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
        <FlaskConical className="w-8 h-8 text-gray-300 mx-auto mb-3" />
        <p className="text-gray-400 text-sm mb-4">No experiments created yet.</p>
        <Button onClick={startEdit} className="mx-auto flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Your First Experiment
        </Button>
      </div>

      {editingId !== null && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={cancelEdit}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">Create Experiment</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Name *</label>
                  <input value={form.name as string} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} placeholder="e.g., Headline Test - June" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Campaign ID (optional)</label>
                  <input type="number" value={form.campaign_id as string} onChange={e => setForm(prev => ({ ...prev, campaign_id: e.target.value }))} placeholder="e.g., 42" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Variable Tested *</label>
                  <input value={form.variable_tested as string} onChange={e => setForm(prev => ({ ...prev, variable_tested: e.target.value }))} placeholder="e.g., Headline" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Success Metric</label>
                  <select value={form.success_metric as string} onChange={e => setForm(prev => ({ ...prev, success_metric: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    {SUCCESS_METRICS.map(m => <option key={m} value={m} className="capitalize">{m}</option>)}
                  </select>
                </div>
              </div>

              {/* Variants sub-form */}
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Variants</label>
                {((form.variants as typeof EMPTY_VARIANT[]) || []).map((v, i) => (
                  <div key={i} className="flex items-start gap-2 mb-2">
                    <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input value={v.label} onChange={e => updateVariantForm(i, 'label', e.target.value)} placeholder="Label (e.g., A)" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <input value={v.variable_value} onChange={e => updateVariantForm(i, 'variable_value', e.target.value)} placeholder="Variable value" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <input value={v.content_value} onChange={e => updateVariantForm(i, 'content_value', e.target.value)} placeholder="Content (optional)" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                    </div>
                    <button onClick={() => removeVariantRow(i)} className="p-1.5 text-gray-400 hover:text-red-500 mt-1"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
                <button onClick={addVariantRow} className="text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1"><Plus className="w-3.5 h-3.5" /> Add variant</button>
              </div>

              <div className="flex items-center gap-3 pt-4">
                <Button onClick={handleSave} disabled={saving || !form.name || !form.variable_tested}>{saving ? 'Saving...' : 'Create'}</Button>
                <button onClick={cancelEdit} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )

  return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <FlaskConical className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">A/B Experiments</h1>
        </div>
        <Button onClick={startEdit} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Experiment
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Create and manage A/B experiments for {brand.name}. Test variables and declare winners based on performance.
      </p>

      {/* Create Modal */}
      {editingId !== null && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={cancelEdit}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">Create Experiment</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Name *</label>
                  <input value={form.name as string} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} placeholder="e.g., Headline Test - June" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Campaign ID (optional)</label>
                  <input type="number" value={form.campaign_id as string} onChange={e => setForm(prev => ({ ...prev, campaign_id: e.target.value }))} placeholder="e.g., 42" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Variable Tested *</label>
                  <input value={form.variable_tested as string} onChange={e => setForm(prev => ({ ...prev, variable_tested: e.target.value }))} placeholder="e.g., Headline" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Success Metric</label>
                  <select value={form.success_metric as string} onChange={e => setForm(prev => ({ ...prev, success_metric: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    {SUCCESS_METRICS.map(m => <option key={m} value={m} className="capitalize">{m}</option>)}
                  </select>
                </div>
              </div>

              {/* Variants sub-form */}
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Variants</label>
                {((form.variants as typeof EMPTY_VARIANT[]) || []).map((v, i) => (
                  <div key={i} className="flex items-start gap-2 mb-2">
                    <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input value={v.label} onChange={e => updateVariantForm(i, 'label', e.target.value)} placeholder="Label (e.g., A)" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <input value={v.variable_value} onChange={e => updateVariantForm(i, 'variable_value', e.target.value)} placeholder="Variable value" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <input value={v.content_value} onChange={e => updateVariantForm(i, 'content_value', e.target.value)} placeholder="Content (optional)" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                    </div>
                    <button onClick={() => removeVariantRow(i)} className="p-1.5 text-gray-400 hover:text-red-500 mt-1"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
                <button onClick={addVariantRow} className="text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1"><Plus className="w-3.5 h-3.5" /> Add variant</button>
              </div>

              <div className="flex items-center gap-3 pt-4">
                <Button onClick={handleSave} disabled={saving || !form.name || !form.variable_tested}>{saving ? 'Saving...' : 'Create'}</Button>
                <button onClick={cancelEdit} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Experiment List */}
        <div className="space-y-3">
          {experiments.map(exp => (
            <div key={exp.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <button onClick={() => toggleExpand(exp.id)} className="w-full flex items-center justify-between p-5 hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-3">
                  {expandedId === exp.id ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronRight className="w-4 h-4 text-gray-400" />}
                  <div className="text-left">
                    <h3 className="font-semibold text-gray-900">{exp.name}</h3>
                    <p className="text-xs text-gray-400">Variable: {exp.variable_tested}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-medium px-2.5 py-1 rounded-full capitalize ${STATUS_COLORS[exp.status] || 'bg-gray-100 text-gray-700'}`}>{exp.status}</span>
                  <span className="text-xs text-gray-400">{exp.variants.length} variant{exp.variants.length !== 1 ? 's' : ''}</span>
                  <button onClick={(e) => { e.stopPropagation(); handleDelete(exp.id) }} className="p-1 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500" title="Delete">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </button>

              {/* Expanded Detail */}
              {expandedId === exp.id && (
                <div className="px-5 pb-5 pt-2 border-t border-gray-50 space-y-6">
                  {/* Experiment Details */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="text-gray-400 text-xs">Campaign ID</p>
                      <p className="text-gray-800 font-medium">{exp.campaign_id ?? 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Variable</p>
                      <p className="text-gray-800 font-medium">{exp.variable_tested}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Success Metric</p>
                      <p className="text-gray-800 font-medium capitalize">{exp.success_metric || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Status</p>
                      <select value={exp.status} onChange={e => handleChangeStatus(exp.id, e.target.value)} className="text-sm border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-purple-500">
                        <option value="draft">Draft</option>
                        <option value="running">Running</option>
                        <option value="completed">Completed</option>
                        <option value="analyzing">Analyzing</option>
                      </select>
                    </div>
                  </div>

                  {/* Variants Table */}
                  <div>
                    <h4 className="text-sm font-semibold text-gray-900 mb-2">Variants</h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="text-left text-gray-400 border-b border-gray-50">
                            <th className="pb-2 font-medium">Label</th>
                            <th className="pb-2 font-medium">Value</th>
                            <th className="pb-2 font-medium text-right">Impressions</th>
                            <th className="pb-2 font-medium text-right">Clicks</th>
                            <th className="pb-2 font-medium text-right">Engagement</th>
                            <th className="pb-2 font-medium text-right">Conversions</th>
                            <th className="pb-2 font-medium text-center">Winner</th>
                            <th className="pb-2 font-medium text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {declareError && (
                            <tr>
                              <td colSpan={8} className="py-2">
                                <p className="text-sm text-red-600 font-medium">{declareError}</p>
                              </td>
                            </tr>
                          )}
                          {exp.variants.map(v => (
                            <tr key={v.id} className={`border-b border-gray-50 ${v.is_winner ? 'bg-green-50/50' : ''}`}>
                              <td className="py-2 font-medium text-gray-800">{v.label}</td>
                              <td className="py-2 text-gray-600">{v.variable_value}</td>
                              <td className="py-2">
                                <input type="number" value={resultForms[v.id]?.impressions ?? ''} onChange={e => setResultForms(prev => ({ ...prev, [v.id]: { ...prev[v.id], impressions: e.target.value } }))} placeholder="0" className="w-full text-right rounded border border-gray-200 px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                              </td>
                              <td className="py-2">
                                <input type="number" value={resultForms[v.id]?.clicks ?? ''} onChange={e => setResultForms(prev => ({ ...prev, [v.id]: { ...prev[v.id], clicks: e.target.value } }))} placeholder="0" className="w-full text-right rounded border border-gray-200 px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                              </td>
                              <td className="py-2">
                                <input type="number" value={resultForms[v.id]?.engagement ?? ''} onChange={e => setResultForms(prev => ({ ...prev, [v.id]: { ...prev[v.id], engagement: e.target.value } }))} placeholder="0" className="w-full text-right rounded border border-gray-200 px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                              </td>
                              <td className="py-2">
                                <input type="number" value={resultForms[v.id]?.conversions ?? ''} onChange={e => setResultForms(prev => ({ ...prev, [v.id]: { ...prev[v.id], conversions: e.target.value } }))} placeholder="0" className="w-full text-right rounded border border-gray-200 px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                              </td>
                              <td className="py-2 text-center">
                                {v.is_winner ? <Trophy className="w-4 h-4 text-yellow-500 mx-auto" /> : '-'}
                              </td>
                              <td className="py-2 text-right">
                                <div className="flex items-center justify-end gap-1">
                                  <Button size="sm" variant="ghost" onClick={() => handleUpdateResults(v.id)} disabled={updatingResults[v.id]} className="text-xs">
                                    {updatingResults[v.id] ? 'Saving...' : 'Update'}
                                  </Button>
                                  {!v.is_winner && exp.status === 'running' && (
                                    <Button size="sm" variant="ghost" onClick={() => handleDeclareWinner(exp.id, v.id)} className="text-xs flex items-center gap-1">
                                      <Trophy className="w-3 h-3" /> Declare Winner
                                    </Button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Add Variant */}
                  <div className="border-t border-gray-100 pt-4">
                    <h4 className="text-sm font-semibold text-gray-900 mb-2">Add Variant</h4>
                    <div className="flex items-start gap-2">
                      <input value={newVariantForm.label} onChange={e => setNewVariantForm(prev => ({ ...prev, label: e.target.value }))} placeholder="Label" className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <input value={newVariantForm.variable_value} onChange={e => setNewVariantForm(prev => ({ ...prev, variable_value: e.target.value }))} placeholder="Value" className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <input value={newVariantForm.content_value} onChange={e => setNewVariantForm(prev => ({ ...prev, content_value: e.target.value }))} placeholder="Content (optional)" className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <Button size="sm" onClick={() => handleAddVariant(exp.id)} disabled={addingVariant || !newVariantForm.label || !newVariantForm.variable_value} className="flex items-center gap-1">
                        <Plus className="w-3.5 h-3.5" /> Add
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
    </div>
  )
}
