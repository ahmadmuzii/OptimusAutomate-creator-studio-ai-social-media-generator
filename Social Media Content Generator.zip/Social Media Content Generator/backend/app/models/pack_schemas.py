from __future__ import annotations

import datetime

from pydantic import BaseModel, ConfigDict


class PackMediaItem(BaseModel):
    type: str
    url: str
    alt_text: str | None = None
    order: int = 0


class PackLink(BaseModel):
    url: str
    title: str | None = None
    description: str | None = None


class ContentPackData(BaseModel):
    title: str
    description: str | None = None
    media: list[PackMediaItem] = []
    links: list[PackLink] = []
    notes: str | None = None
    tags: list[str] = []


class ContentPackTemplate(BaseModel):
    id: int
    brand_id: int
    name: str
    description: str | None = None
    pack_data: ContentPackData
    is_default: bool = False
    created_at: datetime.datetime
    updated_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)


class ContentPackTemplateCreate(BaseModel):
    name: str
    description: str | None = None
    pack_data: ContentPackData
    is_default: bool = False


class ContentPackTemplateUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    pack_data: ContentPackData | None = None
    is_default: bool | None = None


class ContentPackExportRequest(BaseModel):
    campaign_id: int
    post_ids: list[int] | None = None
    format: str = "json"
