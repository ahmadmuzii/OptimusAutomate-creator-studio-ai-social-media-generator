from __future__ import annotations

import datetime

from sqlalchemy import JSON, Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.database import Base


def _utcnow() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    name = Column(String(255), nullable=False)
    brand_name = Column(String(255), nullable=True)
    niche = Column(String(255), nullable=True)
    bio = Column(Text, nullable=True)
    avatar_url = Column(String(500), nullable=True)
    job_title = Column(String(255), nullable=True)
    location = Column(String(255), nullable=True)
    personal_website = Column(String(500), nullable=True)
    theme_preference = Column(String(20), default="light", nullable=False)
    reset_token_hash = Column(String(255), nullable=True)
    reset_token_expires = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow, nullable=False)

    brands = relationship("BrandProfile", back_populates="user", cascade="all, delete-orphan")
    campaigns = relationship("Campaign", back_populates="user", cascade="all, delete-orphan")


class BrandProfile(Base):
    __tablename__ = "brand_profiles"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    niche = Column(String(255), nullable=True)
    target_audience = Column(String(500), nullable=True)
    website = Column(String(500), nullable=True)
    social_links = Column(JSON, nullable=True)
    logo_url = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow, nullable=False)

    user = relationship("User", back_populates="brands")
    campaigns = relationship("Campaign", back_populates="brand_profile", cascade="all, delete-orphan")
    guardrails = relationship("BrandGuardrail", back_populates="brand", uselist=False, cascade="all, delete-orphan")
    personas = relationship("AudiencePersona", back_populates="brand", cascade="all, delete-orphan")
    regional_settings = relationship(
        "BrandRegionalSettings", back_populates="brand", uselist=False, cascade="all, delete-orphan"
    )


class BrandGuardrail(Base):
    __tablename__ = "brand_guardrails"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=False, index=True)
    required_phrases = Column(JSON, nullable=True)
    forbidden_words = Column(JSON, nullable=True)
    competitors_never_mention = Column(JSON, nullable=True)
    approved_product_descriptions = Column(JSON, nullable=True)
    allowed_claims = Column(JSON, nullable=True)
    restricted_claims = Column(JSON, nullable=True)
    preferred_spellings = Column(JSON, nullable=True)
    preferred_capitalizations = Column(JSON, nullable=True)
    product_names = Column(JSON, nullable=True)
    service_names = Column(JSON, nullable=True)
    brand_name_aliases = Column(JSON, nullable=True)
    required_legal_disclaimer = Column(Text, nullable=True)
    example_posts_liked = Column(JSON, nullable=True)
    example_posts_disliked = Column(JSON, nullable=True)
    emoji_allowance = Column(String(50), nullable=True)
    profanity_level = Column(String(50), nullable=True)
    formality_level = Column(String(50), nullable=True)
    max_hashtag_count = Column(Integer, nullable=True)
    min_hashtag_count = Column(Integer, nullable=True)
    allowed_languages = Column(JSON, nullable=True)
    default_language = Column(String(50), nullable=True)
    preferred_cta_style = Column(String(100), nullable=True)
    forbidden_cta_styles = Column(JSON, nullable=True)
    restricted_topics = Column(JSON, nullable=True)
    sensitive_topics_requiring_review = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow, nullable=False)

    brand = relationship("BrandProfile", back_populates="guardrails")


class BrandRegionalSettings(Base):
    __tablename__ = "brand_regional_settings"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=False, unique=True, index=True)
    default_language = Column(String(50), default="en")
    supported_languages = Column(JSON, default=lambda: ["en", "ur", "hi", "ar"])
    support_roman_urdu = Column(Boolean, default=True)
    support_bilingual_posts = Column(Boolean, default=True)
    support_rtl_layout = Column(Boolean, default=True)
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    brand = relationship("BrandProfile", back_populates="regional_settings")


class AudiencePersona(Base):
    __tablename__ = "audience_personas"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    age_range = Column(String(50), nullable=True)
    location_market = Column(String(255), nullable=True)
    main_problem = Column(Text, nullable=True)
    desired_outcome = Column(Text, nullable=True)
    objections = Column(Text, nullable=True)
    preferred_tone = Column(String(50), nullable=True)
    preferred_platform = Column(String(50), nullable=True)
    buying_stage = Column(String(50), nullable=True)
    content_interests = Column(JSON, nullable=True)
    common_questions = Column(JSON, nullable=True)
    main_motivation = Column(Text, nullable=True)
    cta_preference = Column(String(100), nullable=True)
    language_preference = Column(String(50), nullable=True)
    notes = Column(Text, nullable=True)
    is_primary = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow, nullable=False)

    brand = relationship("BrandProfile", back_populates="personas")


class ConversionPath(Base):
    __tablename__ = "conversion_paths"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    destination_type = Column(String(50), nullable=False)
    destination_value = Column(String(500), nullable=False)
    primary_action = Column(String(200), nullable=True)
    cta_keyword = Column(String(100), nullable=True)
    campaign_goal = Column(String(100), nullable=True)
    tracking_label = Column(String(100), nullable=True)
    utm_source = Column(String(200), nullable=True)
    utm_medium = Column(String(200), nullable=True)
    utm_campaign = Column(String(200), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow, nullable=False)

    brand = relationship("BrandProfile", back_populates="conversion_paths")


BrandProfile.conversion_paths = relationship("ConversionPath", back_populates="brand", cascade="all, delete-orphan")
BrandProfile.pack_templates = relationship("ContentPackTemplate", back_populates="brand", cascade="all, delete-orphan")
BrandProfile.strategy_templates = relationship("StrategyTemplate", back_populates="brand", cascade="all, delete-orphan")


class SourceDocument(Base):
    __tablename__ = "source_documents"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=True)
    source_type = Column(String(50), nullable=False)
    original_url = Column(String(1000), nullable=True)
    pasted_text = Column(Text, nullable=True)
    title = Column(String(500), nullable=True)
    extracted_text = Column(Text, nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    user = relationship("User", back_populates="source_documents")
    facts = relationship("SourceFact", back_populates="source_document", cascade="all, delete-orphan")


User.source_documents = relationship("SourceDocument", back_populates="user", cascade="all, delete-orphan")


class SourceFact(Base):
    __tablename__ = "source_facts"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    source_document_id = Column(Integer, ForeignKey("source_documents.id"), nullable=False, index=True)
    category = Column(String(50), nullable=False)
    label = Column(String(255), nullable=False)
    value = Column(Text, nullable=False)
    source_section = Column(String(255), nullable=True)
    confidence = Column(Float, nullable=True)
    approved_by_user = Column(Boolean, default=False, nullable=False)
    excluded_by_user = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    source_document = relationship("SourceDocument", back_populates="facts")


class CompetitorProfile(Base):
    __tablename__ = "competitor_profiles"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    platform = Column(String(50), nullable=True)
    public_handle = Column(String(255), nullable=True)
    website = Column(String(500), nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    brand = relationship("BrandProfile", back_populates="competitor_profiles")


BrandProfile.competitor_profiles = relationship(
    "CompetitorProfile", back_populates="brand", cascade="all, delete-orphan"
)


class CompetitorPost(Base):
    __tablename__ = "competitor_posts"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    competitor_id = Column(Integer, ForeignKey("competitor_profiles.id"), nullable=False, index=True)
    caption = Column(Text, nullable=True)
    content_type = Column(String(50), nullable=True)
    platform = Column(String(50), nullable=True)
    cta_style = Column(String(100), nullable=True)
    hook_type = Column(String(100), nullable=True)
    topics = Column(JSON, nullable=True)
    publication_date = Column(DateTime, nullable=True)
    engagement_metrics = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    competitor = relationship("CompetitorProfile", back_populates="posts")


CompetitorProfile.posts = relationship("CompetitorPost", back_populates="competitor", cascade="all, delete-orphan")


class CampaignExperiment(Base):
    __tablename__ = "campaign_experiments"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=False, index=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), nullable=True)
    name = Column(String(255), nullable=False)
    variable_tested = Column(String(100), nullable=False)
    success_metric = Column(String(100), nullable=True)
    status = Column(String(50), default="draft", nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    brand = relationship("BrandProfile", back_populates="experiments")
    campaign = relationship("Campaign", back_populates="experiments")
    variants = relationship("ExperimentVariant", back_populates="experiment", cascade="all, delete-orphan")


BrandProfile.experiments = relationship("CampaignExperiment", back_populates="brand", cascade="all, delete-orphan")


class ExperimentVariant(Base):
    __tablename__ = "experiment_variants"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    experiment_id = Column(Integer, ForeignKey("campaign_experiments.id"), nullable=False, index=True)
    label = Column(String(255), nullable=False)
    variable_value = Column(Text, nullable=False)
    content_value = Column(Text, nullable=True)
    status = Column(String(50), default="draft", nullable=False)
    impressions = Column(Integer, nullable=True)
    clicks = Column(Integer, nullable=True)
    engagement = Column(Integer, nullable=True)
    conversions = Column(Integer, nullable=True)
    is_winner = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    experiment = relationship("CampaignExperiment", back_populates="variants")


class PerformanceImportBatch(Base):
    __tablename__ = "performance_import_batches"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=True)
    filename = Column(String(500), nullable=True)
    total_rows = Column(Integer, default=0)
    valid_rows = Column(Integer, default=0)
    invalid_rows = Column(Integer, default=0)
    status = Column(String(50), default="pending", nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    user = relationship("User", back_populates="import_batches")


User.import_batches = relationship("PerformanceImportBatch", back_populates="user", cascade="all, delete-orphan")


class PostPerformanceRecord(Base):
    __tablename__ = "post_performance_records"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=True)
    import_batch_id = Column(Integer, ForeignKey("performance_import_batches.id"), nullable=True)
    campaign_post_id = Column(Integer, ForeignKey("campaign_posts.id"), nullable=True)
    external_post_id = Column(String(255), nullable=True)
    platform = Column(String(50), nullable=True)
    content_type = Column(String(50), nullable=True)
    publication_date = Column(DateTime, nullable=True)
    impressions = Column(Integer, nullable=True)
    reach = Column(Integer, nullable=True)
    likes = Column(Integer, nullable=True)
    comments = Column(Integer, nullable=True)
    saves = Column(Integer, nullable=True)
    shares = Column(Integer, nullable=True)
    link_clicks = Column(Integer, nullable=True)
    watch_time = Column(Float, nullable=True)
    video_views = Column(Integer, nullable=True)
    profile_visits = Column(Integer, nullable=True)
    followers_gained = Column(Integer, nullable=True)
    conversion_count = Column(Integer, nullable=True)
    persona_id = Column(Integer, nullable=True)
    funnel_stage = Column(String(50), nullable=True)
    cta_type = Column(String(100), nullable=True)
    caption_fingerprint = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    user = relationship("User", back_populates="performance_records")
    brand = relationship("BrandProfile", back_populates="performance_records")
    import_batch = relationship("PerformanceImportBatch", back_populates="records")


BrandProfile.performance_records = relationship(
    "PostPerformanceRecord", back_populates="brand", cascade="all, delete-orphan"
)
User.performance_records = relationship("PostPerformanceRecord", back_populates="user", cascade="all, delete-orphan")
PerformanceImportBatch.records = relationship(
    "PostPerformanceRecord", back_populates="import_batch", cascade="all, delete-orphan"
)


class PerformanceInsight(Base):
    __tablename__ = "performance_insights"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=True)
    pattern_type = Column(String(100), nullable=False)
    platform = Column(String(50), nullable=True)
    persona_id = Column(Integer, nullable=True)
    content_type = Column(String(50), nullable=True)
    finding = Column(Text, nullable=False)
    supporting_metric = Column(String(255), nullable=True)
    sample_size = Column(Integer, nullable=True)
    date_range_start = Column(DateTime, nullable=True)
    date_range_end = Column(DateTime, nullable=True)
    confidence = Column(String(50), nullable=True)
    is_accepted = Column(Boolean, default=False, nullable=False)
    is_archived = Column(Boolean, default=False, nullable=False)
    affect_future_generation = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)


class ContentGapReport(Base):
    __tablename__ = "content_gap_reports"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=False, index=True)
    status = Column(String(50), default="draft", nullable=False)
    report_data = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    brand = relationship("BrandProfile", back_populates="gap_reports")


BrandProfile.gap_reports = relationship("ContentGapReport", back_populates="brand", cascade="all, delete-orphan")


class Workspace(Base):
    __tablename__ = "workspaces"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    owner = relationship("User", back_populates="owned_workspaces")
    memberships = relationship("WorkspaceMembership", back_populates="workspace", cascade="all, delete-orphan")


User.owned_workspaces = relationship("Workspace", back_populates="owner", cascade="all, delete-orphan")


class WorkspaceMembership(Base):
    __tablename__ = "workspace_memberships"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    role = Column(String(50), default="editor", nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    workspace = relationship("Workspace", back_populates="memberships")
    user = relationship("User", back_populates="workspace_memberships")


User.workspace_memberships = relationship("WorkspaceMembership", back_populates="user", cascade="all, delete-orphan")


class CampaignComment(Base):
    __tablename__ = "campaign_comments"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), nullable=False, index=True)
    post_id = Column(Integer, ForeignKey("campaign_posts.id"), nullable=True)
    author_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    is_resolved = Column(Boolean, default=False, nullable=False)
    parent_id = Column(Integer, ForeignKey("campaign_comments.id"), nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    campaign = relationship("Campaign", back_populates="comments")
    author = relationship("User", back_populates="campaign_comments")
    post = relationship("CampaignPost", back_populates="comments")
    parent = relationship("CampaignComment", back_populates="replies", remote_side=[id])
    replies = relationship("CampaignComment", back_populates="parent", cascade="all, delete-orphan")


User.campaign_comments = relationship("CampaignComment", back_populates="author", cascade="all, delete-orphan")


class ApprovalRequest(Base):
    __tablename__ = "approval_requests"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), nullable=False, index=True)
    requested_by_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    status = Column(String(50), default="pending", nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    campaign = relationship("Campaign", back_populates="approval_requests")
    decisions = relationship("ApprovalDecision", back_populates="approval_request", cascade="all, delete-orphan")


class ApprovalDecision(Base):
    __tablename__ = "approval_decisions"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    approval_request_id = Column(Integer, ForeignKey("approval_requests.id"), nullable=False, index=True)
    reviewer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    decision = Column(String(50), nullable=False)
    comment = Column(Text, nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    approval_request = relationship("ApprovalRequest", back_populates="decisions")


class PostVersion(Base):
    __tablename__ = "post_versions"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    post_id = Column(Integer, ForeignKey("campaign_posts.id"), nullable=False, index=True)
    version_number = Column(Integer, nullable=False)
    changed_by_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    change_reason = Column(String(255), nullable=True)
    caption = Column(Text, nullable=True)
    call_to_action = Column(String(500), nullable=True)
    hashtags = Column(JSON, nullable=True)
    content_pack = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)


class CampaignPostRevision(Base):
    __tablename__ = "campaign_post_revisions"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    campaign_post_id = Column(Integer, ForeignKey("campaign_posts.id"), nullable=False, index=True)
    revision_number = Column(Integer, nullable=False)
    action = Column(String(50), nullable=False)
    previous_hook = Column(Text, nullable=True)
    previous_caption = Column(Text, nullable=False)
    previous_call_to_action = Column(String(500), nullable=True)
    previous_hashtags = Column(JSON, nullable=True)
    previous_tone = Column(String(50), nullable=True)
    previous_content_theme = Column(String(255), nullable=True)
    previous_post_idea = Column(Text, nullable=True)
    previous_content_type = Column(String(50), nullable=True)
    previous_suggested_time = Column(String(20), nullable=True)
    generation_source = Column(String(50), default="groq")
    created_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    post = relationship("CampaignPost", backref="revisions")
    created_by = relationship("User")


class RefinementTrace(Base):
    __tablename__ = "refinement_traces"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), nullable=False, index=True)
    post_id = Column(Integer, ForeignKey("campaign_posts.id"), nullable=False, index=True)
    action = Column(String(50), nullable=False)
    target_tone = Column(String(50), nullable=True)
    groq_used = Column(Boolean, default=False)
    groq_model = Column(String(100), nullable=True)
    generation_source = Column(String(50), default="unknown")
    persona_id = Column(Integer, nullable=True)
    conversion_path_id = Column(Integer, nullable=True)
    source_fact_ids = Column(JSON, nullable=True)
    guardrail_version = Column(Integer, nullable=True)
    changed_fields = Column(JSON, nullable=True)
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)


class ShareLink(Base):
    __tablename__ = "share_links"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), nullable=False, index=True)
    token = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=True)
    expires_at = Column(DateTime, nullable=True)
    is_revoked = Column(Boolean, default=False, nullable=False)
    allow_approval = Column(Boolean, default=False, nullable=False)
    allow_comments = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)


class Campaign(Base):
    __tablename__ = "campaigns"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    brand_profile_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=True)
    name = Column(String(255), nullable=False)
    platform = Column(String(50), nullable=False)
    tone = Column(String(50), nullable=False)
    campaign_goal = Column(String(200), nullable=False)
    status = Column(String(50), default="draft", nullable=False)
    persona_mode = Column(String(20), default="single", nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow, nullable=False)

    user = relationship("User", back_populates="campaigns")
    brand_profile = relationship("BrandProfile", back_populates="campaigns")
    posts = relationship("CampaignPost", back_populates="campaign", cascade="all, delete-orphan")


Campaign.experiments = relationship("CampaignExperiment", back_populates="campaign", cascade="all, delete-orphan")
Campaign.comments = relationship("CampaignComment", back_populates="campaign", cascade="all, delete-orphan")
Campaign.approval_requests = relationship("ApprovalRequest", back_populates="campaign", cascade="all, delete-orphan")


class CampaignPost(Base):
    __tablename__ = "campaign_posts"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), nullable=False)
    day = Column(Integer, nullable=False)
    content_theme = Column(String(255), nullable=False)
    post_idea = Column(Text, nullable=False)
    content_type = Column(String(50), nullable=False)
    suggested_time = Column(String(20), nullable=False)
    platform = Column(String(50), nullable=False)
    caption = Column(Text, nullable=False)
    call_to_action = Column(String(500), nullable=True)
    hashtags = Column(JSON, nullable=True)
    status = Column(String(50), default="draft", nullable=False)
    scheduled_date = Column(DateTime, nullable=True)
    tone_override = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow, nullable=False)

    campaign = relationship("Campaign", back_populates="posts")
    comments = relationship("CampaignComment", back_populates="post", cascade="all, delete-orphan")
    persona_id = Column(Integer, nullable=True)
    persona_name = Column(String(255), nullable=True)
    audience_problem = Column(Text, nullable=True)
    desired_action = Column(Text, nullable=True)


class GenerationTrace(Base):
    __tablename__ = "generation_traces"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), nullable=True, index=True)
    groq_used = Column(Boolean, default=False)
    groq_model = Column(String(100), nullable=True)
    generation_source = Column(String(50), default="unknown")
    brand_id = Column(Integer, nullable=True)
    persona_ids = Column(JSON, nullable=True)
    conversion_path_id = Column(Integer, nullable=True)
    source_fact_ids = Column(JSON, nullable=True)
    strategy_id = Column(Integer, nullable=True)
    performance_insight_ids = Column(JSON, nullable=True)
    experiment_learning_ids = Column(JSON, nullable=True)
    competitor_opportunity_ids = Column(JSON, nullable=True)
    guardrail_version = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=_utcnow, nullable=False)

    campaign = relationship("Campaign", backref="generation_trace", uselist=False)


# Import related models to resolve SQLAlchemy mapper relationships
# (ContentPackTemplate, StrategyTemplate are defined in separate files)
import app.models.pack_db  # noqa: F401, E402
import app.models.strategy_db  # noqa: F401, E402
