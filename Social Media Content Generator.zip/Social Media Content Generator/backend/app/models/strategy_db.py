from __future__ import annotations

import datetime

from sqlalchemy import JSON, Boolean, Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.database import Base


def _utcnow() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)


class StrategyTemplate(Base):
    __tablename__ = "strategy_templates"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    brand_id = Column(Integer, ForeignKey("brand_profiles.id"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    funnel_stage = Column(String(50), nullable=False)
    campaign_goal = Column(String(200), nullable=False)
    recommended_ctas = Column(JSON, nullable=True)
    content_mix = Column(JSON, nullable=True)
    post_frequency = Column(String(50), default="3x_week", nullable=False)
    platform_focus = Column(String(50), default="all", nullable=False)
    icon = Column(String(50), nullable=True)
    is_default = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=_utcnow, nullable=False)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow, nullable=False)

    brand = relationship("BrandProfile", back_populates="strategy_templates")
