import { useEffect, useState } from 'react'
import { Brain, CheckCircle, Loader2, FileText, Link as LinkIcon } from 'lucide-react'
import * as api from '@/api/endpoints'
import type { SourceDocument } from '@/types/source'

interface IntelligencePanelProps {
  brandId: number | null
  selectedIds: number[]
  onChange: (ids: number[]) => void
}

export function IntelligencePanel({ brandId, selectedIds, onChange }: IntelligencePanelProps) {
  const [documents, setDocuments] = useState<SourceDocument[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!brandId) {
      setDocuments([])
      return
    }
    setLoading(true)
    api.fetchSourceDocuments(brandId)
      .then((data) => {
        const docs = (data as SourceDocument[]).filter(d => d.facts?.length > 0)
        setDocuments(docs)
      })
      .catch(() => setDocuments([]))
      .finally(() => setLoading(false))
  }, [brandId])

  const toggle = (id: number) => {
    const next = selectedIds.includes(id)
      ? selectedIds.filter(i => i !== id)
      : [...selectedIds, id]
    onChange(next)
  }

  if (!brandId) return null

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
            <Brain className="w-4 h-4 text-purple-600" />
          </div>
          <h2 className="text-lg font-semibold text-gray-900">Brand Intelligence</h2>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-400">
          <Loader2 className="w-4 h-4 animate-spin" />
          Loading source documents...
        </div>
      </div>
    )
  }

  if (documents.length === 0) {
    return (
      <div className="space-y-5">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
            <Brain className="w-4 h-4 text-purple-600" />
          </div>
          <h2 className="text-lg font-semibold text-gray-900">Brand Intelligence</h2>
        </div>
        <p className="text-sm text-gray-400">No source documents found for this brand. Add sources in the brand's Source Documents page to enrich AI generation.</p>
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
          <Brain className="w-4 h-4 text-purple-600" />
        </div>
        <h2 className="text-lg font-semibold text-gray-900">Brand Intelligence</h2>
        <span className="text-xs text-gray-400 ml-auto">
          {selectedIds.length} of {documents.length} selected
        </span>
      </div>

      <div className="space-y-2 max-h-64 overflow-y-auto">
        {documents.map((doc) => {
          const isSelected = selectedIds.includes(doc.id)
          return (
            <button
              key={doc.id}
              onClick={() => toggle(doc.id)}
              className={`w-full flex items-start gap-3 p-3 rounded-xl border text-left transition-all ${
                isSelected
                  ? 'border-purple-300 bg-purple-50/50 shadow-sm'
                  : 'border-gray-100 hover:border-gray-200 hover:bg-gray-50'
              }`}
            >
              <div className={`mt-0.5 w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 transition-colors ${
                isSelected
                  ? 'border-purple-600 bg-purple-600'
                  : 'border-gray-300'
              }`}>
                {isSelected && <CheckCircle className="w-4 h-4 text-white" />}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-gray-900 truncate">{doc.title || 'Untitled'}</p>
                <div className="flex items-center gap-2 text-xs text-gray-400 mt-0.5">
                  {doc.source_type === 'url' ? (
                    <span className="flex items-center gap-1"><LinkIcon className="w-3 h-3" /> URL</span>
                  ) : (
                    <span className="flex items-center gap-1"><FileText className="w-3 h-3" /> Pasted Text</span>
                  )}
                  <span>{doc.facts?.length || 0} facts</span>
                  {doc.original_url && (
                    <span className="truncate max-w-[120px]">{doc.original_url}</span>
                  )}
                </div>
              </div>
            </button>
          )
        })}
      </div>

      {selectedIds.length > 0 && (
        <p className="text-xs text-purple-600">
          Selected sources will be used as context during generation.
        </p>
      )}
    </div>
  )
}
