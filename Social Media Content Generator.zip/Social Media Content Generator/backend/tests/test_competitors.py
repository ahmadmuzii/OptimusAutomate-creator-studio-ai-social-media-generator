from __future__ import annotations


class TestCompetitorsAPI:
    """Test competitor CRUD, posts, and gap analysis endpoints."""

    def test_create_competitor(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "CompetitorA",
            "platform": "instagram",
            "public_handle": "@comp_a",
            "website": "https://comp_a.com",
            "notes": "Main competitor",
        }
        response = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json=payload,
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "CompetitorA"
        assert data["platform"] == "instagram"
        assert data["public_handle"] == "@comp_a"
        assert data["website"] == "https://comp_a.com"

    def test_list_competitors(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "Comp X"},
            headers=auth_headers,
        )
        client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "Comp Y"},
            headers=auth_headers,
        )
        response = client.get(
            f"/api/v1/brands/{brand_id}/competitors",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 2

    def test_get_competitor(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "Specific Comp"},
            headers=auth_headers,
        ).json()
        response = client.get(
            f"/api/v1/brands/{brand_id}/competitors/{created['id']}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert response.json()["name"] == "Specific Comp"

    def test_update_competitor(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "Old Name", "platform": "twitter"},
            headers=auth_headers,
        ).json()
        response = client.put(
            f"/api/v1/brands/{brand_id}/competitors/{created['id']}",
            json={"name": "New Name", "notes": "Updated notes"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "New Name"
        assert data["notes"] == "Updated notes"
        assert data["platform"] == "twitter"

    def test_delete_competitor(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "Delete Me"},
            headers=auth_headers,
        ).json()
        response = client.delete(
            f"/api/v1/brands/{brand_id}/competitors/{created['id']}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        list_resp = client.get(
            f"/api/v1/brands/{brand_id}/competitors",
            headers=auth_headers,
        )
        ids = [c["id"] for c in list_resp.json()]
        assert created["id"] not in ids

    def test_add_competitor_post(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        comp = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "Comp With Post"},
            headers=auth_headers,
        ).json()
        response = client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={
                "caption": "Check out our new feature",
                "content_type": "carousel",
                "platform": "instagram",
                "topics": ["ai_automation", "machine_learning"],
            },
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["caption"] == "Check out our new feature"
        assert "ai_automation" in data["topics"]

    def test_list_competitor_posts(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        comp = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "Comp Posts"},
            headers=auth_headers,
        ).json()
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={"caption": "Post 1", "topics": ["topic_a"]},
            headers=auth_headers,
        )
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={"caption": "Post 2", "topics": ["topic_b"]},
            headers=auth_headers,
        )
        response = client.get(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2

    def test_delete_competitor_post(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        comp = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "Comp Del Post"},
            headers=auth_headers,
        ).json()
        post = client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={"caption": "To delete", "topics": ["temp"]},
            headers=auth_headers,
        ).json()
        response = client.delete(
            f"/api/v1/brands/{brand_id}/competitors/posts/{post['id']}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        posts_resp = client.get(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            headers=auth_headers,
        )
        assert len(posts_resp.json()) == 0

    def test_analyze_gaps(self, client, auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        comp_resp = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "CompetitorA", "platform": "instagram"},
            headers=auth_headers,
        )
        comp_id = comp_resp.json()["id"]
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp_id}/posts",
            json={
                "caption": "Check out our new feature",
                "topics": ["ai_automation", "machine_learning"],
            },
            headers=auth_headers,
        )
        response = client.post(
            f"/api/v1/brands/{brand_id}/competitors/analyze-gaps",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert "gaps_found" in data
        assert data["gaps_found"] > 0

    def test_list_gap_reports(self, client, auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        comp = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "Gap Comp"},
            headers=auth_headers,
        ).json()
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={"caption": "Gap post", "topics": ["new_topic"]},
            headers=auth_headers,
        )
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/analyze-gaps",
            headers=auth_headers,
        )
        response = client.get(
            f"/api/v1/brands/{brand_id}/competitors/gap-reports",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 1

    def test_cannot_access_other_users_competitor(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "Mine"},
            headers=auth_headers,
        ).json()
        response = client.get(
            f"/api/v1/brands/{brand_id}/competitors/{created['id']}",
            headers=second_auth_headers,
        )
        assert response.status_code == 404

    def _setup_multi_competitor_data(self, client, auth_headers, brand_id):
        """Helper to create multi-competitor data for analytics tests."""
        comp_a = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "CompA", "platform": "instagram"},
            headers=auth_headers,
        ).json()
        comp_b = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "CompB", "platform": "instagram"},
            headers=auth_headers,
        ).json()

        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp_a['id']}/posts",
            json={"caption": "A1", "content_type": "carousel", "topics": ["coffee culture", "seasonal drinks"]},
            headers=auth_headers,
        )
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp_a['id']}/posts",
            json={"caption": "A2", "content_type": "reel", "topics": ["seasonal drinks", "iced coffee"]},
            headers=auth_headers,
        )
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp_b['id']}/posts",
            json={"caption": "B1", "content_type": "static_post", "topics": ["iced-coffee", "café ambience"]},
            headers=auth_headers,
        )
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp_b['id']}/posts",
            json={
                "caption": "B2",
                "content_type": "reel",
                "topics": ["coffee culture", "seasonal drinks", "coffee culture"],
            },
            headers=auth_headers,
        )

    def test_topic_counts_are_correct(self, client, auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        self._setup_multi_competitor_data(client, auth_headers, brand_id)
        response = client.post(
            f"/api/v1/brands/{brand_id}/competitors/analyze-gaps",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()

        tc = {t["topic"]: t for t in data["topic_coverage"]}

        assert tc["coffee culture"]["post_count"] == 2
        assert tc["coffee culture"]["competitor_count"] == 2
        assert set(tc["coffee culture"]["competitors"]) == {"CompA", "CompB"}

        assert tc["seasonal drinks"]["post_count"] == 3
        assert tc["seasonal drinks"]["competitor_count"] == 2

        assert tc["iced coffee"]["post_count"] == 2
        assert tc["iced coffee"]["competitor_count"] == 2

        assert tc["café ambience"]["post_count"] == 1
        assert tc["café ambience"]["competitor_count"] == 1

    def test_topic_normalization(self, client, auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        comp = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "NormComp"},
            headers=auth_headers,
        ).json()
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={"caption": "Norm", "topics": ["Iced Coffee", "iced-coffee", "iced coffee"]},
            headers=auth_headers,
        )
        response = client.post(
            f"/api/v1/brands/{brand_id}/competitors/analyze-gaps",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        topics = [t["topic"] for t in data["topic_coverage"]]
        assert topics.count("iced coffee") == 1
        assert "Iced Coffee" not in topics
        assert "iced-coffee" not in topics

    def test_duplicate_topics_in_one_post_count_once(self, client, auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        comp = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "DupComp"},
            headers=auth_headers,
        ).json()
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={"caption": "Dup", "topics": ["coffee", "coffee", "coffee"]},
            headers=auth_headers,
        )
        response = client.post(
            f"/api/v1/brands/{brand_id}/competitors/analyze-gaps",
            headers=auth_headers,
        )
        data = response.json()
        tc = {t["topic"]: t for t in data["topic_coverage"]}
        assert tc["coffee"]["post_count"] == 1

    def test_priority_rules(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        comp = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "PriComp"},
            headers=auth_headers,
        ).json()
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={"caption": "P1", "topics": ["high_priority_topic"]},
            headers=auth_headers,
        )
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={"caption": "P2", "topics": ["high_priority_topic"]},
            headers=auth_headers,
        )
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={"caption": "P3", "topics": ["medium_priority_topic"]},
            headers=auth_headers,
        )

        response = client.post(
            f"/api/v1/brands/{brand_id}/competitors/analyze-gaps",
            headers=auth_headers,
        )
        data = response.json()
        opps = {o["topic"]: o for o in data["opportunities"]}
        assert opps["high priority topic"]["priority"] == "high"
        assert opps["medium priority topic"]["priority"] == "medium"

    def test_brand_coverage_reduces_priority(self, client, auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        comp = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "BCComp"},
            headers=auth_headers,
        ).json()
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={"caption": "B1", "topics": ["Brand Story"]},
            headers=auth_headers,
        )
        response = client.post(
            f"/api/v1/brands/{brand_id}/competitors/analyze-gaps",
            headers=auth_headers,
        )
        data = response.json()
        brand_story_opps = [o for o in data["opportunities"] if "brand story" in o["topic"].lower()]
        assert len(brand_story_opps) == 0

    def test_no_data_report(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.post(
            f"/api/v1/brands/{brand_id}/competitors/analyze-gaps",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["summary"]["competitors_analyzed"] == 0
        assert data["summary"]["posts_analyzed"] == 0
        assert data["summary"]["unique_topics"] == 0
        assert data["summary"]["opportunities_found"] == 0

    def test_content_mix_reflects_post_types(self, client, auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        self._setup_multi_competitor_data(client, auth_headers, brand_id)
        response = client.post(
            f"/api/v1/brands/{brand_id}/competitors/analyze-gaps",
            headers=auth_headers,
        )
        data = response.json()
        cm = {m["competitor"]: m["content_types"] for m in data["content_mix"]}
        assert cm["CompA"]["carousel"] == 1
        assert cm["CompA"]["reel"] == 1
        assert cm["CompB"]["reel"] == 1
        assert cm["CompB"]["static_post"] == 1

    def test_gap_report_cannot_access_other_user(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        comp = client.post(
            f"/api/v1/brands/{brand_id}/competitors",
            json={"name": "Mine"},
            headers=auth_headers,
        ).json()
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/{comp['id']}/posts",
            json={"caption": "Gap", "topics": ["topic_a"]},
            headers=auth_headers,
        )
        client.post(
            f"/api/v1/brands/{brand_id}/competitors/analyze-gaps",
            headers=auth_headers,
        )
        response = client.post(
            f"/api/v1/brands/{brand_id}/competitors/analyze-gaps",
            headers=second_auth_headers,
        )
        assert response.status_code == 404
