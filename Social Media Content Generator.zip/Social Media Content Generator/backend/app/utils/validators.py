from __future__ import annotations

from app.enums import Platform, Tone
from app.exceptions import UnsupportedPlatformError, UnsupportedToneError


def validate_platform(platform: str) -> Platform:
    try:
        return Platform(platform)
    except ValueError:
        raise UnsupportedPlatformError(platform)


def validate_tone(tone: str) -> Tone:
    try:
        return Tone(tone)
    except ValueError:
        raise UnsupportedToneError(tone)
