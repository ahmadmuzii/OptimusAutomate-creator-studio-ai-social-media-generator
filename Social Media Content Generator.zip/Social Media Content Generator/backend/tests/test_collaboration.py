from __future__ import annotations


class TestWorkspaces:
    """Test workspace CRUD and member management."""

    def test_create_workspace(self, client, auth_headers, registered_user):
        response = client.post("/api/v1/workspaces", json={"name": "My Workspace"}, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "My Workspace"
        assert data["owner_id"] == registered_user["id"]
        assert "id" in data

    def test_list_workspaces(self, client, auth_headers):
        client.post("/api/v1/workspaces", json={"name": "Ws 1"}, headers=auth_headers)
        client.post("/api/v1/workspaces", json={"name": "Ws 2"}, headers=auth_headers)
        response = client.get("/api/v1/workspaces", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 2
        names = [w["name"] for w in data]
        assert "Ws 1" in names
        assert "Ws 2" in names

    def test_get_workspace(self, client, auth_headers):
        created = client.post("/api/v1/workspaces", json={"name": "Get Me"}, headers=auth_headers).json()
        response = client.get(f"/api/v1/workspaces/{created['id']}", headers=auth_headers)
        assert response.status_code == 200
        assert response.json()["name"] == "Get Me"

    def test_update_workspace(self, client, auth_headers):
        created = client.post("/api/v1/workspaces", json={"name": "Old Name"}, headers=auth_headers).json()
        response = client.put(
            f"/api/v1/workspaces/{created['id']}",
            json={"name": "New Name"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert response.json()["name"] == "New Name"

    def test_delete_workspace(self, client, auth_headers):
        created = client.post("/api/v1/workspaces", json={"name": "Delete Me"}, headers=auth_headers).json()
        response = client.delete(f"/api/v1/workspaces/{created['id']}", headers=auth_headers)
        assert response.status_code == 200
        get_resp = client.get(f"/api/v1/workspaces/{created['id']}", headers=auth_headers)
        assert get_resp.status_code == 404

    def test_add_member(self, client, auth_headers, second_user):
        ws = client.post("/api/v1/workspaces", json={"name": "Team Space"}, headers=auth_headers).json()
        response = client.post(
            f"/api/v1/workspaces/{ws['id']}/members",
            json={"user_id": second_user["id"], "role": "editor"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["user_id"] == second_user["id"]
        assert data["role"] == "editor"
        assert data["workspace_id"] == ws["id"]

    def test_update_member_role(self, client, auth_headers, second_user):
        ws = client.post("/api/v1/workspaces", json={"name": "Role Change"}, headers=auth_headers).json()
        member = client.post(
            f"/api/v1/workspaces/{ws['id']}/members",
            json={"user_id": second_user["id"], "role": "editor"},
            headers=auth_headers,
        ).json()
        response = client.put(
            f"/api/v1/workspaces/{ws['id']}/members/{member['id']}",
            json={"role": "viewer"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert response.json()["role"] == "viewer"

    def test_remove_member(self, client, auth_headers, second_user):
        ws = client.post("/api/v1/workspaces", json={"name": "Kick Out"}, headers=auth_headers).json()
        member = client.post(
            f"/api/v1/workspaces/{ws['id']}/members",
            json={"user_id": second_user["id"], "role": "editor"},
            headers=auth_headers,
        ).json()
        response = client.delete(
            f"/api/v1/workspaces/{ws['id']}/members/{member['id']}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        members = client.get(f"/api/v1/workspaces/{ws['id']}", headers=auth_headers).json()["memberships"]
        assert len(members) == 0

    def test_non_owner_cannot_update_or_delete_workspace(self, client, auth_headers, second_auth_headers):
        ws = client.post("/api/v1/workspaces", json={"name": "Only Mine"}, headers=auth_headers).json()

        put_resp = client.put(
            f"/api/v1/workspaces/{ws['id']}",
            json={"name": "Hacked"},
            headers=second_auth_headers,
        )
        assert put_resp.status_code == 404

        del_resp = client.delete(f"/api/v1/workspaces/{ws['id']}", headers=second_auth_headers)
        assert del_resp.status_code == 404


class TestCollaboration:
    """Test campaign collaboration features."""

    def test_create_approval_request(self, client, auth_headers, created_campaign):
        campaign_id = created_campaign["id"]
        response = client.post(
            f"/api/v1/campaigns/{campaign_id}/approval-requests",
            json={"campaign_id": campaign_id},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["campaign_id"] == campaign_id
        assert data["status"] == "pending"

    def test_list_approval_requests(self, client, auth_headers, created_campaign):
        campaign_id = created_campaign["id"]
        client.post(
            f"/api/v1/campaigns/{campaign_id}/approval-requests",
            json={"campaign_id": campaign_id},
            headers=auth_headers,
        )
        response = client.get(
            f"/api/v1/campaigns/{campaign_id}/approval-requests",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["status"] == "pending"

    def test_add_approval_decision(self, client, auth_headers, created_campaign):
        campaign_id = created_campaign["id"]
        req = client.post(
            f"/api/v1/campaigns/{campaign_id}/approval-requests",
            json={"campaign_id": campaign_id},
            headers=auth_headers,
        ).json()
        response = client.post(
            f"/api/v1/campaigns/{campaign_id}/approval-requests/{req['id']}/decisions",
            json={"decision": "approved", "comment": "Looks good"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert response.json()["detail"] == "Decision recorded: approved"

    def test_add_comment(self, client, auth_headers, created_campaign):
        campaign_id = created_campaign["id"]
        post_id = created_campaign["posts"][0]["id"]
        response = client.post(
            f"/api/v1/campaigns/{campaign_id}/comments",
            params={"content": "Great post!", "post_id": post_id},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["content"] == "Great post!"
        assert data["author_name"] == "Registered User"

    def test_list_comments(self, client, auth_headers, created_campaign):
        campaign_id = created_campaign["id"]
        post_id = created_campaign["posts"][0]["id"]
        client.post(
            f"/api/v1/campaigns/{campaign_id}/comments",
            params={"content": "First!", "post_id": post_id},
            headers=auth_headers,
        )
        response = client.get(f"/api/v1/campaigns/{campaign_id}/comments", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["content"] == "First!"

    def test_edit_comment(self, client, auth_headers, created_campaign):
        campaign_id = created_campaign["id"]
        post_id = created_campaign["posts"][0]["id"]
        comment = client.post(
            f"/api/v1/campaigns/{campaign_id}/comments",
            params={"content": "Original", "post_id": post_id},
            headers=auth_headers,
        ).json()
        response = client.put(
            f"/api/v1/campaigns/{campaign_id}/comments/{comment['id']}",
            params={"content": "Updated"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert response.json()["content"] == "Updated"

    def test_delete_comment(self, client, auth_headers, created_campaign):
        campaign_id = created_campaign["id"]
        post_id = created_campaign["posts"][0]["id"]
        comment = client.post(
            f"/api/v1/campaigns/{campaign_id}/comments",
            params={"content": "Delete me", "post_id": post_id},
            headers=auth_headers,
        ).json()
        response = client.delete(
            f"/api/v1/campaigns/{campaign_id}/comments/{comment['id']}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        comments = client.get(f"/api/v1/campaigns/{campaign_id}/comments", headers=auth_headers).json()
        assert len(comments) == 0

    def test_create_post_version(self, client, auth_headers, created_campaign):
        campaign_id = created_campaign["id"]
        post_id = created_campaign["posts"][0]["id"]
        response = client.post(
            f"/api/v1/campaigns/{campaign_id}/versions",
            params={"post_id": post_id, "change_reason": "First draft"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["post_id"] == post_id
        assert data["version_number"] == 1
        assert data["change_reason"] == "First draft"

    def test_list_versions(self, client, auth_headers, created_campaign):
        campaign_id = created_campaign["id"]
        post_id = created_campaign["posts"][0]["id"]
        client.post(
            f"/api/v1/campaigns/{campaign_id}/versions",
            params={"post_id": post_id},
            headers=auth_headers,
        )
        response = client.get(
            f"/api/v1/campaigns/{campaign_id}/versions",
            params={"post_id": post_id},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["version_number"] == 1

    def test_restore_version(self, client, auth_headers, created_campaign):
        campaign_id = created_campaign["id"]
        post_id = created_campaign["posts"][0]["id"]
        version = client.post(
            f"/api/v1/campaigns/{campaign_id}/versions",
            params={"post_id": post_id, "change_reason": "v1"},
            headers=auth_headers,
        ).json()
        response = client.post(
            f"/api/v1/campaigns/{campaign_id}/versions/{version['id']}/restore",
            params={"post_id": post_id},
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert f"version {version['version_number']}" in response.json()["detail"]

    def test_cross_user_access_prevention(self, client, auth_headers, second_auth_headers, created_campaign):
        campaign_id = created_campaign["id"]

        resp = client.get(f"/api/v1/campaigns/{campaign_id}", headers=second_auth_headers)
        assert resp.status_code == 404

        resp = client.post(
            f"/api/v1/campaigns/{campaign_id}/approval-requests",
            json={"campaign_id": campaign_id},
            headers=second_auth_headers,
        )
        assert resp.status_code == 404

        resp = client.post(
            f"/api/v1/campaigns/{campaign_id}/comments",
            params={"content": "sneaky"},
            headers=second_auth_headers,
        )
        assert resp.status_code == 404
