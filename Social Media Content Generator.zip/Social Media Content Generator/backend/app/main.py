from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.api.v1 import router as v1_router
from app.config import settings
from app.core.errors import app_error_handler, generic_error_handler
from app.exceptions import AppError
from app.init_db import init_database
from app.logging_config import setup_logging


def _get_cors_origins() -> list[str]:
    return list(settings.cors_origins)


def create_app() -> FastAPI:
    setup_logging()
    init_database()

    app = FastAPI(
        title=settings.app_name,
        description="AI Campaign Planner \u2014 Generate 7-day social media content plans",
        version=settings.app_version,
        docs_url="/docs" if not settings.is_production else None,
        redoc_url="/redoc" if not settings.is_production else None,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=_get_cors_origins(),
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(v1_router)

    upload_dir = Path(settings.upload_dir)
    upload_dir.mkdir(parents=True, exist_ok=True)
    (upload_dir / "avatar").mkdir(parents=True, exist_ok=True)
    (upload_dir / "logo").mkdir(parents=True, exist_ok=True)
    app.mount(f"/{settings.upload_dir}", StaticFiles(directory=str(upload_dir)), name="uploads")

    app.add_exception_handler(AppError, app_error_handler)
    app.add_exception_handler(Exception, generic_error_handler)

    return app


app = create_app()
