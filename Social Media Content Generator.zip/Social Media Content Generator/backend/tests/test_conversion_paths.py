from __future__ import annotations


class TestConversionPathsAPI:
    """Test Conversion Path CRUD endpoints."""

    BASE = "/api/v1/brands"

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _url(self, brand_id: int, path_id: int | None = None) -> str:
        base = f"{self.BASE}/{brand_id}/conversion-paths"
        return f"{base}/{path_id}" if path_id is not None else base

    def _create_path(self, client, brand_id, payload, headers):
        return client.post(self._url(brand_id), json=payload, headers=headers)

    # ------------------------------------------------------------------
    # Create – different destination types
    # ------------------------------------------------------------------

    def test_create_website_destination(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Website Landing Page",
            "destination_type": "website",
            "destination_value": "https://example.com/landing",
            "primary_action": "visit",
            "cta_keyword": "learn more",
            "campaign_goal": "traffic",
        }
        response = self._create_path(client, brand_id, payload, auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Website Landing Page"
        assert data["destination_type"] == "website"
        assert data["destination_value"] == "https://example.com/landing"
        assert data["primary_action"] == "visit"
        assert data["cta_keyword"] == "learn more"
        assert data["campaign_goal"] == "traffic"
        assert data["is_active"] is True
        assert "id" in data
        assert "created_at" in data

    def test_create_product_page_destination(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Product Page",
            "destination_type": "product_page",
            "destination_value": "https://shop.example.com/item/123",
            "primary_action": "buy",
            "cta_keyword": "shop now",
            "campaign_goal": "conversions",
            "tracking_label": "summer_sale",
            "utm_source": "instagram",
            "utm_medium": "social",
            "utm_campaign": "summer2026",
        }
        response = self._create_path(client, brand_id, payload, auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Product Page"
        assert data["destination_type"] == "product_page"
        assert data["destination_value"] == "https://shop.example.com/item/123"
        assert data["primary_action"] == "buy"
        assert data["cta_keyword"] == "shop now"
        assert data["campaign_goal"] == "conversions"
        assert data["tracking_label"] == "summer_sale"
        assert data["utm_source"] == "instagram"
        assert data["utm_medium"] == "social"
        assert data["utm_campaign"] == "summer2026"

    def test_create_whatsapp_destination(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "WhatsApp Support",
            "destination_type": "whatsapp",
            "destination_value": "https://wa.me/1234567890",
            "primary_action": "chat",
            "cta_keyword": "text us",
            "campaign_goal": "support",
        }
        response = self._create_path(client, brand_id, payload, auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["destination_type"] == "whatsapp"
        assert data["destination_value"] == "https://wa.me/1234567890"
        assert data["primary_action"] == "chat"
        assert data["cta_keyword"] == "text us"

    # ------------------------------------------------------------------
    # Update
    # ------------------------------------------------------------------

    def test_update_conversion_path(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = self._create_path(
            client,
            brand_id,
            {"name": "Old Path", "destination_type": "website", "destination_value": "https://old.example.com"},
            auth_headers,
        ).json()
        update_payload = {
            "name": "Updated Path",
            "destination_value": "https://new.example.com",
            "primary_action": "signup",
        }
        response = client.put(self._url(brand_id, created["id"]), json=update_payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Updated Path"
        assert data["destination_value"] == "https://new.example.com"
        assert data["primary_action"] == "signup"
        assert data["destination_type"] == "website"  # unchanged

    # ------------------------------------------------------------------
    # Delete
    # ------------------------------------------------------------------

    def test_delete_conversion_path(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = self._create_path(
            client,
            brand_id,
            {"name": "Delete Me", "destination_type": "website", "destination_value": "https://del.example.com"},
            auth_headers,
        ).json()
        response = client.delete(self._url(brand_id, created["id"]), headers=auth_headers)
        assert response.status_code == 200
        assert response.json() == {"detail": "Conversion path deleted"}
        # Verify it's gone
        get_resp = client.get(self._url(brand_id), headers=auth_headers)
        assert len(get_resp.json()) == 0

    # ------------------------------------------------------------------
    # List – only current user's paths
    # ------------------------------------------------------------------

    def test_list_conversion_paths(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        self._create_path(
            client,
            brand_id,
            {"name": "Path A", "destination_type": "website", "destination_value": "https://a.example.com"},
            auth_headers,
        )
        self._create_path(
            client,
            brand_id,
            {"name": "Path B", "destination_type": "website", "destination_value": "https://b.example.com"},
            auth_headers,
        )
        response = client.get(self._url(brand_id), headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2
        names = {p["name"] for p in data}
        assert names == {"Path A", "Path B"}

    # ------------------------------------------------------------------
    # Retrieve one
    # ------------------------------------------------------------------

    def test_get_conversion_path(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = self._create_path(
            client,
            brand_id,
            {"name": "Specific Path", "destination_type": "website", "destination_value": "https://get.example.com"},
            auth_headers,
        ).json()
        response = client.get(self._url(brand_id, created["id"]), headers=auth_headers)
        assert response.status_code == 200
        assert response.json()["name"] == "Specific Path"

    # ------------------------------------------------------------------
    # Cross-user access prevention
    # ------------------------------------------------------------------

    def test_cannot_access_other_users_conversion_path(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = self._create_path(
            client,
            brand_id,
            {"name": "Mine", "destination_type": "website", "destination_value": "https://mine.example.com"},
            auth_headers,
        ).json()
        response = client.get(self._url(brand_id, created["id"]), headers=second_auth_headers)
        assert response.status_code == 404

    # ------------------------------------------------------------------
    # Malformed URL rejection
    # ------------------------------------------------------------------

    def test_malformed_url_is_accepted(self, client, auth_headers, created_brand):
        """The current backend does not validate URL format on the
        destination_value field, so malformed URLs are accepted.
        If URL validation is added later this test should be updated."""
        brand_id = created_brand["id"]
        payload = {
            "name": "Bad URL",
            "destination_type": "website",
            "destination_value": "not-a-valid-url",
        }
        response = self._create_path(client, brand_id, payload, auth_headers)
        # Accepts the value without complaint (no URL validation exists)
        assert response.status_code == 200
        assert response.json()["destination_value"] == "not-a-valid-url"
