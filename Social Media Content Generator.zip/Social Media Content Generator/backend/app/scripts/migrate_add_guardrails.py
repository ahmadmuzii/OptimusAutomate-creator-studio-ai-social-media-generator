from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from app.database import Base, engine
from app.models.db_models import BrandGuardrail  # noqa: F401 - ensure model is imported


def run_migration():
    Base.metadata.create_all(bind=engine)
    print("Migration complete. brand_guardrails table created.")


if __name__ == "__main__":
    run_migration()
