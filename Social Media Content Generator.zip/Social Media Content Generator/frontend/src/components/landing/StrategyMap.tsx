import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { cn } from '@/utils/cn'

const days = [
  { day: 1, label: 'Introduce', theme: 'Brand Story', purpose: 'Introduce your brand story, mission, or origin to build connection.', type: 'Carousel or Reel', hook: 'What inspired us to start?', cta: 'Follow to join the journey' },
  { day: 2, label: 'Educate', theme: 'Educational', purpose: 'Share valuable knowledge, tips, or insights related to your niche.', type: 'Reel or Carousel', hook: 'Here is something most people get wrong.', cta: 'Save this for later' },
  { day: 3, label: 'Solve', theme: 'Customer Spotlight', purpose: 'Address a common pain point or feature a customer success story.', type: 'Static Post or Video', hook: 'How we helped our customers solve X.', cta: 'Tag someone who needs this' },
  { day: 4, label: 'Build Trust', theme: 'Behind the Scenes', purpose: 'Show the human side of your brand through authentic content.', type: 'Reel or Story', hook: 'A look behind the curtain.', cta: 'Share your own experience' },
  { day: 5, label: 'Spotlight', theme: 'Product Showcase', purpose: 'Feature a product, service, or offering with compelling context.', type: 'Carousel or Reel', hook: 'What makes this different.', cta: 'Learn more (link in bio)' },
  { day: 6, label: 'Engage', theme: 'Community Engagement', purpose: 'Start a conversation, run a poll, or encourage user participation.', type: 'Static Post or Story', hook: 'We want to hear from you.', cta: 'Comment your answer below' },
  { day: 7, label: 'Convert', theme: 'Conversion', purpose: 'Drive action with a clear offer, trial, or call to conversion.', type: 'Carousel or Video', hook: 'Ready to take the next step?', cta: 'Start your free trial / Shop now' },
]

export function StrategyMap() {
  const [active, setActive] = useState<number | null>(null)
  const reduced = useReducedMotionPreference()

  return (
    <section className="py-20 bg-gray-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            A campaign strategy, not random posts
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            Each day has a purpose. The strategy adapts to your campaign goal and niche.
          </p>
        </div>

        <div className="grid md:grid-cols-7 gap-3 mb-8">
          {days.map((d) => (
            <button
              key={d.day}
              onClick={() => setActive(active === d.day ? null : d.day)}
              className={cn(
                'relative p-4 rounded-xl border-2 text-center transition-all duration-200',
                active === d.day
                  ? 'border-purple-600 bg-purple-50 shadow-md shadow-purple-100'
                  : 'border-gray-100 bg-white hover:border-purple-200 hover:shadow-sm',
              )}
              aria-expanded={active === d.day}
              aria-label={`Day ${d.day}: ${d.label}`}
            >
              <div className={cn(
                'text-xs font-bold rounded-full w-7 h-7 flex items-center justify-center mx-auto mb-2 transition-colors',
                active === d.day ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-500',
              )}>
                {d.day}
              </div>
              <div className={cn(
                'text-sm font-semibold transition-colors',
                active === d.day ? 'text-purple-700' : 'text-gray-900',
              )}>
                {d.label}
              </div>
              <div className="text-[10px] text-gray-400 mt-1">{d.theme}</div>
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {active !== null && active >= 1 && active <= days.length && (
            <motion.div
              key={active}
              initial={reduced ? undefined : { opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={reduced ? undefined : { opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="bg-white rounded-2xl border border-gray-200 p-6 md:p-8 shadow-sm max-w-3xl mx-auto"
            >
              {(() => {
                const day = days[active - 1]
                if (!day) return null
                return (
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <div className="flex items-center gap-2 mb-4">
                        <div className="w-8 h-8 rounded-full bg-purple-600 text-white text-sm font-bold flex items-center justify-center">
                          {day.day}
                        </div>
                        <div>
                          <span className="text-sm font-bold text-purple-700">{day.label}</span>
                          <span className="text-sm text-gray-400 ml-2">&middot; {day.theme}</span>
                        </div>
                      </div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-3">Content Purpose</h4>
                      <p className="text-gray-600 leading-relaxed">{day.purpose}</p>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Post Type</span>
                        <p className="text-sm font-medium text-gray-900 mt-1">{day.type}</p>
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Example Hook</span>
                        <p className="text-sm font-medium text-gray-900 mt-1">{day.hook}</p>
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Recommended CTA</span>
                        <p className="text-sm font-medium text-purple-700 mt-1">{day.cta}</p>
                      </div>
                    </div>
                  </div>
                )
              })()}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  )
}
