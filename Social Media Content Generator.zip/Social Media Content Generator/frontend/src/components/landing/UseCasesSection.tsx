import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Store, User, Building2, Rocket, Users } from 'lucide-react'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { cn } from '@/utils/cn'

const useCases = [
  {
    id: 'small-business',
    icon: Store,
    label: 'Small Businesses',
    headline: 'Maintain a reliable content presence without hiring a full content team.',
    painPoint: 'Running a business leaves little time for social media planning.',
    feature: 'Generate a week of posts from one brand brief in minutes.',
    example: 'A local coffee shop generates a week of Instagram content featuring their seasonal menu, customer stories, and brewing tips.',
  },
  {
    id: 'creators',
    icon: User,
    label: 'Creators',
    headline: 'Turn one idea into a structured week of posts.',
    painPoint: 'Creating fresh content daily leads to burnout.',
    feature: 'Plan an entire week of content from a single concept.',
    example: 'A fitness creator sets a weekly theme and gets 7 platform-ready posts with hooks and CTAs.',
  },
  {
    id: 'agencies',
    icon: Building2,
    label: 'Agencies',
    headline: 'Keep multiple brand profiles and campaigns organized.',
    painPoint: 'Managing content for multiple clients is chaotic without structure.',
    feature: 'Save brand profiles and switch between them instantly.',
    example: 'An agency manages content for 5 clients, each with distinct brand voices and campaign goals.',
  },
  {
    id: 'startups',
    icon: Rocket,
    label: 'Startups',
    headline: 'Build brand presence while focusing on product development.',
    painPoint: 'Marketing teams of one struggle to maintain consistent posting.',
    feature: 'Generate campaigns aligned with product launches and milestones.',
    example: 'A B2B SaaS startup launches a lead-gen campaign tied to their product release.',
  },
  {
    id: 'marketing-teams',
    icon: Users,
    label: 'Marketing Teams',
    headline: 'Scale content production without scaling headcount.',
    painPoint: 'Campaign planning takes days of coordination and iteration.',
    feature: 'Move from strategy to draft content in one session.',
    example: 'A marketing team generates campaign skeletons, reviews, and adjusts before finalizing.',
  },
]

export function UseCasesSection() {
  const [active, setActive] = useState(useCases[0]?.id || 'small-business')
  const reduced = useReducedMotionPreference()

  const current = useCases.find((u) => u.id === active)

  if (!current) return null

  return (
    <section className="py-20 bg-gray-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            Built for different workflows
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            One tool, many ways to use it.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {useCases.map((u) => {
            const Icon = u.icon
            return (
              <button
                key={u.id}
                onClick={() => setActive(u.id)}
                className={cn(
                  'flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium border transition-all duration-200',
                  active === u.id
                    ? 'border-purple-600 bg-purple-50 text-purple-700 shadow-sm'
                    : 'border-gray-200 bg-white text-gray-600 hover:border-purple-300',
                )}
              >
                <Icon className="w-4 h-4" />
                {u.label}
              </button>
            )
          })}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={reduced ? undefined : { opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={reduced ? undefined : { opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="max-w-4xl mx-auto"
          >
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center">
                    <current.icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{current.label}</h3>
                    <p className="text-sm text-gray-500">{current.headline}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="bg-purple-50 rounded-xl p-4 border border-purple-100">
                    <span className="text-[10px] font-semibold text-purple-600 uppercase tracking-wider">The Pain Point</span>
                    <p className="text-sm text-gray-700 mt-1">{current.painPoint}</p>
                  </div>
                  <div className="bg-green-50 rounded-xl p-4 border border-green-100">
                    <span className="text-[10px] font-semibold text-green-600 uppercase tracking-wider">How Creator Studio Helps</span>
                    <p className="text-sm text-gray-700 mt-1">{current.feature}</p>
                  </div>
                </div>
              </div>
              <div className="bg-gradient-to-br from-purple-50 to-purple-100/30 rounded-2xl border border-purple-100 p-6">
                <span className="text-[10px] font-semibold text-purple-600 uppercase tracking-wider">Example Scenario</span>
                <p className="text-sm text-gray-700 mt-3 leading-relaxed">
                  {current.example}
                </p>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  )
}
