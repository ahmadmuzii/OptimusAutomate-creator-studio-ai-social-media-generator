import { useState } from 'react'
import { motion } from 'framer-motion'
import { X } from 'lucide-react'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { cn } from '@/utils/cn'

const genericCaption = 'Check out our latest updates and follow us for more!'

const brandAwareCaption = 'Our Autumn Harvest Blend is here. Tasting notes of dark chocolate, dried cherry, and cedar. This limited release is available for four weeks. Grab a bag at Urban Brew Studio and taste the season.'

export function BeforeAfterSection() {
  const [mode, setMode] = useState<'generic' | 'brand'>('brand')
  const reduced = useReducedMotionPreference()

  return (
    <section className="py-20 bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            Generic AI vs. brand-aware campaigns
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            The difference is in the details that make your brand recognizable.
          </p>
        </div>

        <div className="flex justify-center gap-3 mb-8">
          <button
            onClick={() => setMode('generic')}
            className={cn(
              'px-5 py-2.5 rounded-xl text-sm font-semibold border transition-all duration-200',
              mode === 'generic'
                ? 'border-gray-300 bg-gray-100 text-gray-700'
                : 'border-gray-200 bg-white text-gray-500 hover:border-gray-300',
            )}
          >
            Generic AI Output
          </button>
          <button
            onClick={() => setMode('brand')}
            className={cn(
              'px-5 py-2.5 rounded-xl text-sm font-semibold border transition-all duration-200',
              mode === 'brand'
                ? 'border-purple-600 bg-purple-50 text-purple-700 shadow-sm'
                : 'border-gray-200 bg-white text-gray-500 hover:border-purple-300',
            )}
          >
            Brand-Aware Campaign
          </button>
        </div>

        <motion.div
          key={mode}
          initial={reduced ? undefined : { opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="max-w-2xl mx-auto"
        >
          {mode === 'generic' ? (
            <div className="bg-gray-50 rounded-2xl border border-gray-200 p-6 md:p-8">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-gray-200 flex items-center justify-center">
                  <X className="w-4 h-4 text-gray-400" />
                </div>
                <span className="text-sm font-semibold text-gray-500">Generic AI Caption</span>
              </div>
              <p className="text-gray-500 italic leading-relaxed">
                &ldquo;{genericCaption}&rdquo;
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {['#follow', '#update', '#newpost', '#content'].map((tag) => (
                  <span key={tag} className="text-xs px-2.5 py-1 rounded-full bg-gray-200 text-gray-400">{tag}</span>
                ))}
              </div>
              <div className="mt-3 text-xs text-gray-400">
                CTA: Follow us for more
              </div>
            </div>
          ) : (
            <div className="bg-gradient-to-br from-purple-50 to-purple-100/30 rounded-2xl border border-purple-100 p-6 md:p-8">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center">
                  <span className="text-white text-xs font-bold">B</span>
                </div>
                <span className="text-sm font-semibold text-purple-700">Urban Brew Studio</span>
                <span className="text-xs text-purple-400 ml-auto">Brand-aware output</span>
              </div>
              <p className="text-gray-700 leading-relaxed">
                &ldquo;{brandAwareCaption}&rdquo;
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {['#SeasonalCoffee', '#UrbanBrewStudio', '#LimitedEdition', '#ArtisanCoffee', '#AutumnVibes'].map((tag) => (
                  <span key={tag} className="text-xs px-2.5 py-1 rounded-full bg-purple-100 text-purple-600">{tag}</span>
                ))}
              </div>
              <div className="mt-3 text-xs text-purple-700 font-medium">
                CTA: Grab a bag before it is gone.
              </div>
              <div className="mt-3 flex flex-wrap gap-4 text-[10px] text-gray-400">
                <span>Goal: Sales</span>
                <span>Platform: Instagram</span>
                <span>Tone: Professional & Casual</span>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </section>
  )
}
