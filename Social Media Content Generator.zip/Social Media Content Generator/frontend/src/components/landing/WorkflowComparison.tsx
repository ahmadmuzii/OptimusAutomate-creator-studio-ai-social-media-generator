import { Check, X } from 'lucide-react'
import { cn } from '@/utils/cn'

interface ComparisonRow {
  feature: string
  basicCaption: boolean
  generalChat: boolean
  creatorStudio: boolean
}

const rows: ComparisonRow[] = [
  { feature: 'Brand profiles', basicCaption: false, generalChat: false, creatorStudio: true },
  { feature: 'Multi-day campaigns', basicCaption: false, generalChat: false, creatorStudio: true },
  { feature: 'Platform formatting', basicCaption: false, generalChat: false, creatorStudio: true },
  { feature: 'Calendar view', basicCaption: false, generalChat: false, creatorStudio: true },
  { feature: 'Saved history', basicCaption: false, generalChat: false, creatorStudio: true },
  { feature: 'Caption editing', basicCaption: false, generalChat: true, creatorStudio: true },
  { feature: 'Hashtag generation', basicCaption: true, generalChat: false, creatorStudio: true },
  { feature: 'Campaign organization', basicCaption: false, generalChat: false, creatorStudio: true },
]

export function WorkflowComparison() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            How Creator Studio compares
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            Different tools for different workflows.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-4 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Feature</th>
                <th className="text-center py-4 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Basic Caption Generator</th>
                <th className="text-center py-4 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">General AI Chat</th>
                <th className="text-center py-4 px-4 text-xs font-semibold text-purple-700 uppercase tracking-wider bg-purple-50/50 rounded-t-xl">Creator Studio</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr key={row.feature} className={cn('border-b border-gray-50', i % 2 === 0 && 'bg-gray-50/30')}>
                  <td className="py-3.5 px-4 text-sm font-medium text-gray-900">{row.feature}</td>
                  <td className="text-center py-3.5 px-4">
                    {row.basicCaption ? <Check className="w-4 h-4 text-green-500 mx-auto" /> : <X className="w-4 h-4 text-gray-300 mx-auto" />}
                  </td>
                  <td className="text-center py-3.5 px-4">
                    {row.generalChat ? <Check className="w-4 h-4 text-green-500 mx-auto" /> : <X className="w-4 h-4 text-gray-300 mx-auto" />}
                  </td>
                  <td className="text-center py-3.5 px-4 bg-purple-50/50">
                    <Check className="w-4 h-4 text-purple-600 mx-auto" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  )
}
