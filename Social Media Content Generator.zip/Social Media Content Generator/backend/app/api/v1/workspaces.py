from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.api.deps_features import require_feature
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.db_models import User, Workspace, WorkspaceMembership
from app.models.workspace_schemas import (
    AddMemberRequest,
    UpdateMemberRoleRequest,
    WorkspaceCreate,
    WorkspaceMembershipResponse,
    WorkspaceResponse,
    WorkspaceUpdate,
)

router = APIRouter(
    prefix="/workspaces",
    tags=["Workspaces"],
    dependencies=[require_feature("collaboration")],
)


def _membership_to_response(m: WorkspaceMembership) -> WorkspaceMembershipResponse:
    return WorkspaceMembershipResponse(
        id=m.id,
        user_id=m.user_id,
        workspace_id=m.workspace_id,
        role=m.role,
        user_email=m.user.email if m.user else None,
        created_at=m.created_at,
    )


def _workspace_to_response(w: Workspace) -> WorkspaceResponse:
    return WorkspaceResponse(
        id=w.id,
        name=w.name,
        owner_id=w.owner_id,
        memberships=[_membership_to_response(m) for m in w.memberships] if w.memberships else [],
        created_at=w.created_at,
    )


@router.get("", response_model=list[WorkspaceResponse])
def list_workspaces(
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    owned = db.query(Workspace).filter(Workspace.owner_id == current_user.id).all()
    membership_ids = (
        db.query(WorkspaceMembership.workspace_id).filter(WorkspaceMembership.user_id == current_user.id).subquery()
    )
    member_of = (
        db.query(Workspace).filter(Workspace.id.in_(membership_ids), Workspace.owner_id != current_user.id).all()
    )

    seen = set()
    result = []
    for w in owned + member_of:
        if w.id not in seen:
            seen.add(w.id)
            result.append(_workspace_to_response(w))
    return result


@router.post("", response_model=WorkspaceResponse)
def create_workspace(
    request: WorkspaceCreate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    workspace = Workspace(name=request.name, owner_id=current_user.id)
    db.add(workspace)
    db.commit()
    db.refresh(workspace)
    return _workspace_to_response(workspace)


@router.get("/{workspace_id}", response_model=WorkspaceResponse)
def get_workspace(
    workspace_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    workspace = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not workspace:
        raise NotFoundError("Workspace not found")
    is_owner = workspace.owner_id == current_user.id
    is_member = (
        db.query(WorkspaceMembership)
        .filter(
            WorkspaceMembership.workspace_id == workspace_id,
            WorkspaceMembership.user_id == current_user.id,
        )
        .first()
        is not None
    )
    if not is_owner and not is_member:
        raise NotFoundError("Workspace not found")
    return _workspace_to_response(workspace)


@router.put("/{workspace_id}", response_model=WorkspaceResponse)
def update_workspace(
    workspace_id: int,
    request: WorkspaceUpdate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    workspace = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not workspace or workspace.owner_id != current_user.id:
        raise NotFoundError("Workspace not found")
    if request.name is not None:
        workspace.name = request.name
    db.commit()
    db.refresh(workspace)
    return _workspace_to_response(workspace)


@router.delete("/{workspace_id}")
def delete_workspace(
    workspace_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    workspace = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not workspace or workspace.owner_id != current_user.id:
        raise NotFoundError("Workspace not found")
    db.delete(workspace)
    db.commit()
    return {"detail": "Workspace deleted"}


@router.post("/{workspace_id}/members", response_model=WorkspaceMembershipResponse)
def add_member(
    workspace_id: int,
    request: AddMemberRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    workspace = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not workspace or workspace.owner_id != current_user.id:
        raise NotFoundError("Workspace not found")

    existing = (
        db.query(WorkspaceMembership)
        .filter(
            WorkspaceMembership.workspace_id == workspace_id,
            WorkspaceMembership.user_id == request.user_id,
        )
        .first()
    )
    if existing:
        raise NotFoundError("User is already a member")

    member_user = db.query(User).filter(User.id == request.user_id).first()
    if not member_user:
        raise NotFoundError("User not found")

    membership = WorkspaceMembership(
        workspace_id=workspace_id,
        user_id=request.user_id,
        role=request.role,
    )
    db.add(membership)
    db.commit()
    db.refresh(membership)
    return _membership_to_response(membership)


@router.put("/{workspace_id}/members/{membership_id}", response_model=WorkspaceMembershipResponse)
def update_member_role(
    workspace_id: int,
    membership_id: int,
    request: UpdateMemberRoleRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    workspace = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not workspace or workspace.owner_id != current_user.id:
        raise NotFoundError("Workspace not found")

    membership = (
        db.query(WorkspaceMembership)
        .filter(
            WorkspaceMembership.id == membership_id,
            WorkspaceMembership.workspace_id == workspace_id,
        )
        .first()
    )
    if not membership:
        raise NotFoundError("Membership not found")

    membership.role = request.role
    db.commit()
    db.refresh(membership)
    return _membership_to_response(membership)


@router.delete("/{workspace_id}/members/{membership_id}")
def remove_member(
    workspace_id: int,
    membership_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    workspace = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not workspace or workspace.owner_id != current_user.id:
        raise NotFoundError("Workspace not found")

    membership = (
        db.query(WorkspaceMembership)
        .filter(
            WorkspaceMembership.id == membership_id,
            WorkspaceMembership.workspace_id == workspace_id,
        )
        .first()
    )
    if not membership:
        raise NotFoundError("Membership not found")

    db.delete(membership)
    db.commit()
    return {"detail": "Member removed"}
