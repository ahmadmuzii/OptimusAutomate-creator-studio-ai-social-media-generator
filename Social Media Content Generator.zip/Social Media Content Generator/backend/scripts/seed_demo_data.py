"""
Seed the database with fictional demo data for development and testing.

Usage:
    python -m scripts.seed_demo_data          # seed if empty
    python -m scripts.seed_demo_data --force   # drop and reseed

This creates:
  - Demo user:  demo@creatorstudio.local / Demo1234!
  - Brand:      Brewline Coffee Co.
  - 7-day campaign (Instagram, professional tone)
  - 7 campaign posts
  - Audience persona, conversion path, source facts
  - Strategy template, content pack, experiment
  - Performance records with insights
  - Guardrails, regional settings, competitor
"""

from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone

from passlib.context import CryptContext

from app.database import Base, SessionLocal, engine
from app.models.db_models import (
    AudiencePersona,
    BrandGuardrail,
    BrandProfile,
    BrandRegionalSettings,
    Campaign,
    CampaignExperiment,
    CampaignPost,
    CompetitorProfile,
    ConversionPath,
    ExperimentVariant,
    PerformanceInsight,
    PostPerformanceRecord,
    SourceDocument,
    SourceFact,
    User,
)
from app.models.pack_db import ContentPackTemplate
from app.models.strategy_db import StrategyTemplate

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

DEMO_EMAIL = "demo@creatorstudio.local"
DEMO_PASSWORD = "Demo1234!"
DEMO_NAME = "Alex Rivera"

UTC = timezone.utc


def seed_database(force: bool = False) -> None:
    session = SessionLocal()

    if force:
        session.close()
        Base.metadata.drop_all(bind=engine)
        Base.metadata.create_all(bind=engine)
        print("Database recreated (all tables dropped and created).")
        session = SessionLocal()
    else:
        existing = session.query(User).filter(User.email == DEMO_EMAIL).first()
        if existing:
            print(f"Demo user '{DEMO_EMAIL}' already exists. Use --force to reseed.")
            session.close()
            return

    try:
        user = User(
            email=DEMO_EMAIL,
            password_hash=pwd_context.hash(DEMO_PASSWORD),
            name=DEMO_NAME,
            brand_name="Brewline Coffee Co.",
            niche="Specialty Coffee & Roasting",
            bio="Crafting exceptional single-origin and blend coffees for the modern home barista.",
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )
        session.add(user)
        session.flush()

        brand = BrandProfile(
            user_id=user.id,
            name="Brewline Coffee Co.",
            description="Premium direct-to-consumer coffee roastery offering single-origin beans, "
            "subscription plans, and brewing equipment.",
            niche="Specialty Coffee & Roasting",
            target_audience="Home coffee enthusiasts aged 25-45 who value quality, sustainability, and craft.",
            website="https://brewlinecoffee.example.com",
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )
        session.add(brand)
        session.flush()

        guardrails = BrandGuardrail(
            brand_id=brand.id,
            required_phrases=["Brewline", "craft", "single-origin"],
            forbidden_words=["cheap", "instant", "mass-produced"],
            competitors_never_mention=["Starbucks", "Folgers", "Nescafe"],
            preferred_capitalizations=["Brewline", "Pour-Over", "Cold Brew"],
            product_names=["Signature Blend", "Ethiopia Yirgacheffe", "Morning Ritual"],
            service_names=["Bean Subscription", "Brew Bar Workshop"],
            emoji_allowance="moderate",
            profanity_level="none",
            formality_level="casual-professional",
            max_hashtag_count=8,
            min_hashtag_count=2,
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )
        session.add(guardrails)

        persona = AudiencePersona(
            brand_id=brand.id,
            name="Craig the Connoisseur",
            description="A coffee enthusiast who researches origins, roast profiles, and brewing methods.",
            age_range="28-40",
            location_market="United States (urban)",
            main_problem="Finding consistently excellent beans that match his taste preferences.",
            desired_outcome="A trusted subscription that delivers exciting new coffees monthly.",
            objections="Price per bag seems higher than grocery store options.",
            preferred_tone="informative",
            preferred_platform="instagram",
            buying_stage="consideration",
            content_interests=["pour-over guides", "origin stories", "tasting notes"],
            common_questions=["Where is this sourced?", "What flavor notes?", "How should I brew it?"],
            main_motivation="Discovering unique flavor profiles.",
            cta_preference="Learn More",
            is_primary=True,
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )
        session.add(persona)

        conv_path = ConversionPath(
            brand_id=brand.id,
            name="Subscription Sign-Up",
            destination_type="website",
            destination_value="https://brewlinecoffee.example.com/subscribe",
            primary_action="Subscribe",
            cta_keyword="join the brew club",
            campaign_goal="grow_subscribers",
            tracking_label="sub_landing",
            utm_source="instagram",
            utm_medium="social",
            utm_campaign="subscription_promo",
            is_active=True,
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )
        session.add(conv_path)

        campaign = Campaign(
            user_id=user.id,
            brand_profile_id=brand.id,
            name="Summer Mornings Campaign",
            platform="Instagram",
            tone="professional",
            campaign_goal="brand_awareness",
            status="active",
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
            persona_mode="single",
        )
        session.add(campaign)
        session.flush()

        posts_data = [
            {
                "day": 1,
                "content_theme": "Brand Story",
                "post_idea": "Meet the roaster behind Brewline",
                "content_type": "Carousel",
                "suggested_time": "08:00",
                "platform": "Instagram",
                "caption": "Every cup starts with a story. Ours begins at 5 AM in our roastery, "
                "where single-origin beans from Ethiopia meet exacting craft.",
                "call_to_action": "Swipe to meet the team",
                "status": "published",
                "hashtags": ["BrewlineCoffee", "SpecialtyCoffee", "CoffeeRoasters", "SingleOrigin", "CraftCoffee"],
            },
            {
                "day": 2,
                "content_theme": "Product Highlight",
                "post_idea": "Introducing our Ethiopia Yirgacheffe",
                "content_type": "Static Post",
                "suggested_time": "10:00",
                "platform": "Instagram",
                "caption": "Notes of blueberry, jasmine, and dark chocolate -- our Ethiopia Yirgacheffe "
                "is back by popular demand.",
                "call_to_action": "Shop the roast",
                "status": "published",
                "hashtags": ["EthiopiaYirgacheffe", "SingleOrigin", "CoffeeLovers", "BrewlineCoffee"],
            },
            {
                "day": 3,
                "content_theme": "Educational",
                "post_idea": "Pour-over technique guide",
                "content_type": "Video",
                "suggested_time": "11:00",
                "platform": "Instagram",
                "caption": "Master the pour-over in three minutes with our head roaster.",
                "call_to_action": "Watch the tutorial",
                "status": "published",
                "hashtags": ["PourOver", "CoffeeTutorial", "HomeBarista", "BrewlineCoffee"],
            },
            {
                "day": 4,
                "content_theme": "Testimonial",
                "post_idea": "Customer spotlight",
                "content_type": "Static Post",
                "suggested_time": "12:00",
                "platform": "Instagram",
                "caption": '"Brewline transformed my morning routine." -- Sarah, subscriber since 2025.',
                "call_to_action": "Start your subscription",
                "status": "published",
                "hashtags": ["CustomerLove", "CoffeeSubscription", "BrewlineCoffee"],
            },
            {
                "day": 5,
                "content_theme": "Behind the Scenes",
                "post_idea": "Roasting day at Brewline",
                "content_type": "Video",
                "suggested_time": "14:00",
                "platform": "Instagram",
                "caption": "Behind the roaster door: Watch how our Signature Blend comes to life.",
                "call_to_action": "See the process",
                "status": "published",
                "hashtags": ["RoastingDay", "BehindTheScenes", "CoffeeRoasting", "BrewlineCoffee"],
            },
            {
                "day": 6,
                "content_theme": "Seasonal Promotion",
                "post_idea": "Summer blend announcement",
                "content_type": "Carousel",
                "suggested_time": "09:00",
                "platform": "Instagram",
                "caption": "Introducing our Summer Solstice Blend -- bright, fruity, and made for iced coffee.",
                "call_to_action": "Order now",
                "status": "published",
                "hashtags": ["SummerBlend", "LimitedEdition", "IcedCoffee", "BrewlineCoffee"],
            },
            {
                "day": 7,
                "content_theme": "Community",
                "post_idea": "Tag us in your brew",
                "content_type": "Static Post",
                "suggested_time": "10:00",
                "platform": "Instagram",
                "caption": "Tag @BrewlineCoffee in your morning cup for a chance to be featured.",
                "call_to_action": "Tag us today",
                "status": "draft",
                "hashtags": ["BrewOfTheDay", "CoffeeCommunity", "BrewlineCoffee"],
            },
        ]

        for p in posts_data:
            session.add(
                CampaignPost(
                    campaign_id=campaign.id,
                    day=p["day"],
                    content_theme=p["content_theme"],
                    post_idea=p["post_idea"],
                    content_type=p["content_type"],
                    suggested_time=p["suggested_time"],
                    platform=p["platform"],
                    caption=p["caption"],
                    call_to_action=p["call_to_action"],
                    hashtags=p["hashtags"],
                    status=p["status"],
                    created_at=datetime.now(UTC),
                    updated_at=datetime.now(UTC),
                )
            )

        src = SourceDocument(
            user_id=user.id,
            brand_id=brand.id,
            source_type="url",
            original_url="https://brewlinecoffee.example.com/about",
            title="About Brewline Coffee",
            extracted_text="Brewline Coffee was founded in 2020 with a mission to bring "
            "exceptional single-origin coffee to home brewers.",
            created_at=datetime.now(UTC),
        )
        session.add(src)
        session.flush()

        for cat, label, val in [
            ("brand_origin", "Founded", "2020"),
            ("sourcing", "Origin Countries", "Ethiopia, Colombia, Guatemala"),
            ("product", "Signature Product", "Ethiopia Yirgacheffe Light Roast"),
        ]:
            session.add(
                SourceFact(
                    source_document_id=src.id,
                    category=cat,
                    label=label,
                    value=val,
                    approved_by_user=True,
                    created_at=datetime.now(UTC),
                )
            )

        session.add(
            StrategyTemplate(
                brand_id=brand.id,
                name="Awareness Builder",
                description="A 7-day strategy to build brand awareness through storytelling and education.",
                funnel_stage="awareness",
                campaign_goal="brand_awareness",
                recommended_ctas=["Learn More", "Swipe Up", "Follow Us"],
                content_mix={"educational": 3, "storytelling": 2, "promotional": 1, "community": 1},
                post_frequency="daily",
                platform_focus="instagram",
                is_default=True,
                created_at=datetime.now(UTC),
                updated_at=datetime.now(UTC),
            )
        )

        session.add(
            ContentPackTemplate(
                brand_id=brand.id,
                name="Summer Collection",
                description="Pre-built content pack for summer-themed coffee campaigns.",
                pack_data={
                    "themes": ["Refreshing", "Bright", "Warm Weather"],
                    "cta_variations": ["Cool down with", "Summer sip ready"],
                    "hashtag_suggestions": ["SummerCoffee", "IcedLatte", "ColdBrewSeason"],
                },
                is_default=True,
                created_at=datetime.now(UTC),
                updated_at=datetime.now(UTC),
            )
        )

        exp = CampaignExperiment(
            brand_id=brand.id,
            campaign_id=campaign.id,
            name="Hook Style Test",
            variable_tested="hook_style",
            success_metric="engagement",
            status="running",
            created_at=datetime.now(UTC),
        )
        session.add(exp)
        session.flush()

        for v in [
            {
                "label": "A",
                "variable_value": "question",
                "content_value": "What if your morning coffee could change lives?",
                "status": "active",
                "impressions": 150,
                "clicks": 12,
                "engagement": 45,
                "conversions": 3,
            },
            {
                "label": "B",
                "variable_value": "stat",
                "content_value": "80% of coffee drinkers prefer single-origin.",
                "status": "active",
                "impressions": 200,
                "clicks": 18,
                "engagement": 62,
                "conversions": 7,
            },
            {
                "label": "C",
                "variable_value": "story",
                "content_value": "From a small farm in Ethiopia to your cup.",
                "status": "active",
                "impressions": 175,
                "clicks": 15,
                "engagement": 55,
                "conversions": 5,
            },
        ]:
            session.add(ExperimentVariant(experiment_id=exp.id, **v))

        for i in range(5):
            session.add(
                PostPerformanceRecord(
                    user_id=user.id,
                    brand_id=brand.id,
                    platform="Instagram",
                    content_type="Carousel" if i % 2 == 0 else "Static Post",
                    publication_date=datetime.now(UTC) - timedelta(days=30 - i * 5),
                    impressions=500 + i * 100,
                    reach=400 + i * 80,
                    likes=30 + i * 5,
                    comments=5 + i * 2,
                    saves=10 + i * 3,
                    shares=3 + i,
                    link_clicks=8 + i * 2,
                    created_at=datetime.now(UTC),
                )
            )

        session.add(
            PerformanceInsight(
                user_id=user.id,
                brand_id=brand.id,
                pattern_type="content_type",
                platform="Instagram",
                content_type="Carousel",
                finding="Carousel posts outperform static posts by 40% in engagement.",
                supporting_metric="Avg engagement: Carousel 85 vs Static 60",
                sample_size=20,
                date_range_start=datetime.now(UTC) - timedelta(days=30),
                date_range_end=datetime.now(UTC),
                confidence="high",
                is_accepted=True,
                affect_future_generation=True,
                created_at=datetime.now(UTC),
            )
        )

        session.add(
            BrandRegionalSettings(
                brand_id=brand.id,
                default_language="en",
                supported_languages=["en", "es"],
                support_roman_urdu=False,
                support_bilingual_posts=True,
                support_rtl_layout=False,
                created_at=datetime.now(UTC),
                updated_at=datetime.now(UTC),
            )
        )

        session.add(
            CompetitorProfile(
                brand_id=brand.id,
                name="Artisan Bean Co.",
                platform="Instagram",
                public_handle="@artisanbeanco",
                website="https://artisanbeanco.example.com",
                notes="Competes on sustainability messaging.",
                created_at=datetime.now(UTC),
            )
        )

        session.commit()
        print("Demo data seeded successfully.")
        print(f"  User:     {DEMO_EMAIL}")
        print(f"  Password: {DEMO_PASSWORD}")
        print("  Brand:    Brewline Coffee Co.")

    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Seed demo data for development.")
    parser.add_argument("--force", action="store_true", help="Drop and recreate all tables before seeding.")
    args = parser.parse_args()

    seed_database(force=args.force)
