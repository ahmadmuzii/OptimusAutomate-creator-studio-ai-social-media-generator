import { useMemo } from 'react'
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
} from 'recharts'
import type { TopicCoverageItem } from '@/types/competitor'

interface Props {
  data: TopicCoverageItem[]
}

function CustomTooltip({ active, payload }: { active?: boolean; payload?: Array<{ payload: TopicCoverageItem }> }) {
  if (!active || !payload?.length) return null
  const item = payload[0]!.payload as TopicCoverageItem
  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-lg px-4 py-3 text-sm max-w-xs">
      <p className="font-semibold text-gray-900 mb-1 capitalize">{item.topic}</p>
      <p className="text-gray-600">{item.post_count} competitor post{item.post_count !== 1 ? 's' : ''}</p>
      <p className="text-gray-500 mt-1 text-xs">Covered by:</p>
      <ul className="text-gray-600 text-xs list-disc list-inside">
        {item.competitors.map(c => <li key={c}>{c}</li>)}
      </ul>
    </div>
  )
}

const PURPLE_GRADIENT = '#7c3aed'

export function TopicCoverageChart({ data }: Props) {
  const sorted = useMemo(() => {
    return [...data].sort((a, b) => b.post_count - a.post_count).slice(0, 10)
  }, [data])

  if (sorted.length === 0) return null

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <h3 className="text-sm font-semibold text-gray-900 mb-4">Most Covered Competitor Topics</h3>
      <ResponsiveContainer width="100%" height={Math.max(200, sorted.length * 40)}>
        <BarChart data={sorted} layout="vertical" margin={{ left: 10, right: 30, top: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" horizontal={false} />
          <XAxis type="number" tick={{ fontSize: 12, fill: '#9ca3af' }} />
          <YAxis
            type="category"
            dataKey="topic"
            tick={{ fontSize: 12, fill: '#6b7280' }}
            width={140}
            tickFormatter={(v: string) => v.length > 20 ? v.slice(0, 20) + '...' : v}
          />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: '#f5f3ff' }} />
          <Bar dataKey="post_count" radius={[0, 4, 4, 0]} maxBarSize={20}>
            {sorted.map((_, i) => (
              <Cell key={i} fill={PURPLE_GRADIENT} fillOpacity={0.7 + 0.3 * (1 - i / sorted.length)} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
