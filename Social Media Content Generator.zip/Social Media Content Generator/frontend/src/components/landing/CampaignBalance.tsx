import { motion } from 'framer-motion'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'

const categories = [
  { label: 'Educational', count: 2, color: 'bg-purple-600', days: 'Days 2, 4' },
  { label: 'Storytelling', count: 2, color: 'bg-violet-500', days: 'Days 1, 5' },
  { label: 'Promotional', count: 1, color: 'bg-fuchsia-500', days: 'Day 5' },
  { label: 'Community', count: 1, color: 'bg-indigo-500', days: 'Day 6' },
  { label: 'Conversion', count: 1, color: 'bg-purple-800', days: 'Day 7' },
]

const total = categories.reduce((s, c) => s + c.count, 0)

export function CampaignBalance() {
  const reduced = useReducedMotionPreference()

  return (
    <section className="py-20 bg-gray-50/50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            Campaign Balance
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            A well-rounded campaign mixes education, storytelling, promotion, community, and conversion.
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-6 md:p-8 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-gray-900">Content Distribution</h3>
            <span className="text-xs text-gray-400">{total} posts &middot; 7-day campaign</span>
          </div>

          <div className="space-y-4">
            {categories.map((cat, i) => {
              const pct = (cat.count / total) * 100
              return (
                <motion.div
                  key={cat.label}
                  initial={reduced ? undefined : { opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.25, delay: i * 0.05 }}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <div className={`w-2.5 h-2.5 rounded-full ${cat.color}`} />
                      <span className="text-sm font-medium text-gray-900">{cat.label}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-gray-400">{cat.days}</span>
                      <span className="text-sm font-semibold text-gray-700">{cat.count} post{cat.count > 1 ? 's' : ''}</span>
                    </div>
                  </div>
                  <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
                    <motion.div
                      initial={reduced ? undefined : { width: 0 }}
                      whileInView={{ width: `${pct}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: i * 0.08, ease: 'easeOut' }}
                      className={`h-full rounded-full ${cat.color}`}
                    />
                  </div>
                </motion.div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
