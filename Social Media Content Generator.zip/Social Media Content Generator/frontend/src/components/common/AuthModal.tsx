import { useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { Sparkles, X } from 'lucide-react'
import { ROUTES } from '@/routes/paths'

interface AuthModalProps {
  isOpen: boolean
  onClose: () => void
  redirectTo?: string
}

function isValidRedirect(path: string): boolean {
  if (!path.startsWith('/')) return false
  if (path.startsWith('//')) return false
  try {
    const url = new URL(path, window.location.origin)
    return url.origin === window.location.origin
  } catch {
    return false
  }
}

export function AuthModal({ isOpen, onClose, redirectTo }: AuthModalProps) {
  const navigate = useNavigate()
  const modalRef = useRef<HTMLDivElement>(null)
  const previousFocusRef = useRef<HTMLElement | null>(null)

  const target = redirectTo && isValidRedirect(redirectTo) ? redirectTo : ROUTES.dashboardHome

  useEffect(() => {
    if (isOpen) {
      previousFocusRef.current = document.activeElement as HTMLElement
      setTimeout(() => modalRef.current?.focus(), 50)
    }
  }, [isOpen])

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose()
        return
      }
    if (e.key === 'Tab' && modalRef.current) {
          const focusable = modalRef.current.querySelectorAll<HTMLElement>(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
          )
          if (focusable.length === 0) return
          const first = focusable[0]!
          const last = focusable[focusable.length - 1]!
          if (e.shiftKey) {
            if (document.activeElement === first) {
              e.preventDefault()
              last.focus()
            }
          } else {
            if (document.activeElement === last) {
              e.preventDefault()
              first.focus()
            }
          }
        }
    },
    [onClose],
  )

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) onClose()
  }

  const handleOverlayKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') onClose()
  }

  if (!isOpen) return null

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50"
      onClick={handleOverlayClick}
      onKeyDown={handleOverlayKeyDown}
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
      aria-describedby="auth-modal-desc"
    >
      <div
        ref={modalRef}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
        className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl outline-none"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <h2 id="auth-modal-title" className="text-lg font-bold text-gray-900">
              Sign in to use this feature
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p id="auth-modal-desc" className="text-sm text-gray-500 mb-6 leading-relaxed">
          Create an account or sign in to generate campaigns, save brands, analyze performance, and
          access the full Creator Studio workspace.
        </p>

        <div className="space-y-3">
          <button
            onClick={() => {
              navigate(`/login?redirect=${encodeURIComponent(target)}`)
              onClose()
            }}
            className="w-full bg-gradient-to-r from-purple-600 to-purple-800 text-white font-semibold py-2.5 rounded-xl shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 hover:scale-[1.01] active:scale-[0.99] transition-all duration-200 text-sm"
          >
            Sign In
          </button>
          <button
            onClick={() => {
              navigate(`/signup?redirect=${encodeURIComponent(target)}`)
              onClose()
            }}
            className="w-full bg-white text-purple-700 font-semibold py-2.5 rounded-xl border border-purple-200 hover:bg-purple-50 hover:border-purple-300 transition-all duration-200 text-sm"
          >
            Create Free Account
          </button>
          <button
            onClick={onClose}
            className="w-full text-gray-500 font-medium py-2 rounded-xl hover:bg-gray-50 transition-colors text-sm"
          >
            Continue Exploring
          </button>
        </div>
      </div>
    </div>
  )
}
