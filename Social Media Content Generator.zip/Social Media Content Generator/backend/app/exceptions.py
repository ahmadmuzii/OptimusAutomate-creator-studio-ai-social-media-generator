from __future__ import annotations


class AppError(Exception):
    status_code: int = 500
    detail: str = "Internal server error"
    headers: dict[str, str] | None = None

    def __init__(
        self,
        detail: str | None = None,
        status_code: int | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        if detail:
            self.detail = detail
        if status_code is not None:
            self.status_code = status_code
        if headers is not None:
            self.headers = headers
        super().__init__(self.detail)


class AuthenticationError(AppError):
    status_code: int = 401
    detail: str = "Could not validate credentials"
    headers: dict[str, str] | None = {"WWW-Authenticate": "Bearer"}


class NotFoundError(AppError):
    status_code: int = 404
    detail: str = "Resource not found"


class ValidationError(AppError):
    status_code: int = 400
    detail: str = "Validation failed"


class UnsupportedPlatformError(ValidationError):
    def __init__(self, platform: str) -> None:
        super().__init__(f"Unsupported platform: {platform}")


class UnsupportedToneError(ValidationError):
    def __init__(self, tone: str) -> None:
        super().__init__(f"Unsupported tone: {tone}")


class CalendarGenerationError(AppError):
    status_code: int = 500
    detail: str = "Failed to generate calendar"


class CaptionGenerationError(AppError):
    status_code: int = 500
    detail: str = "Failed to generate caption"
