import { useMemo } from 'react'
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts'
import type { ContentMixItem } from '@/types/competitor'

interface Props {
  data: ContentMixItem[]
}

const COLORS = ['#7c3aed', '#a78bfa', '#c4b5fd', '#ddd6fe', '#ede9fe']

interface TooltipEntry {
  name: string
  value: number
  color: string
}

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: TooltipEntry[]; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-lg px-4 py-3 text-sm">
      <p className="font-semibold text-gray-900 mb-1">{label}</p>
      {payload.map((entry) => (
        <p key={entry.name} className="text-gray-600">
          <span className="inline-block w-2 h-2 rounded-full mr-1.5" style={{ backgroundColor: entry.color }} />
          {entry.name}: {entry.value} post{entry.value !== 1 ? 's' : ''}
        </p>
      ))}
    </div>
  )
}

export function CompetitorContentMixChart({ data }: Props) {
  const chartData = useMemo(() => {
    if (data.length === 0) return []

    const allTypes = new Set<string>()
    data.forEach(item => {
      Object.keys(item.content_types).forEach(t => allTypes.add(t))
    })

    const zeroTotals: Record<string, boolean> = {}
    allTypes.forEach(type => {
      zeroTotals[type] = data.every(item => (item.content_types[type] || 0) === 0)
    })

    const activeTypes = [...allTypes].filter(t => !zeroTotals[t])

    return data.map(item => {
      const row: Record<string, string | number> = { competitor: item.competitor }
      activeTypes.forEach(type => {
        row[type] = item.content_types[type] || 0
      })
      return row
    })
  }, [data])

  if (chartData.length === 0) return null

  const firstRow = chartData[0]
  const keys = firstRow ? Object.keys(firstRow).filter(k => k !== 'competitor') : []

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <h3 className="text-sm font-semibold text-gray-900 mb-4">Competitor Content Mix</h3>
      <ResponsiveContainer width="100%" height={Math.max(200, chartData.length * 60)}>
        <BarChart data={chartData} layout="vertical" margin={{ left: 10, right: 30, top: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" horizontal={false} />
          <XAxis type="number" tick={{ fontSize: 12, fill: '#9ca3af' }} />
          <YAxis
            type="category"
            dataKey="competitor"
            tick={{ fontSize: 12, fill: '#6b7280' }}
            width={140}
          />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: '#f5f3ff' }} />
          <Legend
            wrapperStyle={{ fontSize: 11, color: '#6b7280' }}
            formatter={(value: string) => value.replace(/_/g, ' ')}
          />
          {keys.map((key, i) => (
            <Bar
              key={key}
              dataKey={key}
              name={key}
              stackId="a"
              fill={COLORS[i % COLORS.length]}
              radius={i === keys.length - 1 ? [0, 4, 4, 0] : [0, 0, 0, 0]}
              maxBarSize={20}
            />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
