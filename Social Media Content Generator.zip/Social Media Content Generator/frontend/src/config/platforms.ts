import { Instagram, Linkedin, Music2, Facebook, Twitter, type LucideIcon } from 'lucide-react'

export interface PlatformConfig {
  id: string
  name: string
  icon: LucideIcon
  gradient: string
}

export const platforms: PlatformConfig[] = [
  { id: 'instagram', name: 'Instagram', icon: Instagram, gradient: 'from-pink-500 to-purple-600' },
  { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, gradient: 'from-blue-600 to-blue-800' },
  { id: 'tiktok', name: 'TikTok', icon: Music2, gradient: 'from-black to-gray-800' },
  { id: 'facebook', name: 'Facebook', icon: Facebook, gradient: 'from-blue-500 to-blue-700' },
  { id: 'twitter', name: 'X / Twitter', icon: Twitter, gradient: 'from-gray-900 to-black' },
] as const

export const platformApiValues: Record<string, string> = {
  instagram: 'instagram',
  linkedin: 'linkedin',
  tiktok: 'tiktok',
  facebook: 'facebook',
  twitter: 'x',
}

export const SUPPORTED_PLATFORMS = [
  { value: 'all', label: 'All platforms' },
  { value: 'instagram', label: 'Instagram' },
  { value: 'linkedin', label: 'LinkedIn' },
  { value: 'tiktok', label: 'TikTok' },
  { value: 'facebook', label: 'Facebook' },
  { value: 'x', label: 'X / Twitter' },
] as const

export type PlatformFilterValue = (typeof SUPPORTED_PLATFORMS)[number]['value']
export type SupportedPlatformKey = 'instagram' | 'linkedin' | 'tiktok' | 'facebook' | 'x'
