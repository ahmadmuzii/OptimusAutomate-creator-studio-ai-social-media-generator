from __future__ import annotations

import datetime

from sqlalchemy.orm import Session

from app.models.db_models import PerformanceImportBatch, PostPerformanceRecord


class PerformanceImportService:
    def __init__(self, db: Session, user_id: int):
        self.db = db
        self.user_id = user_id

    def import_rows(self, brand_id: int, rows: list[dict]) -> dict:
        batch = PerformanceImportBatch(
            user_id=self.user_id,
            brand_id=brand_id,
            total_rows=len(rows),
            status="processing",
        )
        self.db.add(batch)
        self.db.flush()

        valid_rows = 0
        invalid_rows = 0
        errors = []

        for row in rows:
            try:
                pub_date = None
                if row.get("publication_date"):
                    try:
                        pub_date = datetime.datetime.fromisoformat(str(row["publication_date"]))
                    except (ValueError, TypeError):
                        pass

                record = PostPerformanceRecord(
                    user_id=self.user_id,
                    brand_id=brand_id,
                    import_batch_id=batch.id,
                    external_post_id=str(row.get("external_post_id", "")),
                    platform=str(row.get("platform", "instagram")),
                    content_type=str(row.get("content_type", "carousel")),
                    publication_date=pub_date,
                    impressions=_safe_int(row.get("impressions")),
                    reach=_safe_int(row.get("reach")),
                    likes=_safe_int(row.get("likes")),
                    comments=_safe_int(row.get("comments")),
                    saves=_safe_int(row.get("saves")),
                    shares=_safe_int(row.get("shares")),
                    link_clicks=_safe_int(row.get("link_clicks")),
                    watch_time=float(row.get("watch_time", 0) or 0),
                    video_views=_safe_int(row.get("video_views")),
                    profile_visits=_safe_int(row.get("profile_visits")),
                    followers_gained=_safe_int(row.get("followers_gained")),
                    conversion_count=_safe_int(row.get("conversion_count")),
                    persona_id=_safe_int(row.get("persona_id")),
                    funnel_stage=str(row["funnel_stage"]) if row.get("funnel_stage") else None,
                    cta_type=str(row["cta_type"]) if row.get("cta_type") else None,
                    caption_fingerprint=str(hash(str(row.get("caption", "")))),
                )
                self.db.add(record)
                valid_rows += 1
            except Exception as e:
                invalid_rows += 1
                errors.append({"error": str(e), "row": row})

        batch.total_rows = len(rows)
        batch.valid_rows = valid_rows
        batch.invalid_rows = invalid_rows
        batch.status = "completed" if invalid_rows == 0 else "completed_with_errors"
        self.db.commit()

        return {
            "batch_id": batch.id,
            "total_rows": len(rows),
            "valid_rows": valid_rows,
            "invalid_rows": invalid_rows,
            "errors": errors,
        }

    @staticmethod
    def calculate_engagement_rate(record: PostPerformanceRecord) -> float:
        engagements = (record.likes or 0) + (record.comments or 0) + (record.saves or 0) + (record.shares or 0)
        impressions = record.impressions or 0
        return (engagements / max(impressions, 1)) * 100


def _safe_int(value) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (ValueError, TypeError):
        return None
