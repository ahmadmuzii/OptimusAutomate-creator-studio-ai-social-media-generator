export interface CompetitorProfile {
  id: number
  brand_id: number
  name: string
  platform: string | null
  public_handle: string | null
  website: string | null
  notes: string | null
  created_at: string
}

export interface CompetitorProfileCreate {
  name: string
  platform?: string | null
  public_handle?: string | null
  website?: string | null
  notes?: string | null
}

export interface CompetitorProfileUpdate {
  name?: string
  platform?: string | null
  public_handle?: string | null
  website?: string | null
  notes?: string | null
}

export interface CompetitorPost {
  id: number
  competitor_id: number
  caption: string | null
  content_type: string | null
  platform: string | null
  cta_style: string | null
  hook_type: string | null
  topics: string[] | null
  publication_date: string | null
  engagement_metrics: Record<string, unknown> | null
}

export interface CompetitorPostCreate {
  caption?: string | null
  content_type?: string | null
  platform?: string | null
  cta_style?: string | null
  hook_type?: string | null
  topics?: string[]
  publication_date?: string | null
  engagement_metrics?: Record<string, unknown> | null
}

export interface GapReportSummary {
  competitors_analyzed: number
  posts_analyzed: number
  unique_topics: number
  opportunities_found: number
}

export interface TopicCoverageItem {
  topic: string
  post_count: number
  competitor_count: number
  competitors: string[]
}

export interface ContentMixItem {
  competitor: string
  content_types: Record<string, number>
}

export interface OpportunityItem {
  topic: string
  competitor_coverage: number
  brand_coverage: number
  competitors: string[]
  priority: 'high' | 'medium' | 'low'
  suggested_format: string | null
  selected_for_generation: boolean
}

export interface GapReportData {
  summary: GapReportSummary
  topic_coverage: TopicCoverageItem[]
  content_mix: ContentMixItem[]
  opportunities: OpportunityItem[]
  recommendations: string[]
  gaps_found?: number
  brand_themes_count?: number
  competitor_topics_count?: number
  gaps?: Array<{ topic: string; competitors_covering: string[]; platforms: string[] }>
  missing_topics?: string[]
}

export interface GapReport {
  id: number
  brand_id: number
  status: string
  report_data: GapReportData | null
  created_at: string
}
