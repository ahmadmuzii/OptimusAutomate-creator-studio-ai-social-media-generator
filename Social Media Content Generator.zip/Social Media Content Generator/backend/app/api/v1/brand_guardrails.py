from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.db_models import BrandGuardrail, BrandProfile, User
from app.models.guardrail_schemas import (
    BrandCheckResult,
    BrandGuardrailRequest,
    BrandGuardrailResponse,
)

router = APIRouter(prefix="/brands/{brand_id}/guardrails", tags=["Brand Guardrails"])


def _get_brand_or_404(db: Session, brand_id: int, user_id: int) -> BrandProfile:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != user_id:
        raise NotFoundError("Brand not found")
    return brand


def _guardrail_to_response(g: BrandGuardrail) -> BrandGuardrailResponse:
    return BrandGuardrailResponse(
        id=g.id,
        brand_id=g.brand_id,
        required_phrases=g.required_phrases or [],
        forbidden_words=g.forbidden_words or [],
        competitors_never_mention=g.competitors_never_mention or [],
        approved_product_descriptions=g.approved_product_descriptions or [],
        allowed_claims=g.allowed_claims or [],
        restricted_claims=g.restricted_claims or [],
        preferred_spellings=g.preferred_spellings or {},
        preferred_capitalizations=g.preferred_capitalizations or [],
        product_names=g.product_names or [],
        service_names=g.service_names or [],
        brand_name_aliases=g.brand_name_aliases or [],
        required_legal_disclaimer=g.required_legal_disclaimer,
        example_posts_liked=g.example_posts_liked or [],
        example_posts_disliked=g.example_posts_disliked or [],
        emoji_allowance=g.emoji_allowance,
        profanity_level=g.profanity_level,
        formality_level=g.formality_level,
        max_hashtag_count=g.max_hashtag_count,
        min_hashtag_count=g.min_hashtag_count,
        allowed_languages=g.allowed_languages or [],
        default_language=g.default_language,
        preferred_cta_style=g.preferred_cta_style,
        forbidden_cta_styles=g.forbidden_cta_styles or [],
        restricted_topics=g.restricted_topics or [],
        sensitive_topics_requiring_review=g.sensitive_topics_requiring_review or [],
        created_at=g.created_at.isoformat() if g.created_at else None,
        updated_at=g.updated_at.isoformat() if g.updated_at else None,
    )


@router.get("", response_model=BrandGuardrailResponse)
def get_guardrails(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    guardrail = db.query(BrandGuardrail).filter(BrandGuardrail.brand_id == brand_id).first()
    if not guardrail:
        guardrail = BrandGuardrail(brand_id=brand_id)
        db.add(guardrail)
        db.commit()
        db.refresh(guardrail)
    return _guardrail_to_response(guardrail)


@router.put("", response_model=BrandGuardrailResponse)
def update_guardrails(
    brand_id: int,
    request: BrandGuardrailRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    guardrail = db.query(BrandGuardrail).filter(BrandGuardrail.brand_id == brand_id).first()
    if not guardrail:
        guardrail = BrandGuardrail(brand_id=brand_id)
        db.add(guardrail)

    update_data = request.model_dump(exclude_none=True)
    for key, value in update_data.items():
        setattr(guardrail, key, value)

    db.commit()
    db.refresh(guardrail)
    return _guardrail_to_response(guardrail)


@router.delete("")
def reset_guardrails(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    guardrail = db.query(BrandGuardrail).filter(BrandGuardrail.brand_id == brand_id).first()
    if guardrail:
        for column in BrandGuardrail.__table__.columns:
            if column.name not in ("id", "brand_id", "created_at", "updated_at"):
                setattr(guardrail, column.name, None)
        db.commit()
    return {"detail": "Guardrails reset"}


@router.post("/check", response_model=BrandCheckResult)
def run_brand_check(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    brand = _get_brand_or_404(db, brand_id, current_user.id)
    guardrail = db.query(BrandGuardrail).filter(BrandGuardrail.brand_id == brand_id).first()

    from app.services.brand_check_service import BrandCheckService

    service = BrandCheckService()
    result = service.check_guardrails(brand, guardrail, None)
    return result
