import json
import sqlite3

conn = sqlite3.connect("social_media.db")
cur = conn.execute(
    "SELECT required_phrases, forbidden_words, competitors_never_mention, preferred_capitalizations, product_names, service_names FROM brand_guardrails WHERE brand_id = 1"
)
row = cur.fetchone()
if row:
    for name, val in zip(
        [
            "required_phrases",
            "forbidden_words",
            "competitors_never_mention",
            "preferred_capitalizations",
            "product_names",
            "service_names",
        ],
        row,
    ):
        try:
            parsed = json.loads(val) if val else None
            print(f"{name}: {parsed}")
        except:
            print(f"{name}: {val}")
else:
    print("No guardrails record exists for brand 1")
conn.close()
