"""Safe migration: add campaign_post_revisions and refinement_traces tables.

Adds the following new tables:
  - campaign_post_revisions: stores revision history for post refinements
  - refinement_traces: stores audit trail for every refinement action

Preserves all existing data. Safe to run multiple times.
"""

import os
import sqlite3
import sys

TABLES = {
    "campaign_post_revisions": """
        CREATE TABLE IF NOT EXISTS campaign_post_revisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campaign_post_id INTEGER NOT NULL,
            revision_number INTEGER NOT NULL,
            action VARCHAR(50) NOT NULL,
            previous_hook TEXT,
            previous_caption TEXT NOT NULL,
            previous_call_to_action VARCHAR(500),
            previous_hashtags JSON,
            previous_tone VARCHAR(50),
            previous_content_theme VARCHAR(255),
            previous_post_idea TEXT,
            previous_content_type VARCHAR(50),
            previous_suggested_time VARCHAR(20),
            generation_source VARCHAR(50),
            created_by_user_id INTEGER NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (campaign_post_id) REFERENCES campaign_posts(id)
        )
    """,
    "refinement_traces": """
        CREATE TABLE IF NOT EXISTS refinement_traces (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campaign_id INTEGER NOT NULL,
            post_id INTEGER NOT NULL,
            action VARCHAR(50) NOT NULL,
            target_tone VARCHAR(50),
            groq_used BOOLEAN,
            groq_model VARCHAR(100),
            generation_source VARCHAR(50),
            persona_id INTEGER,
            conversion_path_id INTEGER,
            source_fact_ids JSON,
            guardrail_version INTEGER,
            changed_fields JSON,
            created_by INTEGER,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
            FOREIGN KEY (post_id) REFERENCES campaign_posts(id)
        )
    """,
}


def get_db_path() -> str:
    db_dir = os.path.dirname(os.path.abspath(__file__))
    backend_dir = os.path.dirname(db_dir)
    return os.path.join(backend_dir, "social_media.db")


def table_exists(cursor: sqlite3.Cursor, table: str) -> bool:
    cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)
    )
    return cursor.fetchone() is not None


def run_migration(db_path: str) -> None:
    if not os.path.exists(db_path):
        print(f"Database not found: {db_path}")
        sys.exit(1)

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    created: list[str] = []
    skipped: list[str] = []

    for table_name, ddl in TABLES.items():
        if table_exists(cursor, table_name):
            skipped.append(table_name)
        else:
            cursor.execute(ddl)
            created.append(table_name)

    conn.commit()
    conn.close()

    if created:
        print(f"Created tables: {', '.join(created)}")
    if skipped:
        print(f"Skipped (already exist): {', '.join(skipped)}")
    if not created and not skipped:
        print("No migration needed.")
    print("Migration 003 complete.")


if __name__ == "__main__":
    run_migration(get_db_path())
