import { useMemo } from 'react'
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts'
import type { OpportunityItem } from '@/types/competitor'

interface Props {
  data: OpportunityItem[]
}

interface TooltipEntry {
  name: string
  value: number
  color: string
}

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: TooltipEntry[]; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-lg px-4 py-3 text-sm">
      <p className="font-semibold text-gray-900 mb-1 capitalize">{label}</p>
      {payload.map((entry) => (
        <p key={entry.name} className="text-gray-600">
          <span className="inline-block w-2 h-2 rounded-full mr-1.5" style={{ backgroundColor: entry.color }} />
          {entry.name}: {entry.value} post{entry.value !== 1 ? 's' : ''}
        </p>
      ))}
    </div>
  )
}

export function ContentOpportunityChart({ data }: Props) {
  const chartData = useMemo(() => {
    return data
      .filter(o => o.competitor_coverage > 0)
      .slice(0, 10)
      .map(o => ({
        topic: o.topic,
        'Competitor Coverage': o.competitor_coverage,
        'Brand Coverage': o.brand_coverage,
      }))
  }, [data])

  if (chartData.length === 0) return null

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <h3 className="text-sm font-semibold text-gray-900 mb-4">Content Gap Opportunities</h3>
      <ResponsiveContainer width="100%" height={Math.max(200, chartData.length * 40)}>
        <BarChart data={chartData} layout="vertical" margin={{ left: 10, right: 30, top: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" horizontal={false} />
          <XAxis type="number" tick={{ fontSize: 12, fill: '#9ca3af' }} />
          <YAxis
            type="category"
            dataKey="topic"
            tick={{ fontSize: 12, fill: '#6b7280' }}
            width={140}
            tickFormatter={(v: string) => v.length > 20 ? v.slice(0, 20) + '...' : v}
          />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: '#f5f3ff' }} />
          <Legend wrapperStyle={{ fontSize: 11, color: '#6b7280' }} />
          <Bar dataKey="Competitor Coverage" fill="#7c3aed" radius={[0, 4, 4, 0]} maxBarSize={16} />
          <Bar dataKey="Brand Coverage" fill="#c4b5fd" radius={[0, 4, 4, 0]} maxBarSize={16} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
