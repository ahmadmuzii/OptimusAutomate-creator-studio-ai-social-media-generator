from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session, joinedload

from app.ai.post_refinement_service import refine_campaign_post
from app.api.deps import get_caption_service
from app.api.deps_auth import require_current_user
from app.database import get_db
from app.exceptions import AppError
from app.logging_config import get_logger
from app.models.db_models import BrandProfile, Campaign, CampaignPost, CampaignPostRevision, User
from app.models.refinement_schemas import RefinedPostData, RefinementRequest, RefinementResponse
from app.services.caption_service import CaptionService

router = APIRouter(prefix="/campaigns", tags=["Campaigns"])

logger = get_logger("api.campaigns")


class CampaignCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    platform: str = Field(..., min_length=1, max_length=50)
    tone: str = Field(..., min_length=1, max_length=50)
    campaign_goal: str = Field(..., min_length=1, max_length=200)
    brand_profile_id: int | None = None
    posts: list[dict] | None = None


class CampaignUpdateRequest(BaseModel):
    name: str | None = None
    status: str | None = None


class CampaignReGenerateRequest(BaseModel):
    post_id: int
    post_idea: str = Field(..., min_length=1)
    content_theme: str = Field(default="")
    platform: str = Field(..., min_length=1)
    tone: str = Field(..., min_length=1)
    brand_details: dict = Field(default_factory=dict)


class CampaignPostResponse(BaseModel):
    id: int
    day: int
    content_theme: str
    post_idea: str
    content_type: str
    suggested_time: str
    platform: str
    caption: str
    call_to_action: str | None
    hashtags: list | None
    status: str
    scheduled_date: str | None

    model_config = {"from_attributes": True}


class CampaignResponse(BaseModel):
    id: int
    name: str
    platform: str
    tone: str
    campaign_goal: str
    status: str
    brand_profile_id: int | None
    posts: list[CampaignPostResponse] | None
    created_at: str
    updated_at: str

    model_config = {"from_attributes": True}


def _get_campaign_or_404(db: Session, campaign_id: int, user_id: int) -> Campaign:
    campaign = (
        db.query(Campaign)
        .options(joinedload(Campaign.posts))
        .filter(Campaign.id == campaign_id, Campaign.user_id == user_id)
        .first()
    )
    if not campaign:
        raise AppError(status_code=404, detail="Campaign not found")
    return campaign


def _post_to_response(post: CampaignPost) -> CampaignPostResponse:
    return CampaignPostResponse(
        id=post.id,
        day=post.day,
        content_theme=post.content_theme,
        post_idea=post.post_idea,
        content_type=post.content_type,
        suggested_time=post.suggested_time,
        platform=post.platform,
        caption=post.caption,
        call_to_action=post.call_to_action,
        hashtags=post.hashtags,
        status=post.status,
        scheduled_date=post.scheduled_date.isoformat() if post.scheduled_date else None,
    )


def _campaign_to_response(campaign: Campaign) -> CampaignResponse:
    return CampaignResponse(
        id=campaign.id,
        name=campaign.name,
        platform=campaign.platform,
        tone=campaign.tone,
        campaign_goal=campaign.campaign_goal,
        status=campaign.status,
        brand_profile_id=campaign.brand_profile_id,
        posts=[_post_to_response(p) for p in campaign.posts] if campaign.posts else None,
        created_at=campaign.created_at.isoformat() if campaign.created_at else "",
        updated_at=campaign.updated_at.isoformat() if campaign.updated_at else "",
    )


@router.get("", response_model=list[CampaignResponse])
def list_campaigns(
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
    brand_id: int | None = None,
):
    try:
        query = db.query(Campaign).options(joinedload(Campaign.posts)).filter(Campaign.user_id == current_user.id)
        if brand_id is not None:
            query = query.filter(Campaign.brand_profile_id == brand_id)
        campaigns = query.order_by(Campaign.created_at.desc()).all()
        return [_campaign_to_response(c) for c in campaigns]
    except Exception:
        logger.exception(
            "campaign_list_failed",
            user_id=current_user.id,
            brand_id=brand_id,
        )
        raise


@router.post("", response_model=CampaignResponse)
def create_campaign(
    request: CampaignCreateRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    campaign = Campaign(
        user_id=current_user.id,
        name=request.name,
        platform=request.platform,
        tone=request.tone,
        campaign_goal=request.campaign_goal,
        brand_profile_id=request.brand_profile_id,
    )
    db.add(campaign)
    db.commit()
    db.refresh(campaign)

    if request.posts:
        for p in request.posts:
            post = CampaignPost(
                campaign_id=campaign.id,
                day=p.get("day", 1),
                content_theme=p.get("contentTheme", ""),
                post_idea=p.get("postIdea", ""),
                content_type=p.get("contentType", ""),
                suggested_time=p.get("suggestedTime", ""),
                platform=p.get("platform", request.platform),
                caption=p.get("caption", ""),
                call_to_action=p.get("callToAction", ""),
                hashtags=p.get("hashtags", []),
            )
            db.add(post)
        db.commit()

    campaign = _get_campaign_or_404(db, campaign.id, current_user.id)
    return _campaign_to_response(campaign)


@router.get("/{campaign_id}", response_model=CampaignResponse)
def get_campaign(
    campaign_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    campaign = _get_campaign_or_404(db, campaign_id, current_user.id)
    return _campaign_to_response(campaign)


@router.put("/{campaign_id}", response_model=CampaignResponse)
def update_campaign(
    campaign_id: int,
    request: CampaignUpdateRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    campaign = _get_campaign_or_404(db, campaign_id, current_user.id)
    if request.name is not None:
        campaign.name = request.name
    if request.status is not None:
        campaign.status = request.status
    db.commit()
    db.refresh(campaign)
    campaign = _get_campaign_or_404(db, campaign.id, current_user.id)
    return _campaign_to_response(campaign)


@router.delete("/{campaign_id}")
def delete_campaign(
    campaign_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    campaign = _get_campaign_or_404(db, campaign_id, current_user.id)
    db.delete(campaign)
    db.commit()
    return {"detail": "Campaign deleted"}


class PostUpdateRequest(BaseModel):
    status: str | None = None
    scheduled_date: str | None = None


@router.delete("/{campaign_id}/posts/{post_id}")
def delete_post(
    campaign_id: int,
    post_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    campaign = _get_campaign_or_404(db, campaign_id, current_user.id)
    post = db.query(CampaignPost).filter(CampaignPost.id == post_id, CampaignPost.campaign_id == campaign.id).first()
    if not post:
        raise AppError(status_code=404, detail="Post not found")
    db.delete(post)
    db.commit()
    return {"detail": "Post deleted"}


@router.put("/{campaign_id}/posts/{post_id}")
def update_post(
    campaign_id: int,
    post_id: int,
    request: PostUpdateRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    campaign = _get_campaign_or_404(db, campaign_id, current_user.id)
    post = db.query(CampaignPost).filter(CampaignPost.id == post_id, CampaignPost.campaign_id == campaign.id).first()
    if not post:
        raise AppError(status_code=404, detail="Post not found")
    if request.status is not None:
        valid_statuses = {"draft", "scheduled", "published"}
        if request.status not in valid_statuses:
            raise AppError(
                status_code=400, detail=f"Invalid status. Must be one of: {', '.join(sorted(valid_statuses))}"
            )
        post.status = request.status
    if request.scheduled_date is not None:
        from datetime import datetime

        post.scheduled_date = datetime.fromisoformat(request.scheduled_date)
    db.commit()
    logger.info("post_updated", post_id=post_id, status=request.status)
    return {"detail": "Post updated"}


@router.post("/{campaign_id}/posts/{post_id}/refine")
def refine_post(
    campaign_id: int,
    post_id: int,
    request: RefinementRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    campaign = _get_campaign_or_404(db, campaign_id, current_user.id)
    post = db.query(CampaignPost).filter(CampaignPost.id == post_id, CampaignPost.campaign_id == campaign.id).first()
    if not post:
        raise AppError(status_code=404, detail="Post not found")

    if campaign.brand_profile_id:
        brand = (
            db.query(BrandProfile)
            .filter(
                BrandProfile.id == campaign.brand_profile_id,
                BrandProfile.user_id == current_user.id,
            )
            .first()
        )
        if not brand:
            raise AppError(status_code=404, detail="Brand not found")

    result = refine_campaign_post(
        db=db,
        current_user=current_user,
        campaign=campaign,
        post=post,
        action=request.action,
        target_tone=request.target_tone,
        custom_instruction=request.custom_instruction,
    )

    if result.get("status") == "error":
        raise AppError(status_code=500, detail=result.get("error", "Refinement failed"))
    if result.get("status") == "blocked":
        return result

    return RefinementResponse(
        post=RefinedPostData(**result["post"]),
        refinement=result["refinement"],
    )


@router.get("/{campaign_id}/posts/{post_id}/revisions")
def list_post_revisions(
    campaign_id: int,
    post_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    campaign = _get_campaign_or_404(db, campaign_id, current_user.id)
    post = db.query(CampaignPost).filter(CampaignPost.id == post_id, CampaignPost.campaign_id == campaign.id).first()
    if not post:
        raise AppError(status_code=404, detail="Post not found")

    revisions = (
        db.query(CampaignPostRevision)
        .filter(CampaignPostRevision.campaign_post_id == post_id)
        .order_by(CampaignPostRevision.revision_number.desc())
        .all()
    )
    return [
        {
            "id": r.id,
            "campaign_post_id": r.campaign_post_id,
            "revision_number": r.revision_number,
            "action": r.action,
            "previous_caption": r.previous_caption,
            "previous_call_to_action": r.previous_call_to_action,
            "previous_hashtags": r.previous_hashtags or [],
            "previous_tone": r.previous_tone,
            "generation_source": r.generation_source,
            "created_at": r.created_at.isoformat() if r.created_at else "",
        }
        for r in revisions
    ]


@router.post("/{campaign_id}/posts/{post_id}/undo")
def undo_post_refinement(
    campaign_id: int,
    post_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    campaign = _get_campaign_or_404(db, campaign_id, current_user.id)
    post = db.query(CampaignPost).filter(CampaignPost.id == post_id, CampaignPost.campaign_id == campaign.id).first()
    if not post:
        raise AppError(status_code=404, detail="Post not found")

    revision = (
        db.query(CampaignPostRevision)
        .filter(CampaignPostRevision.campaign_post_id == post_id)
        .order_by(CampaignPostRevision.revision_number.desc())
        .first()
    )
    if not revision:
        raise AppError(status_code=404, detail="No revisions found for this post")

    post.caption = revision.previous_caption
    post.call_to_action = revision.previous_call_to_action
    post.hashtags = revision.previous_hashtags
    post.tone_override = revision.previous_tone
    post.content_theme = revision.previous_content_theme or post.content_theme
    post.post_idea = revision.previous_post_idea or post.post_idea
    post.content_type = revision.previous_content_type or post.content_type
    post.suggested_time = revision.previous_suggested_time or post.suggested_time

    db.delete(revision)
    db.commit()
    db.refresh(post)

    return {
        "detail": "Undo successful",
        "post": _post_to_response(post),
    }


@router.get("/{campaign_id}/posts/{post_id}/revisions/{revision_id}/restore")
def restore_post_revision(
    campaign_id: int,
    post_id: int,
    revision_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    campaign = _get_campaign_or_404(db, campaign_id, current_user.id)
    post = db.query(CampaignPost).filter(CampaignPost.id == post_id, CampaignPost.campaign_id == campaign.id).first()
    if not post:
        raise AppError(status_code=404, detail="Post not found")

    revision = (
        db.query(CampaignPostRevision)
        .filter(
            CampaignPostRevision.id == revision_id,
            CampaignPostRevision.campaign_post_id == post_id,
        )
        .first()
    )
    if not revision:
        raise AppError(status_code=404, detail="Revision not found")

    save_result = refine_campaign_post(
        db=db,
        current_user=current_user,
        campaign=campaign,
        post=post,
        action="custom",
        custom_instruction=f"Restore to revision {revision.revision_number}",
    )

    if save_result.get("status") == "error":
        raise AppError(status_code=500, detail=save_result.get("error", "Restore failed"))

    return {
        "detail": f"Revision {revision.revision_number} restored",
        "post": save_result.get("post"),
    }


@router.post("/{campaign_id}/posts/{post_id}/regenerate")
def regenerate_post_caption(
    campaign_id: int,
    post_id: int,
    request: CampaignReGenerateRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
    caption_service: CaptionService = Depends(get_caption_service),
):
    campaign = _get_campaign_or_404(db, campaign_id, current_user.id)
    post = db.query(CampaignPost).filter(CampaignPost.id == post_id, CampaignPost.campaign_id == campaign.id).first()
    if not post:
        raise AppError(status_code=404, detail="Post not found")

    brand_details = request.brand_details or {}
    try:
        new_caption = caption_service.generate_caption(
            post_idea=request.post_idea or post.post_idea,
            platform=request.platform or post.platform,
            tone=request.tone or campaign.tone,
            brand_details=brand_details,
        )
        new_hashtags = caption_service.generate_hashtags(
            niche=brand_details.get("niche", "general"),
            platform=request.platform or post.platform,
            campaign_goal=brand_details.get("campaignGoal", campaign.campaign_goal),
            brand_name=brand_details.get("brandName", ""),
        )
        post.caption = new_caption
        post.hashtags = new_hashtags
        db.commit()
        logger.info("post_caption_regenerated", post_id=post_id)
        return {
            "detail": "Caption regenerated",
            "caption": new_caption,
            "hashtags": new_hashtags,
        }
    except Exception as e:
        logger.error("caption_regeneration_failed", post_id=post_id, error=str(e))
        raise AppError(status_code=500, detail="Failed to regenerate caption")
