from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.api.deps_features import require_feature
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.db_models import (
    BrandProfile,
    PerformanceImportBatch,
    PerformanceInsight,
    PostPerformanceRecord,
    User,
)
from app.models.performance_schemas import (
    ImportBatchResponse,
    InsightResponse,
    InsightUpdate,
    PerformanceImportRequest,
    PerformanceRecordResponse,
    PerformanceSummary,
)
from app.services.insight_service import InsightService
from app.services.performance_import_service import PerformanceImportService

router = APIRouter(
    prefix="/brands/{brand_id}/performance",
    tags=["Performance"],
    dependencies=[require_feature("performance_memory")],
)


def _get_brand_or_404(db: Session, brand_id: int, user_id: int) -> BrandProfile:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != user_id:
        raise NotFoundError("Brand not found")
    return brand


@router.get("/summary", response_model=PerformanceSummary)
def get_performance_summary(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    service = InsightService(db)
    return service.get_summary(brand_id)


@router.post("/import")
def import_performance_data(
    brand_id: int,
    request: PerformanceImportRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    service = PerformanceImportService(db, current_user.id)
    rows = [r.model_dump() for r in request.rows]
    result = service.import_rows(brand_id, rows)
    return result


@router.get("/imports", response_model=list[ImportBatchResponse])
def list_import_batches(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    batches = (
        db.query(PerformanceImportBatch)
        .filter(PerformanceImportBatch.brand_id == brand_id)
        .order_by(PerformanceImportBatch.created_at.desc())
        .all()
    )
    return batches


@router.get("/records", response_model=list[PerformanceRecordResponse])
def list_performance_records(
    brand_id: int,
    limit: int = 50,
    offset: int = 0,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    records = (
        db.query(PostPerformanceRecord)
        .filter(PostPerformanceRecord.brand_id == brand_id)
        .order_by(PostPerformanceRecord.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )
    result = []
    for r in records:
        eng_rate = PerformanceImportService.calculate_engagement_rate(r)
        result.append(
            PerformanceRecordResponse(
                id=r.id,
                platform=r.platform,
                content_type=r.content_type,
                impressions=r.impressions,
                reach=r.reach,
                likes=r.likes,
                comments=r.comments,
                saves=r.saves,
                shares=r.shares,
                link_clicks=r.link_clicks,
                engagement_rate=round(eng_rate, 2),
                publication_date=r.publication_date,
                persona_id=r.persona_id,
            )
        )
    return result


@router.get("/insights", response_model=list[InsightResponse])
def list_insights(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    insights = (
        db.query(PerformanceInsight)
        .filter(PerformanceInsight.brand_id == brand_id)
        .order_by(PerformanceInsight.created_at.desc())
        .all()
    )
    return insights


@router.patch("/insights/{insight_id}", response_model=InsightResponse)
def update_insight(
    brand_id: int,
    insight_id: int,
    request: InsightUpdate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    insight = (
        db.query(PerformanceInsight)
        .filter(PerformanceInsight.id == insight_id, PerformanceInsight.brand_id == brand_id)
        .first()
    )
    if not insight:
        raise NotFoundError("Insight not found")

    update_data = request.model_dump(exclude_none=True)
    for key, value in update_data.items():
        setattr(insight, key, value)
    db.commit()
    db.refresh(insight)
    return insight


@router.post("/insights/generate")
def generate_insights(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    service = InsightService(db)
    insights = service.generate_insights(brand_id, current_user.id)
    return {"insights_generated": len(insights)}
