import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Sparkles, Instagram, Linkedin, Music2, Facebook, Twitter } from 'lucide-react'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { demoBrands, demoCalendarData } from '@/data/landingDemoData'
import { cn } from '@/utils/cn'

const platformIcons: Record<string, typeof Instagram | typeof Linkedin | typeof Music2 | typeof Facebook | typeof Twitter> = {
  instagram: Instagram,
  linkedin: Linkedin,
  tiktok: Music2,
  facebook: Facebook,
  twitter: Twitter,
}

const platformColors: Record<string, string> = {
  instagram: 'from-pink-500 to-purple-600',
  linkedin: 'from-blue-600 to-blue-800',
  tiktok: 'from-black to-gray-800',
  facebook: 'from-blue-500 to-blue-700',
  twitter: 'from-gray-900 to-black',
}

function StaticPreview({ brandId }: { brandId: string }) {
  const days = demoCalendarData[brandId]?.slice(0, 3) || []
  const caption = days[0]?.caption?.slice(0, 80) || ''

  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-xl overflow-hidden">
      <div className="p-4 border-b border-gray-100 flex items-center gap-2">
        <div className="w-2.5 h-2.5 rounded-full bg-red-400" />
        <div className="w-2.5 h-2.5 rounded-full bg-yellow-400" />
        <div className="w-2.5 h-2.5 rounded-full bg-green-400" />
        <span className="ml-3 text-xs text-gray-400 font-medium">Creator Studio Preview</span>
      </div>
      <div className="p-5 space-y-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1">
            <div className="text-xs font-semibold text-gray-900">{demoBrands.find(b => b.id === brandId)?.name || 'Brand'}</div>
            <div className="text-[10px] text-gray-400">Campaign preview</div>
          </div>
          <div className="flex gap-1">
            {['instagram', 'linkedin', 'tiktok'].map((p) => {
              const IconComponent = platformIcons[p]
              return IconComponent ? (
                <div key={p} className={cn('w-6 h-6 rounded-md bg-gradient-to-br flex items-center justify-center', platformColors[p])}>
                  <IconComponent className="w-3 h-3 text-white" />
                </div>
              ) : null
            })}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {days.map((day, i) => (
            <div key={i} className="bg-gray-50 rounded-xl p-2.5 border border-gray-100">
              <div className="text-[10px] font-semibold text-purple-600 mb-1">Day {day.day}</div>
              <div className="text-[10px] font-medium text-gray-800 leading-tight">{day.contentTheme}</div>
              <div className="text-[9px] text-gray-400 mt-1 line-clamp-2">{day.postIdea}</div>
            </div>
          ))}
        </div>

        <div className="bg-purple-50/50 rounded-xl p-3 border border-purple-100">
          <div className="text-[10px] font-semibold text-purple-700 mb-1">Caption Preview</div>
          <p className="text-xs text-gray-600 leading-relaxed line-clamp-2">{caption}</p>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {(demoCalendarData[brandId]?.[0]?.hashtags || []).slice(0, 4).map((tag, i) => (
            <span key={i} className="text-[9px] px-2 py-0.5 rounded-full bg-purple-100 text-purple-600 font-medium">
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}

export function InteractiveHeroDemo() {
  const [selectedBrand, setSelectedBrand] = useState(demoBrands[0]?.id || 'coffee')
  const [phase, setPhase] = useState(0)
  const reduced = useReducedMotionPreference()

  useEffect(() => {
    if (reduced) {
      setPhase(4)
      return
    }
    const timer = setTimeout(() => {
      setPhase((p) => (p < 4 ? p + 1 : 0))
    }, phase === 0 ? 800 : phase === 4 ? 2500 : 400)

    return () => clearTimeout(timer)
  }, [phase, reduced])

  const handleBrandChange = useCallback((id: string) => {
    setSelectedBrand(id)
    if (!reduced) setPhase(1)
  }, [reduced])

  const brand = demoBrands.find(b => b.id === selectedBrand)
  if (!brand) return null

  if (reduced) {
    return (
      <div className="space-y-4">
        <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-center">
          <span className="text-xs font-medium text-gray-500">Example: {brand.name}</span>
        </div>
        <StaticPreview brandId={selectedBrand} />
        <div className="flex flex-wrap gap-2 justify-center">
          {demoBrands.map((b) => (
            <button
              key={b.id}
              onClick={() => handleBrandChange(b.id)}
              className={cn(
                'px-3 py-1.5 rounded-full text-xs font-medium border transition-colors',
                selectedBrand === b.id
                  ? 'bg-purple-600 text-white border-purple-600'
                  : 'bg-white text-gray-600 border-gray-200 hover:border-purple-300',
              )}
            >
              {b.name}
            </button>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-center">
        <span className="text-xs font-medium text-gray-500">
          Example: <span className="text-purple-700">{brand.name}</span> &middot; {brand.niche}
        </span>
      </div>

      <div className="relative bg-white rounded-2xl border border-gray-200 shadow-xl overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-red-400" />
          <div className="w-2.5 h-2.5 rounded-full bg-yellow-400" />
          <div className="w-2.5 h-2.5 rounded-full bg-green-400" />
          <span className="ml-3 text-xs text-gray-400 font-medium">Creator Studio Preview</span>
        </div>

        <div className="p-5 space-y-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedBrand}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25 }}
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1">
                  <div className="text-xs font-semibold text-gray-900">{brand.name}</div>
                  <div className="text-[10px] text-gray-400">Campaign goal: {brand.goal.replace(/_/g, ' ')}</div>
                </div>
                <div className="flex gap-1">
                  {['instagram', 'linkedin', 'tiktok'].map((p) => {
                    const IconComponent = platformIcons[p]
                    return IconComponent ? (
                      <div key={p} className={cn('w-6 h-6 rounded-md bg-gradient-to-br flex items-center justify-center', platformColors[p])}>
                        <IconComponent className="w-3 h-3 text-white" />
                      </div>
                    ) : null
                  })}
                </div>
              </div>

              {phase >= 2 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: reduced ? 0 : 0.1 }}
                  className="grid grid-cols-3 gap-2 mb-4"
                >
                  {(demoCalendarData[selectedBrand] || []).slice(0, 3).map((day, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.25, delay: i * 0.08 }}
                      className="bg-gray-50 rounded-xl p-2.5 border border-gray-100"
                    >
                      <div className="text-[10px] font-semibold text-purple-600 mb-1">Day {day.day}</div>
                      <div className="text-[10px] font-medium text-gray-800 leading-tight">{day.contentTheme}</div>
                      <div className="text-[9px] text-gray-400 mt-1 line-clamp-2">{day.postIdea}</div>
                    </motion.div>
                  ))}
                </motion.div>
              )}

              {phase >= 3 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: reduced ? 0 : 0.15 }}
                  className="bg-purple-50/50 rounded-xl p-3 border border-purple-100 mb-4"
                >
                  <div className="text-[10px] font-semibold text-purple-700 mb-1">Caption Preview</div>
                  <p className="text-xs text-gray-600 leading-relaxed line-clamp-2">
                    {(demoCalendarData[selectedBrand]?.[0]?.caption || '').slice(0, 100)}
                  </p>
                </motion.div>
              )}

              {phase >= 4 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.2 }}
                  className="flex flex-wrap gap-1.5"
                >
                  {(demoCalendarData[selectedBrand]?.[0]?.hashtags || []).slice(0, 5).map((tag, i) => (
                    <motion.span
                      key={i}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.15, delay: i * 0.04 }}
                      className="text-[9px] px-2 py-0.5 rounded-full bg-purple-100 text-purple-600 font-medium"
                    >
                      {tag}
                    </motion.span>
                  ))}
                </motion.div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 justify-center">
        {demoBrands.map((b) => (
          <button
            key={b.id}
            onClick={() => handleBrandChange(b.id)}
            className={cn(
              'px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200',
              selectedBrand === b.id
                ? 'bg-purple-600 text-white border-purple-600 shadow-sm shadow-purple-500/25'
                : 'bg-white text-gray-600 border-gray-200 hover:border-purple-300 hover:text-purple-700',
            )}
          >
            {b.name}
          </button>
        ))}
      </div>
    </div>
  )
}
