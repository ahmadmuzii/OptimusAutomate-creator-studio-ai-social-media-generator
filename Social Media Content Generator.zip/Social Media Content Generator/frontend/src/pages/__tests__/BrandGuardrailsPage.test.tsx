import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { BrowserRouter } from 'react-router-dom'
import { normalizeGuardrails } from '@/pages/BrandGuardrailsPage'

const mockFetchGuardrails = vi.fn()
const mockUpdateGuardrails = vi.fn()

vi.mock('@/api/endpoints', () => ({
  fetchGuardrails: (...args: unknown[]) => mockFetchGuardrails(...args),
  updateGuardrails: (...args: unknown[]) => mockUpdateGuardrails(...args),
}))

vi.mock('@/components/layout/BrandWorkspaceLayout', () => ({
  useBrandWorkspace: () => ({
    brandId: 1,
    brand: { id: 1, name: 'Brewline Coffee Co.' },
    refetchBrand: vi.fn(),
  }),
}))

// We import the page dynamically to avoid hoisting issues
import { BrandGuardrailsPage } from '@/pages/BrandGuardrailsPage'

function renderPage() {
  return render(
    <BrowserRouter>
      <BrandGuardrailsPage />
    </BrowserRouter>,
  )
}

// ---------- normalizeGuardrails pure-function tests ----------

describe('normalizeGuardrails', () => {
  it('returns empty arrays for null input', () => {
    const result = normalizeGuardrails(null)
    expect(result.required_phrases).toEqual([])
    expect(result.forbidden_words).toEqual([])
    expect(result.competitors_never_mention).toEqual([])
    expect(result.preferred_capitalizations).toEqual([])
    expect(result.product_names).toEqual([])
    expect(result.service_names).toEqual([])
  })

  it('returns empty arrays for undefined input', () => {
    const result = normalizeGuardrails(undefined)
    expect(result.required_phrases).toEqual([])
    expect(result.forbidden_words).toEqual([])
    expect(result.competitors_never_mention).toEqual([])
    expect(result.preferred_capitalizations).toEqual([])
    expect(result.product_names).toEqual([])
    expect(result.service_names).toEqual([])
  })

  it('passes through complete response with all fields separate', () => {
    const data = {
      required_phrases: ['Brewline Coffee Co.'],
      forbidden_words: ['cheap'],
      competitors_never_mention: ['Starbucks'],
      preferred_capitalizations: ['CreatorStudio'],
      product_names: ['Brewline Signature Roast'],
      service_names: ['Brewline Rewards'],
      brand_name_aliases: ['BCC'],
      approved_product_descriptions: ['Handcrafted'],
      allowed_claims: ['Clinically tested'],
      restricted_claims: ['guaranteed'],
      preferred_spellings: { 'favor': 'favour' },
      required_legal_disclaimer: null,
      emoji_allowance: null,
      profanity_level: null,
      formality_level: null,
      max_hashtag_count: null,
      min_hashtag_count: null,
      allowed_languages: ['en'],
      default_language: null,
      preferred_cta_style: null,
      forbidden_cta_styles: [],
      restricted_topics: [],
      sensitive_topics_requiring_review: [],
      id: 1,
      brand_id: 1,
      created_at: null,
      updated_at: null,
    }
    const result = normalizeGuardrails(data as unknown as Record<string, unknown>)
    expect(result.required_phrases).toEqual(['Brewline Coffee Co.'])
    expect(result.forbidden_words).toEqual(['cheap'])
    expect(result.competitors_never_mention).toEqual(['Starbucks'])
    expect(result.preferred_capitalizations).toEqual(['CreatorStudio'])
    expect(result.product_names).toEqual(['Brewline Signature Roast'])
    expect(result.service_names).toEqual(['Brewline Rewards'])
    expect(result.brand_name_aliases).toEqual(['BCC'])
  })

  it('does not copy brand name into unrelated fields', () => {
    const data = {
      required_phrases: [],
      forbidden_words: [],
      competitors_never_mention: [],
      preferred_capitalizations: [],
      product_names: [],
      service_names: [],
      brand_name_aliases: [],
      approved_product_descriptions: [],
      allowed_claims: [],
      restricted_claims: [],
      preferred_spellings: {},
      allowed_languages: [],
      forbidden_cta_styles: [],
      restricted_topics: [],
      sensitive_topics_requiring_review: [],
    }
    const result = normalizeGuardrails(data as unknown as Record<string, unknown>)
    expect(result.required_phrases).toEqual([])
    expect(result.forbidden_words).toEqual([])
    expect(result.product_names).toEqual([])
    expect(result.service_names).toEqual([])
  })

  it('handles null values in every list field independently', () => {
    const result = normalizeGuardrails({
      required_phrases: null,
      forbidden_words: null,
      competitors_never_mention: null,
      preferred_capitalizations: null,
      product_names: null,
      service_names: null,
      brand_name_aliases: null,
    } as unknown as Record<string, unknown>)
    expect(result.required_phrases).toEqual([])
    expect(result.forbidden_words).toEqual([])
    expect(result.competitors_never_mention).toEqual([])
    expect(result.preferred_capitalizations).toEqual([])
    expect(result.product_names).toEqual([])
    expect(result.service_names).toEqual([])
    expect(result.brand_name_aliases).toEqual([])
  })

  it('interprets missing keys independently as empty arrays', () => {
    const result = normalizeGuardrails({ id: 1, brand_id: 1 } as unknown as Record<string, unknown>)
    expect(result.required_phrases).toEqual([])
    expect(result.forbidden_words).toEqual([])
    expect(result.product_names).toEqual([])
    expect(result.service_names).toEqual([])
  })

  it('preserves non-array values as empty arrays, not brand name', () => {
    const result = normalizeGuardrails({
      required_phrases: 'not-an-array',
      forbidden_words: 'not-an-array',
      product_names: 'not-an-array',
      service_names: 'not-an-array',
    } as unknown as Record<string, unknown>)
    expect(result.required_phrases).toEqual([])
    expect(result.forbidden_words).toEqual([])
    expect(result.product_names).toEqual([])
    expect(result.service_names).toEqual([])
  })
})

// ---------- BrandGuardrailsPage integration tests ----------

describe('BrandGuardrailsPage', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('shows loading spinner initially', () => {
    mockFetchGuardrails.mockReturnValue(new Promise(() => {}))
    renderPage()
    const spinner = document.querySelector('.animate-spin')
    expect(spinner).toBeInTheDocument()
  })

  it('renders empty guardrails with all fields separate', async () => {
    mockFetchGuardrails.mockResolvedValue({
      id: 1,
      brand_id: 1,
      required_phrases: [],
      forbidden_words: [],
      competitors_never_mention: [],
      approved_product_descriptions: [],
      allowed_claims: [],
      restricted_claims: [],
      preferred_spellings: {},
      preferred_capitalizations: [],
      product_names: [],
      service_names: [],
      brand_name_aliases: [],
      required_legal_disclaimer: null,
      example_posts_liked: [],
      example_posts_disliked: [],
      emoji_allowance: null,
      profanity_level: null,
      formality_level: null,
      max_hashtag_count: null,
      min_hashtag_count: null,
      allowed_languages: [],
      default_language: null,
      preferred_cta_style: null,
      forbidden_cta_styles: [],
      restricted_topics: [],
      sensitive_topics_requiring_review: [],
      created_at: null,
      updated_at: null,
    })
    renderPage()
    await waitFor(() => {
      expect(screen.getByText('Brand Guardrails')).toBeInTheDocument()
    })
    expect(screen.getAllByText('None configured.').length).toBeGreaterThanOrEqual(6)
  })

  it('renders brand name only in required_phrases when user adds it', async () => {
    mockFetchGuardrails.mockResolvedValue({
      id: 1,
      brand_id: 1,
      required_phrases: ['Brewline Coffee Co.'],
      forbidden_words: [],
      competitors_never_mention: [],
      approved_product_descriptions: [],
      allowed_claims: [],
      restricted_claims: [],
      preferred_spellings: {},
      preferred_capitalizations: [],
      product_names: [],
      service_names: [],
      brand_name_aliases: [],
      required_legal_disclaimer: null,
      example_posts_liked: [],
      example_posts_disliked: [],
      emoji_allowance: null,
      profanity_level: null,
      formality_level: null,
      max_hashtag_count: null,
      min_hashtag_count: null,
      allowed_languages: [],
      default_language: null,
      preferred_cta_style: null,
      forbidden_cta_styles: [],
      restricted_topics: [],
      sensitive_topics_requiring_review: [],
      created_at: null,
      updated_at: null,
    })
    renderPage()
    await waitFor(() => {
      expect(screen.getByDisplayValue('Brewline Coffee Co.')).toBeInTheDocument()
    })
    const inputs = screen.getAllByDisplayValue('Brewline Coffee Co.')
    expect(inputs.length).toBe(1)
  })

  it('shows error state on API failure', async () => {
    mockFetchGuardrails.mockRejectedValue(new Error('Network error'))
    renderPage()
    await waitFor(() => {
      expect(screen.getByText('Could not load guardrails.')).toBeInTheDocument()
    })
  })

  describe('focus and state stability', () => {
    function renderWithServiceNames() {
      mockFetchGuardrails.mockResolvedValue({
        id: 1,
        brand_id: 1,
        required_phrases: [],
        forbidden_words: [],
        competitors_never_mention: [],
        approved_product_descriptions: [],
        allowed_claims: [],
        restricted_claims: [],
        preferred_spellings: {},
        preferred_capitalizations: [],
        product_names: [],
        service_names: ['Gold Plan', 'Silver Plan', 'Bronze Plan'],
        brand_name_aliases: [],
        required_legal_disclaimer: null,
        example_posts_liked: [],
        example_posts_disliked: [],
        emoji_allowance: null,
        profanity_level: null,
        formality_level: null,
        max_hashtag_count: null,
        min_hashtag_count: null,
        allowed_languages: [],
        default_language: null,
        preferred_cta_style: null,
        forbidden_cta_styles: [],
        restricted_topics: [],
        sensitive_topics_requiring_review: [],
        created_at: null,
        updated_at: null,
      })
      return render(
        <BrowserRouter>
          <BrandGuardrailsPage />
        </BrowserRouter>,
      )
    }

    it('keeps focus and accumulates value while typing', async () => {
      renderWithServiceNames()
      const user = userEvent.setup()

      await waitFor(() => {
        const inputs = screen.getAllByPlaceholderText('e.g., Consultation Package')
        expect(inputs.length).toBe(3)
      })

      const inputs = screen.getAllByPlaceholderText('e.g., Consultation Package') as HTMLInputElement[]
      const input = inputs[1]!

      await user.click(input)
      await user.type(input, 'Brewline Rewards')

      expect(input).toHaveValue('Silver PlanBrewline Rewards')
      expect(input).toHaveFocus()
    })

    it('does not modify other fields when editing one list item', async () => {
      renderWithServiceNames()
      const user = userEvent.setup()

      await waitFor(() => {
        const inputs = screen.getAllByPlaceholderText('e.g., Consultation Package')
        expect(inputs.length).toBe(3)
      })

      const inputs = screen.getAllByPlaceholderText('e.g., Consultation Package') as HTMLInputElement[]
      const first = inputs[0]!
      const second = inputs[1]!
      const third = inputs[2]!

      await user.click(second)
      await user.type(second, ' Updated')

      expect(first).toHaveValue('Gold Plan')
      expect(second).toHaveValue('Silver Plan Updated')
      expect(third).toHaveValue('Bronze Plan')
    })

    it('keeps focus on the middle input when editing it among three items', async () => {
      renderWithServiceNames()
      const user = userEvent.setup()

      await waitFor(() => {
        const inputs = screen.getAllByPlaceholderText('e.g., Consultation Package')
        expect(inputs.length).toBe(3)
      })

      const inputs = screen.getAllByPlaceholderText('e.g., Consultation Package') as HTMLInputElement[]
      const second = inputs[1]!

      await user.click(second)
      for (const char of 'Test') {
        await user.type(second, char)
        expect(second).toHaveFocus()
      }
    })
  })
})
