import { Palette } from 'lucide-react'
import { tones } from '@/config/tones'
import { TonePill } from './TonePill'

interface ToneSelectorProps {
  selected: string
  onSelect: (id: string) => void
}

export function ToneSelector({ selected, onSelect }: ToneSelectorProps) {
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
          <Palette className="w-4 h-4 text-purple-600" />
        </div>
        <h2 className="text-lg font-semibold text-gray-900">Choose Tone</h2>
      </div>

      <div className="flex flex-wrap gap-3">
        {tones.map((tone) => (
          <TonePill
            key={tone.id}
            tone={tone}
            isSelected={selected === tone.id}
            onSelect={onSelect}
          />
        ))}
      </div>
    </div>
  )
}
