from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class StrategyTemplate(BaseModel):
    id: int
    brand_id: int
    name: str
    description: str | None = None
    funnel_stage: str
    campaign_goal: str
    recommended_ctas: list[str] = []
    content_mix: list[str] = []
    post_frequency: str
    platform_focus: str
    icon: str | None = None
    is_default: bool = False

    model_config = ConfigDict(from_attributes=True)


class StrategyTemplateCreate(BaseModel):
    name: str
    description: str | None = None
    funnel_stage: str
    campaign_goal: str
    recommended_ctas: list[str] = []
    content_mix: list[str] = []
    post_frequency: str = "3x_week"
    platform_focus: str = "all"
    icon: str | None = None
    is_default: bool = False


class StrategyTemplateUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    funnel_stage: str | None = None
    campaign_goal: str | None = None
    recommended_ctas: list[str] | None = None
    content_mix: list[str] | None = None
    post_frequency: str | None = None
    platform_focus: str | None = None
    icon: str | None = None
    is_default: bool | None = None


class ApplyStrategyRequest(BaseModel):
    template_id: int
    campaign_id: int
