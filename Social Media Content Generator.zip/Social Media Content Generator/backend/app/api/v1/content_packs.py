from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.api.deps_features import require_feature
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.db_models import BrandProfile, CampaignPost, User
from app.models.pack_db import ContentPackTemplate
from app.models.pack_schemas import (
    ContentPackExportRequest,
    ContentPackTemplateCreate,
    ContentPackTemplateUpdate,
)
from app.models.pack_schemas import (
    ContentPackTemplate as ContentPackTemplateSchema,
)

router = APIRouter(
    prefix="/brands/{brand_id}/content-packs",
    tags=["Content Packs"],
    dependencies=[require_feature("content_packs")],
)


def _get_brand_or_404(db: Session, brand_id: int, user_id: int) -> BrandProfile:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != user_id:
        raise NotFoundError("Brand not found")
    return brand


def _template_to_schema(t: ContentPackTemplate) -> ContentPackTemplateSchema:
    return ContentPackTemplateSchema(
        id=t.id,
        brand_id=t.brand_id,
        name=t.name,
        description=t.description,
        pack_data=t.pack_data,
        is_default=t.is_default,
        created_at=t.created_at,
        updated_at=t.updated_at,
    )


@router.get("", response_model=list[ContentPackTemplateSchema])
def list_templates(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    templates = db.query(ContentPackTemplate).filter(ContentPackTemplate.brand_id == brand_id).all()
    return [_template_to_schema(t) for t in templates]


@router.post("", response_model=ContentPackTemplateSchema)
def create_template(
    brand_id: int,
    request: ContentPackTemplateCreate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    brand = _get_brand_or_404(db, brand_id, current_user.id)

    template = ContentPackTemplate(
        brand_id=brand.id,
        name=request.name,
        description=request.description,
        pack_data=request.pack_data.model_dump() if request.pack_data else {},
        is_default=request.is_default,
    )
    db.add(template)
    db.commit()
    db.refresh(template)
    return _template_to_schema(template)


@router.get("/{template_id}", response_model=ContentPackTemplateSchema)
def get_template(
    brand_id: int,
    template_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    template = (
        db.query(ContentPackTemplate)
        .filter(
            ContentPackTemplate.id == template_id,
            ContentPackTemplate.brand_id == brand_id,
        )
        .first()
    )
    if not template:
        raise NotFoundError("Content pack template not found")
    return _template_to_schema(template)


@router.put("/{template_id}", response_model=ContentPackTemplateSchema)
def update_template(
    brand_id: int,
    template_id: int,
    request: ContentPackTemplateUpdate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    template = (
        db.query(ContentPackTemplate)
        .filter(
            ContentPackTemplate.id == template_id,
            ContentPackTemplate.brand_id == brand_id,
        )
        .first()
    )
    if not template:
        raise NotFoundError("Content pack template not found")

    update_data = request.model_dump(exclude_none=True)
    if "pack_data" in update_data and update_data["pack_data"] is not None:
        update_data["pack_data"] = (
            update_data["pack_data"].model_dump()
            if hasattr(update_data["pack_data"], "model_dump")
            else update_data["pack_data"]
        )

    for key, value in update_data.items():
        setattr(template, key, value)
    db.commit()
    db.refresh(template)
    return _template_to_schema(template)


@router.delete("/{template_id}")
def delete_template(
    brand_id: int,
    template_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    template = (
        db.query(ContentPackTemplate)
        .filter(
            ContentPackTemplate.id == template_id,
            ContentPackTemplate.brand_id == brand_id,
        )
        .first()
    )
    if not template:
        raise NotFoundError("Content pack template not found")
    db.delete(template)
    db.commit()
    return {"detail": "Content pack template deleted"}


@router.post("/export")
def export_content_pack(
    brand_id: int,
    request: ContentPackExportRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)

    query = db.query(CampaignPost).filter(CampaignPost.campaign_id == request.campaign_id)
    if request.post_ids:
        query = query.filter(CampaignPost.id.in_(request.post_ids))

    posts = query.all()
    if not posts:
        raise NotFoundError("No posts found for the given campaign")

    items = []
    for p in posts:
        items.append(
            {
                "day": p.day,
                "content_theme": p.content_theme,
                "post_idea": p.post_idea,
                "content_type": p.content_type,
                "platform": p.platform,
                "caption": p.caption,
                "call_to_action": p.call_to_action,
                "hashtags": p.hashtags,
            }
        )

    manifest = {
        "format": request.format,
        "campaign_id": request.campaign_id,
        "total_posts": len(items),
        "items": items,
    }
    return manifest
