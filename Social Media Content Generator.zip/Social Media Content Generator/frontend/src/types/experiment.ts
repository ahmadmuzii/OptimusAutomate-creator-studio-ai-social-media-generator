export interface ExperimentVariant {
  id: number
  label: string
  variable_value: string
  content_value: string | null
  status: string
  impressions: number | null
  clicks: number | null
  engagement: number | null
  conversions: number | null
  is_winner: boolean
}

export interface ExperimentVariantCreate {
  label: string
  variable_value: string
  content_value?: string | null
}

export interface Experiment {
  id: number
  brand_id: number
  campaign_id: number | null
  name: string
  variable_tested: string
  success_metric: string | null
  status: string
  variants: ExperimentVariant[]
  created_at: string
}

export interface ExperimentCreate {
  name: string
  campaign_id?: number | null
  variable_tested: string
  success_metric?: string | null
  variants?: ExperimentVariantCreate[]
}

export interface ExperimentUpdate {
  name?: string
  variable_tested?: string
  success_metric?: string | null
  status?: string
}

export interface VariantResultUpdate {
  impressions?: number
  clicks?: number
  engagement?: number
  conversions?: number
}

export interface DeclareWinnerRequest {
  variant_id: number
}
