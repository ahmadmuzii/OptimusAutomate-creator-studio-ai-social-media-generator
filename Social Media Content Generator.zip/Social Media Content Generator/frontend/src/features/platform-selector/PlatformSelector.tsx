import { Instagram } from 'lucide-react'
import { platforms } from '@/config/platforms'
import { PlatformCard } from './PlatformCard'

interface PlatformSelectorProps {
  selected: string
  onSelect: (id: string) => void
}

export function PlatformSelector({ selected, onSelect }: PlatformSelectorProps) {
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
          <Instagram className="w-4 h-4 text-purple-600" />
        </div>
        <h2 className="text-lg font-semibold text-gray-900">Select Platform</h2>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
        {platforms.map((platform) => (
          <PlatformCard
            key={platform.id}
            platform={platform}
            isSelected={selected === platform.id}
            onSelect={onSelect}
          />
        ))}
      </div>
    </div>
  )
}
