import { useState, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Copy, Check, ChevronDown, ChevronUp } from 'lucide-react'
import { tones } from '@/config/tones'
import { platforms } from '@/config/platforms'
import { cn } from '@/utils/cn'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { buildLiveDemo } from '@/lib/buildLiveDemo'
import type { PlatformKey, ToneKey } from '@/data/liveDemoBaseData'

const PLATFORM_MAP: Record<string, PlatformKey> = {
  instagram: 'instagram',
  linkedin: 'linkedin',
  tiktok: 'tiktok',
  facebook: 'facebook',
  twitter: 'x',
}

const TONE_MAP: Record<string, ToneKey> = {
  professional: 'professional',
  funny: 'funny',
  luxury: 'luxury',
  genz: 'genz',
}

export function LiveCampaignExample() {
  const [platform, setPlatform] = useState<PlatformKey>('instagram')
  const [tone, setTone] = useState<ToneKey>('professional')
  const [expandedCaption, setExpandedCaption] = useState<number | null>(null)
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null)
  const reduced = useReducedMotionPreference()

  const activeDemo = useMemo(
    () => buildLiveDemo({ platform, tone }),
    [platform, tone],
  )

  const copyToClipboard = async (text: string, index: number) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedIndex(index)
      setTimeout(() => setCopiedIndex(null), 2000)
    } catch {
      // fallback
    }
  }

  return (
    <section id="live-example" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            Live Campaign Example
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            A complete 7-day campaign for <span className="font-semibold text-purple-700">Urban Brew Studio</span>. Fictional brand, real workflow.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 mb-8 justify-center">
          <span className="text-xs font-medium text-gray-400 mr-2">Platform:</span>
          {platforms.map((p) => {
            const Icon = p.icon
            const key = PLATFORM_MAP[p.id] ?? p.id
            return (
              <button
                key={p.id}
                onClick={() => setPlatform(key as PlatformKey)}
                aria-pressed={platform === key}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all duration-200',
                  platform === key
                    ? 'border-purple-600 bg-purple-50 text-purple-700'
                    : 'border-gray-200 text-gray-500 hover:border-purple-300',
                )}
              >
                <Icon className="w-3.5 h-3.5" />
                {p.name}
              </button>
            )
          })}
          <span className="w-px h-5 bg-gray-200 mx-2" />
          <span className="text-xs font-medium text-gray-400 mr-2">Tone:</span>
          {tones.slice(0, 4).map((t) => {
            const key = TONE_MAP[t.id] ?? t.id
            return (
              <button
                key={t.id}
                onClick={() => setTone(key as ToneKey)}
                aria-pressed={tone === key}
                className={cn(
                  'px-3 py-1.5 rounded-lg text-xs font-medium border transition-all duration-200',
                  tone === key
                    ? 'border-purple-600 bg-purple-50 text-purple-700'
                    : 'border-gray-200 text-gray-500 hover:border-purple-300',
                )}
              >
                {t.emoji} {t.label}
              </button>
            )
          })}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={`${platform}-${tone}`}
            initial={reduced ? undefined : { opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={reduced ? undefined : { opacity: 0, y: -4 }}
            transition={{ duration: 0.18 }}
          >
            <div className="grid md:grid-cols-7 gap-2 mb-8">
              {activeDemo.days.map((d) => (
                <div
                  key={d.day}
                  className="bg-gradient-to-b from-purple-50 to-white rounded-xl border border-purple-100 p-3 text-center"
                >
                  <div className="text-[10px] font-bold text-purple-600 mb-1">Day {d.day}</div>
                  <div className="text-xs font-semibold text-gray-900 leading-tight mb-1">{d.theme}</div>
                  <div className="text-[9px] text-gray-400 truncate">{d.idea.slice(0, 30)}...</div>
                  <div className="text-[8px] text-gray-300 mt-1">{d.contentType} &middot; {d.postingTime}</div>
                </div>
              ))}
            </div>

            <div className="max-w-3xl mx-auto space-y-4">
              {activeDemo.featuredCaptions.map((c, i) => (
                <div key={i} className="bg-gray-50 rounded-xl border border-gray-100 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-purple-600">Day {c.day} Caption</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => copyToClipboard(c.caption, i)}
                        className="text-gray-400 hover:text-purple-600 transition-colors p-1"
                        title="Copy caption"
                      >
                        {copiedIndex === i ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        onClick={() => setExpandedCaption(expandedCaption === i ? null : i)}
                        className="text-gray-400 hover:text-gray-600 transition-colors p-1"
                      >
                        {expandedCaption === i ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                  <p className={cn('text-sm text-gray-700 leading-relaxed', expandedCaption !== i && 'line-clamp-2')}>
                    &ldquo;{c.caption}&rdquo;
                  </p>
                  <div className="mt-2 text-xs text-purple-700 font-medium">
                    CTA: {c.cta}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {activeDemo.hashtags.map((tag) => (
                <span key={tag} className="text-xs px-3 py-1 rounded-full bg-purple-100 text-purple-600 font-medium">
                  {tag}
                </span>
              ))}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  )
}
