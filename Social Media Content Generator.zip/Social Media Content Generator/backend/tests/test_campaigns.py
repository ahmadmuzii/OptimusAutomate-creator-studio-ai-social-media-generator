from __future__ import annotations


class TestCampaigns:
    def test_create_campaign(self, client, auth_headers, sample_campaign_payload):
        response = client.post("/api/v1/campaigns", json=sample_campaign_payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == sample_campaign_payload["name"]
        assert data["platform"] == sample_campaign_payload["platform"]
        assert len(data["posts"]) == 2

    def test_list_campaigns(self, client, auth_headers, created_campaign):
        response = client.get("/api/v1/campaigns", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 1
        assert any(c["id"] == created_campaign["id"] for c in data)

    def test_get_campaign(self, client, auth_headers, created_campaign):
        response = client.get(f"/api/v1/campaigns/{created_campaign['id']}", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["id"] == created_campaign["id"]
        assert len(data["posts"]) == 2

    def test_update_campaign(self, client, auth_headers, created_campaign):
        response = client.put(
            f"/api/v1/campaigns/{created_campaign['id']}",
            json={"name": "Updated Campaign"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Updated Campaign"

    def test_delete_campaign(self, client, auth_headers, created_campaign):
        response = client.delete(f"/api/v1/campaigns/{created_campaign['id']}", headers=auth_headers)
        assert response.status_code == 200
        # Verify it's gone
        response = client.get(f"/api/v1/campaigns/{created_campaign['id']}", headers=auth_headers)
        assert response.status_code == 404

    def test_campaign_not_found(self, client, auth_headers):
        response = client.get("/api/v1/campaigns/99999", headers=auth_headers)
        assert response.status_code == 404

    def test_cannot_access_other_users_campaign(self, client, second_auth_headers, created_campaign):
        response = client.get(f"/api/v1/campaigns/{created_campaign['id']}", headers=second_auth_headers)
        assert response.status_code == 404

    def test_cannot_update_other_users_campaign(self, client, second_auth_headers, created_campaign):
        response = client.put(
            f"/api/v1/campaigns/{created_campaign['id']}",
            json={"name": "Hacked"},
            headers=second_auth_headers,
        )
        assert response.status_code == 404

    def test_cannot_delete_other_users_campaign(self, client, second_auth_headers, created_campaign):
        response = client.delete(f"/api/v1/campaigns/{created_campaign['id']}", headers=second_auth_headers)
        assert response.status_code == 404

    def test_generated_campaign_has_requested_posts(self, client, auth_headers, sample_campaign_payload):
        response = client.post("/api/v1/campaigns", json=sample_campaign_payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert len(data["posts"]) == len(sample_campaign_payload["posts"])

    def test_captions_are_non_empty(self, client, auth_headers, sample_campaign_payload):
        response = client.post("/api/v1/campaigns", json=sample_campaign_payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        for post in data["posts"]:
            assert post["caption"], f"Post {post['day']} has empty caption"

    def test_hashtags_stored_correctly(self, client, auth_headers, sample_campaign_payload):
        response = client.post("/api/v1/campaigns", json=sample_campaign_payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        for post in data["posts"]:
            assert isinstance(post["hashtags"], list)
            if post["hashtags"]:
                for tag in post["hashtags"]:
                    assert isinstance(tag, str)
