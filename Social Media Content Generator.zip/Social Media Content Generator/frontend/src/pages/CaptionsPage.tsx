import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Copy, Search, X, ArrowRight,
} from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useGuestMode } from '@/context/GuestModeContext'
import * as api from '@/api/endpoints'
import type { CampaignData, CampaignPost, RefinementAction, SupportedTone } from '@/types/common'
import { guestCampaigns } from '@/data/guestDemoData'
import { PageTransition } from '@/components/layout/PageTransition'
import { useToast } from '@/components/ui/Toast'
import { Skeleton, CaptionSkeleton } from '@/components/ui/Skeleton'
import { PostRefinementMenu } from '@/components/common/PostRefinementMenu'
import { InlineRefinementError } from '@/components/common/InlineRefinementError'
import { useRefineCampaignPost } from '@/hooks/useRefineCampaignPost'
import { SUPPORTED_PLATFORMS } from '@/config/platforms'
import { getPlatformDisplayName, normalizePlatform } from '@/utils/platforms'
import { ROUTES } from '@/routes/paths'

interface PostWithMeta extends CampaignPost {
  campaignName: string
  campaignPlatform: string
  campaignTone: string
  campaignId: number
}

const STATUS_OPTIONS = [
  { value: '', label: 'All statuses' },
  { value: 'draft', label: 'Draft' },
  { value: 'scheduled', label: 'Scheduled' },
  { value: 'published', label: 'Published' },
]

export function CaptionsPage() {
  const { showToast } = useToast()
  const { isAuthenticated } = useAuth()
  const { isGuestMode } = useGuestMode()
  const isDemo = isGuestMode && !isAuthenticated
  const [campaigns, setCampaigns] = useState<CampaignData[]>([])
  const [loading, setLoading] = useState(true)
  const [expandedId, setExpandedId] = useState<number | null>(null)
  const [refinementCampaignId, setRefinementCampaignId] = useState<number>(0)
  const [searchParams, setSearchParams] = useSearchParams()

  const search = searchParams.get('search') || ''
  const platformFilter = searchParams.get('platform') || ''
  const statusFilter = searchParams.get('status') || ''

  const setFilter = (key: string, value: string) => {
    setSearchParams((prev) => {
      if (value) {
        prev.set(key, value)
      } else {
        prev.delete(key)
      }
      return prev
    }, { replace: true })
  }

  const {
    refining,
    refiningPostId,
    error: refineError,
    refine,
    clearError: clearRefineError,
  } = useRefineCampaignPost(refinementCampaignId)

  useEffect(() => {
    if (isDemo) {
      setCampaigns(guestCampaigns)
      setLoading(false)
      return
    }
    api.fetchCampaigns()
      .then(setCampaigns)
      .catch(() => setCampaigns([]))
      .finally(() => setLoading(false))
  }, [isDemo])

  const allPosts = useMemo(() =>
    campaigns.flatMap((c) =>
      (c.posts || []).map((p) => ({
        ...p,
        campaignName: c.name,
        campaignPlatform: c.platform,
        campaignTone: c.tone,
        campaignId: c.id,
      }))
    ), [campaigns])

  const platformCounts = useMemo(() => {
    const counts: Record<string, number> = {}
    for (const p of allPosts) {
      const key = normalizePlatform(p.platform) || '__other__'
      counts[key] = (counts[key] || 0) + 1
    }
    return counts
  }, [allPosts])

  const filtered = useMemo(() => {
    let result = [...allPosts]
    if (search.trim()) {
      const q = search.toLowerCase()
      result = result.filter((p) =>
        p.caption.toLowerCase().includes(q) ||
        p.content_theme.toLowerCase().includes(q) ||
        p.post_idea.toLowerCase().includes(q) ||
        p.campaignName.toLowerCase().includes(q)
      )
    }
    if (platformFilter && platformFilter !== 'all') {
      const canonical = platformFilter as string
      result = result.filter((p) => normalizePlatform(p.platform) === canonical)
    }
    if (statusFilter) result = result.filter((p) => p.status === statusFilter)
    return result
  }, [allPosts, search, platformFilter, statusFilter])

  const selectedPlatformLabel = useMemo(() => {
    if (!platformFilter || platformFilter === 'all') return null
    const entry = SUPPORTED_PLATFORMS.find((sp) => sp.value === platformFilter)
    return entry?.label || platformFilter
  }, [platformFilter])

  const handleCopy = async (post: PostWithMeta) => {
    const text = `${post.caption}\n\n${post.call_to_action || ''}\n\n${(post.hashtags || []).map((h) => `#${h}`).join(' ')}`
    try {
      await navigator.clipboard.writeText(text)
      showToast('Caption copied', 'success')
    } catch {
      showToast('Failed to copy.', 'error')
    }
  }

  const handleRefine = async (post: PostWithMeta, action: RefinementAction, targetTone?: SupportedTone | null, customInstruction?: string | null) => {
    setRefinementCampaignId(post.campaignId)
    const updated = await refine(post, action, targetTone, customInstruction)
    if (updated) {
      setCampaigns((prev) =>
        prev.map((c) =>
          c.id === post.campaignId
            ? { ...c, posts: (c.posts || []).map((p) => (p.id === updated.id ? updated : p)) }
            : c,
        ),
      )
      showToast('Post updated successfully', 'success')
    }
  }

  const isLong = (text: string) => text.length > 200

  if (loading) {
    return (
      <PageTransition>
        <div className="max-w-5xl mx-auto space-y-6">
          <Skeleton className="h-7 w-24 mb-2" />
          <Skeleton className="h-4 w-36" />
          {Array.from({ length: 4 }).map((_, i) => <CaptionSkeleton key={i} />)}
        </div>
      </PageTransition>
    )
  }

  return (
    <PageTransition>
      <div className="max-w-5xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Captions</h1>
          <p className="text-gray-500 mt-1">Browse, edit, and manage your post captions.</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              value={search}
              onChange={(e) => setFilter('search', e.target.value)}
              placeholder="Search captions..."
              className="pl-9 pr-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500 text-sm w-full"
            />
          </div>
          <select
            value={platformFilter || 'all'}
            onChange={(e) => setFilter('platform', e.target.value === 'all' ? '' : e.target.value)}
            aria-label="Filter by platform"
            className="px-3 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-sm bg-white text-gray-700"
          >
            {SUPPORTED_PLATFORMS.map((sp) => {
              const count = sp.value === 'all'
                ? allPosts.length
                : (platformCounts[sp.value] || 0)
              return (
                <option key={sp.value} value={sp.value}>
                  {sp.label} ({count})
                </option>
              )
            })}
          </select>
          <select
            value={statusFilter}
            onChange={(e) => setFilter('status', e.target.value)}
            aria-label="Filter by status"
            className="px-3 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-sm bg-white text-gray-700"
          >
            {STATUS_OPTIONS.map((so) => (
              <option key={so.value} value={so.value}>{so.label}</option>
            ))}
          </select>
          {(search || platformFilter || statusFilter) && (
            <button onClick={() => { setSearchParams({}, { replace: true }) }}
              className="flex items-center gap-1 text-xs text-gray-500 hover:text-gray-700 px-2 py-1">
              <X className="w-3 h-3" /> Clear
            </button>
          )}
        </div>

        {filtered.length === 0 && (
          <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
            {search || statusFilter ? (
              <p className="text-gray-400 text-sm">No captions match your filters.</p>
            ) : platformFilter && platformFilter !== 'all' && selectedPlatformLabel ? (
              <>
                <p className="text-gray-400 text-sm mb-1">No {selectedPlatformLabel} captions found</p>
                <p className="text-gray-400 text-xs mb-4">Generate a {selectedPlatformLabel} campaign to see its captions here.</p>
                <a
                  href={`${ROUTES.generate}?platform=${platformFilter}`}
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-purple-600 hover:text-purple-700"
                >
                  Generate {selectedPlatformLabel} Campaign <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </>
            ) : (
              <p className="text-gray-400 text-sm">No captions yet. Generate a campaign first!</p>
            )}
          </div>
        )}

        {filtered.length > 0 && (
          <div className="space-y-4">
            {filtered.map((post, i) => {
              const long = isLong(post.caption)
              const expanded = expandedId === post.id
              return (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.02, duration: 0.2 }}
                  className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-all duration-200"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="text-xs font-medium bg-purple-50 text-purple-700 px-2 py-0.5 rounded-full">
                          Day {post.day}
                        </span>
                        <span className="text-xs text-gray-400">{getPlatformDisplayName(post.platform)}</span>
                        <span className="text-xs text-gray-300">&middot;</span>
                        <span className="text-xs text-gray-500 font-medium">{post.campaignName}</span>
                        <span className="text-xs text-gray-300">&middot;</span>
                        <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${
                          post.status === 'published' ? 'bg-green-50 text-green-700 border-green-200' :
                          post.status === 'scheduled' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                          'bg-yellow-50 text-yellow-700 border-yellow-200'
                        }`}>
                          {post.status}
                        </span>
                      </div>
                      <p className="text-sm font-medium text-gray-900">{post.content_theme}</p>
                    </div>
                  </div>

                  <div className="text-sm text-gray-700 leading-relaxed mb-3">
                    {long && !expanded ? (
                      <>{post.caption.slice(0, 200)}... </>
                    ) : post.caption}
                    {long && (
                      <button
                        onClick={() => setExpandedId(expanded ? null : post.id)}
                        className="text-purple-600 hover:text-purple-800 text-xs font-medium ml-1"
                      >
                        {expanded ? 'Show less' : 'Show more'}
                      </button>
                    )}
                  </div>

                  {post.call_to_action && (
                    <p className="text-sm text-purple-600 font-medium mb-2">CTA: {post.call_to_action}</p>
                  )}

                  {post.hashtags && post.hashtags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {post.hashtags.map((h, i) => (
                        <span key={i} className="text-xs bg-gray-50 text-gray-600 px-2 py-0.5 rounded-full">
                          #{h}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center gap-1 pt-2 border-t border-gray-50">
                    <button onClick={() => handleCopy(post)}
                      className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg hover:bg-gray-100 text-gray-600 transition-colors"
                      title="Copy">
                      <Copy className="w-3.5 h-3.5" />
                      Copy
                    </button>
                    {!isDemo && (
                      <PostRefinementMenu
                        post={post}
                        isRefining={refining && refiningPostId === post.id}
                        hasRevisions={false}
                        onRefine={(action, tone, instruction) => handleRefine(post, action, tone, instruction)}
                        onUndo={() => {}}
                        onShowHistory={() => {}}
                      />
                    )}
                  </div>
                  {refineError && refiningPostId === post.id && (
                    <div className="mt-2">
                      <InlineRefinementError message={refineError} onDismiss={clearRefineError} />
                    </div>
                  )}
                </motion.div>
              )
            })}
          </div>
        )}
      </div>
    </PageTransition>
  )
}
