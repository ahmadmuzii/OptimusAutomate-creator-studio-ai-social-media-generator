import { MessageSquare, Megaphone, Hash } from 'lucide-react'
import type { CaptionCardData } from '@/types/caption'
import { cn } from '@/utils/cn'
import { getPlatformIcon, getPlatformGradient } from '@/utils/platforms'
import { ClipboardButton } from './ClipboardButton'
import { HashtagDisplay } from './HashtagDisplay'

interface CaptionCardProps {
  data: CaptionCardData
  isCopied: boolean
  onCopy: () => void
}

function PlatformIcon({ platform }: { platform: string }) {
  const Icon = getPlatformIcon(platform)
  return <Icon className="w-4 h-4" />
}

export function CaptionCard({ data, isCopied, onCopy }: CaptionCardProps) {
  return (
    <div className="caption-card group">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className={cn('w-8 h-8 rounded-lg bg-gradient-to-r flex items-center justify-center text-white', getPlatformGradient(data.platform))}>
            <PlatformIcon platform={data.platform} />
          </div>
          <div>
            <span className="text-sm font-semibold text-gray-900">Day {data.day}</span>
            <span className="text-xs text-gray-400 ml-2">{data.platform}</span>
          </div>
        </div>
        <ClipboardButton
          isCopied={isCopied}
          onCopy={onCopy}
        />
      </div>

      <div className="mb-4">
        <p className="text-sm text-gray-400 mb-1.5 flex items-center gap-1.5">
          <MessageSquare className="w-3.5 h-3.5" />
          Caption
        </p>
        <p className="text-gray-800 text-sm leading-relaxed bg-gray-50 rounded-xl p-4">
          {data.caption}
        </p>
      </div>

      <div className="mb-4">
        <p className="text-sm text-gray-400 mb-1.5 flex items-center gap-1.5">
          <Megaphone className="w-3.5 h-3.5" />
          Call to Action
        </p>
        <p className="text-purple-700 font-medium text-sm bg-purple-50 rounded-xl p-3">
          {data.callToAction}
        </p>
      </div>

      <div>
        <p className="text-sm text-gray-400 mb-1.5 flex items-center gap-1.5">
          <Hash className="w-3.5 h-3.5" />
          Hashtags
        </p>
        <HashtagDisplay hashtags={data.hashtags} />
      </div>
    </div>
  )
}
