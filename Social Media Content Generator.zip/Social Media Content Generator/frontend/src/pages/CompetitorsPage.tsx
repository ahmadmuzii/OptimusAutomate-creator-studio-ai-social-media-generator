import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'
import { ArrowLeft, Plus, Trash2, Swords, BarChart3, Loader2, ChevronDown, ChevronRight, Search, TrendingUp } from 'lucide-react'
import { ErrorState } from '@/components/ui/ErrorState'
import { LoadingSpinner } from '@/components/ui/LoadingSpinner'
import * as api from '@/api/endpoints'
import type { CompetitorProfile, CompetitorPost, GapReport, GapReportData } from '@/types/competitor'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'
import { GapSummaryCards } from '@/components/competitors/GapSummaryCards'
import { TopicCoverageChart } from '@/components/competitors/TopicCoverageChart'
import { CompetitorContentMixChart } from '@/components/competitors/CompetitorContentMixChart'
import { ContentOpportunityChart } from '@/components/competitors/ContentOpportunityChart'
import { OpportunityTable } from '@/components/competitors/OpportunityTable'

const PLATFORMS = ['Instagram', 'Facebook', 'Twitter', 'LinkedIn', 'TikTok', 'YouTube', 'Pinterest', 'Snapchat']

type Tab = 'competitors' | 'gap-analysis'

export function CompetitorsPage() {
  const { brandId, brand } = useBrandWorkspace()

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [activeTab, setActiveTab] = useState<Tab>('competitors')
  const [competitors, setCompetitors] = useState<CompetitorProfile[]>([])
  const [expandedCompId, setExpandedCompId] = useState<number | null>(null)
  const [compPosts, setCompPosts] = useState<Record<number, CompetitorPost[]>>({})
  const [loadingPosts, setLoadingPosts] = useState<Record<number, boolean>>({})

  const [showAddModal, setShowAddModal] = useState(false)
  const [addForm, setAddForm] = useState({ name: '', platform: '', public_handle: '', website: '', notes: '' })
  const [saving, setSaving] = useState(false)

  const [showAddPostModal, setShowAddPostModal] = useState(false)
  const [addPostForComp, setAddPostForComp] = useState<number | null>(null)
  const [postForm, setPostForm] = useState({ caption: '', content_type: '', platform: '', cta_style: '', hook_type: '', topics: '' })
  const [savingPost, setSavingPost] = useState(false)

  const [gapReports, setGapReports] = useState<GapReport[]>([])
  const [analyzing, setAnalyzing] = useState(false)
  const [loadingGaps, setLoadingGaps] = useState(false)

  const loadCompetitors = useCallback(async () => {
    const data = await api.fetchCompetitors(brandId)
    setCompetitors(data as CompetitorProfile[])
  }, [brandId])

  useEffect(() => {
    loadCompetitors()
      .catch(() => setError('Could not load competitors.'))
      .finally(() => setLoading(false))
  }, [brandId, loadCompetitors])

  const loadGapReports = async () => {
    setLoadingGaps(true)
    try {
      const data = await api.fetchGapReports(brandId)
      setGapReports(data as GapReport[])
    } catch { setError('Could not load gap reports.') }
    finally { setLoadingGaps(false) }
  }

  useEffect(() => {
    if (activeTab === 'gap-analysis') loadGapReports()
  }, [activeTab, brandId]) // eslint-disable-line react-hooks/exhaustive-deps

  const toggleExpand = async (compId: number) => {
    if (expandedCompId === compId) { setExpandedCompId(null); return }
    setExpandedCompId(compId)
    if (!compPosts[compId]) {
      setLoadingPosts(prev => ({ ...prev, [compId]: true }))
      try {
        const data = await api.fetchCompetitorPosts(brandId, compId)
        setCompPosts(prev => ({ ...prev, [compId]: data as CompetitorPost[] }))
      } catch (_err) { /* silently ignore */ }
      finally { setLoadingPosts(prev => ({ ...prev, [compId]: false })) }
    }
  }

  const handleAddCompetitor = async () => {
    if (!addForm.name.trim()) return
    setSaving(true)
    try {
      await api.createCompetitor(brandId, addForm)
      const data = await api.fetchCompetitors(brandId)
      setCompetitors(data as CompetitorProfile[])
      setShowAddModal(false)
      setAddForm({ name: '', platform: '', public_handle: '', website: '', notes: '' })
    } catch { setError('Failed to add competitor.') }
    finally { setSaving(false) }
  }

  const handleDeleteCompetitor = async (compId: number) => {
    try {
      await api.deleteCompetitor(brandId, compId)
      setCompetitors(prev => prev.filter(c => c.id !== compId))
      setCompPosts(prev => { const n = { ...prev }; delete n[compId]; return n })
    } catch { setError('Failed to delete competitor.') }
  }

  const handleAddPost = async () => {
    if (!addPostForComp) return
    setSavingPost(true)
    try {
      const payload: Record<string, unknown> = {
        caption: postForm.caption || null,
        content_type: postForm.content_type || null,
        platform: postForm.platform || null,
        cta_style: postForm.cta_style || null,
        hook_type: postForm.hook_type || null,
        topics: postForm.topics ? postForm.topics.split(',').map(t => t.trim()) : [],
      }
      await api.addCompetitorPost(brandId, addPostForComp, payload)
      const data = await api.fetchCompetitorPosts(brandId, addPostForComp)
      setCompPosts(prev => ({ ...prev, [addPostForComp]: data as CompetitorPost[] }))
      setShowAddPostModal(false)
      setAddPostForComp(null)
      setPostForm({ caption: '', content_type: '', platform: '', cta_style: '', hook_type: '', topics: '' })
    } catch { setError('Failed to add post.') }
    finally { setSavingPost(false) }
  }

  const handleDeletePost = async (postId: number, compId: number) => {
    try {
      await api.deleteCompetitorPost(brandId, postId)
      setCompPosts(prev => ({
        ...prev,
        [compId]: (prev[compId] || []).filter(p => p.id !== postId),
      }))
    } catch { setError('Failed to delete post.') }
  }

  const handleRunAnalysis = async () => {
    setAnalyzing(true)
    try {
      await api.analyzeGaps(brandId)
      await loadGapReports()
    } catch { setError('Analysis failed.') }
    finally { setAnalyzing(false) }
  }

  if (loading) return <LoadingSpinner />

  if (error) return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>
      <ErrorState message={error} onRetry={loadCompetitors} />
    </div>
  )

  const tabs: { key: Tab; label: string; icon: typeof Swords }[] = [
    { key: 'competitors', label: 'Competitors', icon: Swords },
    { key: 'gap-analysis', label: 'Gap Analysis', icon: BarChart3 },
  ]

  return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Swords className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Competitors</h1>
        </div>
      </div>

      <div className="flex items-center gap-2 border-b border-gray-100 pb-3">
        {tabs.map(tab => {
          const Icon = tab.icon
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`text-sm font-medium px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
                activeTab === tab.key
                  ? 'bg-purple-50 text-purple-700'
                  : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          )
        })}
      </div>

      {activeTab === 'competitors' && (
        <>
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-500">Track competitor content and analyze their strategies.</p>
            <Button onClick={() => setShowAddModal(true)} className="flex items-center gap-2">
              <Plus className="w-4 h-4" /> Add Competitor
            </Button>
          </div>

          {competitors.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
              <Swords className="w-8 h-8 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-400 text-sm mb-4">No competitors tracked yet.</p>
              <Button onClick={() => setShowAddModal(true)} className="mx-auto flex items-center gap-2">
                <Plus className="w-4 h-4" /> Add Your First Competitor
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {competitors.map(comp => (
                <div key={comp.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                  <div className="p-5">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <button onClick={() => toggleExpand(comp.id)} className="p-1 text-gray-400 hover:text-gray-600">
                          {expandedCompId === comp.id ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                        </button>
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center text-white font-bold text-sm shrink-0">
                          {comp.name.charAt(0).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <h3 className="font-semibold text-gray-900 text-sm">{comp.name}</h3>
                          {comp.public_handle && (
                            <p className="text-xs text-gray-400 mt-0.5">@{comp.public_handle}</p>
                          )}
                        </div>
                        {comp.platform && (
                          <span className="text-xs font-medium bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full shrink-0">
                            {comp.platform}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1 ml-2">
                        <Button variant="secondary" size="sm" onClick={() => { setAddPostForComp(comp.id); setShowAddPostModal(true) }}>
                          <Plus className="w-3.5 h-3.5" /> Post
                        </Button>
                        <button onClick={() => handleDeleteCompetitor(comp.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                    {comp.website && <a href={comp.website} target="_blank" rel="noopener noreferrer" className="text-xs text-purple-600 hover:text-purple-800 ml-9">{comp.website}</a>}
                    {comp.notes && <p className="text-xs text-gray-500 mt-1 ml-9">{comp.notes}</p>}
                  </div>

                  {expandedCompId === comp.id && (
                    <div className="border-t border-gray-50 px-5 py-4 bg-gray-50/50 space-y-3">
                      {loadingPosts[comp.id] ? (
                        <div className="flex items-center justify-center py-4">
                          <Loader2 className="w-5 h-5 animate-spin text-purple-600" />
                        </div>
                      ) : (compPosts[comp.id] || []).length === 0 ? (
                        <p className="text-xs text-gray-400 text-center py-4">No posts tracked yet for this competitor.</p>
                      ) : (
                        (compPosts[comp.id] || []).map(post => (
                          <div key={post.id} className="bg-white rounded-xl border border-gray-100 p-4 text-sm">
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex items-center gap-2">
                                {post.platform && <span className="text-xs font-medium bg-gray-100 text-gray-600 px-2 py-0.5 rounded">{post.platform}</span>}
                                {post.content_type && <span className="text-xs text-gray-400">{post.content_type}</span>}
                              </div>
                              <button onClick={() => handleDeletePost(post.id, comp.id)} className="p-1 rounded hover:bg-red-50 text-gray-400 hover:text-red-500">
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            {post.caption && <p className="text-gray-700 mb-2">{post.caption}</p>}
                            <div className="flex flex-wrap gap-2 text-xs text-gray-400">
                              {post.cta_style && <span>CTA: {post.cta_style}</span>}
                              {post.hook_type && <span>Hook: {post.hook_type}</span>}
                              {post.topics && post.topics.length > 0 && (
                                <span>Topics: {post.topics.join(', ')}</span>
                              )}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {activeTab === 'gap-analysis' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-500">Identify content topics your brand is missing compared to competitors.</p>
            <Button onClick={handleRunAnalysis} disabled={analyzing} loading={analyzing} className="flex items-center gap-2">
              <Search className="w-4 h-4" />
              {analyzing ? 'Analyzing...' : 'Run Analysis'}
            </Button>
          </div>

          {loadingGaps ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-purple-600" />
            </div>
          ) : gapReports.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
              <TrendingUp className="w-8 h-8 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-400 text-sm mb-4">No gap analysis reports yet.</p>
              <Button onClick={handleRunAnalysis} disabled={analyzing} loading={analyzing} className="mx-auto flex items-center gap-2">
                <Search className="w-4 h-4" />
                Run First Analysis
              </Button>
            </div>
          ) : (
            gapReports.map(report => {
              const rd = report.report_data as GapReportData | null
              const isNewReport = rd?.summary && rd?.topic_coverage && rd?.opportunities
              const hasEnoughData = rd?.summary?.posts_analyzed && rd.summary.posts_analyzed >= 2

              return (
                <div key={report.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                  <div className="p-5 border-b border-gray-50">
                    <div className="flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-purple-600" />
                      <h3 className="font-semibold text-gray-900">Gap Report {new Date(report.created_at).toLocaleDateString()}</h3>
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${report.status === 'completed' ? 'bg-green-50 text-green-700' : 'bg-yellow-50 text-yellow-700'}`}>{report.status}</span>
                    </div>
                  </div>

                  <div className="p-5 space-y-6">
                    {rd && isNewReport && hasEnoughData && (
                      <>
                        <GapSummaryCards summary={rd.summary} />

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                          <TopicCoverageChart data={rd.topic_coverage} />
                          <CompetitorContentMixChart data={rd.content_mix} />
                        </div>

                        <ContentOpportunityChart data={rd.opportunities} />

                        <OpportunityTable data={rd.opportunities} />
                      </>
                    )}

                    {rd && isNewReport && !hasEnoughData && (
                      <div className="bg-gray-50 rounded-xl p-8 text-center">
                        <TrendingUp className="w-8 h-8 text-gray-300 mx-auto mb-3" />
                        <p className="text-gray-500 font-medium">Not enough competitor content yet</p>
                        <p className="text-gray-400 text-sm mt-1">Add more competitor posts to generate a meaningful comparison.</p>
                      </div>
                    )}

                    {rd && !isNewReport && Array.isArray(rd.recommendations) && rd.recommendations.length > 0 && (
                      <div>
                        <p className="text-sm text-gray-500 mb-3">This report was created with an older format. <button onClick={handleRunAnalysis} disabled={analyzing} className="text-purple-600 hover:text-purple-800 underline">Rerun analysis</button> for enhanced visualizations.</p>
                        <div>
                          <h4 className="text-sm font-medium text-gray-700 mb-2 flex items-center gap-1.5">
                            <TrendingUp className="w-4 h-4 text-green-500" /> Recommendations
                          </h4>
                          <ul className="space-y-1">
                            {rd.recommendations.map((rec, i) => (
                              <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                                <span className="text-purple-600 mt-0.5">&#8226;</span>
                                {rec}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}

                    {rd && !isNewReport && (!Array.isArray(rd.recommendations) || rd.recommendations.length === 0) && (
                      <p className="text-sm text-gray-400 text-center py-4">No recommendations available for this report.</p>
                    )}
                  </div>
                </div>
              )
            })
          )}
        </div>
      )}

      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={() => setShowAddModal(false)}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-md max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">Add Competitor</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Name *</label>
                <input value={addForm.name} onChange={e => setAddForm(prev => ({ ...prev, name: e.target.value }))} placeholder="e.g., Competitor Inc." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Platform</label>
                <select value={addForm.platform} onChange={e => setAddForm(prev => ({ ...prev, platform: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                  <option value="">Select platform</option>
                  {PLATFORMS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Public Handle</label>
                <input value={addForm.public_handle} onChange={e => setAddForm(prev => ({ ...prev, public_handle: e.target.value }))} placeholder="@handle" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Website</label>
                <input value={addForm.website} onChange={e => setAddForm(prev => ({ ...prev, website: e.target.value }))} placeholder="https://" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Notes</label>
                <textarea value={addForm.notes} onChange={e => setAddForm(prev => ({ ...prev, notes: e.target.value }))} rows={3} placeholder="Additional notes..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div className="flex items-center gap-3 pt-4">
                <Button onClick={handleAddCompetitor} disabled={saving || !addForm.name.trim()}>{saving ? 'Saving...' : 'Add Competitor'}</Button>
                <button onClick={() => setShowAddModal(false)} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showAddPostModal && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={() => setShowAddPostModal(false)}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-md max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">Add Post</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Caption</label>
                <textarea value={postForm.caption} onChange={e => setPostForm(prev => ({ ...prev, caption: e.target.value }))} rows={3} placeholder="Post caption..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Content Type</label>
                <input value={postForm.content_type} onChange={e => setPostForm(prev => ({ ...prev, content_type: e.target.value }))} placeholder="e.g., carousel" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Platform</label>
                <select value={postForm.platform} onChange={e => setPostForm(prev => ({ ...prev, platform: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                  <option value="">Select platform</option>
                  {PLATFORMS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">CTA Style</label>
                <input value={postForm.cta_style} onChange={e => setPostForm(prev => ({ ...prev, cta_style: e.target.value }))} placeholder="e.g., link in bio" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Hook Type</label>
                <input value={postForm.hook_type} onChange={e => setPostForm(prev => ({ ...prev, hook_type: e.target.value }))} placeholder="e.g., question" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Topics (comma separated)</label>
                <input value={postForm.topics} onChange={e => setPostForm(prev => ({ ...prev, topics: e.target.value }))} placeholder="e.g., marketing, SEO" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div className="flex items-center gap-3 pt-4">
                <Button onClick={handleAddPost} disabled={savingPost}>{savingPost ? 'Saving...' : 'Add Post'}</Button>
                <button onClick={() => { setShowAddPostModal(false); setAddPostForComp(null) }} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
