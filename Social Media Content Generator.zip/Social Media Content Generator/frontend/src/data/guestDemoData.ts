import type { CampaignData, BrandProfile, CampaignPost } from '@/types/common'

function daysAgo(n: number): string {
  const d = new Date()
  d.setDate(d.getDate() - n)
  return d.toISOString()
}

export const guestCampaignPosts: Record<string, CampaignPost[]> = {
  'demo-campaign-1': [
    {
      id: 10001,
      day: 1,
      content_theme: 'Brand Story',
      post_idea: 'Introduce your brand mission and values',
      content_type: 'Carousel',
      suggested_time: '09:00',
      platform: 'Instagram',
      caption:
        'Every brand has a story. Here\'s ours. We started with a simple idea: make creative tools accessible to everyone. Swipe through to see our journey from concept to launch. What\'s your brand story?',
      call_to_action: 'Share your story in the comments',
      hashtags: ['brandstory', 'creatoreconomy', 'missiondriven'],
      status: 'published',
      scheduled_date: daysAgo(7),
    },
    {
      id: 10002,
      day: 1,
      content_theme: 'Brand Story',
      post_idea: 'Behind the scenes of our creative process',
      content_type: 'Video',
      suggested_time: '12:00',
      platform: 'TikTok',
      caption:
        'Ever wondered how we create our content? Here\'s a sneak peek behind the scenes! 🎬 From brainstorming to final edit, every step is fueled by passion and creativity.',
      call_to_action: 'Follow for more BTS content',
      hashtags: ['behindthescenes', 'contentcreation', 'creativelife'],
      status: 'published',
      scheduled_date: daysAgo(7),
    },
    {
      id: 10003,
      day: 2,
      content_theme: 'Product Spotlight',
      post_idea: 'Highlight key features of Creator Studio',
      content_type: 'Carousel',
      suggested_time: '10:00',
      platform: 'Instagram',
      caption:
        '5 features that make Creator Studio your ultimate content companion. From AI-powered captions to smart scheduling, we\'ve packed everything you need into one platform.',
      call_to_action: 'Try it free today',
      hashtags: ['contenttools', 'socialmediamarketing', 'creatorsuite'],
      status: 'published',
      scheduled_date: daysAgo(6),
    },
    {
      id: 10004,
      day: 2,
      content_theme: 'Tips & Tutorials',
      post_idea: 'How to write engaging captions',
      content_type: 'Carousel',
      suggested_time: '14:00',
      platform: 'LinkedIn',
      caption:
        'Writing captions that convert: a simple framework. 1. Hook them in the first line. 2. Provide value. 3. End with a clear CTA. Save this for your next post!',
      call_to_action: 'Save and share with your team',
      hashtags: ['contentwriting', 'socialmediastrategy', 'marketingtips'],
      status: 'published',
      scheduled_date: daysAgo(6),
    },
    {
      id: 10005,
      day: 3,
      content_theme: 'Social Proof',
      post_idea: 'Customer testimonial highlight',
      content_type: 'Static Image',
      suggested_time: '11:00',
      platform: 'Twitter',
      caption:
        '"Creator Studio cut our content planning time in half." — Sarah, Marketing Lead at GrowthStack. See why teams are switching to smarter content tools.',
      call_to_action: 'Read more case studies',
      hashtags: ['customerlove', 'testimonial', 'contentstrategy'],
      status: 'published',
      scheduled_date: daysAgo(5),
    },
    {
      id: 10006,
      day: 3,
      content_theme: 'Industry Insights',
      post_idea: 'Social media trends this quarter',
      content_type: 'Video',
      suggested_time: '16:00',
      platform: 'TikTok',
      caption:
        'The top 3 social media trends you need to know this quarter 📊 Short-form video is dominating. AI tools are becoming essential. Community building is the new marketing.',
      call_to_action: 'Which trend are you trying?',
      hashtags: ['socialmediatrends', 'marketing2025', 'trendalert'],
      status: 'scheduled',
      scheduled_date: daysAgo(5),
    },
    {
      id: 10007,
      day: 4,
      content_theme: 'Educational',
      post_idea: 'Content calendar best practices',
      content_type: 'Carousel',
      suggested_time: '09:30',
      platform: 'LinkedIn',
      caption:
        'A content calendar isn\'t just a schedule — it\'s your strategic roadmap. Here\'s how to build one that actually works. Plan themes, not just posts. Batch your creation. Leave room for spontaneity.',
      call_to_action: 'Download our free template',
      hashtags: ['contentcalendar', 'socialmediaplanning', 'contentstrategy'],
      status: 'scheduled',
      scheduled_date: daysAgo(4),
    },
    {
      id: 10008,
      day: 5,
      content_theme: 'Engagement',
      post_idea: 'Poll your audience about content preferences',
      content_type: 'Static Image',
      suggested_time: '12:00',
      platform: 'Instagram',
      caption:
        'We want to hear from you! What type of content do you want to see more of? Drop your answer in the comments 👇',
      call_to_action: 'Vote in the comments',
      hashtags: ['community', 'audienceengagement', 'contentpreferences'],
      status: 'draft',
      scheduled_date: null,
    },
    {
      id: 10009,
      day: 6,
      content_theme: 'Value Proposition',
      post_idea: 'Comparison: manual vs AI-assisted content creation',
      content_type: 'Carousel',
      suggested_time: '10:00',
      platform: 'Instagram',
      caption:
        'Manual vs AI-assisted content creation: the numbers don\'t lie. 5 hours vs 30 minutes. 3 platforms vs 7 platforms. 1 campaign vs 10 campaigns. The choice is clear.',
      call_to_action: 'Start your free trial',
      hashtags: ['aicontent', 'productivity', 'creatortips'],
      status: 'draft',
      scheduled_date: null,
    },
    {
      id: 10010,
      day: 7,
      content_theme: 'Wrap Up',
      post_idea: 'Weekly roundup of top posts',
      content_type: 'Static Image',
      suggested_time: '17:00',
      platform: 'Twitter',
      caption:
        'This week\'s top posts: the content that resonated most with our community. Thank you for being part of this journey! See you next week.',
      call_to_action: 'Tag someone who needs to see this',
      hashtags: ['weeklyroundup', 'communitylove', 'contentcreator'],
      status: 'draft',
      scheduled_date: null,
    },
  ],
}

export const guestCampaigns: CampaignData[] = [
  {
    id: 1,
    name: 'Demo Campaign — Brand Launch',
    platform: 'Instagram',
    tone: 'professional',
    campaign_goal: 'brand_awareness',
    status: 'active',
    brand_profile_id: 1,
    posts: guestCampaignPosts['demo-campaign-1'] ?? null,
    created_at: daysAgo(14),
    updated_at: daysAgo(1),
  },
  {
    id: 2,
    name: 'Demo Campaign — Product Showcase',
    platform: 'LinkedIn',
    tone: 'professional',
    campaign_goal: 'lead_generation',
    status: 'active',
    brand_profile_id: 1,
    posts: [
      {
        id: 20001,
        day: 1,
        content_theme: 'Thought Leadership',
        post_idea: 'Why consistency matters in branding',
        content_type: 'Article',
        suggested_time: '08:00',
        platform: 'LinkedIn',
        caption:
          'Consistency is the secret ingredient behind every memorable brand. When your audience knows what to expect, trust builds naturally. Here\'s how to maintain brand consistency across every touchpoint.',
        call_to_action: 'Share your consistency tips',
        hashtags: ['branding', 'consistency', 'marketingstrategy'],
        status: 'published',
        scheduled_date: daysAgo(3),
      },
      {
        id: 20002,
        day: 3,
        content_theme: 'Data & Insights',
        post_idea: 'Content marketing ROI statistics',
        content_type: 'Infographic',
        suggested_time: '10:00',
        platform: 'LinkedIn',
        caption:
          'Content marketing delivers 3x more leads than paid advertising. Companies that blog get 67% more leads. Yet only 30% of brands have a documented strategy. The data speaks for itself.',
        call_to_action: 'Download the full report',
        hashtags: ['contentmarketing', 'roi', 'marketingdata'],
        status: 'published',
        scheduled_date: daysAgo(1),
      },
      {
        id: 20003,
        day: 5,
        content_theme: 'Best Practices',
        post_idea: 'LinkedIn content strategy guide',
        content_type: 'Carousel',
        suggested_time: '09:00',
        platform: 'LinkedIn',
        caption:
          'Your LinkedIn content strategy in 5 slides. 1. Optimize your profile. 2. Share valuable insights. 3. Engage with your network. 4. Post consistently. 5. Measure and iterate.',
        call_to_action: 'Save for later',
        hashtags: ['linkedinstrategy', 'b2bmarketing', 'professionalgrowth'],
        status: 'scheduled',
        scheduled_date: null,
      },
    ],
    created_at: daysAgo(10),
    updated_at: daysAgo(1),
  },
  {
    id: 3,
    name: 'Demo Campaign — Product Launch',
    platform: 'TikTok',
    tone: 'casual',
    campaign_goal: 'engagement',
    status: 'active',
    brand_profile_id: 1,
    posts: [
      {
        id: 30001,
        day: 1,
        content_theme: 'Teaser',
        post_idea: 'Countdown to product launch',
        content_type: 'Video',
        suggested_time: '18:00',
        platform: 'TikTok',
        caption:
          'Something big is coming... 👀 Stay tuned for our biggest announcement yet! Drop a 🔥 if you\'re ready!',
        call_to_action: 'Turn on notifications',
        hashtags: ['comingsoon', 'newproduct', 'excitingnews'],
        status: 'published',
        scheduled_date: daysAgo(2),
      },
    ],
    created_at: daysAgo(5),
    updated_at: daysAgo(1),
  },
]

export const guestBrands: BrandProfile[] = [
  {
    id: 1,
    name: 'Demo Brand Co.',
    description: 'A sample brand profile showcasing Creator Studio features.',
    niche: 'Content Creation',
    target_audience: 'Social media managers and content creators',
    website: 'https://example.com',
    social_links: {
      instagram: 'https://instagram.com/demobrand',
      linkedin: 'https://linkedin.com/company/demobrand',
    },
    logo_url: null,
    campaign_count: 3,
  },
]

export const guestStats = {
  campaigns: guestCampaigns.length,
  brands: guestBrands.length,
  totalPosts: guestCampaigns.reduce((s, c) => s + (c.posts?.length || 0), 0),
}

interface GuestCalendarEvent {
  id: number; day: number; content_type: string; platform: string; caption: string;
  status: string; campaignName: string; content_theme: string; post_idea: string;
  call_to_action: string | null; hashtags: string[] | null;
}

export const guestCalendarEvents: GuestCalendarEvent[] = guestCampaigns.flatMap((c) =>
  (c.posts || []).map((p) => ({
    id: p.id,
    day: p.day,
    content_type: p.content_type,
    platform: p.platform,
    caption: p.caption,
    status: p.status,
    campaignName: c.name,
    content_theme: p.content_theme,
    post_idea: p.post_idea,
    call_to_action: p.call_to_action,
    hashtags: p.hashtags,
  })),
)
