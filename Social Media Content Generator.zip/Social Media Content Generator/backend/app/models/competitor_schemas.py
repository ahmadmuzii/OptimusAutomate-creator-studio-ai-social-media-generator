from __future__ import annotations

import datetime

from pydantic import BaseModel, ConfigDict


class TopicCoverageItem(BaseModel):
    topic: str
    post_count: int
    competitor_count: int
    competitors: list[str]


class ContentMixItem(BaseModel):
    competitor: str
    content_types: dict[str, int]


class OpportunityItem(BaseModel):
    topic: str
    competitor_coverage: int
    brand_coverage: int
    competitors: list[str]
    priority: str
    suggested_format: str | None = None
    selected_for_generation: bool = False


class GapReportSummary(BaseModel):
    competitors_analyzed: int
    posts_analyzed: int
    unique_topics: int
    opportunities_found: int


class GapItem(BaseModel):
    topic: str
    competitors_covering: list[str]
    platforms: list[str]


class GapReportAnalytics(BaseModel):
    summary: GapReportSummary
    topic_coverage: list[TopicCoverageItem]
    content_mix: list[ContentMixItem]
    opportunities: list[OpportunityItem]
    recommendations: list[str]
    gaps_found: int = 0
    brand_themes_count: int = 0
    competitor_topics_count: int = 0
    gaps: list[GapItem] = []


class CompetitorProfileCreate(BaseModel):
    name: str
    platform: str | None = None
    public_handle: str | None = None
    website: str | None = None
    notes: str | None = None


class CompetitorProfileUpdate(BaseModel):
    name: str | None = None
    platform: str | None = None
    public_handle: str | None = None
    website: str | None = None
    notes: str | None = None


class CompetitorProfileResponse(BaseModel):
    id: int
    brand_id: int
    name: str
    platform: str | None = None
    public_handle: str | None = None
    website: str | None = None
    notes: str | None = None
    created_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)


class CompetitorPostCreate(BaseModel):
    caption: str | None = None
    content_type: str | None = None
    platform: str | None = None
    cta_style: str | None = None
    hook_type: str | None = None
    topics: list[str] | None = None
    publication_date: str | None = None
    engagement_metrics: dict | None = None


class CompetitorPostResponse(BaseModel):
    id: int
    competitor_id: int
    caption: str | None = None
    content_type: str | None = None
    platform: str | None = None
    cta_style: str | None = None
    hook_type: str | None = None
    topics: list[str] | None = None
    publication_date: datetime.datetime | None = None
    engagement_metrics: dict | None = None

    model_config = ConfigDict(from_attributes=True)


class GapReportResponse(BaseModel):
    id: int
    brand_id: int
    status: str
    report_data: dict | None = None
    created_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)
