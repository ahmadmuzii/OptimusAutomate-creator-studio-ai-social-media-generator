from __future__ import annotations


class TestRegionalSettingsAPI:
    """Test regional settings endpoints."""

    def test_get_regional_settings(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.get(
            f"/api/v1/brands/{brand_id}/regional-settings",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert "supported_languages" in data
        assert "default_language" in data
        assert data["default_language"] == "en"
        assert data["support_bilingual_posts"] is True

    def test_update_regional_settings(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.put(
            f"/api/v1/brands/{brand_id}/regional-settings",
            json={"default_language": "ur", "support_bilingual_posts": False},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["default_language"] == "ur"
        assert data["support_bilingual_posts"] is False
        assert data["support_roman_urdu"] is True

    def test_cannot_access_other_users_regional_settings(
        self, client, auth_headers, second_auth_headers, created_brand
    ):
        brand_id = created_brand["id"]
        response = client.get(
            f"/api/v1/brands/{brand_id}/regional-settings",
            headers=second_auth_headers,
        )
        assert response.status_code == 404
