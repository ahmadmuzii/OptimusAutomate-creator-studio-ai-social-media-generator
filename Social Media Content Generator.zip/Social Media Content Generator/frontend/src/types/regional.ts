export interface RegionalSettings {
  supported_languages: string[]
  default_language: string
  support_roman_urdu: boolean
  support_bilingual_posts: boolean
  support_rtl_layout: boolean
}
