from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.ai.source_extractor import extract_facts_with_groq
from app.api.deps_auth import require_current_user
from app.api.deps_features import require_feature
from app.config import settings
from app.database import get_db
from app.exceptions import NotFoundError, ValidationError
from app.models.db_models import BrandProfile, SourceDocument, SourceFact, User
from app.models.source_schemas import (
    ExtractRequest,
    SourceDocumentCreate,
    SourceDocumentResponse,
    SourceFactResponse,
    SourceFactUpdate,
)
from app.services.source_fetch_service import SourceFetchService

router = APIRouter(
    prefix="/brands/{brand_id}/source-documents",
    tags=["Source Documents"],
    dependencies=[require_feature("source_to_campaign")],
)


def _get_brand_or_404(db: Session, brand_id: int, user_id: int) -> BrandProfile:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != user_id:
        raise NotFoundError("Brand not found")
    return brand


def _fact_to_response(f: SourceFact) -> SourceFactResponse:
    return SourceFactResponse(
        id=f.id,
        category=f.category,
        label=f.label,
        value=f.value,
        source_section=f.source_section,
        confidence=f.confidence,
        approved_by_user=f.approved_by_user,
        excluded_by_user=f.excluded_by_user,
    )


def _document_to_response(doc: SourceDocument) -> SourceDocumentResponse:
    return SourceDocumentResponse(
        id=doc.id,
        user_id=doc.user_id,
        brand_id=doc.brand_id,
        source_type=doc.source_type,
        original_url=doc.original_url,
        pasted_text=doc.pasted_text,
        title=doc.title,
        extracted_text=doc.extracted_text,
        created_at=doc.created_at,
        facts=[_fact_to_response(f) for f in doc.facts],
    )


@router.get("", response_model=list[SourceDocumentResponse])
def list_source_documents(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    docs = db.query(SourceDocument).filter(SourceDocument.brand_id == brand_id).all()
    return [_document_to_response(d) for d in docs]


@router.post("", response_model=SourceDocumentResponse)
async def create_source_document(
    brand_id: int,
    request: SourceDocumentCreate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)

    if request.source_type not in ("url", "text"):
        raise ValidationError("source_type must be 'url' or 'text'")
    if request.source_type == "url" and not request.original_url:
        raise ValidationError("original_url is required when source_type is 'url'")
    if request.source_type == "text" and not request.pasted_text:
        raise ValidationError("pasted_text is required when source_type is 'text'")

    service = SourceFetchService()
    fetch_result = await service.process_source(
        source_type=request.source_type,
        url=request.original_url,
        text=request.pasted_text,
    )

    if fetch_result.get("error"):
        raise ValidationError(fetch_result["error"])

    # Extract facts using Groq when available, fallback to regex extraction
    extracted_text = fetch_result.get("text", "")
    doc_title = fetch_result.get("title", "")

    if settings.groq_enabled and extracted_text:
        extraction_result = extract_facts_with_groq(
            title=doc_title,
            text=extracted_text,
        )
        facts_data = extraction_result["facts"]
    else:
        facts_data = fetch_result.get("facts", [])

    doc = SourceDocument(
        user_id=current_user.id,
        brand_id=brand_id,
        source_type=request.source_type,
        original_url=request.original_url,
        pasted_text=request.pasted_text,
        title=doc_title,
        extracted_text=extracted_text,
    )
    db.add(doc)
    db.flush()

    for fact_data in facts_data:
        fact = SourceFact(
            source_document_id=doc.id,
            category=fact_data.get("category", "other"),
            label=fact_data.get("label", "")[:200],
            value=fact_data.get("value", "")[:2000],
            source_section=fact_data.get("source_excerpt") or fact_data.get("source_section", "")[:1000],
            confidence=fact_data.get("confidence", 0.5),
        )
        db.add(fact)

    db.commit()
    db.refresh(doc)
    return _document_to_response(doc)


@router.get("/{doc_id}", response_model=SourceDocumentResponse)
def get_source_document(
    brand_id: int,
    doc_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    doc = db.query(SourceDocument).filter(SourceDocument.id == doc_id, SourceDocument.brand_id == brand_id).first()
    if not doc:
        raise NotFoundError("Source document not found")
    return _document_to_response(doc)


@router.post("/{doc_id}/extract", response_model=SourceDocumentResponse)
async def reextract_source_document(
    brand_id: int,
    doc_id: int,
    request: ExtractRequest,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    doc = db.query(SourceDocument).filter(SourceDocument.id == doc_id, SourceDocument.brand_id == brand_id).first()
    if not doc:
        raise NotFoundError("Source document not found")

    service = SourceFetchService()
    fetch_result = await service.process_source(
        source_type=doc.source_type,
        url=request.url or doc.original_url,
        text=request.text or doc.pasted_text,
    )

    if fetch_result.get("error"):
        raise ValidationError(fetch_result["error"])

    extracted_text = fetch_result.get("text", "")
    doc_title = fetch_result.get("title", "")

    doc.title = doc_title
    doc.extracted_text = extracted_text

    db.query(SourceFact).filter(SourceFact.source_document_id == doc.id).delete()

    if settings.groq_enabled and extracted_text:
        extraction_result = extract_facts_with_groq(
            title=doc_title,
            text=extracted_text,
        )
        facts_data = extraction_result["facts"]
    else:
        facts_data = fetch_result.get("facts", [])

    for fact_data in facts_data:
        fact = SourceFact(
            source_document_id=doc.id,
            category=fact_data.get("category", "other"),
            label=fact_data.get("label", "")[:200],
            value=fact_data.get("value", "")[:2000],
            source_section=fact_data.get("source_excerpt") or fact_data.get("source_section", "")[:1000],
            confidence=fact_data.get("confidence", 0.5),
        )
        db.add(fact)

    db.commit()
    db.refresh(doc)
    return _document_to_response(doc)


@router.patch("/facts/{fact_id}", response_model=SourceFactResponse)
def update_source_fact(
    brand_id: int,
    fact_id: int,
    request: SourceFactUpdate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    fact = (
        db.query(SourceFact)
        .join(SourceDocument)
        .filter(
            SourceFact.id == fact_id,
            SourceDocument.brand_id == brand_id,
        )
        .first()
    )
    if not fact:
        raise NotFoundError("Fact not found")

    update_data = request.model_dump(exclude_none=True)
    for key, value in update_data.items():
        setattr(fact, key, value)
    db.commit()
    db.refresh(fact)
    return _fact_to_response(fact)


@router.delete("/{doc_id}")
def delete_source_document(
    brand_id: int,
    doc_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    doc = db.query(SourceDocument).filter(SourceDocument.id == doc_id, SourceDocument.brand_id == brand_id).first()
    if not doc:
        raise NotFoundError("Source document not found")
    db.delete(doc)
    db.commit()
    return {"detail": "Source document deleted"}
