export type PlatformId = 'instagram' | 'linkedin' | 'tiktok' | 'facebook' | 'twitter'

export type PlatformName = 'Instagram' | 'LinkedIn' | 'TikTok' | 'Facebook' | 'X'

export type ContentType =
  | 'reel'
  | 'carousel'
  | 'static_post'
  | 'story'
  | 'short_video'
  | 'thread'

export type CaptionLength = 'very_short' | 'short' | 'medium' | 'long'

export interface PlatformConfig {
  captionLength: CaptionLength
  maxCaptionChars: number
  style: string
  ctaStyle: string
  hashtagRange: [number, number]
  contentTypes: ContentType[]
}

export interface PlatformResponse {
  platforms: string[]
}
