export interface FatigueAnalysis {
  status?: string
  fatigue_score: number
  total_campaigns: number
  total_posts: number
  repeated_themes: Record<string, number>
  cta_diversity: number
  recommendations: string[]
}
