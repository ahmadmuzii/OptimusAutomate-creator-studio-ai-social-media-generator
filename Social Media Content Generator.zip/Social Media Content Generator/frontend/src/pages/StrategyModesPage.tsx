import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'
import { ArrowLeft, Plus, Trash2, Pencil, Target, Check, X, Layers } from 'lucide-react'
import { ErrorState } from '@/components/ui/ErrorState'
import { LoadingSpinner } from '@/components/ui/LoadingSpinner'
import * as api from '@/api/endpoints'
import type { StrategyTemplate, ApplyStrategyRequest } from '@/types/strategy'
import type { CampaignData } from '@/types/common'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'

const FUNNEL_STAGES = ['awareness', 'consideration', 'conversion', 'retention', 'mixed'] as const
const CONTENT_MIX_OPTIONS = ['educational', 'promotional', 'engagement', 'behind_the_scenes', 'user_generated', 'storytelling']
const POST_FREQUENCIES = ['daily', '3x_week', 'weekly']
const PLATFORM_OPTIONS = ['instagram', 'facebook', 'twitter', 'linkedin', 'tiktok', 'youtube', 'pinterest']

const FUNNEL_COLORS: Record<string, string> = {
  awareness: 'bg-blue-100 text-blue-700',
  consideration: 'bg-purple-100 text-purple-700',
  conversion: 'bg-green-100 text-green-700',
  retention: 'bg-orange-100 text-orange-700',
  mixed: 'bg-gray-100 text-gray-700',
}

const EMPTY_TEMPLATE = {
  name: '', description: '', funnel_stage: 'awareness', campaign_goal: '',
  recommended_ctas: [] as string[], content_mix: [] as string[],
  post_frequency: 'weekly', platform_focus: '', is_default: false, icon: '',
}

export function StrategyModesPage() {
  const { brandId, brand } = useBrandWorkspace()

  const [loading, setLoading] = useState(true)

  const [templates, setTemplates] = useState<StrategyTemplate[]>([])
  const [editingId, setEditingId] = useState<number | 'new' | null>(null)
  const [form, setForm] = useState<Record<string, unknown>>({ ...EMPTY_TEMPLATE })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [applyTarget, setApplyTarget] = useState<number | null>(null)
  const [campaigns, setCampaigns] = useState<CampaignData[]>([])
  const [selectedCampaignId, setSelectedCampaignId] = useState<number | ''>('')
  const [applying, setApplying] = useState(false)

  const load = useCallback(async () => {
    const data = await api.fetchStrategyTemplates(brandId)
    setTemplates(data as StrategyTemplate[])
  }, [brandId])

  useEffect(() => {
    load().catch(() => setError('Could not load templates.')).finally(() => setLoading(false))
  }, [brandId, load])

  const startEdit = (tmpl?: StrategyTemplate) => {
    if (tmpl) {
      setEditingId(tmpl.id)
      setForm({
        name: tmpl.name, description: tmpl.description || '',
        funnel_stage: tmpl.funnel_stage, campaign_goal: tmpl.campaign_goal || '',
        recommended_ctas: tmpl.recommended_ctas || [],
        content_mix: tmpl.content_mix || [],
        post_frequency: tmpl.post_frequency || 'weekly',
        platform_focus: tmpl.platform_focus || '',
        is_default: tmpl.is_default, icon: tmpl.icon || '',
      })
    } else {
      setEditingId('new')
      setForm({ ...EMPTY_TEMPLATE })
    }
  }

  const cancelEdit = () => { setEditingId(null); setForm({ ...EMPTY_TEMPLATE }) }

  const handleSave = async () => {
    setSaving(true)
    try {
      const payload = {
        ...form,
        recommended_ctas: (form.recommended_ctas as string[]).filter(Boolean),
        content_mix: form.content_mix as string[],
      }
      if (editingId === 'new') {
        await api.createStrategyTemplate(brandId, payload)
      } else {
        await api.updateStrategyTemplate(brandId, editingId as number, payload)
      }
      await load()
      cancelEdit()
    } catch { setError('Failed to save.') }
    finally { setSaving(false) }
  }

  const handleDelete = async (templateId: number) => {
    try {
      await api.deleteStrategyTemplate(brandId, templateId)
      setTemplates(prev => prev.filter(t => t.id !== templateId))
    } catch { setError('Failed to delete.') }
  }

  const toggleContentMix = (val: string) => {
    const current = (form.content_mix as string[]) || []
    const next = current.includes(val) ? current.filter(v => v !== val) : [...current, val]
    setForm(prev => ({ ...prev, content_mix: next }))
  }

  const openApply = async (templateId: number) => {
    setApplyTarget(templateId)
    setSelectedCampaignId('')
    try {
      const data = await api.fetchCampaigns(brandId)
      setCampaigns(data as CampaignData[])
    } catch { setCampaigns([]) }
  }

  const handleApply = async () => {
    if (!applyTarget || !selectedCampaignId) return
    setApplying(true)
    try {
      const payload: ApplyStrategyRequest = { template_id: applyTarget, campaign_id: Number(selectedCampaignId) }
      await api.applyStrategy(brandId, payload as unknown as Record<string, unknown>)
      setApplyTarget(null)
    } catch { setError('Failed to apply template.') }
    finally { setApplying(false) }
  }

  if (loading) return <LoadingSpinner />

  if (error) return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>
      <ErrorState message={error} onRetry={load} />
    </div>
  )

  if (templates.length === 0) return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Target className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Strategy Templates</h1>
        </div>
        <Button onClick={() => startEdit()} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Template
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Create reusable strategy templates for {brand.name}. Apply them to campaigns to quickly set goals, content mix, and frequency.
      </p>

      <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
        <Target className="w-8 h-8 text-gray-300 mx-auto mb-3" />
        <p className="text-gray-400 text-sm mb-4">No strategy templates created yet.</p>
        <Button onClick={() => startEdit()} className="mx-auto flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Your First Template
        </Button>
      </div>

      {editingId !== null && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={cancelEdit}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">{editingId === 'new' ? 'Create Template' : 'Edit Template'}</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Name *</label>
                  <input value={form.name as string} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} placeholder="e.g., Product Launch Awareness" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Description</label>
                  <textarea value={form.description as string} onChange={e => setForm(prev => ({ ...prev, description: e.target.value }))} rows={2} placeholder="Describe this strategy..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Funnel Stage</label>
                  <select value={form.funnel_stage as string} onChange={e => setForm(prev => ({ ...prev, funnel_stage: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    {FUNNEL_STAGES.map(s => <option key={s} value={s} className="capitalize">{s.replace(/_/g, ' ')}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Campaign Goal</label>
                  <input value={form.campaign_goal as string} onChange={e => setForm(prev => ({ ...prev, campaign_goal: e.target.value }))} placeholder="e.g., Drive brand awareness" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Recommended CTAs (comma-separated)</label>
                  <input value={(form.recommended_ctas as string[]).join(', ')} onChange={e => setForm(prev => ({ ...prev, recommended_ctas: e.target.value.split(',').map(s => s.trim()).filter(Boolean) }))} placeholder="Learn More, Sign Up, Shop Now" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Content Mix</label>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {CONTENT_MIX_OPTIONS.map(opt => {
                      const checked = ((form.content_mix as string[]) || []).includes(opt)
                      return (
                        <button key={opt} type="button" onClick={() => toggleContentMix(opt)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${checked ? 'bg-purple-100 text-purple-700 border-purple-300' : 'bg-white text-gray-500 border-gray-200 hover:border-purple-200'}`}>
                          {checked ? <Check className="w-3 h-3" /> : <X className="w-3 h-3 opacity-0" />}
                          {opt.replace(/_/g, ' ')}
                        </button>
                      )
                    })}
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Post Frequency</label>
                  <select value={form.post_frequency as string} onChange={e => setForm(prev => ({ ...prev, post_frequency: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    {POST_FREQUENCIES.map(f => <option key={f} value={f}>{f.replace(/_/g, ' ')}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Platform Focus</label>
                  <select value={form.platform_focus as string} onChange={e => setForm(prev => ({ ...prev, platform_focus: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    <option value="">Any</option>
                    {PLATFORM_OPTIONS.map(p => <option key={p} value={p} className="capitalize">{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Icon (emoji or text)</label>
                  <input value={form.icon as string} onChange={e => setForm(prev => ({ ...prev, icon: e.target.value }))} placeholder="e.g., 🚀" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
              </div>
              <div className="flex items-center gap-3 pt-4 border-t border-gray-100">
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={form.is_default as boolean} onChange={e => setForm(prev => ({ ...prev, is_default: e.target.checked }))} className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" />
                  <span className="text-sm text-gray-700">Set as default template</span>
                </label>
              </div>
              <div className="flex items-center gap-3 pt-4">
                <Button onClick={handleSave} disabled={saving || !form.name}>{saving ? 'Saving...' : 'Save'}</Button>
                <button onClick={cancelEdit} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )

  return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Target className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Strategy Templates</h1>
        </div>
        <Button onClick={() => startEdit()} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Template
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Create reusable strategy templates for {brand.name}. Apply them to campaigns to quickly set goals, content mix, and frequency.
      </p>

      {/* Editor Modal */}
      {editingId !== null && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={cancelEdit}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">{editingId === 'new' ? 'Create Template' : 'Edit Template'}</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Name *</label>
                  <input value={form.name as string} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} placeholder="e.g., Product Launch Awareness" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Description</label>
                  <textarea value={form.description as string} onChange={e => setForm(prev => ({ ...prev, description: e.target.value }))} rows={2} placeholder="Describe this strategy..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Funnel Stage</label>
                  <select value={form.funnel_stage as string} onChange={e => setForm(prev => ({ ...prev, funnel_stage: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    {FUNNEL_STAGES.map(s => <option key={s} value={s} className="capitalize">{s.replace(/_/g, ' ')}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Campaign Goal</label>
                  <input value={form.campaign_goal as string} onChange={e => setForm(prev => ({ ...prev, campaign_goal: e.target.value }))} placeholder="e.g., Drive brand awareness" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Recommended CTAs (comma-separated)</label>
                  <input value={(form.recommended_ctas as string[]).join(', ')} onChange={e => setForm(prev => ({ ...prev, recommended_ctas: e.target.value.split(',').map(s => s.trim()).filter(Boolean) }))} placeholder="Learn More, Sign Up, Shop Now" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Content Mix</label>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {CONTENT_MIX_OPTIONS.map(opt => {
                      const checked = ((form.content_mix as string[]) || []).includes(opt)
                      return (
                        <button key={opt} type="button" onClick={() => toggleContentMix(opt)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${checked ? 'bg-purple-100 text-purple-700 border-purple-300' : 'bg-white text-gray-500 border-gray-200 hover:border-purple-200'}`}>
                          {checked ? <Check className="w-3 h-3" /> : <X className="w-3 h-3 opacity-0" />}
                          {opt.replace(/_/g, ' ')}
                        </button>
                      )
                    })}
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Post Frequency</label>
                  <select value={form.post_frequency as string} onChange={e => setForm(prev => ({ ...prev, post_frequency: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    {POST_FREQUENCIES.map(f => <option key={f} value={f}>{f.replace(/_/g, ' ')}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Platform Focus</label>
                  <select value={form.platform_focus as string} onChange={e => setForm(prev => ({ ...prev, platform_focus: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    <option value="">Any</option>
                    {PLATFORM_OPTIONS.map(p => <option key={p} value={p} className="capitalize">{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Icon (emoji or text)</label>
                  <input value={form.icon as string} onChange={e => setForm(prev => ({ ...prev, icon: e.target.value }))} placeholder="e.g., 🚀" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
              </div>
              <div className="flex items-center gap-3 pt-4 border-t border-gray-100">
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={form.is_default as boolean} onChange={e => setForm(prev => ({ ...prev, is_default: e.target.checked }))} className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" />
                  <span className="text-sm text-gray-700">Set as default template</span>
                </label>
              </div>
              <div className="flex items-center gap-3 pt-4">
                <Button onClick={handleSave} disabled={saving || !form.name}>{saving ? 'Saving...' : 'Save'}</Button>
                <button onClick={cancelEdit} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Apply to Campaign Modal */}
      {applyTarget !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={() => setApplyTarget(null)}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-gray-900 mb-4">Apply Template to Campaign</h3>
            <select value={selectedCampaignId} onChange={e => setSelectedCampaignId(e.target.value ? Number(e.target.value) : '')} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 mb-4">
              <option value="">Select a campaign...</option>
              {campaigns.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <div className="flex items-center gap-3">
              <Button onClick={handleApply} disabled={!selectedCampaignId || applying}>{applying ? 'Applying...' : 'Apply'}</Button>
              <button onClick={() => setApplyTarget(null)} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Template List */}
        <div className="space-y-4">
          {templates.map(tmpl => (
            <div key={tmpl.id} className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  {tmpl.icon && <span className="text-2xl">{tmpl.icon}</span>}
                  <div>
                    <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                      {tmpl.name}
                      {tmpl.is_default && <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">Default</span>}
                    </h3>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button size="sm" variant="secondary" onClick={() => openApply(tmpl.id)} className="flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5" /> Apply to Campaign
                  </Button>
                  <button onClick={() => startEdit(tmpl)} className="p-1.5 rounded-lg hover:bg-purple-50 text-gray-400 hover:text-purple-600" title="Edit">
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => handleDelete(tmpl.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500" title="Delete">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              {tmpl.description && <p className="text-sm text-gray-500 mb-3">{tmpl.description}</p>}
              <div className="flex flex-wrap items-center gap-2">
                <span className={`text-xs font-medium px-2.5 py-1 rounded-full capitalize ${FUNNEL_COLORS[tmpl.funnel_stage] || 'bg-gray-100 text-gray-700'}`}>
                  {tmpl.funnel_stage.replace(/_/g, ' ')}
                </span>
                {tmpl.campaign_goal && <span className="text-xs bg-gray-50 text-gray-600 px-2.5 py-1 rounded-full">{tmpl.campaign_goal}</span>}
                {tmpl.post_frequency && <span className="text-xs bg-gray-50 text-gray-600 px-2.5 py-1 rounded-full capitalize">{tmpl.post_frequency.replace(/_/g, ' ')}</span>}
                {tmpl.platform_focus && <span className="text-xs bg-gray-50 text-gray-600 px-2.5 py-1 rounded-full capitalize">{tmpl.platform_focus}</span>}
              </div>
              {tmpl.content_mix && tmpl.content_mix.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {tmpl.content_mix.map(m => (
                    <span key={m} className="text-xs bg-purple-50 text-purple-600 px-2 py-0.5 rounded-full capitalize">{m.replace(/_/g, ' ')}</span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
    </div>
  )
}
