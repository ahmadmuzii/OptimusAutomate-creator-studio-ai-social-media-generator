import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronDown } from 'lucide-react'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { cn } from '@/utils/cn'

const faqs = [
  {
    q: 'What does the Social Media Content Generator create?',
    a: 'It generates complete 7-day social media campaigns including content themes, post ideas, captions, calls to action, hashtags, suggested posting times, and content types for each day. You can also generate individual captions and manage your content calendar.',
  },
  {
    q: 'Which platforms are supported?',
    a: 'Instagram, LinkedIn, TikTok, Facebook, and X (Twitter). Content is adapted to each platform\'s best practices, caption lengths, and content formats.',
  },
  {
    q: 'Can I edit generated captions?',
    a: 'Yes. Every caption can be edited inline, regenerated individually, copied to clipboard, and assigned a status (draft, scheduled, or published).',
  },
  {
    q: 'Does it generate hashtags and CTAs?',
    a: 'Yes. Each post includes platform-relevant hashtags and a suggested call to action aligned with the campaign goal and tone.',
  },
  {
    q: 'Can I save multiple brands?',
    a: 'Yes. You can create and save multiple brand profiles. Each profile stores your brand name, description, niche, target audience, and campaign goals for quick reuse.',
  },
  {
    q: 'Is my campaign saved?',
    a: 'Campaigns are saved to your account automatically. You can return to any past campaign to view, edit, or manage its posts.',
  },
  {
    q: 'Can I regenerate one caption?',
    a: 'Yes. You can regenerate individual captions without regenerating the entire campaign. This is useful when you want a fresh take on a specific post.',
  },
  {
    q: 'Does it automatically publish posts?',
    a: 'No. Creator Studio generates and organizes your content for scheduled posting, but does not publish directly to social media platforms. You copy or adapt the content into your preferred scheduling tool.',
  },
  {
    q: 'Is AI-generated content always accurate?',
    a: 'AI-generated content should be reviewed before publishing. We recommend checking facts, brand references, and tone alignment. The AI follows your input but can occasionally produce unexpected results.',
  },
  {
    q: 'Do I need an account?',
    a: 'Yes. A free account is required to save brands, campaigns, and manage your content. Account creation takes less than a minute.',
  },
]

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)
  const reduced = useReducedMotionPreference()

  const toggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section id="faq" className="py-20 bg-gray-50/50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            Frequently asked questions
          </h2>
        </div>

        <div className="space-y-2">
          {faqs.map((faq, i) => {
            const isOpen = openIndex === i
            const panelId = `faq-panel-${i}`
            const buttonId = `faq-button-${i}`

            return (
              <div
                key={i}
                className="bg-white rounded-xl border border-gray-100 overflow-hidden"
              >
                <button
                  id={buttonId}
                  onClick={() => toggle(i)}
                  className="w-full flex items-center justify-between p-4 md:p-5 text-left transition-colors hover:bg-gray-50/50"
                  aria-expanded={isOpen}
                  aria-controls={panelId}
                >
                  <span className="text-sm font-medium text-gray-900 pr-4">{faq.q}</span>
                  <ChevronDown
                    className={cn(
                      'w-4 h-4 text-gray-400 flex-shrink-0 transition-transform duration-200',
                      isOpen && 'rotate-180',
                    )}
                  />
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      id={panelId}
                      key="content"
                      initial={reduced ? undefined : { height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={reduced ? undefined : { height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      role="region"
                      aria-labelledby={buttonId}
                      className="overflow-hidden"
                    >
                      <div className="px-4 md:px-5 pb-4 md:pb-5">
                        <p className="text-sm text-gray-600 leading-relaxed">{faq.a}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
