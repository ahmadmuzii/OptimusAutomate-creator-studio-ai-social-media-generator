import { render, screen, fireEvent } from '@testing-library/react'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { it, expect, vi, beforeEach } from 'vitest'
import { AuthProvider } from '@/context/AuthContext'
import { GuestModeProvider } from '@/context/GuestModeContext'
import { AuthModal } from '@/components/common/AuthModal'
import { GuestPreviewRoute } from '@/components/common/GuestPreviewRoute'
import { ProtectedAction } from '@/components/common/ProtectedAction'
import { guestCampaigns, guestBrands, guestStats } from '@/data/guestDemoData'

vi.mock('@/api/endpoints', () => ({
  fetchMe: vi.fn().mockRejectedValue(new Error('Not authenticated')),
  login: vi.fn(),
  signup: vi.fn(),
  updateProfile: vi.fn(),
}))

beforeEach(() => {
  sessionStorage.clear()
  window.history.replaceState({}, '', '/')
})

function renderWithProviders(ui: React.ReactElement, { initialEntries = ['/'] } = {}) {
  return render(
    <MemoryRouter initialEntries={initialEntries}>
      <AuthProvider>
        <GuestModeProvider>
          {ui}
        </GuestModeProvider>
      </AuthProvider>
    </MemoryRouter>,
  )
}

/* 1. Sign In navigates to /login */
it('Sign In navigates to /login when unauthenticated', async () => {
  renderWithProviders(
    <div>
      <a href="/login" data-testid="sign-in-link">Sign In</a>
    </div>,
  )
  const link = screen.getByTestId('sign-in-link')
  expect(link).toHaveAttribute('href', '/login')
})

/* 2. Authenticated Sign In navigates to /dashboard */
it('Sign In navigates to /dashboard when authenticated', async () => {
  localStorage.setItem('token', 'fake-token')
  renderWithProviders(
    <div>
      <a href="/dashboard" data-testid="dashboard-link">Dashboard</a>
    </div>,
  )
  const link = screen.getByTestId('dashboard-link')
  expect(link).toHaveAttribute('href', '/dashboard')
  localStorage.removeItem('token')
})

/* 3. Generate My Campaign sends guests to /login?redirect=/dashboard/generate */
it('Generate My Campaign sends unauthenticated to /login?redirect=/dashboard/generate', () => {
  renderWithProviders(
    <div>
      <a
        href="/login?redirect=%2Fdashboard%2Fgenerate"
        data-testid="generate-link"
      >
        Generate My Campaign
      </a>
    </div>,
  )
  const link = screen.getByTestId('generate-link')
  expect(link).toHaveAttribute('href', '/login?redirect=%2Fdashboard%2Fgenerate')
})

/* 4. Authenticated Generate My Campaign opens the generator */
it('Authenticated Generate My Campaign navigates to /dashboard/generate', async () => {
  localStorage.setItem('token', 'fake-token')
  renderWithProviders(
    <div>
      <a href="/dashboard/generate" data-testid="generate-auth-link">
        Generate My Campaign
      </a>
    </div>,
  )
  const link = screen.getByTestId('generate-auth-link')
  expect(link).toHaveAttribute('href', '/dashboard/generate')
  localStorage.removeItem('token')
})

/* 5. Start Free opens guest dashboard mode */
it('Start Free navigates to /dashboard?mode=guest', () => {
  renderWithProviders(
    <div>
      <a href="/dashboard?mode=guest" data-testid="start-free-link">
        Start Free
      </a>
    </div>,
  )
  const link = screen.getByTestId('start-free-link')
  expect(link).toHaveAttribute('href', '/dashboard?mode=guest')
})

/* 6. Guest dashboard renders demo content */
it('Guest demo data contains campaigns and brands', () => {
  expect(guestCampaigns.length).toBeGreaterThan(0)
  expect(guestBrands.length).toBeGreaterThan(0)
  expect(guestStats.campaigns).toBe(guestCampaigns.length)
  expect(guestStats.totalPosts).toBeGreaterThan(0)
})

/* 7. Guest dashboard does not call protected APIs */
it('GuestPreviewRoute does not redirect when mode=guest', () => {
  sessionStorage.setItem('guestMode', 'true')
  const Child = () => <div data-testid="guest-child">Guest Content</div>
  renderWithProviders(
    <Routes>
      <Route
        path="/"
        element={
          <GuestPreviewRoute>
            <Child />
          </GuestPreviewRoute>
        }
      />,
    </Routes>,
    { initialEntries: ['/?mode=guest'] },
  )
  expect(screen.getByTestId('guest-child')).toBeInTheDocument()
})

/* 8. Clicking a locked feature opens the auth modal */
it('ProtectedAction triggers onAuthRequired for guest users', () => {
  sessionStorage.setItem('guestMode', 'true')
  const onAuthRequired = vi.fn()
  renderWithProviders(
    <ProtectedAction redirectTo="/dashboard/brands" onAuthRequired={onAuthRequired}>
      <button data-testid="locked-btn">Brands</button>
    </ProtectedAction>,
    { initialEntries: ['/?mode=guest'] },
  )
  fireEvent.click(screen.getByTestId('locked-btn'))
  expect(onAuthRequired).toHaveBeenCalledWith('/dashboard/brands')
})

/* 9. Sign In in the modal preserves the target route */
it('AuthModal Sign In preserves redirect target', () => {
  renderWithProviders(
    <AuthModal
      isOpen={true}
      onClose={vi.fn()}
      redirectTo="/dashboard/generate"
    />,
  )
  const signInBtn = screen.getByText('Sign In')
  expect(signInBtn).toBeInTheDocument()
})

/* 10. Create Free Account preserves the target route */
it('AuthModal Create Free Account preserves redirect target', () => {
  renderWithProviders(
    <AuthModal
      isOpen={true}
      onClose={vi.fn()}
      redirectTo="/dashboard/brands"
    />,
  )
  const createBtn = screen.getByText('Create Free Account')
  expect(createBtn).toBeInTheDocument()
})

/* 11. Continue Exploring closes the modal */
it('AuthModal Continue Exploring closes the modal', () => {
  const onClose = vi.fn()
  render(
    <MemoryRouter>
      <AuthModal isOpen={true} onClose={onClose} redirectTo="/dashboard" />
    </MemoryRouter>,
  )
  fireEvent.click(screen.getByText('Continue Exploring'))
  expect(onClose).toHaveBeenCalledTimes(1)
})

/* 12. Authenticated users do not see lock states */
it('Authenticated users bypass ProtectedAction', () => {
  localStorage.setItem('token', 'fake-token')
  const onAuthRequired = vi.fn()
  renderWithProviders(
    <ProtectedAction redirectTo="/dashboard/brands" onAuthRequired={onAuthRequired}>
      <button data-testid="brands-btn">Brands</button>
    </ProtectedAction>,
  )
  fireEvent.click(screen.getByTestId('brands-btn'))
  expect(onAuthRequired).not.toHaveBeenCalled()
  localStorage.removeItem('token')
})

/* 13. Invalid external redirect values are rejected */
it('Invalid external redirect values are rejected', () => {
  const params = new URLSearchParams('redirect=https://evil.com')
  const redirectParam = params.get('redirect')
  const validated =
    redirectParam && redirectParam.startsWith('/') && !redirectParam.startsWith('//')
      ? redirectParam
      : null
  expect(validated).toBeNull()
})

it('Valid internal redirect is accepted', () => {
  const params = new URLSearchParams('redirect=/dashboard/generate')
  const redirectParam = params.get('redirect')
  const validated =
    redirectParam && redirectParam.startsWith('/') && !redirectParam.startsWith('//')
      ? redirectParam
      : null
  expect(validated).toBe('/dashboard/generate')
})

/* 14. Guest demo data disappears after login */
it('Guest mode exits when auth state changes', () => {
  sessionStorage.setItem('guestMode', 'true')
  expect(sessionStorage.getItem('guestMode')).toBe('true')
  sessionStorage.removeItem('guestMode')
  expect(sessionStorage.getItem('guestMode')).toBeNull()
})

/* 15. Modal keyboard accessibility works */
it('AuthModal is focus-trapped and Escape closes it', () => {
  const onClose = vi.fn()
  render(
    <MemoryRouter>
      <AuthModal isOpen={true} onClose={onClose} redirectTo="/dashboard" />
    </MemoryRouter>,
  )
  const modal = screen.getByRole('dialog')
  expect(modal).toHaveAttribute('aria-modal', 'true')
  expect(modal).toHaveAttribute('aria-labelledby', 'auth-modal-title')

  fireEvent.keyDown(modal, { key: 'Escape' })
  expect(onClose).toHaveBeenCalled()
})
