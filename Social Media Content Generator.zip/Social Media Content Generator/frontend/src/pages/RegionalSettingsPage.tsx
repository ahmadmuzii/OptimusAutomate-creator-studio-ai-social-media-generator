import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'
import { ArrowLeft, Save, Languages, Check } from 'lucide-react'
import { ErrorState } from '@/components/ui/ErrorState'
import { LoadingSpinner } from '@/components/ui/LoadingSpinner'
import * as api from '@/api/endpoints'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'
import { RegionalSettings } from '@/types/regional'

const SUPPORTED_LANGUAGES = ['English', 'Urdu', 'Hindi', 'Arabic']

export function RegionalSettingsPage() {
  const { brandId, brand } = useBrandWorkspace()

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)


  const [defaultLanguage, setDefaultLanguage] = useState('English')
  const [supportedLanguages, setSupportedLanguages] = useState<string[]>(['English'])
  const [supportRomanUrdu, setSupportRomanUrdu] = useState(false)
  const [supportBilingual, setSupportBilingual] = useState(false)
  const [supportRtl, setSupportRtl] = useState(false)

  useEffect(() => {
    api.getRegionalSettings(brandId)
      .then((settings) => {
        const s = settings as RegionalSettings
        setSupportedLanguages(s.supported_languages || ['English'])
        setDefaultLanguage(s.default_language || 'English')
        setSupportRomanUrdu(s.support_roman_urdu ?? false)
        setSupportBilingual(s.support_bilingual_posts ?? false)
        setSupportRtl(s.support_rtl_layout ?? false)
      })
      .catch(() => setError('Could not load regional settings.'))
      .finally(() => setLoading(false))
  }, [brandId])

  const toggleLanguage = (lang: string) => {
    setSupportedLanguages(prev =>
      prev.includes(lang)
        ? prev.filter(l => l !== lang)
        : [...prev, lang],
    )
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      await api.updateRegionalSettings(brandId, {
        supported_languages: supportedLanguages,
        default_language: defaultLanguage,
        support_roman_urdu: supportRomanUrdu,
        support_bilingual_posts: supportBilingual,
        support_rtl_layout: supportRtl,
      })
    } catch { setError('Failed to save settings.') }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSpinner />

  if (error) return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>
      <ErrorState message={error} onRetry={() => window.location.reload()} />
    </div>
  )

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Languages className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Regional Settings</h1>
        </div>
        <Button onClick={handleSave} disabled={saving} className="flex items-center gap-2">
          <Save className="w-4 h-4" />
          {saving ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Configure language preferences and regional content settings for {brand.name}.
      </p>

      <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm space-y-6">
        <div>
          <label className="text-sm font-medium text-gray-700 mb-3 block">Default Language</label>
          <select
            value={defaultLanguage}
            onChange={e => setDefaultLanguage(e.target.value)}
            className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
          >
            {SUPPORTED_LANGUAGES.map(lang => (
              <option key={lang} value={lang}>{lang}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700 mb-3 block">Supported Languages</label>
          <div className="space-y-2">
            {SUPPORTED_LANGUAGES.map(lang => (
              <button
                key={lang}
                onClick={() => toggleLanguage(lang)}
                className={`w-full flex items-center justify-between px-4 py-2.5 rounded-lg border transition-colors text-sm ${
                  supportedLanguages.includes(lang)
                    ? 'border-purple-200 bg-purple-50 text-purple-700'
                    : 'border-gray-200 text-gray-600 hover:border-gray-300'
                }`}
              >
                <span>{lang}</span>
                {supportedLanguages.includes(lang) && <Check className="w-4 h-4 text-purple-600" />}
              </button>
            ))}
          </div>
        </div>

        <div className="pt-2 space-y-4">
          <label className="text-sm font-medium text-gray-700 block">Regional Options</label>
          <label className="flex items-center justify-between py-2">
            <span className="text-sm text-gray-700">Support Roman Urdu</span>
            <button
              onClick={() => setSupportRomanUrdu(!supportRomanUrdu)}
              className={`relative w-10 h-5 rounded-full transition-colors ${supportRomanUrdu ? 'bg-purple-600' : 'bg-gray-200'}`}
            >
              <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${supportRomanUrdu ? 'translate-x-5' : ''}`} />
            </button>
          </label>
          <label className="flex items-center justify-between py-2">
            <span className="text-sm text-gray-700">Support Bilingual Posts</span>
            <button
              onClick={() => setSupportBilingual(!supportBilingual)}
              className={`relative w-10 h-5 rounded-full transition-colors ${supportBilingual ? 'bg-purple-600' : 'bg-gray-200'}`}
            >
              <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${supportBilingual ? 'translate-x-5' : ''}`} />
            </button>
          </label>
          <label className="flex items-center justify-between py-2">
            <span className="text-sm text-gray-700">Support RTL Layout</span>
            <button
              onClick={() => setSupportRtl(!supportRtl)}
              className={`relative w-10 h-5 rounded-full transition-colors ${supportRtl ? 'bg-purple-600' : 'bg-gray-200'}`}
            >
              <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${supportRtl ? 'translate-x-5' : ''}`} />
            </button>
          </label>
        </div>
      </div>
    </div>
  )
}
