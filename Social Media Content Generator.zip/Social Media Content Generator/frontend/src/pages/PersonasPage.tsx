import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'
import { ArrowLeft, Plus, Trash2, Copy, Star, Users } from 'lucide-react'
import * as api from '@/api/endpoints'
import type { AudiencePersona } from '@/types/persona'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'

const EMPTY_PERSONA = {
  name: '', description: '', age_range: '', location_market: '',
  main_problem: '', desired_outcome: '', objections: '',
  preferred_tone: '', preferred_platform: '', buying_stage: '',
  content_interests: [] as string[], common_questions: [] as string[],
  main_motivation: '', cta_preference: '', language_preference: '',
  notes: '', is_primary: false,
}

export function PersonasPage() {
  const { brandId, brand } = useBrandWorkspace()

  const [loading, setLoading] = useState(true)

  const [personas, setPersonas] = useState<AudiencePersona[]>([])
  const [editingId, setEditingId] = useState<number | 'new' | null>(null)
  const [form, setForm] = useState<Record<string, unknown>>({ ...EMPTY_PERSONA })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    const data = await api.fetchPersonas(brandId)
    setPersonas(data as AudiencePersona[])
  }, [brandId])

  useEffect(() => {
    load().catch(() => setError('Could not load personas.')).finally(() => setLoading(false))
  }, [brandId, load])

  const startEdit = (persona?: AudiencePersona) => {
    if (persona) {
      setEditingId(persona.id)
      setForm({
        name: persona.name, description: persona.description || '',
        age_range: persona.age_range || '', location_market: persona.location_market || '',
        main_problem: persona.main_problem || '', desired_outcome: persona.desired_outcome || '',
        objections: persona.objections || '', preferred_tone: persona.preferred_tone || '',
        preferred_platform: persona.preferred_platform || '', buying_stage: persona.buying_stage || '',
        content_interests: persona.content_interests || [],
        common_questions: persona.common_questions || [],
        main_motivation: persona.main_motivation || '', cta_preference: persona.cta_preference || '',
        language_preference: persona.language_preference || '', notes: persona.notes || '',
        is_primary: persona.is_primary,
      })
    } else {
      setEditingId('new')
      setForm({ ...EMPTY_PERSONA })
    }
  }

  const cancelEdit = () => { setEditingId(null); setForm({ ...EMPTY_PERSONA }) }

  const handleSave = async () => {
    setSaving(true)
    try {
      if (editingId === 'new') {
        await api.createPersona(brandId, form)
      } else {
        await api.updatePersona(brandId, editingId as number, form)
      }
      await load()
      cancelEdit()
    } catch { setError('Failed to save.') }
    finally { setSaving(false) }
  }

  const handleDelete = async (personaId: number) => {
    try {
      await api.deletePersona(brandId, personaId)
      setPersonas(prev => prev.filter(p => p.id !== personaId))
    } catch { setError('Failed to delete.') }
  }

  const handleDuplicate = async (persona: AudiencePersona) => {
    try {
      const { id: _id, brand_id: _b, created_at: _c, is_primary: _p, ...rest } = persona
      await api.createPersona(brandId, { ...rest, name: `${persona.name} (Copy)` })
      await load()
    } catch { setError('Failed to duplicate.') }
  }

  const setPrimary = async (persona: AudiencePersona) => {
    try {
      await api.updatePersona(brandId, persona.id, { is_primary: true })
      await load()
    } catch { setError('Failed to set primary.') }
  }

  const updateListField = (key: string, index: number, value: string) => {
    const arr = [...((form[key] as string[]) || [])]
    arr[index] = value
    setForm(prev => ({ ...prev, [key]: arr }))
  }

  const addToList = (key: string) => {
    setForm(prev => ({ ...prev, [key]: [...((prev[key] as string[]) || []), ''] }))
  }

  const removeFromList = (key: string, index: number) => {
    const arr = [...((form[key] as string[]) || [])]
    arr.splice(index, 1)
    setForm(prev => ({ ...prev, [key]: arr }))
  }

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600" /></div>
  }

  return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Audience Personas</h1>
        </div>
        <Button onClick={() => startEdit()} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> New Persona
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Create reusable audience personas for {brand.name}. Select personas when generating campaigns to tailor content.
      </p>

      {error && <div className="p-4 bg-red-50 text-sm text-red-600 rounded-lg">{error}</div>}

      {/* Editor Modal */}
      {editingId !== null && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={cancelEdit}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">{editingId === 'new' ? 'New Persona' : 'Edit Persona'}</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Name *</label>
                  <input value={form.name as string} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} placeholder="e.g., Busy University Student" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Description</label>
                  <textarea value={form.description as string} onChange={e => setForm(prev => ({ ...prev, description: e.target.value }))} rows={2} placeholder="Brief description of this persona..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Age Range</label>
                  <input value={form.age_range as string} onChange={e => setForm(prev => ({ ...prev, age_range: e.target.value }))} placeholder="e.g., 18-25" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Location / Market</label>
                  <input value={form.location_market as string} onChange={e => setForm(prev => ({ ...prev, location_market: e.target.value }))} placeholder="e.g., Lahore, Pakistan" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Main Problem</label>
                  <textarea value={form.main_problem as string} onChange={e => setForm(prev => ({ ...prev, main_problem: e.target.value }))} rows={2} placeholder="What problem does this persona face?" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Desired Outcome</label>
                  <textarea value={form.desired_outcome as string} onChange={e => setForm(prev => ({ ...prev, desired_outcome: e.target.value }))} rows={2} placeholder="What outcome does this persona want?" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Objections</label>
                  <textarea value={form.objections as string} onChange={e => setForm(prev => ({ ...prev, objections: e.target.value }))} rows={2} placeholder="Common objections this persona has..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Preferred Tone</label>
                  <input value={form.preferred_tone as string} onChange={e => setForm(prev => ({ ...prev, preferred_tone: e.target.value }))} placeholder="e.g., casual" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Preferred Platform</label>
                  <input value={form.preferred_platform as string} onChange={e => setForm(prev => ({ ...prev, preferred_platform: e.target.value }))} placeholder="e.g., Instagram" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Buying Stage</label>
                  <select value={form.buying_stage as string} onChange={e => setForm(prev => ({ ...prev, buying_stage: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                    <option value="">Not set</option>
                    <option value="awareness">Awareness</option>
                    <option value="interest">Interest</option>
                    <option value="consideration">Consideration</option>
                    <option value="conversion">Conversion</option>
                    <option value="retention">Retention</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Main Motivation</label>
                  <input value={form.main_motivation as string} onChange={e => setForm(prev => ({ ...prev, main_motivation: e.target.value }))} placeholder="e.g., Save time" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">CTA Preference</label>
                  <input value={form.cta_preference as string} onChange={e => setForm(prev => ({ ...prev, cta_preference: e.target.value }))} placeholder="e.g., Learn more" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Language Preference</label>
                  <input value={form.language_preference as string} onChange={e => setForm(prev => ({ ...prev, language_preference: e.target.value }))} placeholder="e.g., en" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Content Interests</label>
                  {((form.content_interests as string[]) || []).map((item, i) => (
                    <div key={i} className="flex items-center gap-2 mt-1">
                      <input value={item} onChange={e => updateListField('content_interests', i, e.target.value)} placeholder="e.g., Tutorials" className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <button onClick={() => removeFromList('content_interests', i)} className="p-1 text-gray-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  ))}
                  <button onClick={() => addToList('content_interests')} className="mt-1 text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1"><Plus className="w-3.5 h-3.5" /> Add interest</button>
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Common Questions</label>
                  {((form.common_questions as string[]) || []).map((item, i) => (
                    <div key={i} className="flex items-center gap-2 mt-1">
                      <input value={item} onChange={e => updateListField('common_questions', i, e.target.value)} placeholder="e.g., How much does it cost?" className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <button onClick={() => removeFromList('common_questions', i)} className="p-1 text-gray-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  ))}
                  <button onClick={() => addToList('common_questions')} className="mt-1 text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1"><Plus className="w-3.5 h-3.5" /> Add question</button>
                </div>
                <div className="sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700">Notes</label>
                  <textarea value={form.notes as string} onChange={e => setForm(prev => ({ ...prev, notes: e.target.value }))} rows={2} placeholder="Additional notes..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
              </div>
              <div className="flex items-center gap-3 pt-4 border-t border-gray-100">
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={form.is_primary as boolean} onChange={e => setForm(prev => ({ ...prev, is_primary: e.target.checked }))} className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" />
                  <span className="text-sm text-gray-700">Set as primary persona</span>
                </label>
              </div>
              <div className="flex items-center gap-3 pt-4">
                <Button onClick={handleSave} disabled={saving || !form.name}>{saving ? 'Saving...' : 'Save'}</Button>
                <button onClick={cancelEdit} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Persona Cards */}
      {personas.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
          <Users className="w-8 h-8 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-400 text-sm mb-4">No personas created yet.</p>
          <Button onClick={() => startEdit()} className="mx-auto flex items-center gap-2">
            <Plus className="w-4 h-4" /> Create Your First Persona
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {personas.map(persona => (
            <div key={persona.id} className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-gray-900">{persona.name}</h3>
                  {persona.is_primary && <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />}
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={() => setPrimary(persona)} className="p-1.5 rounded-lg hover:bg-yellow-50 text-gray-400 hover:text-yellow-600" title="Set as primary">
                    <Star className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => handleDuplicate(persona)} className="p-1.5 rounded-lg hover:bg-gray-50 text-gray-400 hover:text-gray-600" title="Duplicate">
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => startEdit(persona)} className="p-1.5 rounded-lg hover:bg-purple-50 text-gray-400 hover:text-purple-600 text-xs font-medium" title="Edit">
                    Edit
                  </button>
                  <button onClick={() => handleDelete(persona.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500" title="Delete">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              {persona.description && <p className="text-sm text-gray-500 mb-2">{persona.description}</p>}
              <div className="flex flex-wrap gap-2 text-xs text-gray-400">
                {persona.age_range && <span className="bg-gray-50 px-2 py-1 rounded-md">{persona.age_range}</span>}
                {persona.location_market && <span className="bg-gray-50 px-2 py-1 rounded-md">{persona.location_market}</span>}
                {persona.buying_stage && <span className="bg-gray-50 px-2 py-1 rounded-md capitalize">{persona.buying_stage}</span>}
                {persona.preferred_platform && <span className="bg-gray-50 px-2 py-1 rounded-md">{persona.preferred_platform}</span>}
              </div>
              {persona.main_problem && (
                <p className="text-xs text-gray-400 mt-3">
                  <span className="font-medium">Problem:</span> {persona.main_problem.length > 80 ? persona.main_problem.slice(0, 80) + '...' : persona.main_problem}
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
