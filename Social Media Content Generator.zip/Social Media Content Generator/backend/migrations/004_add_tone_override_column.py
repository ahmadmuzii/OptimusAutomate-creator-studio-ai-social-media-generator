"""Safe migration: add tone_override column to campaign_posts table.

Adds tone_override VARCHAR(50) column if it does not already exist.
Preserves all existing data. Safe to run multiple times.
"""

import os
import sqlite3
import sys


def get_db_path() -> str:
    db_dir = os.path.dirname(os.path.abspath(__file__))
    backend_dir = os.path.dirname(db_dir)
    return os.path.join(backend_dir, "social_media.db")


def column_exists(cursor: sqlite3.Cursor, table: str, column: str) -> bool:
    cursor.execute(f"PRAGMA table_info({table})")
    return any(row[1] == column for row in cursor.fetchall())


def run_migration(db_path: str) -> None:
    if not os.path.exists(db_path):
        print(f"Database not found: {db_path}")
        sys.exit(1)

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    if not column_exists(cursor, "campaign_posts", "tone_override"):
        cursor.execute(
            "ALTER TABLE campaign_posts ADD COLUMN tone_override VARCHAR(50)"
        )
        print("Added tone_override column to campaign_posts")
    else:
        print("tone_override column already exists — skipping")

    conn.commit()
    conn.close()
    print("Migration 004 complete.")


if __name__ == "__main__":
    run_migration(get_db_path())
