from __future__ import annotations

import datetime

from pydantic import BaseModel, ConfigDict


class ConversionPathCreate(BaseModel):
    name: str
    destination_type: str
    destination_value: str
    primary_action: str | None = None
    cta_keyword: str | None = None
    campaign_goal: str | None = None
    tracking_label: str | None = None
    utm_source: str | None = None
    utm_medium: str | None = None
    utm_campaign: str | None = None
    is_active: bool = True


class ConversionPathUpdate(BaseModel):
    name: str | None = None
    destination_type: str | None = None
    destination_value: str | None = None
    primary_action: str | None = None
    cta_keyword: str | None = None
    campaign_goal: str | None = None
    tracking_label: str | None = None
    utm_source: str | None = None
    utm_medium: str | None = None
    utm_campaign: str | None = None
    is_active: bool | None = None


class ConversionPathResponse(BaseModel):
    id: int
    brand_id: int
    name: str
    destination_type: str
    destination_value: str
    primary_action: str | None = None
    cta_keyword: str | None = None
    campaign_goal: str | None = None
    tracking_label: str | None = None
    utm_source: str | None = None
    utm_medium: str | None = None
    utm_campaign: str | None = None
    is_active: bool
    created_at: datetime.datetime
    updated_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)
