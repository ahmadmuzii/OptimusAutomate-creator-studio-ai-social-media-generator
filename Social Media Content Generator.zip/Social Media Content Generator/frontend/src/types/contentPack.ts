export interface PackMediaItem {
  type: 'image' | 'video' | 'audio' | 'document'
  url: string
  alt_text?: string | null
  order: number
}

export interface PackLink {
  url: string
  title?: string | null
  description?: string | null
}

export interface ContentPackData {
  title: string
  description?: string | null
  media: PackMediaItem[]
  links: PackLink[]
  notes?: string | null
  tags: string[]
}

export interface ContentPackTemplate {
  id: number
  brand_id: number
  name: string
  description: string | null
  pack_data: ContentPackData
  is_default: boolean
  created_at: string
  updated_at: string
}

export interface ContentPackTemplateCreate {
  name: string
  description?: string | null
  pack_data: ContentPackData
  is_default?: boolean
}

export interface ContentPackTemplateUpdate {
  name?: string
  description?: string | null
  pack_data?: ContentPackData
  is_default?: boolean
}

export interface ContentPackExportRequest {
  campaign_id: number
  post_ids?: number[]
  format: 'json' | 'csv'
}
