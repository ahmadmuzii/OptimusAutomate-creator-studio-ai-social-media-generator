from typing import Literal
from pydantic import field_validator
from pydantic import BaseModel, Field


class SourceFactItem(BaseModel):
    category: Literal[
        "brand",
        "product",
        "service",
        "feature",
        "benefit",
        "target_audience",
        "price",
        "date",
        "location",
        "event",
        "conversion_path",
        "campaign_goal",
        "brand_style",
        "restricted_claim",
        "legal_disclaimer",
        "contact",
        "offer",
        "course",
        "speaker",
        "testimonial",
        "other",
    ] = "other"
    label: str = Field(..., max_length=200)
    value: str = Field(..., max_length=2000)
    source_excerpt: str = Field(..., max_length=1000)
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)


class SourceExtractionResult(BaseModel):
    document_title: str = Field(default="", max_length=500)
    facts: list[SourceFactItem] = Field(default_factory=list)


class CampaignDayPlan(BaseModel):
    day: int = Field(..., ge=1, le=30)
    theme: str = Field(..., max_length=200)
    purpose: str = Field(..., max_length=500)
    funnel_stage: Literal["awareness", "interest", "decision", "action", "retention"] = "awareness"
    persona_id: int | None = None
    content_type: str = Field(default="static_post", max_length=100)
    audience_action: str = Field(default="", max_length=500)
    reason_for_format: str = Field(default="", max_length=500)
    source_fact_ids: list[int] = Field(default_factory=list)
    performance_insight_ids: list[int] = Field(default_factory=list)
    competitor_opportunity_ids: list[int] = Field(default_factory=list)


class CampaignStrategy(BaseModel):
    campaign_name: str = Field(..., max_length=500)
    campaign_summary: str = Field(..., max_length=2000)
    strategy: str = Field(..., max_length=2000)
    days: list[CampaignDayPlan] = Field(..., min_length=1, max_length=30)


class GeneratedPost(BaseModel):
    hook: str = Field(default="", max_length=500)
    caption: str = Field(..., max_length=5000)
    call_to_action: str = Field(default="", max_length=500)
    hashtags: list[str] = Field(default_factory=list, max_length=30)
    content_theme: str = Field(default="", max_length=200)
    post_idea: str = Field(default="", max_length=500)
    content_type: str = Field(default="static_post", max_length=100)
    suggested_time: str = Field(default="", max_length=100)
    purpose: str = Field(default="", max_length=500)
    funnel_stage: Literal["awareness", "interest", "decision", "action", "retention"] = "awareness"
    audience_action: str = Field(default="", max_length=500)
    reason_for_format: str = Field(default="", max_length=500)
    source_fact_ids: list[int] = Field(default_factory=list)
    guardrails_applied: list[str] = Field(default_factory=list)
    performance_insights_applied: list[str] = Field(default_factory=list)


class PostGenerationResult(BaseModel):
    posts: list[GeneratedPost] = Field(..., min_length=1)

@field_validator("persona_id", mode="before")
@classmethod
def normalize_persona_id(cls, value):
    if value is None or value == "":
        return None

    if isinstance(value, int):
        return value

    if isinstance(value, str):
        if value.strip().isdigit():
            return int(value.strip())
        return None

    return None