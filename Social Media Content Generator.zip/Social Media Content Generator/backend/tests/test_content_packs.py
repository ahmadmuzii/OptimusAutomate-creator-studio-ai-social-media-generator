from __future__ import annotations


class TestContentPackTemplates:
    def test_create_template(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Launch Campaign Pack",
            "description": "Template for product launches",
            "pack_data": {
                "title": "Product Launch",
                "description": "A complete launch strategy",
                "media": [{"type": "image", "url": "https://example.com/img.png", "alt_text": "Hero", "order": 0}],
                "links": [{"url": "https://example.com", "title": "Landing Page", "description": "Product page"}],
                "notes": "Use bold visuals",
                "tags": ["launch", "product"],
            },
            "is_default": True,
        }
        response = client.post(
            f"/api/v1/brands/{brand_id}/content-packs",
            json=payload,
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == payload["name"]
        assert data["description"] == payload["description"]
        assert data["is_default"] is True
        assert data["pack_data"]["title"] == "Product Launch"
        assert data["pack_data"]["tags"] == ["launch", "product"]
        assert data["brand_id"] == brand_id
        assert "id" in data
        assert "created_at" in data

    def test_list_templates(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        client.post(
            f"/api/v1/brands/{brand_id}/content-packs",
            json={"name": "T1", "pack_data": {"title": "Pack 1"}},
            headers=auth_headers,
        )
        client.post(
            f"/api/v1/brands/{brand_id}/content-packs",
            json={"name": "T2", "pack_data": {"title": "Pack 2"}},
            headers=auth_headers,
        )

        response = client.get(
            f"/api/v1/brands/{brand_id}/content-packs",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 2
        names = [t["name"] for t in data]
        assert "T1" in names
        assert "T2" in names

    def test_get_template(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/content-packs",
            json={"name": "My Pack", "pack_data": {"title": "My Pack Title"}},
            headers=auth_headers,
        )
        created = create_resp.json()

        response = client.get(
            f"/api/v1/brands/{brand_id}/content-packs/{created['id']}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["id"] == created["id"]
        assert data["name"] == "My Pack"
        assert data["pack_data"]["title"] == "My Pack Title"

    def test_update_template(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/content-packs",
            json={"name": "Original", "pack_data": {"title": "Original Title"}},
            headers=auth_headers,
        )
        created = create_resp.json()

        response = client.put(
            f"/api/v1/brands/{brand_id}/content-packs/{created['id']}",
            json={
                "name": "Updated Name",
                "description": "Updated description",
                "pack_data": {
                    "title": "Updated Title",
                    "tags": ["updated"],
                },
            },
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Updated Name"
        assert data["description"] == "Updated description"
        assert data["pack_data"]["title"] == "Updated Title"
        assert data["pack_data"]["tags"] == ["updated"]

    def test_delete_template(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/content-packs",
            json={"name": "Delete Me", "pack_data": {"title": "Gone"}},
            headers=auth_headers,
        )
        created = create_resp.json()

        response = client.delete(
            f"/api/v1/brands/{brand_id}/content-packs/{created['id']}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert response.json()["detail"] == "Content pack template deleted"

        get_resp = client.get(
            f"/api/v1/brands/{brand_id}/content-packs/{created['id']}",
            headers=auth_headers,
        )
        assert get_resp.status_code == 404

    def test_template_not_found(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.get(
            f"/api/v1/brands/{brand_id}/content-packs/99999",
            headers=auth_headers,
        )
        assert response.status_code == 404

    def test_export_content_pack(self, client, auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        campaign_id = created_campaign["id"]
        response = client.post(
            f"/api/v1/brands/{brand_id}/content-packs/export",
            json={"campaign_id": campaign_id, "format": "json"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["campaign_id"] == campaign_id
        assert data["total_posts"] > 0
        assert len(data["items"]) == data["total_posts"]
        for item in data["items"]:
            assert "day" in item
            assert "content_theme" in item
            assert "post_idea" in item
            assert "content_type" in item
            assert "platform" in item
            assert "caption" in item
            assert "call_to_action" in item
            assert "hashtags" in item

    def test_export_content_pack_with_post_filter(self, client, auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        campaign_id = created_campaign["id"]
        # Get the first post's id from the export
        export_resp = client.post(
            f"/api/v1/brands/{brand_id}/content-packs/export",
            json={"campaign_id": campaign_id, "format": "json"},
            headers=auth_headers,
        )
        all_items = export_resp.json()
        first_post_id = all_items["items"][0]["id"] if "id" in all_items["items"][0] else None

        if first_post_id:
            response = client.post(
                f"/api/v1/brands/{brand_id}/content-packs/export",
                json={"campaign_id": campaign_id, "post_ids": [first_post_id], "format": "json"},
                headers=auth_headers,
            )
            assert response.status_code == 200
            data = response.json()
            assert data["total_posts"] == 1

    def test_export_no_posts(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        # Create a campaign with no posts
        camp_resp = client.post(
            "/api/v1/campaigns",
            json={
                "name": "Empty Campaign",
                "platform": "instagram",
                "tone": "professional",
                "campaign_goal": "brand_awareness",
                "brand_profile_id": brand_id,
                "posts": [],
            },
            headers=auth_headers,
        )
        assert camp_resp.status_code == 200
        empty_campaign = camp_resp.json()

        response = client.post(
            f"/api/v1/brands/{brand_id}/content-packs/export",
            json={"campaign_id": empty_campaign["id"], "format": "json"},
            headers=auth_headers,
        )
        assert response.status_code == 404


class TestContentPackCrossUser:
    def test_cannot_access_other_users_template(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/content-packs",
            json={"name": "Secret", "pack_data": {"title": "Secret Pack"}},
            headers=auth_headers,
        )
        assert create_resp.status_code == 200
        template_id = create_resp.json()["id"]

        response = client.get(
            f"/api/v1/brands/{brand_id}/content-packs/{template_id}",
            headers=second_auth_headers,
        )
        assert response.status_code == 404

    def test_cannot_update_other_users_template(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/content-packs",
            json={"name": "Mine", "pack_data": {"title": "Mine"}},
            headers=auth_headers,
        )
        template_id = create_resp.json()["id"]

        response = client.put(
            f"/api/v1/brands/{brand_id}/content-packs/{template_id}",
            json={"name": "Hacked"},
            headers=second_auth_headers,
        )
        assert response.status_code == 404

    def test_cannot_delete_other_users_template(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/content-packs",
            json={"name": "Mine", "pack_data": {"title": "Mine"}},
            headers=auth_headers,
        )
        template_id = create_resp.json()["id"]

        response = client.delete(
            f"/api/v1/brands/{brand_id}/content-packs/{template_id}",
            headers=second_auth_headers,
        )
        assert response.status_code == 404

    def test_cannot_export_other_users_campaign(self, client, second_auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        response = client.post(
            f"/api/v1/brands/{brand_id}/content-packs/export",
            json={"campaign_id": created_campaign["id"], "format": "json"},
            headers=second_auth_headers,
        )
        assert response.status_code == 404

    def test_cannot_list_other_users_templates(self, client, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.get(
            f"/api/v1/brands/{brand_id}/content-packs",
            headers=second_auth_headers,
        )
        assert response.status_code == 404
