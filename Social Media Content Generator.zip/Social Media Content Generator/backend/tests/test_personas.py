from __future__ import annotations


class TestPersonasAPI:
    """Test Audience Persona CRUD endpoints."""

    def test_create_persona(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "name": "Busy Professional",
            "description": "Works 9-5, needs quick solutions",
            "age_range": "25-40",
            "main_problem": "No time for research",
            "desired_outcome": "Find trusted products fast",
            "buying_stage": "consideration",
            "is_primary": True,
        }
        response = client.post(f"/api/v1/brands/{brand_id}/personas", json=payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Busy Professional"
        assert data["buying_stage"] == "consideration"
        assert data["is_primary"] is True

    def test_list_personas(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        client.post(f"/api/v1/brands/{brand_id}/personas", json={"name": "Persona A"}, headers=auth_headers)
        client.post(f"/api/v1/brands/{brand_id}/personas", json={"name": "Persona B"}, headers=auth_headers)
        response = client.get(f"/api/v1/brands/{brand_id}/personas", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2

    def test_get_persona(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(
            f"/api/v1/brands/{brand_id}/personas", json={"name": "Test Persona"}, headers=auth_headers
        ).json()
        response = client.get(f"/api/v1/brands/{brand_id}/personas/{created['id']}", headers=auth_headers)
        assert response.status_code == 200
        assert response.json()["name"] == "Test Persona"

    def test_update_persona(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(
            f"/api/v1/brands/{brand_id}/personas", json={"name": "Old Name"}, headers=auth_headers
        ).json()
        response = client.put(
            f"/api/v1/brands/{brand_id}/personas/{created['id']}",
            json={"name": "New Name", "age_range": "30-45"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "New Name"
        assert data["age_range"] == "30-45"

    def test_delete_persona(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(
            f"/api/v1/brands/{brand_id}/personas", json={"name": "Delete Me"}, headers=auth_headers
        ).json()
        response = client.delete(f"/api/v1/brands/{brand_id}/personas/{created['id']}", headers=auth_headers)
        assert response.status_code == 200
        get_resp = client.get(f"/api/v1/brands/{brand_id}/personas", headers=auth_headers)
        assert len(get_resp.json()) == 0

    def test_cannot_access_other_users_persona(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        created = client.post(f"/api/v1/brands/{brand_id}/personas", json={"name": "Mine"}, headers=auth_headers).json()
        response = client.get(f"/api/v1/brands/{brand_id}/personas/{created['id']}", headers=second_auth_headers)
        assert response.status_code == 404

    def test_set_primary_persona(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        p1 = client.post(
            f"/api/v1/brands/{brand_id}/personas", json={"name": "P1", "is_primary": True}, headers=auth_headers
        ).json()
        assert p1["is_primary"] is True
        p2 = client.post(
            f"/api/v1/brands/{brand_id}/personas", json={"name": "P2", "is_primary": True}, headers=auth_headers
        ).json()
        assert p2["is_primary"] is True
        p1_refetch = client.get(f"/api/v1/brands/{brand_id}/personas/{p1['id']}", headers=auth_headers).json()
        assert p1_refetch["is_primary"] is False

    def test_duplicate_persona(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        dup = client.post(
            f"/api/v1/brands/{brand_id}/personas",
            json={"name": "Original (Copy)", "age_range": "20-30"},
            headers=auth_headers,
        ).json()
        assert dup["name"] == "Original (Copy)"
        assert dup["age_range"] == "20-30"
