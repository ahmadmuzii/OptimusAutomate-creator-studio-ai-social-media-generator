import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react'
import { useSearchParams } from 'react-router-dom'

interface GuestModeState {
  isGuestMode: boolean
  enterGuestMode: () => void
  exitGuestMode: () => void
}

const GuestModeContext = createContext<GuestModeState | null>(null)

export function GuestModeProvider({ children }: { children: ReactNode }) {
  const [searchParams, setSearchParams] = useSearchParams()
  const [isGuestMode, setInternal] = useState<boolean>(() => {
    return sessionStorage.getItem('guestMode') === 'true'
  })

  useEffect(() => {
    const fromUrl = searchParams.get('mode') === 'guest'
    const fromStorage = sessionStorage.getItem('guestMode') === 'true'
    const active = fromUrl || fromStorage
    setInternal(active)
    if (active) {
      sessionStorage.setItem('guestMode', 'true')
    }
  }, [searchParams])

  const enterGuestMode = useCallback(() => {
    sessionStorage.setItem('guestMode', 'true')
    setInternal(true)
    setSearchParams({ mode: 'guest' }, { replace: true })
  }, [setSearchParams])

  const exitGuestMode = useCallback(() => {
    sessionStorage.removeItem('guestMode')
    setInternal(false)
  }, [])

  return (
    <GuestModeContext.Provider value={{ isGuestMode, enterGuestMode, exitGuestMode }}>
      {children}
    </GuestModeContext.Provider>
  )
}

export function useGuestMode(): GuestModeState {
  const context = useContext(GuestModeContext)
  if (!context) throw new Error('useGuestMode must be used within a GuestModeProvider')
  return context
}
