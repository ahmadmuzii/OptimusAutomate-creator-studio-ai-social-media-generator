from __future__ import annotations

from pydantic import BaseModel


class BrandGuardrailRequest(BaseModel):
    required_phrases: list[str] | None = None
    forbidden_words: list[str] | None = None
    competitors_never_mention: list[str] | None = None
    approved_product_descriptions: list[str] | None = None
    allowed_claims: list[str] | None = None
    restricted_claims: list[str] | None = None
    preferred_spellings: dict[str, str] | None = None
    preferred_capitalizations: list[str] | None = None
    product_names: list[str] | None = None
    service_names: list[str] | None = None
    brand_name_aliases: list[str] | None = None
    required_legal_disclaimer: str | None = None
    example_posts_liked: list[dict] | None = None
    example_posts_disliked: list[dict] | None = None
    emoji_allowance: str | None = None
    profanity_level: str | None = None
    formality_level: str | None = None
    max_hashtag_count: int | None = None
    min_hashtag_count: int | None = None
    allowed_languages: list[str] | None = None
    default_language: str | None = None
    preferred_cta_style: str | None = None
    forbidden_cta_styles: list[str] | None = None
    restricted_topics: list[str] | None = None
    sensitive_topics_requiring_review: list[str] | None = None


class BrandGuardrailResponse(BaseModel):
    id: int
    brand_id: int
    required_phrases: list[str] | None = None
    forbidden_words: list[str] | None = None
    competitors_never_mention: list[str] | None = None
    approved_product_descriptions: list[str] | None = None
    allowed_claims: list[str] | None = None
    restricted_claims: list[str] | None = None
    preferred_spellings: dict[str, str] | None = None
    preferred_capitalizations: list[str] | None = None
    product_names: list[str] | None = None
    service_names: list[str] | None = None
    brand_name_aliases: list[str] | None = None
    required_legal_disclaimer: str | None = None
    example_posts_liked: list[dict] | None = None
    example_posts_disliked: list[dict] | None = None
    emoji_allowance: str | None = None
    profanity_level: str | None = None
    formality_level: str | None = None
    max_hashtag_count: int | None = None
    min_hashtag_count: int | None = None
    allowed_languages: list[str] | None = None
    default_language: str | None = None
    preferred_cta_style: str | None = None
    forbidden_cta_styles: list[str] | None = None
    restricted_topics: list[str] | None = None
    sensitive_topics_requiring_review: list[str] | None = None
    created_at: str | None = None
    updated_at: str | None = None

    model_config = {"from_attributes": True}


class BrandCheckItem(BaseModel):
    code: str
    label: str
    status: str  # passed, warning, blocked
    message: str
    field: str | None = None
    post_id: int | None = None
    matched_text: str | None = None


class BrandCheckSummary(BaseModel):
    passed: int = 0
    warnings: int = 0
    blocked: int = 0


class BrandCheckResult(BaseModel):
    status: str  # passed, warning, blocked
    summary: BrandCheckSummary
    checks: list[BrandCheckItem]
    campaign_id: int | None = None
    brand_check_version: str = "1.0"
