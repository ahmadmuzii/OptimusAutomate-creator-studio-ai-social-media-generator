from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

from app.services.llm_service import (
    _build_caption_prompt,
    _build_system_prompt,
    _build_user_prompt,
    call_groq,
    call_groq_for_caption,
)


class TestBuildPrompts:
    def test_system_prompt_includes_day_count(self) -> None:
        prompt = _build_system_prompt(5)
        assert "5 days" in prompt
        assert "numbered 1-5" in prompt
        assert "Exactly 5 days" in prompt

    def test_system_prompt_default_7_days(self) -> None:
        prompt = _build_system_prompt(7)
        assert "7 days" in prompt
        assert "numbered 1-7" in prompt

    def test_user_prompt_includes_all_params(self) -> None:
        prompt = _build_user_prompt(
            brand_name="TestBrand",
            brand_description="A test company",
            niche="tech",
            target_audience="developers",
            platform="Twitter",
            tone="funny",
            campaign_goal="engagement",
            days=3,
        )
        assert "TestBrand" in prompt
        assert "A test company" in prompt
        assert "tech" in prompt
        assert "developers" in prompt
        assert "Twitter" in prompt
        assert "funny" in prompt
        assert "engagement" in prompt
        assert "Day 1" in prompt
        assert "Day 2" in prompt
        assert "Day 3" in prompt

    def test_caption_prompt_includes_post_idea(self) -> None:
        prompt = _build_caption_prompt(
            post_idea="Introduction post",
            platform="instagram",
            tone="professional",
            brand_details={
                "brandName": "TestBrand",
                "niche": "tech",
                "targetAudience": "devs",
                "campaignGoal": "engagement",
                "brandDescription": "A test",
            },
        )
        assert "Introduction post" in prompt
        assert "TestBrand" in prompt
        assert "tech" in prompt
        assert "devs" in prompt
        assert "instagram" in prompt
        assert "professional" in prompt


class TestCallGroq:
    def test_returns_none_when_groq_disabled(self) -> None:
        with patch("app.services.llm_service.settings") as mock_settings:
            mock_settings.groq_enabled = False
            mock_settings.groq_api_key = "test-key"
            result = call_groq("b", "d", "n", "a", "p", "t", "g")
            assert result is None

    def test_returns_none_when_key_missing(self) -> None:
        with patch("app.services.llm_service.settings") as mock_settings:
            mock_settings.groq_enabled = True
            mock_settings.groq_api_key = ""
            result = call_groq("b", "d", "n", "a", "p", "t", "g")
            assert result is None

    def test_returns_none_when_sdk_not_available(self) -> None:
        with (
            patch("app.services.llm_service.settings") as mock_settings,
            patch("app.services.llm_service._groq_available", False),
        ):
            mock_settings.groq_enabled = True
            mock_settings.groq_api_key = "test-key"
            result = call_groq("b", "d", "n", "a", "p", "t", "g")
            assert result is None

    def test_returns_parsed_json_on_success(self) -> None:
        expected = {"calendar": [{"day": 1, "caption": "hello"}]}
        mock_completion = MagicMock()
        mock_completion.choices = [MagicMock(message=MagicMock(content=json.dumps(expected)))]
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_completion

        with (
            patch("app.services.llm_service.settings") as mock_settings,
            patch("app.services.llm_service._groq_available", True),
            patch("app.services.llm_service.Groq", return_value=mock_client),
        ):
            mock_settings.groq_enabled = True
            mock_settings.groq_api_key = "test-key"
            mock_settings.groq_model = "test-model"
            mock_settings.groq_timeout_seconds = 30
            mock_settings.groq_max_retries = 1

            result = call_groq("b", "d", "n", "a", "p", "t", "g", days=1)
            assert result == expected

    def test_retries_on_failure_then_returns_none(self) -> None:
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("API error")

        with (
            patch("app.services.llm_service.settings") as mock_settings,
            patch("app.services.llm_service._groq_available", True),
            patch("app.services.llm_service.Groq", return_value=mock_client),
        ):
            mock_settings.groq_enabled = True
            mock_settings.groq_api_key = "test-key"
            mock_settings.groq_model = "test-model"
            mock_settings.groq_timeout_seconds = 30
            mock_settings.groq_max_retries = 2

            result = call_groq("b", "d", "n", "a", "p", "t", "g")
            assert result is None
            assert mock_client.chat.completions.create.call_count == 2

    def test_retries_on_empty_response(self) -> None:
        mock_completion = MagicMock()
        mock_completion.choices = [MagicMock(message=MagicMock(content=None))]
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_completion

        with (
            patch("app.services.llm_service.settings") as mock_settings,
            patch("app.services.llm_service._groq_available", True),
            patch("app.services.llm_service.Groq", return_value=mock_client),
        ):
            mock_settings.groq_enabled = True
            mock_settings.groq_api_key = "test-key"
            mock_settings.groq_model = "test-model"
            mock_settings.groq_timeout_seconds = 30
            mock_settings.groq_max_retries = 2

            result = call_groq("b", "d", "n", "a", "p", "t", "g")
            assert result is None
            assert mock_client.chat.completions.create.call_count == 2


class TestCallGroqForCaption:
    def test_returns_parsed_json_on_success(self) -> None:
        expected = {"caption": "Hello!", "callToAction": "Follow", "hashtags": ["#test"]}
        mock_completion = MagicMock()
        mock_completion.choices = [MagicMock(message=MagicMock(content=json.dumps(expected)))]
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_completion

        with (
            patch("app.services.llm_service.settings") as mock_settings,
            patch("app.services.llm_service._groq_available", True),
            patch("app.services.llm_service.Groq", return_value=mock_client),
        ):
            mock_settings.groq_enabled = True
            mock_settings.groq_api_key = "test-key"
            mock_settings.groq_model = "test-model"
            mock_settings.groq_timeout_seconds = 30
            mock_settings.groq_max_retries = 1

            result = call_groq_for_caption(
                post_idea="Intro",
                platform="instagram",
                tone="professional",
                brand_details={"brandName": "Test"},
            )
            assert result == expected

    def test_returns_none_when_disabled(self) -> None:
        with patch("app.services.llm_service.settings") as mock_settings:
            mock_settings.groq_enabled = False
            result = call_groq_for_caption("i", "p", "t", {})
            assert result is None

    def test_returns_none_when_key_missing(self) -> None:
        with patch("app.services.llm_service.settings") as mock_settings:
            mock_settings.groq_enabled = True
            mock_settings.groq_api_key = ""
            result = call_groq_for_caption("i", "p", "t", {})
            assert result is None
