import type { PlatformConfig } from '@/config/platforms'
import { cn } from '@/utils/cn'

interface PlatformCardProps {
  platform: PlatformConfig
  isSelected: boolean
  onSelect: (id: string) => void
}

export function PlatformCard({ platform, isSelected, onSelect }: PlatformCardProps) {
  const Icon = platform.icon

  return (
    <div
      onClick={() => onSelect(platform.id)}
      className={cn(
        'relative p-4 rounded-2xl border-2 bg-white cursor-pointer transition-all duration-300 ease-out',
        isSelected
          ? 'border-purple-600 bg-purple-50/50 shadow-md shadow-purple-100'
          : 'border-gray-100 hover:border-purple-300 hover:shadow-lg hover:shadow-purple-100/50',
      )}
    >
      <div className="flex flex-col items-center gap-3">
        <div
          className={cn(
            'w-12 h-12 rounded-xl bg-gradient-to-br flex items-center justify-center shadow-lg transition-transform duration-300',
            platform.gradient,
            isSelected ? 'scale-110' : 'group-hover:scale-105',
          )}
        >
          <Icon className="w-6 h-6 text-white" />
        </div>
        <span className={cn('text-sm font-medium', isSelected ? 'text-purple-700' : 'text-gray-600')}>
          {platform.name}
        </span>
      </div>

      {isSelected && (
        <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-purple-600 flex items-center justify-center">
          <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
          </svg>
        </div>
      )}
    </div>
  )
}
