from dataclasses import dataclass, field
from typing import Any

import structlog
from sqlalchemy.orm import Session

from app.models.db_models import (
    AudiencePersona,
    BrandGuardrail,
    BrandProfile,
    BrandRegionalSettings,
    Campaign,
    CampaignExperiment,
    CampaignPost,
    ContentGapReport,
    ConversionPath,
    ExperimentVariant,
    PerformanceInsight,
    SourceDocument,
    SourceFact,
)
from app.models.strategy_db import StrategyTemplate

logger = structlog.get_logger(__name__)


@dataclass
class BrandContext:
    id: int
    name: str
    description: str | None = None
    niche: str | None = None
    target_audience: str | None = None
    website: str | None = None


@dataclass
class GuardrailContext:
    required_phrases: list[str] = field(default_factory=list)
    forbidden_words: list[str] = field(default_factory=list)
    competitors_never_mention: list[str] = field(default_factory=list)
    approved_product_descriptions: list[str] = field(default_factory=list)
    allowed_claims: list[str] = field(default_factory=list)
    restricted_claims: list[str] = field(default_factory=list)
    preferred_spellings: dict[str, str] = field(default_factory=dict)
    preferred_capitalizations: list[str] = field(default_factory=list)
    product_names: list[str] = field(default_factory=list)
    service_names: list[str] = field(default_factory=list)
    brand_name_aliases: list[str] = field(default_factory=list)
    required_legal_disclaimer: str | None = None
    emoji_allowance: str | None = None
    profanity_level: str | None = None
    formality_level: str | None = None
    max_hashtag_count: int | None = None
    min_hashtag_count: int | None = None
    allowed_languages: list[str] = field(default_factory=list)
    default_language: str | None = None
    preferred_cta_style: str | None = None
    forbidden_cta_styles: list[str] = field(default_factory=list)
    restricted_topics: list[str] = field(default_factory=list)
    sensitive_topics_requiring_review: list[str] = field(default_factory=list)
    example_posts_liked: list[dict[str, str]] | None = None
    example_posts_disliked: list[dict[str, str]] | None = None

    def count_active_rules(self) -> int:
        count = 0
        for val in self.__dict__.values():
            if isinstance(val, list) and val:
                count += 1
            elif isinstance(val, dict) and val:
                count += 1
            elif isinstance(val, str) and val:
                count += 1
            elif isinstance(val, int) and val is not None:
                count += 1
        return count


@dataclass
class PersonaContext:
    id: int
    name: str | None = None
    description: str | None = None
    main_problem: str | None = None
    desired_outcome: str | None = None
    objections: str | None = None
    preferred_tone: str | None = None
    preferred_platform: str | None = None
    buying_stage: str | None = None
    motivation: str | None = None
    cta_preference: str | None = None
    language: str | None = None
    content_interests: list[str] | None = None
    questions: list[str] | None = None


@dataclass
class ConversionPathContext:
    id: int
    name: str
    destination_type: str | None = None
    destination_value: str | None = None
    primary_action: str | None = None
    cta_keyword: str | None = None
    campaign_goal: str | None = None
    tracking_label: str | None = None


@dataclass
class SourceFactContext:
    id: int
    category: str
    label: str
    value: str
    source_section: str | None = None
    confidence: float = 0.5


@dataclass
class StrategyContext:
    id: int | None = None
    name: str | None = None
    description: str | None = None
    funnel_stage: str | None = None
    campaign_goal: str | None = None
    recommended_ctas: str | None = None
    content_mix: str | None = None


@dataclass
class PerformanceInsightContext:
    id: int
    pattern_type: str
    finding: str
    platform: str | None = None
    content_type: str | None = None
    confidence: float | None = None


@dataclass
class ExperimentLearningContext:
    experiment_name: str
    variable_tested: str
    success_metric: str
    winner_label: str
    winner_value: str


@dataclass
class FreshnessContext:
    fatigue_score: float = 0.0
    repeated_themes: list[str] = field(default_factory=list)
    cta_diversity: dict[str, int] = field(default_factory=dict)
    recent_campaign_names: list[str] = field(default_factory=list)
    recent_hooks: list[str] = field(default_factory=list)
    recent_ctas: list[str] = field(default_factory=list)
    recent_hashtags: list[list[str]] = field(default_factory=list)


@dataclass
class CompetitorOpportunityContext:
    topic: str
    description: str


@dataclass
class RegionalContext:
    default_language: str = "en"
    supported_languages: list[str] = field(default_factory=lambda: ["en"])
    support_roman_urdu: bool = False
    support_bilingual_posts: bool = False
    support_rtl_layout: bool = False


@dataclass
class RecentCampaignContext:
    name: str
    platform: str
    tone: str
    campaign_goal: str
    posts: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class CampaignRequestContext:
    platform: str
    tone: str
    campaign_goal: str
    persona_ids: list[int] = field(default_factory=list)
    conversion_path_id: int | None = None
    strategy_id: int | None = None
    performance_insight_ids: list[int] = field(default_factory=list)
    experiment_learning_ids: list[int] = field(default_factory=list)
    competitor_opportunity_ids: list[int] = field(default_factory=list)
    days_count: int = 7


@dataclass
class CampaignGenerationContext:
    brand: BrandContext | None = None
    guardrails: GuardrailContext = field(default_factory=GuardrailContext)
    personas: list[PersonaContext] = field(default_factory=list)
    conversion_path: ConversionPathContext | None = None
    source_facts: list[SourceFactContext] = field(default_factory=list)
    strategy: StrategyContext | None = None
    performance_insights: list[PerformanceInsightContext] = field(default_factory=list)
    experiment_learnings: list[ExperimentLearningContext] = field(default_factory=list)
    freshness_context: FreshnessContext = field(default_factory=FreshnessContext)
    competitor_opportunities: list[CompetitorOpportunityContext] = field(default_factory=list)
    regional_settings: RegionalContext = field(default_factory=RegionalContext)
    recent_campaigns: list[RecentCampaignContext] = field(default_factory=list)
    request: CampaignRequestContext | None = None


def build_campaign_context(
    db: Session,
    brand_id: int,
    user_id: int,
    request: CampaignRequestContext | None = None,
) -> CampaignGenerationContext:
    ctx = CampaignGenerationContext(request=request)

    brand = (
        db.query(BrandProfile)
        .filter(
            BrandProfile.id == brand_id,
            BrandProfile.user_id == user_id,
        )
        .first()
    )
    if not brand:
        logger.warning("Brand not found or unauthorized", brand_id=brand_id, user_id=user_id)
        return ctx

    ctx.brand = BrandContext(
        id=brand.id,
        name=brand.name,
        description=brand.description,
        niche=brand.niche,
        target_audience=brand.target_audience,
        website=brand.website,
    )

    guardrail = db.query(BrandGuardrail).filter(BrandGuardrail.brand_id == brand_id).first()
    if guardrail:
        ctx.guardrails = GuardrailContext(
            required_phrases=list(guardrail.required_phrases or []),
            forbidden_words=list(guardrail.forbidden_words or []),
            competitors_never_mention=list(guardrail.competitors_never_mention or []),
            approved_product_descriptions=list(guardrail.approved_product_descriptions or []),
            allowed_claims=list(guardrail.allowed_claims or []),
            restricted_claims=list(guardrail.restricted_claims or []),
            preferred_spellings=dict(guardrail.preferred_spellings or {}),
            preferred_capitalizations=list(guardrail.preferred_capitalizations or []),
            product_names=list(guardrail.product_names or []),
            service_names=list(guardrail.service_names or []),
            brand_name_aliases=list(guardrail.brand_name_aliases or []),
            required_legal_disclaimer=guardrail.required_legal_disclaimer,
            emoji_allowance=guardrail.emoji_allowance,
            profanity_level=guardrail.profanity_level,
            formality_level=guardrail.formality_level,
            max_hashtag_count=guardrail.max_hashtag_count,
            min_hashtag_count=guardrail.min_hashtag_count,
            allowed_languages=list(guardrail.allowed_languages or []),
            default_language=guardrail.default_language,
            preferred_cta_style=guardrail.preferred_cta_style,
            forbidden_cta_styles=list(guardrail.forbidden_cta_styles or []),
            restricted_topics=list(guardrail.restricted_topics or []),
            sensitive_topics_requiring_review=list(guardrail.sensitive_topics_requiring_review or []),
        )
        if guardrail.example_posts_liked:
            ctx.guardrails.example_posts_liked = list(guardrail.example_posts_liked)
        if guardrail.example_posts_disliked:
            ctx.guardrails.example_posts_disliked = list(guardrail.example_posts_disliked)

    if request and request.persona_ids:
        personas = (
            db.query(AudiencePersona)
            .filter(
                AudiencePersona.id.in_(request.persona_ids),
                AudiencePersona.brand_id == brand_id,
            )
            .all()
        )
        for p in personas:
            ctx.personas.append(
                PersonaContext(
                    id=p.id,
                    name=p.name,
                    description=p.description,
                    main_problem=p.main_problem,
                    desired_outcome=p.desired_outcome,
                    objections=p.objections,
                    preferred_tone=p.preferred_tone,
                    preferred_platform=p.preferred_platform,
                    buying_stage=p.buying_stage,
                    motivation=p.main_motivation,
                    cta_preference=p.cta_preference,
                    language=p.language_preference,
                )
            )

    if request and request.conversion_path_id:
        cp = (
            db.query(ConversionPath)
            .filter(
                ConversionPath.id == request.conversion_path_id,
                ConversionPath.brand_id == brand_id,
                ConversionPath.is_active,
            )
            .first()
        )
        if cp:
            ctx.conversion_path = ConversionPathContext(
                id=cp.id,
                name=cp.name,
                destination_type=cp.destination_type,
                destination_value=cp.destination_value,
                primary_action=cp.primary_action,
                cta_keyword=cp.cta_keyword,
                campaign_goal=cp.campaign_goal,
                tracking_label=cp.tracking_label,
            )

    facts = (
        db.query(SourceFact)
        .join(SourceDocument)
        .filter(
            SourceDocument.brand_id == brand_id,
            SourceFact.approved_by_user,
            ~SourceFact.excluded_by_user,
        )
        .all()
    )
    for f in facts:
        ctx.source_facts.append(
            SourceFactContext(
                id=f.id,
                category=f.category or "other",
                label=f.label or "",
                value=f.value or "",
                source_section=f.source_section,
                confidence=f.confidence or 0.5,
            )
        )

    if request and request.strategy_id:
        strat = (
            db.query(StrategyTemplate)
            .filter(
                StrategyTemplate.id == request.strategy_id,
                StrategyTemplate.brand_id == brand_id,
            )
            .first()
        )
        if strat:
            ctx.strategy = StrategyContext(
                id=strat.id,
                name=strat.name,
                description=strat.description,
                funnel_stage=strat.funnel_stage,
                campaign_goal=strat.campaign_goal,
                recommended_ctas=strat.recommended_ctas,
                content_mix=strat.content_mix,
            )

    if request and request.performance_insight_ids:
        insights = (
            db.query(PerformanceInsight)
            .filter(
                PerformanceInsight.id.in_(request.performance_insight_ids),
                PerformanceInsight.is_accepted,
            )
            .all()
        )
        for ins in insights:
            ctx.performance_insights.append(
                PerformanceInsightContext(
                    id=ins.id,
                    pattern_type=ins.pattern_type or "",
                    finding=ins.finding or "",
                    platform=ins.platform,
                    content_type=ins.content_type,
                    confidence=ins.confidence,
                )
            )

    if request and request.experiment_learning_ids:
        variants = (
            db.query(ExperimentVariant)
            .filter(
                ExperimentVariant.id.in_(request.experiment_learning_ids),
                ExperimentVariant.is_winner,
            )
            .all()
        )
        for v in variants:
            exp = db.query(CampaignExperiment).filter(CampaignExperiment.id == v.experiment_id).first()
            if exp:
                ctx.experiment_learnings.append(
                    ExperimentLearningContext(
                        experiment_name=exp.name,
                        variable_tested=exp.variable_tested or "",
                        success_metric=exp.success_metric or "",
                        winner_label=v.label or "",
                        winner_value=v.variable_value or "",
                    )
                )

    gap_report = (
        db.query(ContentGapReport)
        .filter(
            ContentGapReport.brand_id == brand_id,
            ContentGapReport.status == "completed",
        )
        .order_by(ContentGapReport.id.desc())
        .first()
    )
    if gap_report and gap_report.report_data:
        report = gap_report.report_data
        if isinstance(report, dict):
            opportunities = report.get("content_gaps") or report.get("opportunities", [])
            for opp in opportunities:
                if isinstance(opp, dict):
                    ctx.competitor_opportunities.append(
                        CompetitorOpportunityContext(
                            topic=opp.get("topic") or opp.get("gap_topic", ""),
                            description=opp.get("description") or opp.get("recommendation", ""),
                        )
                    )

    regional = db.query(BrandRegionalSettings).filter(BrandRegionalSettings.brand_id == brand_id).first()
    if regional:
        ctx.regional_settings = RegionalContext(
            default_language=regional.default_language or "en",
            supported_languages=list(regional.supported_languages or ["en"]),
            support_roman_urdu=regional.support_roman_urdu or False,
            support_bilingual_posts=regional.support_bilingual_posts or False,
            support_rtl_layout=regional.support_rtl_layout or False,
        )

    recent_campaigns = (
        db.query(Campaign)
        .filter(
            Campaign.brand_profile_id == brand_id,
            Campaign.status != "draft",
        )
        .order_by(Campaign.created_at.desc())
        .limit(10)
        .all()
    )
    for c in recent_campaigns:
        posts = db.query(CampaignPost).filter(CampaignPost.campaign_id == c.id).all()
        recent_ctx = RecentCampaignContext(
            name=c.name or "",
            platform=c.platform or "",
            tone=c.tone or "",
            campaign_goal=c.campaign_goal or "",
        )
        for p in posts:
            recent_ctx.posts.append(
                {
                    "day": p.day,
                    "content_theme": p.content_theme,
                    "post_idea": p.post_idea,
                    "caption": p.caption,
                    "call_to_action": p.call_to_action,
                    "hashtags": p.hashtags or [],
                }
            )
        ctx.recent_campaigns.append(recent_ctx)

    if ctx.recent_campaigns:
        all_hooks = []
        all_ctas = []
        all_hashtags = []
        for c in ctx.recent_campaigns:
            for p in c.posts:
                if p.get("post_idea"):
                    all_hooks.append(p["post_idea"])
                if p.get("call_to_action"):
                    all_ctas.append(p["call_to_action"])
                if p.get("hashtags"):
                    htags = p["hashtags"]
                    if isinstance(htags, list):
                        all_hashtags.append([t for t in htags if isinstance(t, str)])
        ctx.freshness_context.recent_hooks = all_hooks
        ctx.freshness_context.recent_ctas = all_ctas
        ctx.freshness_context.recent_hashtags = all_hashtags
        ctx.freshness_context.recent_campaign_names = [c.name for c in ctx.recent_campaigns]

    return ctx
