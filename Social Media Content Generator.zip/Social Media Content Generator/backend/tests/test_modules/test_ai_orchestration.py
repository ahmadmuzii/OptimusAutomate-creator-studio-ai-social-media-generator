from __future__ import annotations

from unittest.mock import patch

from app.ai.context_builder import SourceFactContext
from app.ai.generation_trace import GenerationTraceData
from app.ai.response_schemas import (
    CampaignDayPlan,
    CampaignStrategy,
    GeneratedPost,
    PostGenerationResult,
    SourceExtractionResult,
    SourceFactItem,
)
from app.ai.source_extractor import extract_facts_with_groq


class TestResponseSchemas:
    def test_campaign_strategy_valid(self):
        data = {
            "campaign_name": "Summer Launch",
            "campaign_summary": "Launch campaign for summer",
            "strategy": "Influencer-led storytelling",
            "days": [
                {
                    "day": 1,
                    "theme": "Brand Story",
                    "purpose": "Introduce the brand",
                    "funnel_stage": "awareness",
                    "content_type": "carousel",
                    "audience_action": "Follow us",
                    "reason_for_format": "Visual storytelling",
                }
            ],
        }
        result = CampaignStrategy(**data)
        assert result.campaign_name == "Summer Launch"
        assert len(result.days) == 1
        assert result.days[0].day == 1
        assert result.days[0].funnel_stage == "awareness"

    def test_campaign_day_plan_defaults(self):
        plan = CampaignDayPlan(day=1, theme="Theme", purpose="Purpose", funnel_stage="interest")
        assert plan.content_type == "static_post"
        assert plan.source_fact_ids == []
        assert plan.performance_insight_ids == []

    def test_generated_post_valid(self):
        post = GeneratedPost(
            caption="Check out our new product!",
            call_to_action="Shop now",
            hashtags=["#new", "#product"],
        )
        assert post.caption == "Check out our new product!"
        assert post.hashtags == ["#new", "#product"]
        assert post.content_type == "static_post"
        assert post.funnel_stage == "awareness"

    def test_post_generation_result(self):
        result = PostGenerationResult(
            posts=[
                GeneratedPost(caption="Post 1", call_to_action="Act"),
                GeneratedPost(caption="Post 2", call_to_action="Buy"),
            ]
        )
        assert len(result.posts) == 2

    def test_source_fact_item_valid(self):
        item = SourceFactItem(
            category="feature",
            label="Performance",
            value="10x faster",
            source_excerpt="10x faster than competitors",
        )
        assert item.category == "feature"
        assert item.confidence == 0.5

    def test_source_extraction_result(self):
        result = SourceExtractionResult(
            document_title="Product Page",
            facts=[
                SourceFactItem(category="feature", label="Speed", value="Fast", source_excerpt="Fast"),
            ],
        )
        assert result.document_title == "Product Page"
        assert len(result.facts) == 1


class TestGenerationTraceData:
    def test_default_values(self):
        trace = GenerationTraceData()
        assert trace.groq_used is False
        assert trace.generation_source == "unknown"
        assert trace.source_fact_ids == []
        assert trace.created_at is not None

    def test_custom_values(self):
        trace = GenerationTraceData(
            groq_used=True,
            groq_model="llama-3.3-70b",
            generation_source="groq",
            brand_id=1,
            source_fact_ids=[1, 2, 3],
        )
        assert trace.groq_used is True
        assert trace.groq_model == "llama-3.3-70b"
        assert trace.generation_source == "groq"
        assert trace.source_fact_ids == [1, 2, 3]


class TestSourceFactContext:
    def test_create_source_fact_context(self):
        fact = SourceFactContext(
            id=1, category="feature", label="Speed", value="10x faster", source_section="Hero", confidence=0.9
        )
        assert fact.id == 1
        assert fact.category == "feature"
        assert fact.label == "Speed"
        assert fact.value == "10x faster"
        assert fact.source_section == "Hero"
        assert fact.confidence == 0.9

    def test_source_fact_default_confidence(self):
        fact = SourceFactContext(id=2, category="other", label="Note", value="Something")
        assert fact.confidence == 0.5


class TestSourceExtractor:
    @patch("app.ai.source_extractor.groq_json_chat")
    def test_extract_facts_with_groq_success(self, mock_chat):
        mock_chat.return_value = {
            "document_title": "Test",
            "facts": [
                {
                    "category": "feature",
                    "label": "Speed",
                    "value": "10x faster",
                    "source_excerpt": "10x faster",
                    "confidence": 0.9,
                },
            ],
        }

        result = extract_facts_with_groq(title="Test", text="Our product is 10x faster.")
        assert len(result["facts"]) == 1
        assert result["facts"][0]["label"] == "Speed"
        assert result["extraction_source"] == "groq"

    @patch("app.ai.source_extractor.groq_json_chat")
    def test_extract_facts_fallback_on_empty(self, mock_chat):
        mock_chat.return_value = {"document_title": "", "facts": []}

        result = extract_facts_with_groq(title="Test", text="Hello world.")
        assert len(result["facts"]) == 0
        assert result["extraction_source"] == "groq"

    @patch("app.ai.source_extractor.groq_json_chat")
    def test_extract_facts_on_api_error(self, mock_chat):
        mock_chat.return_value = None

        result = extract_facts_with_groq(title="Test", text="Hello world.")
        assert result["extraction_source"] == "fallback"
        assert isinstance(result["facts"], list)
