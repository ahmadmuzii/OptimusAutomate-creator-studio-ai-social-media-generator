import { useEffect, useRef } from 'react'
import { X, Check, RotateCcw, Loader2 } from 'lucide-react'
import type { CampaignPost, RefinementResponse } from '@/types/common'
import { InlineRefinementError } from './InlineRefinementError'

interface RefinementPreviewModalProps {
  post: CampaignPost
  originalPost: CampaignPost
  refinedResult: RefinementResponse
  isApplying: boolean
  error: string | null
  onApply: () => void
  onTryAnother: () => void
  onCancel: () => void
}

export function RefinementPreviewModal({
  post,
  originalPost,
  refinedResult,
  isApplying,
  error,
  onApply,
  onTryAnother,
  onCancel,
}: RefinementPreviewModalProps) {
  const overlayRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onCancel()
      }
    }
    document.addEventListener('keydown', handleKeyDown)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.body.style.overflow = ''
    }
  }, [onCancel])

  useEffect(() => {
    contentRef.current?.focus()
  }, [])

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === overlayRef.current) {
      onCancel()
    }
  }

  const isSame = (a: string | null | undefined, b: string | null | undefined) =>
    (a ?? '') === (b ?? '')

  const captionChanged = !isSame(originalPost.caption, refinedResult.post.caption)
  const ctaChanged = !isSame(originalPost.call_to_action, refinedResult.post.call_to_action)
  const hashtagsChanged =
    JSON.stringify(originalPost.hashtags) !== JSON.stringify(refinedResult.post.hashtags)

  if (!refinedResult.post) return null

  return (
    <div
      ref={overlayRef}
      onClick={handleOverlayClick}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40"
    >
      <div
        ref={contentRef}
        tabIndex={-1}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[85vh] overflow-y-auto m-4 focus:outline-none"
      >
        <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between z-10">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Refinement Preview</h2>
            <p className="text-sm text-gray-500">
              Day {post.day} &middot; {refinedResult.refinement.action.replace(/_/g, ' ')}
            </p>
          </div>
          <button onClick={onCancel} className="p-1 hover:bg-gray-100 rounded-lg transition-colors">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {error && <InlineRefinementError message={error} onDismiss={onCancel} />}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-gray-200 rounded-xl p-4">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-400 mb-3">
                Original
              </h3>
              <div className="space-y-3">
                {originalPost.post_idea && (
                  <div>
                    <span className="text-xs text-gray-400 font-medium">Hook</span>
                    <p className="text-sm text-gray-600">{originalPost.post_idea}</p>
                  </div>
                )}
                <div>
                  <span className="text-xs text-gray-400 font-medium">Caption</span>
                  <p className="text-sm text-gray-600 whitespace-pre-wrap">{originalPost.caption}</p>
                </div>
                {originalPost.call_to_action && (
                  <div>
                    <span className="text-xs text-gray-400 font-medium">CTA</span>
                    <p className="text-sm text-gray-600">{originalPost.call_to_action}</p>
                  </div>
                )}
                {originalPost.hashtags && originalPost.hashtags.length > 0 && (
                  <div>
                    <span className="text-xs text-gray-400 font-medium">Hashtags</span>
                    <p className="text-sm text-gray-600">{originalPost.hashtags.join(' ')}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="border-2 border-purple-200 rounded-xl p-4 bg-purple-50/30">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-purple-600 mb-3">
                Updated
              </h3>
              <div className="space-y-3">
                {captionChanged && refinedResult.post.hook && (
                  <div>
                    <span className="text-xs text-purple-500 font-medium">Hook</span>
                    <p className="text-sm text-gray-800">{refinedResult.post.hook}</p>
                  </div>
                )}
                <div>
                  <span className="text-xs text-purple-500 font-medium">Caption</span>
                  <p className={`text-sm whitespace-pre-wrap ${captionChanged ? 'text-gray-800' : 'text-gray-400'}`}>
                    {refinedResult.post.caption}
                  </p>
                  {!captionChanged && (
                    <span className="text-xs text-gray-400 italic">(unchanged)</span>
                  )}
                </div>
                <div>
                  <span className="text-xs text-purple-500 font-medium">CTA</span>
                  <p className={`text-sm ${ctaChanged ? 'text-gray-800' : 'text-gray-400'}`}>
                    {refinedResult.post.call_to_action || '(none)'}
                  </p>
                  {!ctaChanged && (
                    <span className="text-xs text-gray-400 italic">(unchanged)</span>
                  )}
                </div>
                <div>
                  <span className="text-xs text-purple-500 font-medium">Hashtags</span>
                  <p className={`text-sm ${hashtagsChanged ? 'text-gray-800' : 'text-gray-400'}`}>
                    {refinedResult.post.hashtags.length > 0
                      ? refinedResult.post.hashtags.join(' ')
                      : '(none)'}
                  </p>
                  {!hashtagsChanged && (
                    <span className="text-xs text-gray-400 italic">(unchanged)</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {refinedResult.refinement.fallback_used && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-700">
              AI was unavailable. A basic version was applied instead. For best results, try again later.
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-2 border-t border-gray-100">
            <button
              onClick={onCancel}
              className="px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={onTryAnother}
              className="px-4 py-2 text-sm text-purple-700 border border-purple-200 rounded-lg hover:bg-purple-50 transition-colors inline-flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Try another version
            </button>
            <button
              onClick={onApply}
              disabled={isApplying}
              className="px-4 py-2 text-sm font-medium text-white bg-purple-600 rounded-lg hover:bg-purple-700 disabled:opacity-50 transition-colors inline-flex items-center gap-2"
            >
              {isApplying ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Check className="w-4 h-4" />
              )}
              {isApplying ? 'Saving...' : 'Apply change'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
