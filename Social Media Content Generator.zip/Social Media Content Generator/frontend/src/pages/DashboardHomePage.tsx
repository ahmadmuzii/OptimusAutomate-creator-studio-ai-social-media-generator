import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Wand2, Building2, Calendar, FileText, ArrowRight, Lock } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useGuestMode } from '@/context/GuestModeContext'
import { useAuthGate } from '@/hooks/useAuthGate'
import { AuthModal } from '@/components/common/AuthModal'
import { ROUTES } from '@/routes/paths'
import * as api from '@/api/endpoints'
import type { CampaignData, BrandProfile } from '@/types/common'
import { guestCampaigns, guestBrands, guestStats } from '@/data/guestDemoData'
import { Skeleton, CardSkeleton } from '@/components/ui/Skeleton'
import { staggerContainer, listItem } from '@/lib/animation'

export function DashboardHomePage() {
  const { user, isAuthenticated } = useAuth()
  const { isGuestMode } = useGuestMode()
  const { showAuthModal, authModalRedirect, openAuthModal, closeAuthModal } = useAuthGate()
  const isDemo = isGuestMode && !isAuthenticated

  const [campaigns, setCampaigns] = useState<CampaignData[]>([])
  const [brands, setBrands] = useState<BrandProfile[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (isDemo) {
      setCampaigns(guestCampaigns)
      setBrands(guestBrands)
      setLoading(false)
      return
    }
    Promise.all([
      api.fetchCampaigns().catch(() => [] as CampaignData[]),
      api.fetchBrands().catch(() => [] as BrandProfile[]),
    ]).then(([c, b]) => {
      setCampaigns(c)
      setBrands(b)
    }).finally(() => setLoading(false))
  }, [isDemo])

  const stats = isDemo
    ? [
        { label: 'Campaigns', value: guestStats.campaigns, icon: Calendar, color: 'text-purple-600', bg: 'bg-purple-50' },
        { label: 'Brand Profiles', value: guestStats.brands, icon: Building2, color: 'text-blue-600', bg: 'bg-blue-50' },
        { label: 'Total Posts', value: guestStats.totalPosts, icon: FileText, color: 'text-green-600', bg: 'bg-green-50' },
      ]
    : [
        { label: 'Campaigns', value: campaigns.length, icon: Calendar, color: 'text-purple-600', bg: 'bg-purple-50' },
        { label: 'Brand Profiles', value: brands.length, icon: Building2, color: 'text-blue-600', bg: 'bg-blue-50' },
        { label: 'Total Posts', value: campaigns.reduce((s, c) => s + (c.posts?.length || 0), 0), icon: FileText, color: 'text-green-600', bg: 'bg-green-50' },
      ]

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <Skeleton className="h-7 w-56 mb-2" />
          <Skeleton className="h-4 w-40" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
              <Skeleton className="h-10 w-10 rounded-xl mb-3" />
              <Skeleton className="h-7 w-12 mb-1" />
              <Skeleton className="h-4 w-20" />
            </div>
          ))}
        </div>
        <CardSkeleton />
        <CardSkeleton />
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <AuthModal
        isOpen={showAuthModal}
        onClose={closeAuthModal}
        redirectTo={authModalRedirect}
      />

      <div>
        <h1 className="text-2xl font-bold text-gray-900">
          {isDemo ? 'Welcome to Creator Studio' : `Welcome back, ${user?.name?.split(' ')[0] || 'Creator'}`}
        </h1>
        <p className="text-gray-500 mt-1">
          {isDemo ? 'Explore the workspace with sample content.' : "Here's your content studio overview."}
        </p>
      </div>

      {/* Stats */}
      <motion.div variants={staggerContainer} initial="hidden" animate="visible" className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {stats.map((s) => (
          <motion.div key={s.label} variants={listItem} className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <div className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center mb-3`}>
              <s.icon className={`w-5 h-5 ${s.color}`} />
            </div>
            <p className="text-2xl font-bold text-gray-900">{s.value}</p>
            <p className="text-sm text-gray-500">{s.label}</p>
          </motion.div>
        ))}
      </motion.div>

      {/* Quick actions */}
      <motion.div variants={staggerContainer} initial="hidden" animate="visible" className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <motion.div variants={staggerContainer} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <motion.div variants={listItem}>
            {isDemo ? (
              <button
                onClick={() => openAuthModal(ROUTES.generate)}
                className="flex w-full items-center justify-between p-4 rounded-xl bg-gradient-to-r from-purple-50 to-purple-100/50 border border-purple-100 hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center">
                    <Wand2 className="w-5 h-5 text-purple-600" />
                  </div>
                  <div className="text-left">
                    <p className="font-semibold text-gray-900 text-sm">Generate Campaign</p>
                    <p className="text-xs text-gray-500">Create a new AI campaign</p>
                  </div>
                </div>
                <Lock className="w-4 h-4 text-gray-300" />
              </button>
            ) : (
              <Link
                to={ROUTES.generate}
                className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-purple-50 to-purple-100/50 border border-purple-100 hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center">
                    <Wand2 className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Generate Campaign</p>
                    <p className="text-xs text-gray-500">Create a new AI campaign</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-purple-400" />
              </Link>
            )}
          </motion.div>
          <motion.div variants={listItem}>
            {isDemo ? (
              <button
                onClick={() => openAuthModal(ROUTES.brands)}
                className="flex w-full items-center justify-between p-4 rounded-xl bg-gradient-to-r from-blue-50 to-blue-100/50 border border-blue-100 hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="text-left">
                    <p className="font-semibold text-gray-900 text-sm">Manage Brands</p>
                    <p className="text-xs text-gray-500">Add or edit brand profiles</p>
                  </div>
                </div>
                <Lock className="w-4 h-4 text-gray-300" />
              </button>
            ) : (
              <Link
                to={ROUTES.brands}
                className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-blue-50 to-blue-100/50 border border-blue-100 hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Manage Brands</p>
                    <p className="text-xs text-gray-500">Add or edit brand profiles</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-blue-400" />
              </Link>
            )}
          </motion.div>
        </motion.div>
      </motion.div>

      {/* Recent campaigns */}
      <motion.div variants={staggerContainer} initial="hidden" animate="visible" className="bg-white rounded-2xl border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between p-6 pb-4 border-b border-gray-50">
          <h2 className="text-lg font-semibold text-gray-900">Recent Campaigns</h2>
          {!isDemo && (
            <Link to={ROUTES.history} className="text-sm text-purple-600 hover:text-purple-700 font-medium">
              View all
            </Link>
          )}
        </div>
        {campaigns.length === 0 ? (
          <div className="p-6 text-center text-sm text-gray-400">
            No campaigns yet. Generate your first one!
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {campaigns.slice(0, 5).map((c) => (
              <motion.div key={c.id} variants={listItem} className="flex items-center justify-between px-6 py-4 hover:bg-gray-50 transition-colors">
                <div>
                  <p className="font-medium text-gray-900 text-sm">{c.name}</p>
                  <p className="text-xs text-gray-500">{c.platform} &middot; {c.tone}</p>
                </div>
                <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${
                  c.status === 'published' ? 'bg-green-50 text-green-700' :
                  c.status === 'draft' ? 'bg-yellow-50 text-yellow-700' :
                  'bg-gray-50 text-gray-600'
                }`}>
                  {c.status}
                </span>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  )
}
