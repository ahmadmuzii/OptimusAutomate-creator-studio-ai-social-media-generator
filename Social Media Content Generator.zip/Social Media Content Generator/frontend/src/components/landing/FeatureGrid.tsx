import { motion } from 'framer-motion'
import { CalendarDays, Instagram, Building2, FileText, Calendar, Clock } from 'lucide-react'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { staggerContainer, listItem } from '@/lib/animation'

const features = [
  {
    icon: CalendarDays,
    title: 'Seven-Day Campaign Planner',
    desc: 'Generate an organized campaign instead of disconnected posts. Each day has a theme, post idea, and suggested time.',
    color: 'from-purple-500 to-purple-600',
  },
  {
    icon: Instagram,
    title: 'Platform-Aware Writing',
    desc: 'Adapt content for Instagram, LinkedIn, TikTok, Facebook, and X with platform-specific formatting.',
    color: 'from-violet-500 to-purple-600',
  },
  {
    icon: Building2,
    title: 'Saved Brand Profiles',
    desc: 'Reuse audience, voice, niche, and campaign preferences across multiple campaigns.',
    color: 'from-fuchsia-500 to-purple-600',
  },
  {
    icon: FileText,
    title: 'Caption Workspace',
    desc: 'Copy, edit, regenerate, and organize captions in one place. Status management included.',
    color: 'from-purple-600 to-indigo-600',
  },
  {
    icon: Calendar,
    title: 'Visual Content Calendar',
    desc: 'See campaign posts in a weekly or monthly schedule with status and timing.',
    color: 'from-indigo-500 to-purple-600',
  },
  {
    icon: Clock,
    title: 'Campaign History',
    desc: 'Return to previous campaigns and manage generated content. Search and filter included.',
    color: 'from-purple-500 to-violet-600',
  },
]

export function FeatureGrid() {
  const reduced = useReducedMotionPreference()

  return (
    <section id="features-grid" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            Everything you need to plan content
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            From campaign planning to caption management, all in one workspace.
          </p>
        </div>

        <motion.div
          variants={reduced ? undefined : staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {features.map((f) => (
            <motion.div
              key={f.title}
              variants={reduced ? undefined : listItem}
              className="bg-white rounded-2xl border border-gray-100 p-6 hover:shadow-lg hover:shadow-purple-100/50 transition-all duration-300"
            >
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${f.color} flex items-center justify-center mb-4 shadow-md`}>
                <f.icon className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{f.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
