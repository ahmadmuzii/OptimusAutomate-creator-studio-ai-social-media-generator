import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, it, expect, vi } from 'vitest'
import { IntelligencePanel } from '../IntelligencePanel'
import type { SourceDocument } from '@/types/source'

const mockDocuments: SourceDocument[] = [
  {
    id: 1,
    user_id: 1,
    brand_id: 1,
    source_type: 'url',
    original_url: 'https://example.com/product',
    pasted_text: null,
    title: 'Product Page',
    extracted_text: 'Product info here',
    facts: [
      { id: 1, category: 'feature', label: 'Speed', value: '10x faster', source_section: 'Hero', confidence: 0.9, approved_by_user: false, excluded_by_user: false },
    ],
    created_at: '2026-06-01T00:00:00Z',
  },
  {
    id: 2,
    user_id: 1,
    brand_id: 1,
    source_type: 'text',
    original_url: null,
    pasted_text: 'Brand values',
    title: 'Brand Values Doc',
    extracted_text: 'Core values',
    facts: [
      { id: 2, category: 'value', label: 'Integrity', value: 'Honest dealings', source_section: null, confidence: 0.8, approved_by_user: false, excluded_by_user: false },
    ],
    created_at: '2026-06-02T00:00:00Z',
  },
]

vi.mock('@/api/endpoints', () => ({
  fetchSourceDocuments: vi.fn(),
}))

import * as api from '@/api/endpoints'

function renderPanel(brandId: number | null = 1, selectedIds: number[] = [], onChange = vi.fn()) {
  return render(
    <IntelligencePanel brandId={brandId} selectedIds={selectedIds} onChange={onChange} />,
  )
}

describe('IntelligencePanel', () => {
  it('renders nothing when brandId is null', () => {
    const { container } = renderPanel(null)
    expect(container.innerHTML).toBe('')
  })

  it('shows loading state', () => {
    vi.mocked(api.fetchSourceDocuments).mockReturnValue(new Promise(() => {}))
    renderPanel(1)
    expect(screen.getByText('Loading source documents...')).toBeDefined()
  })

  it('shows empty state when no documents', async () => {
    vi.mocked(api.fetchSourceDocuments).mockResolvedValue([] as unknown as never)
    renderPanel(1)
    await waitFor(() => {
      expect(screen.getByText(/No source documents found/)).toBeDefined()
    })
  })

  it('shows only documents with facts', async () => {
    const docsWithEmpty: SourceDocument[] = [
      ...mockDocuments,
      {
        id: 3,
        user_id: 1,
        brand_id: 1,
        source_type: 'url',
        original_url: null,
        pasted_text: null,
        title: 'Empty Doc',
        extracted_text: null,
        facts: [],
        created_at: '2026-06-03T00:00:00Z',
      },
    ]
    vi.mocked(api.fetchSourceDocuments).mockResolvedValue(docsWithEmpty as unknown as never)
    renderPanel(1)
    await waitFor(() => {
      expect(screen.getByText('Product Page')).toBeDefined()
      expect(screen.getByText('Brand Values Doc')).toBeDefined()
      expect(screen.queryByText('Empty Doc')).toBeNull()
    })
  })

  it('calls onChange with selected id on click', async () => {
    vi.mocked(api.fetchSourceDocuments).mockResolvedValue(mockDocuments as unknown as never)
    const onChange = vi.fn()
    renderPanel(1, [], onChange)

    await waitFor(() => {
      expect(screen.getByText('Product Page')).toBeDefined()
    })

    await userEvent.click(screen.getByText('Product Page'))
    expect(onChange).toHaveBeenCalledWith([1])
  })

  it('deselects already selected id', async () => {
    vi.mocked(api.fetchSourceDocuments).mockResolvedValue(mockDocuments as unknown as never)
    const onChange = vi.fn()
    renderPanel(1, [1], onChange)

    await waitFor(() => {
      expect(screen.getByText('Product Page')).toBeDefined()
    })

    await userEvent.click(screen.getByText('Product Page'))
    expect(onChange).toHaveBeenCalledWith([])
  })

  it('shows selected count', async () => {
    vi.mocked(api.fetchSourceDocuments).mockResolvedValue(mockDocuments as unknown as never)
    renderPanel(1, [1], vi.fn())

    await waitFor(() => {
      expect(screen.getByText('1 of 2 selected')).toBeDefined()
    })
  })
})
