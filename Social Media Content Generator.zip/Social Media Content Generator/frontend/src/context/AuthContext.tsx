import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react'
import type { UserData } from '@/types/common'
import * as api from '@/api/endpoints'
import { setAccessToken as storeAccessToken, clearToken, setLogoutHandler } from '@/api/client'

interface AuthState {
  user: UserData | null
  token: string | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  signup: (email: string, password: string, name: string) => Promise<void>
  logout: () => void
  updateUser: (data: Partial<UserData>) => Promise<void>
}

const AuthContext = createContext<AuthState | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserData | null>(null)
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('token'))
  const [isLoading, setIsLoading] = useState(true)

  const logout = useCallback(() => {
    clearToken()
    setToken(null)
    setUser(null)
  }, [])

  useEffect(() => {
    setLogoutHandler(logout)
  }, [logout])

  useEffect(() => {
    if (token) {
      api.fetchMe()
        .then(setUser)
        .catch(() => {
          clearToken()
          setToken(null)
          setUser(null)
        })
        .finally(() => setIsLoading(false))
    } else {
      setIsLoading(false)
    }
  }, [token])

  const login = useCallback(async (email: string, password: string) => {
    const res = await api.login(email, password)
    storeAccessToken(res.access_token)
    setToken(res.access_token)
    setUser(res.user)
  }, [])

  const signup = useCallback(async (email: string, password: string, name: string) => {
    const res = await api.signup(email, password, name)
    storeAccessToken(res.access_token)
    setToken(res.access_token)
    setUser(res.user)
  }, [])

  const updateUser = useCallback(async (data: Partial<UserData>) => {
    const updated = await api.updateProfile(data)
    setUser(updated)
  }, [])

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        login,
        signup,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthState {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
