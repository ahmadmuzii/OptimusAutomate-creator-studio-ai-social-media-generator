from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "social_media.db"


def column_exists(cursor: sqlite3.Cursor, table: str, column: str) -> bool:
    cursor.execute(f"PRAGMA table_info({table})")
    return any(row[1] == column for row in cursor.fetchall())


def main() -> None:
    if not DB_PATH.exists():
        print(f"Database not found at {DB_PATH}")
        sys.exit(1)

    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()

    if not column_exists(cursor, "brand_profiles", "logo_url"):
        cursor.execute("ALTER TABLE brand_profiles ADD COLUMN logo_url VARCHAR(500)")
        print("Added logo_url column to brand_profiles")
    else:
        print("logo_url column already exists in brand_profiles — skipping")

    conn.commit()
    conn.close()
    print("Migration 002 complete.")


if __name__ == "__main__":
    main()
