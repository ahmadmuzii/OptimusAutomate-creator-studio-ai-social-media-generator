import { Users, FileText, Tags, Target } from 'lucide-react'
import type { GapReportSummary } from '@/types/competitor'

interface Props {
  summary: GapReportSummary
}

const cards = [
  { key: 'competitors_analyzed' as const, label: 'Competitors analyzed', icon: Users },
  { key: 'posts_analyzed' as const, label: 'Posts analyzed', icon: FileText },
  { key: 'unique_topics' as const, label: 'Unique topics detected', icon: Tags },
  { key: 'opportunities_found' as const, label: 'Content opportunities found', icon: Target },
]

export function GapSummaryCards({ summary }: Props) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map(card => {
        const Icon = card.icon
        return (
          <div key={card.key} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-xl bg-purple-50 flex items-center justify-center">
                <Icon className="w-4 h-4 text-purple-600" />
              </div>
            </div>
            <p className="text-2xl font-bold text-gray-900">{summary[card.key]}</p>
            <p className="text-sm text-gray-500 mt-1">{card.label}</p>
          </div>
        )
      })}
    </div>
  )
}
