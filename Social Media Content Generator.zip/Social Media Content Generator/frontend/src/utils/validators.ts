import type { BrandFormData } from '@/types/common'

export interface ValidationErrors {
  brandName?: string
  brandDescription?: string
  niche?: string
  targetAudience?: string
  campaignGoal?: string
  platform?: string
  tone?: string
}

export function validateBrandForm(data: Partial<BrandFormData>): ValidationErrors {
  const errors: ValidationErrors = {}

  if (!data.brandName?.trim()) {
    errors.brandName = 'Brand name is required'
  }
  if (!data.brandDescription?.trim()) {
    errors.brandDescription = 'Brand description is required'
  }
  if (!data.niche?.trim()) {
    errors.niche = 'Niche is required'
  }
  if (!data.targetAudience?.trim()) {
    errors.targetAudience = 'Target audience is required'
  }
  if (!data.campaignGoal?.trim()) {
    errors.campaignGoal = 'Campaign goal is required'
  }

  return errors
}

export function isFormValid(
  data: Partial<BrandFormData>,
  platform: string,
  tone: string,
): boolean {
  const errors = validateBrandForm(data)
  return Object.keys(errors).length === 0 && !!platform && !!tone
}
