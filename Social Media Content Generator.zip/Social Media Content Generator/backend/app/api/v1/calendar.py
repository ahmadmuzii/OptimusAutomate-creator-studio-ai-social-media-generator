from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.ai.campaign_orchestrator import generate_full_campaign
from app.ai.generation_trace import GenerationTraceData, save_generation_trace
from app.api.deps import get_calendar_service
from app.api.deps_auth import get_current_user
from app.config import settings
from app.database import get_db
from app.exceptions import CalendarGenerationError, NotFoundError
from app.logging_config import get_logger
from app.models.db_models import BrandProfile, Campaign, CampaignPost, User
from app.models.schemas import CalendarRequest, CalendarResponse
from app.services.calendar_service import CalendarService
from app.utils.brand_name import format_campaign_title
from app.utils.validators import validate_platform, validate_tone

router = APIRouter(tags=["Calendar"])

logger = get_logger("api.calendar")


@router.post("/generate-calendar", response_model=CalendarResponse, response_model_by_alias=True)
def create_calendar(
    request: CalendarRequest,
    calendar_service: CalendarService = Depends(get_calendar_service),
    db: Session = Depends(get_db),
    current_user: User | None = Depends(get_current_user),
):
    validate_platform(request.platform)
    validate_tone(request.tone)

    logger.info("create_calendar", platform=request.platform, tone=request.tone)

    # Validate brand ownership BEFORE generation
    if current_user and request.brand_profile_id is not None:
        brand = (
            db.query(BrandProfile)
            .filter(
                BrandProfile.id == request.brand_profile_id,
                BrandProfile.user_id == current_user.id,
            )
            .first()
        )
        if not brand:
            raise NotFoundError("Brand not found")

    # If user is authenticated with a brand profile, use AI orchestrator
    if current_user and request.brand_profile_id is not None:
        try:
            orchestrated = generate_full_campaign(
                db=db,
                user_id=current_user.id,
                brand_id=request.brand_profile_id,
                platform=request.platform,
                tone=request.tone,
                campaign_goal=request.campaign_goal,
                days_count=request.days_count,
                persona_ids=request.persona_ids if request.use_personas else None,
                conversion_path_id=request.conversion_path_id,
                strategy_id=request.strategy_id,
                performance_insight_ids=request.performance_insight_ids if request.use_performance_memory else None,
                experiment_learning_ids=request.experiment_learning_ids if request.use_experiment_learnings else None,
                competitor_opportunity_ids=request.competitor_opportunity_ids if request.use_competitor_gaps else None,
            )

            if "error" in orchestrated:
                raise NotFoundError(orchestrated["error"])

            posts = orchestrated.get("posts", [])
            generation_source = orchestrated.get("generation_source", "fallback")

            calendar = []
            for i, post in enumerate(posts):
                calendar.append(
                    {
                        "day": i + 1,
                        "contentTheme": post.get("content_theme", ""),
                        "postIdea": post.get("post_idea", ""),
                        "contentType": post.get("content_type", "static_post"),
                        "suggestedTime": post.get("suggested_time", ""),
                        "platform": request.platform,
                        "caption": post.get("caption", ""),
                        "callToAction": post.get("call_to_action", ""),
                        "hashtags": post.get("hashtags", []),
                        "personaName": post.get("persona_name"),
                        "audienceProblem": post.get("audience_problem"),
                        "desiredAction": post.get("desired_action"),
                        "sourceFactIds": post.get("source_fact_ids", []),
                        "purpose": post.get("purpose"),
                        "funnelStage": post.get("funnel_stage"),
                    }
                )

            saved = False
            if current_user and calendar:
                campaign = Campaign(
                    user_id=current_user.id,
                    name=orchestrated.get(
                        "campaign_name", format_campaign_title(request.brand_name, request.platform, request.tone)
                    ),
                    platform=request.platform,
                    tone=request.tone,
                    campaign_goal=request.campaign_goal,
                    brand_profile_id=request.brand_profile_id,
                )
                db.add(campaign)
                db.commit()
                db.refresh(campaign)

                for day_data in calendar:
                    post = CampaignPost(
                        campaign_id=campaign.id,
                        day=day_data.get("day", 1),
                        content_theme=day_data.get("contentTheme", ""),
                        post_idea=day_data.get("postIdea", ""),
                        content_type=day_data.get("contentType", ""),
                        suggested_time=day_data.get("suggestedTime", ""),
                        platform=day_data.get("platform", request.platform),
                        caption=day_data.get("caption", ""),
                        call_to_action=day_data.get("callToAction", ""),
                        hashtags=day_data.get("hashtags", []),
                        persona_name=day_data.get("personaName"),
                        audience_problem=day_data.get("audienceProblem"),
                        desired_action=day_data.get("desiredAction"),
                    )
                    db.add(post)
                db.commit()

                # Save generation trace
                trace_dict = orchestrated.get("generation_trace", {})
                if trace_dict:
                    trace_data = GenerationTraceData(**trace_dict)
                    save_generation_trace(db, campaign.id, trace_data)

                saved = True
                logger.info("campaign_saved_to_db", campaign_id=campaign.id, user_id=current_user.id)

            trace_data = orchestrated.get("generation_trace")
            intelligence_summary = orchestrated.get("intelligence_summary")

            return {
                "calendar": calendar,
                "generation_source": generation_source,
                "saved": saved,
                "generation_trace": trace_data,
                "intelligence_summary": intelligence_summary,
            }
        except CalendarGenerationError:
            raise
        except Exception:
            db.rollback()
            logger.exception(
                "campaign_persistence_failed",
                user_id=current_user.id,
                brand_profile_id=request.brand_profile_id,
                platform=request.platform,
                tone=request.tone,
            )
            raise HTTPException(
                status_code=500,
                detail="Failed to save generated campaign",
            )

    # Fallback to legacy generation for unauthenticated users or brands without profiles
    try:
        result = calendar_service.generate_calendar(
            brand_name=request.brand_name,
            brand_description=request.brand_description,
            niche=request.niche,
            target_audience=request.target_audience,
            platform=request.platform,
            tone=request.tone,
            campaign_goal=request.campaign_goal,
        )

        calendar = result["calendar"]
        generation_source = result["generation_source"]

        saved = False
        if current_user:
            campaign = Campaign(
                user_id=current_user.id,
                name=format_campaign_title(request.brand_name, request.platform, request.tone),
                platform=request.platform,
                tone=request.tone,
                campaign_goal=request.campaign_goal,
                brand_profile_id=request.brand_profile_id,
            )
            db.add(campaign)
            db.commit()
            db.refresh(campaign)

            for day_data in calendar:
                post = CampaignPost(
                    campaign_id=campaign.id,
                    day=day_data.get("day", 1),
                    content_theme=day_data.get("contentTheme", ""),
                    post_idea=day_data.get("postIdea", ""),
                    content_type=day_data.get("contentType", ""),
                    suggested_time=day_data.get("suggestedTime", ""),
                    platform=day_data.get("platform", request.platform),
                    caption=day_data.get("caption", ""),
                    call_to_action=day_data.get("callToAction", ""),
                    hashtags=day_data.get("hashtags", []),
                )
                db.add(post)
            db.commit()
            saved = True
            logger.info("campaign_saved_to_db", campaign_id=campaign.id, user_id=current_user.id)
        else:
            logger.warning("campaign_not_saved_user_not_authenticated")

        return {"calendar": calendar, "generation_source": generation_source, "saved": saved}
    except CalendarGenerationError:
        raise
    except Exception:
        db.rollback()
        logger.exception(
            "campaign_persistence_failed",
            user_id=current_user.id if current_user else None,
            brand_profile_id=request.brand_profile_id,
            platform=request.platform,
            tone=request.tone,
        )
        raise HTTPException(
            status_code=500,
            detail="Failed to save generated campaign",
        )


@router.get("/groq-status")
def groq_status():
    return {
        "enabled": settings.groq_enabled,
        "key_configured": bool(settings.groq_api_key),
        "model": settings.groq_model,
    }
