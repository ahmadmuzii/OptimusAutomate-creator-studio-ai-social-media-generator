from __future__ import annotations

import datetime

from pydantic import BaseModel, ConfigDict


class PerformanceImportRow(BaseModel):
    external_post_id: str = ""
    platform: str = "instagram"
    content_type: str = "carousel"
    publication_date: str | None = None
    impressions: int = 0
    reach: int = 0
    likes: int = 0
    comments: int = 0
    saves: int = 0
    shares: int = 0
    link_clicks: int = 0
    watch_time: float = 0
    video_views: int = 0
    profile_visits: int = 0
    followers_gained: int = 0
    conversion_count: int = 0
    caption: str = ""
    persona_id: int | None = None
    funnel_stage: str | None = None
    cta_type: str | None = None


class PerformanceImportRequest(BaseModel):
    brand_id: int | None = None
    rows: list[PerformanceImportRow]


class ImportBatchResponse(BaseModel):
    id: int
    filename: str | None = None
    total_rows: int
    valid_rows: int
    invalid_rows: int
    status: str
    created_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)


class PerformanceRecordResponse(BaseModel):
    id: int
    platform: str | None = None
    content_type: str | None = None
    impressions: int | None = None
    reach: int | None = None
    likes: int | None = None
    comments: int | None = None
    saves: int | None = None
    shares: int | None = None
    link_clicks: int | None = None
    engagement_rate: float | None = None
    publication_date: datetime.datetime | None = None
    persona_id: int | None = None

    model_config = ConfigDict(from_attributes=True)


class PerformanceSummary(BaseModel):
    total_posts: int
    avg_impressions: float
    avg_engagement_rate: float
    best_platform: str | None = None
    best_content_type: str | None = None
    top_performers: list[PerformanceRecordResponse] = []
    insights: list[str] = []


class InsightResponse(BaseModel):
    id: int
    pattern_type: str
    platform: str | None = None
    persona_id: int | None = None
    content_type: str | None = None
    finding: str
    supporting_metric: str | None = None
    sample_size: int | None = None
    confidence: str | None = None
    is_accepted: bool
    is_archived: bool
    affect_future_generation: bool
    created_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)


class InsightUpdate(BaseModel):
    is_accepted: bool | None = None
    is_archived: bool | None = None
    affect_future_generation: bool | None = None
