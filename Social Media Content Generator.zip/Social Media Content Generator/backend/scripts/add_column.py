import sqlite3

conn = sqlite3.connect("social_media.db")
cursor = conn.cursor()

cursor.execute("PRAGMA table_info(campaigns)")
cols = [row[1] for row in cursor.fetchall()]
print("Current columns:", cols)

if "persona_mode" not in cols:
    sql = "ALTER TABLE campaigns ADD COLUMN persona_mode VARCHAR(20) DEFAULT 'single'"
    cursor.execute(sql)
    conn.commit()
    print("Added persona_mode column")
else:
    print("persona_mode column already exists")

cursor.execute("PRAGMA table_info(campaigns)")
cols = [row[1] for row in cursor.fetchall()]
print("Columns after:", cols)
conn.close()
