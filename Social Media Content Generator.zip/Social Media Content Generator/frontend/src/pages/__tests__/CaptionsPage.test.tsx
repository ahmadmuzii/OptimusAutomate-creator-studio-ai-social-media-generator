import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { CaptionsPage } from '@/pages/CaptionsPage'
import type { CampaignData } from '@/types/common'

const mockFetchCampaigns = vi.fn()
const user = userEvent.setup()

vi.mock('@/api/endpoints', () => ({
  fetchCampaigns: (...args: unknown[]) => mockFetchCampaigns(...args),
}))

vi.mock('@/context/AuthContext', () => ({
  useAuth: () => ({ isAuthenticated: false, user: null, isLoading: false }),
}))

vi.mock('@/context/GuestModeContext', () => ({
  useGuestMode: () => ({ isGuestMode: false }),
}))

vi.mock('@/hooks/useRefineCampaignPost', () => ({
  useRefineCampaignPost: () => ({
    refining: false,
    refiningPostId: null,
    error: null,
    refine: vi.fn(),
    clearError: vi.fn(),
  }),
}))

vi.mock('@/components/ui/Toast', () => ({
  useToast: () => ({ showToast: vi.fn() }),
}))

function renderPage() {
  return render(
    <MemoryRouter initialEntries={['/']}>
      <CaptionsPage />
    </MemoryRouter>,
  )
}

function makeInstagramPost(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    id: 1,
    day: 1,
    content_theme: 'Brand Story',
    post_idea: 'Test post',
    content_type: 'Carousel',
    suggested_time: '09:00',
    platform: 'Instagram',
    caption: 'Test Instagram caption',
    call_to_action: 'Learn more',
    hashtags: ['test'],
    status: 'published',
    scheduled_date: null,
    ...overrides,
  }
}

function makeLinkedInPost(overrides: Partial<Record<string, unknown>> = {}) {
  return makeInstagramPost({ id: 2, platform: 'LinkedIn', caption: 'Test LinkedIn caption', ...overrides })
}

function makeTikTokPost(overrides: Partial<Record<string, unknown>> = {}) {
  return makeInstagramPost({ id: 3, platform: 'TikTok', caption: 'Test TikTok caption', ...overrides })
}

function makeFacebookPost(overrides: Partial<Record<string, unknown>> = {}) {
  return makeInstagramPost({ id: 4, platform: 'Facebook', caption: 'Test Facebook caption', ...overrides })
}

function makeXPost(overrides: Partial<Record<string, unknown>> = {}) {
  return makeInstagramPost({ id: 5, platform: 'x', caption: 'Test X caption', ...overrides })
}

const mockCampaign: CampaignData = {
  id: 1,
  name: 'Test Campaign',
  platform: 'Instagram',
  tone: 'professional',
  campaign_goal: 'brand_awareness',
  status: 'active',
  brand_profile_id: 1,
  posts: [
    makeInstagramPost(),
    makeLinkedInPost(),
    makeTikTokPost(),
    makeFacebookPost(),
    makeXPost(),
  ],
  created_at: '2026-01-01T00:00:00Z',
  updated_at: '2026-01-01T00:00:00Z',
}

describe('CaptionsPage platform filter', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    mockFetchCampaigns.mockResolvedValue([mockCampaign])
  })

  it('shows all six filter options in the dropdown', async () => {
    renderPage()
    await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())

    const select = screen.getByLabelText('Filter by platform')
    const options = Array.from(select.querySelectorAll('option'))
    const labels = options.map((o) => o.textContent?.replace(/\s*\(\d+\)$/, ''))
    expect(labels).toEqual([
      'All platforms',
      'Instagram',
      'LinkedIn',
      'TikTok',
      'Facebook',
      'X / Twitter',
    ])
  })

  it('shows all six options even when API returns only Instagram captions', async () => {
    mockFetchCampaigns.mockResolvedValue([{
      ...mockCampaign,
      posts: [makeInstagramPost()],
    }])
    renderPage()
    await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())

    const select = screen.getByLabelText('Filter by platform')
    const options = Array.from(select.querySelectorAll('option'))
    const labels = options.map((o) => o.textContent?.replace(/\s*\(\d+\)$/, ''))
    expect(labels).toEqual([
      'All platforms',
      'Instagram',
      'LinkedIn',
      'TikTok',
      'Facebook',
      'X / Twitter',
    ])
  })

  it('uses proper capitalized labels', async () => {
    renderPage()
    await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())

    const select = screen.getByLabelText('Filter by platform') as HTMLSelectElement
    const options = Array.from(select.options)
    expect(options[1]).toBeDefined()
    expect(options[1]!.textContent).toMatch(/^Instagram/)
    expect(options[2]!.textContent).toMatch(/^LinkedIn/)
    expect(options[3]!.textContent).toMatch(/^TikTok/)
    expect(options[4]!.textContent).toMatch(/^Facebook/)
    expect(options[5]!.textContent).toMatch(/^X \/ Twitter/)
  })

  it('shows only Instagram captions when Instagram is selected', async () => {
    renderPage()
    await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())

    const select = screen.getByLabelText('Filter by platform')
    await user.selectOptions(select, 'instagram')

    expect(screen.getByText('Test Instagram caption')).toBeInTheDocument()
    expect(screen.queryByText('Test LinkedIn caption')).not.toBeInTheDocument()
    expect(screen.queryByText('Test TikTok caption')).not.toBeInTheDocument()
    expect(screen.queryByText('Test Facebook caption')).not.toBeInTheDocument()
    expect(screen.queryByText('Test X caption')).not.toBeInTheDocument()
  })

  it('shows only LinkedIn captions when LinkedIn is selected', async () => {
    renderPage()
    await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())

    const select = screen.getByLabelText('Filter by platform')
    await user.selectOptions(select, 'linkedin')

    expect(screen.getByText('Test LinkedIn caption')).toBeInTheDocument()
    expect(screen.queryByText('Test Instagram caption')).not.toBeInTheDocument()
  })

  it('shows only TikTok captions when TikTok is selected', async () => {
    renderPage()
    await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())

    const select = screen.getByLabelText('Filter by platform')
    await user.selectOptions(select, 'tiktok')

    expect(screen.getByText('Test TikTok caption')).toBeInTheDocument()
    expect(screen.queryByText('Test Instagram caption')).not.toBeInTheDocument()
  })

  it('shows only Facebook captions when Facebook is selected', async () => {
    renderPage()
    await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())

    const select = screen.getByLabelText('Filter by platform')
    await user.selectOptions(select, 'facebook')

    expect(screen.getByText('Test Facebook caption')).toBeInTheDocument()
    expect(screen.queryByText('Test Instagram caption')).not.toBeInTheDocument()
  })

  it('shows only X / Twitter captions matching x, twitter, and X / Twitter legacy values', async () => {
    mockFetchCampaigns.mockResolvedValue([{
      ...mockCampaign,
      posts: [
        makeXPost({ id: 10, platform: 'x' }),
        makeInstagramPost({ id: 11, platform: 'twitter', caption: 'Legacy twitter caption' }),
        makeInstagramPost({ id: 12, platform: 'X / Twitter', caption: 'Legacy X / Twitter caption' }),
      ],
    }])
    renderPage()
    await waitFor(() => expect(screen.getByText('Test X caption')).toBeInTheDocument())

    const select = screen.getByLabelText('Filter by platform')
    await user.selectOptions(select, 'x')

    expect(screen.getByText('Test X caption')).toBeInTheDocument()
    expect(screen.getByText('Legacy twitter caption')).toBeInTheDocument()
    expect(screen.getByText('Legacy X / Twitter caption')).toBeInTheDocument()
  })

  it('shows a clean empty state when a platform has no captions', async () => {
    mockFetchCampaigns.mockResolvedValue([{
      ...mockCampaign,
      posts: [makeInstagramPost()],
    }])
    renderPage()
    await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())

    const select = screen.getByLabelText('Filter by platform')
    await user.selectOptions(select, 'linkedin')

    expect(screen.getByText('No LinkedIn captions found')).toBeInTheDocument()
    expect(screen.getByText(/Generate a LinkedIn campaign/)).toBeInTheDocument()
    expect(screen.getByText('Generate LinkedIn Campaign')).toBeInTheDocument()
  })

  it('platform and status filters work together', async () => {
    mockFetchCampaigns.mockResolvedValue([{
      ...mockCampaign,
      posts: [
        makeInstagramPost({ id: 10, status: 'published' }),
        makeInstagramPost({ id: 11, status: 'draft', caption: 'Draft Instagram caption' }),
      ],
    }])
    renderPage()
    await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())

    const platformSelect = screen.getByLabelText('Filter by platform')
    await user.selectOptions(platformSelect, 'instagram')

    const statusSelect = screen.getByLabelText('Filter by status')
    await user.selectOptions(statusSelect, 'draft')

    expect(screen.getByText('Draft Instagram caption')).toBeInTheDocument()
    expect(screen.queryByText('Test Instagram caption')).not.toBeInTheDocument()
  })

  it('search and platform filters work together', async () => {
    renderPage()
    await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())

    const platformSelect = screen.getByLabelText('Filter by platform')
    await user.selectOptions(platformSelect, 'linkedin')

    const searchInput = screen.getByPlaceholderText('Search captions...')
    await user.type(searchInput, 'LinkedIn')

    expect(screen.getByText('Test LinkedIn caption')).toBeInTheDocument()
    expect(screen.queryByText('Test Instagram caption')).not.toBeInTheDocument()
  })

  it('unknown platform values do not crash the page', async () => {
    mockFetchCampaigns.mockResolvedValue([{
      ...mockCampaign,
      posts: [makeInstagramPost({ platform: 'MySpace' })],
    }])
    renderPage()
    await waitFor(() => {
      expect(screen.getByText('MySpace')).toBeInTheDocument()
    })
  })

  it('selecting All platforms restores all captions', async () => {
    renderPage()
    await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())

    const select = screen.getByLabelText('Filter by platform')

    await user.selectOptions(select, 'instagram')
    expect(screen.queryByText('Test LinkedIn caption')).not.toBeInTheDocument()

    await user.selectOptions(select, 'all')
    expect(screen.getByText('Test Instagram caption')).toBeInTheDocument()
    expect(screen.getByText('Test LinkedIn caption')).toBeInTheDocument()
    expect(screen.getByText('Test TikTok caption')).toBeInTheDocument()
    expect(screen.getByText('Test Facebook caption')).toBeInTheDocument()
    expect(screen.getByText('Test X caption')).toBeInTheDocument()
  })

  describe('empty state navigation links', () => {
    function renderWithOnlyInstagram() {
      mockFetchCampaigns.mockResolvedValue([{
        ...mockCampaign,
        posts: [makeInstagramPost()],
      }])
      renderPage()
    }

    async function selectPlatform(value: string) {
      await user.selectOptions(screen.getByLabelText('Filter by platform'), value)
    }

    async function waitForInstagram() {
      await waitFor(() => expect(screen.getByText('Test Instagram caption')).toBeInTheDocument())
    }

    async function expectLink(platformValue: string, expectedHref: string, label: string) {
      await selectPlatform(platformValue)
      const link = screen.getByText(`Generate ${label} Campaign`)
      expect(link).toBeInTheDocument()
      expect(link.closest('a')).toHaveAttribute('href', expectedHref)
    }

    it('Instagram empty state links to /dashboard/generate?platform=instagram', async () => {
      mockFetchCampaigns.mockResolvedValue([])
      render(
        <MemoryRouter initialEntries={['/?platform=instagram']}>
          <CaptionsPage />
        </MemoryRouter>,
      )
      await waitFor(() => expect(screen.getByText('No Instagram captions found')).toBeInTheDocument())
      const link = screen.getByText('Generate Instagram Campaign')
      expect(link.closest('a')).toHaveAttribute('href', '/dashboard/generate?platform=instagram')
    })

    it('LinkedIn empty state links to /dashboard/generate?platform=linkedin', async () => {
      renderWithOnlyInstagram()
      await waitForInstagram()
      await expectLink('linkedin', '/dashboard/generate?platform=linkedin', 'LinkedIn')
    })

    it('TikTok empty state links to /dashboard/generate?platform=tiktok', async () => {
      renderWithOnlyInstagram()
      await waitForInstagram()
      await expectLink('tiktok', '/dashboard/generate?platform=tiktok', 'TikTok')
    })

    it('Facebook empty state links to /dashboard/generate?platform=facebook', async () => {
      renderWithOnlyInstagram()
      await waitForInstagram()
      await expectLink('facebook', '/dashboard/generate?platform=facebook', 'Facebook')
    })

    it('X / Twitter empty state links to /dashboard/generate?platform=x', async () => {
      renderWithOnlyInstagram()
      await waitForInstagram()
      await expectLink('x', '/dashboard/generate?platform=x', 'X / Twitter')
    })
  })
})
