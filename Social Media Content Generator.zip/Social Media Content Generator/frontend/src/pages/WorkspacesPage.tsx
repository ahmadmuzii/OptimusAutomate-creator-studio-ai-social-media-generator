import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Trash2, Users, UserPlus, Edit3, ArrowLeft, ChevronDown, ChevronRight, Building2 } from 'lucide-react'
import * as api from '@/api/endpoints'
import type { Workspace } from '@/types/workspace'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'

export function WorkspacesPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [workspaces, setWorkspaces] = useState<Workspace[]>([])
  const [expandedId, setExpandedId] = useState<number | null>(null)

  const [showCreateModal, setShowCreateModal] = useState(false)
  const [createName, setCreateName] = useState('')
  const [creating, setCreating] = useState(false)

  const [addMemberForWs, setAddMemberForWs] = useState<number | null>(null)
  const [addUserId, setAddUserId] = useState('')
  const [addRole, setAddRole] = useState('viewer')
  const [addingMember, setAddingMember] = useState(false)

  const [editMemberRole, setEditMemberRole] = useState<{ wsId: number; memId: number; role: string } | null>(null)
  const [savingRole, setSavingRole] = useState(false)

  useEffect(() => {
    api.fetchWorkspaces()
      .then(data => setWorkspaces(data as Workspace[]))
      .catch(() => setError('Could not load workspaces.'))
      .finally(() => setLoading(false))
  }, [])

  const loadWorkspaces = async () => {
    const data = await api.fetchWorkspaces()
    setWorkspaces(data as Workspace[])
  }

  const handleCreate = async () => {
    if (!createName.trim()) return
    setCreating(true)
    try {
      await api.createWorkspace({ name: createName.trim() })
      await loadWorkspaces()
      setShowCreateModal(false)
      setCreateName('')
    } catch { setError('Failed to create workspace.') }
    finally { setCreating(false) }
  }

  const handleDelete = async (wsId: number) => {
    try {
      await api.deleteWorkspace(wsId)
      setWorkspaces(prev => prev.filter(w => w.id !== wsId))
    } catch { setError('Failed to delete workspace.') }
  }

  const handleAddMember = async (wsId: number) => {
    if (!addUserId.trim()) return
    setAddingMember(true)
    try {
      await api.addWorkspaceMember(wsId, { user_id: parseInt(addUserId.trim()), role: addRole })
      await loadWorkspaces()
      setAddMemberForWs(null)
      setAddUserId('')
      setAddRole('viewer')
    } catch { setError('Failed to add member.') }
    finally { setAddingMember(false) }
  }

  const handleUpdateRole = async (wsId: number, memId: number) => {
    if (!editMemberRole) return
    setSavingRole(true)
    try {
      await api.updateMemberRole(wsId, memId, { role: editMemberRole.role })
      await loadWorkspaces()
      setEditMemberRole(null)
    } catch { setError('Failed to update role.') }
    finally { setSavingRole(false) }
  }

  const handleRemoveMember = async (wsId: number, memId: number) => {
    try {
      await api.removeWorkspaceMember(wsId, memId)
      setWorkspaces(prev => prev.map(w => w.id === wsId ? { ...w, memberships: w.memberships.filter(m => m.id !== memId) } : w))
    } catch { setError('Failed to remove member.') }
  }

  const roleBadge = (role: string) => {
    const colors: Record<string, string> = {
      admin: 'bg-purple-50 text-purple-700',
      editor: 'bg-blue-50 text-blue-700',
      viewer: 'bg-gray-50 text-gray-600',
    }
    return colors[role] || 'bg-gray-50 text-gray-600'
  }

  const formatDate = (d: string) => new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600" />
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Link to={ROUTES.dashboard} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Building2 className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Workspaces</h1>
        </div>
        <Button onClick={() => setShowCreateModal(true)} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Workspace
        </Button>
      </div>

      <p className="text-sm text-gray-500">Collaborate with your team in shared workspaces.</p>

      {error && <div className="p-4 bg-red-50 text-sm text-red-600 rounded-lg">{error}</div>}

      {workspaces.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
          <Building2 className="w-8 h-8 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-400 text-sm mb-4">No workspaces yet.</p>
          <Button onClick={() => setShowCreateModal(true)} className="mx-auto flex items-center gap-2">
            <Plus className="w-4 h-4" /> Create Your First Workspace
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {workspaces.map(ws => {
            const isExpanded = expandedId === ws.id
            const members = ws.memberships || []
            return (
              <div key={ws.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="p-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <button onClick={() => setExpandedId(isExpanded ? null : ws.id)} className="p-1 text-gray-400 hover:text-gray-600">
                        {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                      </button>
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
                        {ws.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-semibold text-gray-900 text-sm">{ws.name}</h3>
                        <p className="text-xs text-gray-400 mt-0.5">{members.length} member{members.length !== 1 ? 's' : ''}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => handleDelete(ws.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>

                {isExpanded && (
                  <div className="border-t border-gray-50">
                    <div className="px-5 py-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                          <Users className="w-4 h-4" /> Members
                        </h4>
                        <button
                          onClick={() => setAddMemberForWs(addMemberForWs === ws.id ? null : ws.id)}
                          className="text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1"
                        >
                          <UserPlus className="w-3.5 h-3.5" /> Add Member
                        </button>
                      </div>

                      {addMemberForWs === ws.id && (
                        <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl">
                          <input
                            value={addUserId}
                            onChange={e => setAddUserId(e.target.value)}
                            placeholder="User ID"
                            type="number"
                            className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                          />
                          <select
                            value={addRole}
                            onChange={e => setAddRole(e.target.value)}
                            className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                          >
                            <option value="viewer">Viewer</option>
                            <option value="editor">Editor</option>
                            <option value="admin">Admin</option>
                          </select>
                          <Button size="sm" onClick={() => handleAddMember(ws.id)} disabled={addingMember || !addUserId.trim()}>
                            {addingMember ? 'Adding...' : 'Add'}
                          </Button>
                          <button onClick={() => setAddMemberForWs(null)} className="text-sm text-gray-400 hover:text-gray-600 px-2">Cancel</button>
                        </div>
                      )}

                      {members.length === 0 ? (
                        <p className="text-xs text-gray-400 text-center py-4">No members yet.</p>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b border-gray-100">
                                <th className="text-left text-xs font-medium text-gray-400 pb-2 pr-4">Email</th>
                                <th className="text-left text-xs font-medium text-gray-400 pb-2 pr-4">Role</th>
                                <th className="text-left text-xs font-medium text-gray-400 pb-2 pr-4">Joined</th>
                                <th className="text-right text-xs font-medium text-gray-400 pb-2">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                              {members.map(mem => (
                                <tr key={mem.id} className="border-b border-gray-50">
                                  <td className="py-2.5 pr-4 text-gray-700">{mem.user_email || `User #${mem.user_id}`}</td>
                                  <td className="py-2.5 pr-4">
                                    {editMemberRole && editMemberRole.memId === mem.id ? (
                                      <div className="flex items-center gap-1">
                                        <select
                                          value={editMemberRole.role}
                                          onChange={e => setEditMemberRole({ ...editMemberRole, role: e.target.value })}
                                          className="rounded-lg border border-gray-200 px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500"
                                        >
                                          <option value="viewer">Viewer</option>
                                          <option value="editor">Editor</option>
                                          <option value="admin">Admin</option>
                                        </select>
                                        <button onClick={() => handleUpdateRole(ws.id, mem.id)} disabled={savingRole} className="text-xs text-purple-600 hover:text-purple-800 px-1">Save</button>
                                        <button onClick={() => setEditMemberRole(null)} className="text-xs text-gray-400 hover:text-gray-600">X</button>
                                      </div>
                                    ) : (
                                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${roleBadge(mem.role)}`}>{mem.role}</span>
                                    )}
                                  </td>
                                  <td className="py-2.5 pr-4 text-xs text-gray-400">{formatDate(mem.created_at)}</td>
                                  <td className="py-2.5 text-right">
                                    <div className="flex items-center justify-end gap-1">
                                      <button
                                        onClick={() => setEditMemberRole({ wsId: ws.id, memId: mem.id, role: mem.role })}
                                        className="p-1.5 rounded-lg hover:bg-purple-50 text-gray-400 hover:text-purple-600"
                                      >
                                        <Edit3 className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        onClick={() => handleRemoveMember(ws.id, mem.id)}
                                        className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}

      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={() => setShowCreateModal(false)}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">Create Workspace</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Name *</label>
                <input value={createName} onChange={e => setCreateName(e.target.value)} placeholder="e.g., Marketing Team" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div className="flex items-center gap-3 pt-4">
                <Button onClick={handleCreate} disabled={creating || !createName.trim()}>{creating ? 'Creating...' : 'Create'}</Button>
                <button onClick={() => setShowCreateModal(false)} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
