import { MessageSquare } from 'lucide-react'
import { motion } from 'framer-motion'
import type { CaptionCardData } from '@/types/caption'
import { pluralize } from '@/utils/formatters'
import { useClipboard } from '@/hooks/useClipboard'
import { CaptionCard } from './CaptionCard'

interface CaptionSectionProps {
  captions: CaptionCardData[]
}

export function CaptionSection({ captions }: CaptionSectionProps) {
  const { copiedId, copy } = useClipboard()

  if (!captions?.length) return null

  const handleCopy = (item: CaptionCardData, index: number) => {
    const hashtagStr = item.hashtags?.join(' ') ?? ''
    const text = `${item.caption}\n\n${item.callToAction}\n\n${hashtagStr}`
    copy(text, item.id ?? index)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
            <MessageSquare className="w-4 h-4 text-purple-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900">Generated Captions</h2>
        </div>
        <span className="text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
          {captions.length} {pluralize(captions.length, 'post')}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {captions.map((item, index) => (
          <motion.div
            key={item.id ?? index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.08 + 0.3, duration: 0.4 }}
          >
            <CaptionCard
              data={item}
              isCopied={copiedId === (item.id ?? index)}
              onCopy={() => handleCopy(item, index)}
            />
          </motion.div>
        ))}
      </div>
    </div>
  )
}
