from __future__ import annotations

from fastapi import APIRouter

from app.enums import Platform, Tone
from app.models.schemas import PlatformResponse, ToneResponse

router = APIRouter(tags=["Platforms & Tones"])


@router.get("/platforms", response_model=PlatformResponse)
def get_platforms():
    return {"platforms": Platform.values()}


@router.get("/tones", response_model=ToneResponse)
def get_tones():
    return {"tones": Tone.values()}
