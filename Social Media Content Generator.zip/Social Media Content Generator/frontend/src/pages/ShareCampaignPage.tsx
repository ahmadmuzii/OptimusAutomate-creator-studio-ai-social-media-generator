import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { ArrowLeft, Plus, Trash2, Copy, Check, Link2, Eye, EyeOff, ToggleLeft, ToggleRight } from 'lucide-react'
import client from '@/api/client'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'

interface ShareLink {
  id: number
  campaign_id: number
  token: string
  status: string
  password_hash?: string | null
  expiry_date?: string | null
  allow_approval?: boolean
  allow_comments?: boolean
  created_at: string
}

async function fetchShareLinks(campaignId: number): Promise<ShareLink[]> {
  const { data } = await client.get(`/campaigns/${campaignId}/share-links`)
  return data
}

async function createShareLink(campaignId: number, payload: Record<string, unknown>): Promise<ShareLink> {
  const { data } = await client.post(`/campaigns/${campaignId}/share-links`, payload)
  return data
}

async function updateShareLink(campaignId: number, linkId: number, payload: Record<string, unknown>): Promise<ShareLink> {
  const { data } = await client.put(`/campaigns/${campaignId}/share-links/${linkId}`, payload)
  return data
}

async function deleteShareLink(campaignId: number, linkId: number): Promise<void> {
  await client.delete(`/campaigns/${campaignId}/share-links/${linkId}`)
}

export function ShareCampaignPage() {
  const { campaignId: cId } = useParams<{ campaignId: string }>()
  const campaignId = Number(cId)

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [links, setLinks] = useState<ShareLink[]>([])

  const [showCreateModal, setShowCreateModal] = useState(false)
  const [createForm, setCreateForm] = useState({
    password: '',
    expiry_date: '',
    allow_approval: true,
    allow_comments: true,
  })
  const [creating, setCreating] = useState(false)

  const [copiedId, setCopiedId] = useState<number | null>(null)

  useEffect(() => {
    if (!campaignId) { setError('Invalid campaign ID.'); setLoading(false); return }
    fetchShareLinks(campaignId)
      .then(setLinks)
      .catch(() => setError('Could not load share links.'))
      .finally(() => setLoading(false))
  }, [campaignId])

  const loadLinks = async () => {
    const data = await fetchShareLinks(campaignId)
    setLinks(data)
  }

  const handleCreate = async () => {
    setCreating(true)
    try {
      const payload: Record<string, unknown> = {}
      if (createForm.password) payload.password = createForm.password
      if (createForm.expiry_date) payload.expiry_date = createForm.expiry_date
      payload.allow_approval = createForm.allow_approval
      payload.allow_comments = createForm.allow_comments
      await createShareLink(campaignId, payload)
      await loadLinks()
      setShowCreateModal(false)
      setCreateForm({ password: '', expiry_date: '', allow_approval: true, allow_comments: true })
    } catch { setError('Failed to create share link.') }
    finally { setCreating(false) }
  }

  const handleRevoke = async (link: ShareLink) => {
    try {
      await updateShareLink(campaignId, link.id, { status: link.status === 'revoked' ? 'active' : 'revoked' })
      setLinks(prev => prev.map(l => l.id === link.id ? { ...l, status: l.status === 'revoked' ? 'active' : 'revoked' } : l))
    } catch { setError('Failed to update share link.') }
  }

  const handleDelete = async (linkId: number) => {
    try {
      await deleteShareLink(campaignId, linkId)
      setLinks(prev => prev.filter(l => l.id !== linkId))
    } catch { setError('Failed to delete share link.') }
  }

  const handleCopyLink = async (link: ShareLink) => {
    const baseUrl = window.location.origin
    const shareUrl = `${baseUrl}/share/campaign/${link.token}`
    try {
      await navigator.clipboard.writeText(shareUrl)
      setCopiedId(link.id)
      setTimeout(() => setCopiedId(null), 2000)
    } catch (_err) { /* silently ignore */ }
  }

  const statusBadge = (status: string) => {
    const colors: Record<string, string> = {
      active: 'bg-green-50 text-green-700',
      revoked: 'bg-red-50 text-red-700',
      expired: 'bg-gray-50 text-gray-600',
    }
    return colors[status] || 'bg-gray-50 text-gray-600'
  }

  const formatDate = (d: string | null | undefined) => {
    if (!d) return '—'
    return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600" />
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <Link to={ROUTES.dashboard} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link2 className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Share Campaign</h1>
        </div>
        <Button onClick={() => setShowCreateModal(true)} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Share Link
        </Button>
      </div>

      <p className="text-sm text-gray-500">Create and manage shareable links for this campaign.</p>

      {error && <div className="p-4 bg-red-50 text-sm text-red-600 rounded-lg">{error}</div>}

      {links.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
          <Link2 className="w-8 h-8 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-400 text-sm mb-4">No share links created yet.</p>
          <Button onClick={() => setShowCreateModal(true)} className="mx-auto flex items-center gap-2">
            <Plus className="w-4 h-4" /> Create Your First Share Link
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {links.map(link => (
            <div key={link.id} className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-400 to-blue-500 flex items-center justify-center">
                    <Link2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm text-gray-900 font-medium">
                        ...{link.token.slice(-8)}
                      </span>
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${statusBadge(link.status)}`}>
                        {link.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-400 mt-0.5">
                      <span>Created {formatDate(link.created_at)}</span>
                      {link.expiry_date && <span>Expires {formatDate(link.expiry_date)}</span>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleCopyLink(link)}
                    className="p-2 rounded-lg hover:bg-purple-50 text-gray-400 hover:text-purple-600"
                    title="Copy link"
                  >
                    {copiedId === link.id ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => handleRevoke(link)}
                    className={`p-2 rounded-lg transition-colors ${link.status === 'revoked' ? 'hover:bg-green-50 text-gray-400 hover:text-green-600' : 'hover:bg-red-50 text-gray-400 hover:text-red-600'}`}
                    title={link.status === 'revoked' ? 'Reactivate' : 'Revoke'}
                  >
                    {link.status === 'revoked' ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => handleDelete(link.id)}
                    className="p-2 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {link.password_hash && (
                <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
                  <span className="bg-yellow-50 text-yellow-700 px-2 py-0.5 rounded">Password protected</span>
                </div>
              )}

              <div className="flex items-center gap-4 text-xs text-gray-400 border-t border-gray-50 pt-3">
                <span className="flex items-center gap-1">
                  {link.allow_approval ? <ToggleRight className="w-3.5 h-3.5 text-purple-600" /> : <ToggleLeft className="w-3.5 h-3.5 text-gray-300" />}
                  Approvals {link.allow_approval ? 'on' : 'off'}
                </span>
                <span className="flex items-center gap-1">
                  {link.allow_comments ? <ToggleRight className="w-3.5 h-3.5 text-purple-600" /> : <ToggleLeft className="w-3.5 h-3.5 text-gray-300" />}
                  Comments {link.allow_comments ? 'on' : 'off'}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={() => setShowCreateModal(false)}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">Create Share Link</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Password (optional)</label>
                <input
                  type="password"
                  value={createForm.password}
                  onChange={e => setCreateForm(prev => ({ ...prev, password: e.target.value }))}
                  placeholder="Leave empty for no password"
                  className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Expiry Date (optional)</label>
                <input
                  type="datetime-local"
                  value={createForm.expiry_date}
                  onChange={e => setCreateForm(prev => ({ ...prev, expiry_date: e.target.value }))}
                  className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <label className="flex items-center justify-between py-2">
                <span className="text-sm text-gray-700">Allow Approvals</span>
                <button
                  onClick={() => setCreateForm(prev => ({ ...prev, allow_approval: !prev.allow_approval }))}
                  className={`relative w-10 h-5 rounded-full transition-colors ${createForm.allow_approval ? 'bg-purple-600' : 'bg-gray-200'}`}
                >
                  <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${createForm.allow_approval ? 'translate-x-5' : ''}`} />
                </button>
              </label>
              <label className="flex items-center justify-between py-2">
                <span className="text-sm text-gray-700">Allow Comments</span>
                <button
                  onClick={() => setCreateForm(prev => ({ ...prev, allow_comments: !prev.allow_comments }))}
                  className={`relative w-10 h-5 rounded-full transition-colors ${createForm.allow_comments ? 'bg-purple-600' : 'bg-gray-200'}`}
                >
                  <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${createForm.allow_comments ? 'translate-x-5' : ''}`} />
                </button>
              </label>
              <div className="flex items-center gap-3 pt-4">
                <Button onClick={handleCreate} disabled={creating}>{creating ? 'Creating...' : 'Create Share Link'}</Button>
                <button onClick={() => setShowCreateModal(false)} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
