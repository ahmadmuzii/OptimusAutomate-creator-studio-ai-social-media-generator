import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { BrowserRouter } from 'react-router-dom'

const mockDeclareWinner = vi.fn()
const mockFetchExperiments = vi.fn()
const mockGetExperiment = vi.fn()
const mockCreateExperiment = vi.fn()
const mockDeleteExperiment = vi.fn()
const mockUpdateExperiment = vi.fn()
const mockAddExperimentVariant = vi.fn()
const mockUpdateVariantResult = vi.fn()

vi.mock('@/api/endpoints', () => ({
  declareWinner: (...args: unknown[]) => mockDeclareWinner(...args),
  fetchExperiments: (...args: unknown[]) => mockFetchExperiments(...args),
  getExperiment: (...args: unknown[]) => mockGetExperiment(...args),
  createExperiment: (...args: unknown[]) => mockCreateExperiment(...args),
  deleteExperiment: (...args: unknown[]) => mockDeleteExperiment(...args),
  updateExperiment: (...args: unknown[]) => mockUpdateExperiment(...args),
  addExperimentVariant: (...args: unknown[]) => mockAddExperimentVariant(...args),
  updateVariantResult: (...args: unknown[]) => mockUpdateVariantResult(...args),
}))

vi.mock('@/components/layout/BrandWorkspaceLayout', () => ({
  useBrandWorkspace: () => ({
    brandId: 1,
    brand: { id: 1, name: 'Brewline Coffee Co.' },
    refetchBrand: vi.fn(),
  }),
}))

import { ExperimentsPage } from '@/pages/ExperimentsPage'

const sampleExperiment = {
  id: 1,
  brand_id: 1,
  campaign_id: null,
  name: 'Hook Test A/B',
  variable_tested: 'hook_style',
  success_metric: 'engagement',
  status: 'running',
  created_at: '2026-06-01T00:00:00Z',
  variants: [
    { id: 1, label: 'A', variable_value: 'question', content_value: 'What if...', status: 'active', impressions: 100, clicks: 10, engagement: 50, conversions: 5, is_winner: false },
    { id: 2, label: 'B', variable_value: 'stat', content_value: '80% of...', status: 'active', impressions: 200, clicks: 20, engagement: 80, conversions: 10, is_winner: false },
    { id: 3, label: 'C', variable_value: 'hook', content_value: 'Experience Hook', status: 'active', impressions: 150, clicks: 25, engagement: 90, conversions: 15, is_winner: false },
  ],
}

const winnerResult = {
  id: 1,
  brand_id: 1,
  campaign_id: null,
  name: 'Hook Test A/B',
  variable_tested: 'hook_style',
  success_metric: 'engagement',
  status: 'completed',
  created_at: '2026-06-01T00:00:00Z',
  variants: [
    { id: 1, label: 'A', variable_value: 'question', content_value: 'What if...', status: 'active', impressions: 100, clicks: 10, engagement: 50, conversions: 5, is_winner: false },
    { id: 2, label: 'B', variable_value: 'stat', content_value: '80% of...', status: 'active', impressions: 200, clicks: 20, engagement: 80, conversions: 10, is_winner: false },
    { id: 3, label: 'C', variable_value: 'hook', content_value: 'Experience Hook', status: 'active', impressions: 150, clicks: 25, engagement: 90, conversions: 15, is_winner: true },
  ],
}

function renderPage() {
  return render(
    <BrowserRouter>
      <ExperimentsPage />
    </BrowserRouter>,
  )
}

describe('ExperimentsPage', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    mockFetchExperiments.mockResolvedValue([sampleExperiment])
    mockGetExperiment.mockResolvedValue(sampleExperiment)
  })

  it('loads and displays experiments', async () => {
    renderPage()
    await waitFor(() => {
      expect(screen.getByText('Hook Test A/B')).toBeInTheDocument()
    })
    expect(mockFetchExperiments).toHaveBeenCalledWith(1)
  })

  it('declare winner sends numeric variant_id in JSON body', async () => {
    const user = userEvent.setup()
    mockGetExperiment.mockResolvedValue(sampleExperiment)
    mockDeclareWinner.mockResolvedValue(winnerResult)

    renderPage()
    await waitFor(() => {
      expect(screen.getByText('Hook Test A/B')).toBeInTheDocument()
    })

    const expandBtn = screen.getByText('Hook Test A/B').closest('button')
    await user.click(expandBtn!)

    await waitFor(() => {
      const declareButtons = screen.getAllByText('Declare Winner')
      expect(declareButtons.length).toBeGreaterThan(0)
    })

    const declareBtn = screen.getAllByText('Declare Winner')[2]!
    await user.click(declareBtn)

    await waitFor(() => {
      expect(mockDeclareWinner).toHaveBeenCalledTimes(1)
    })

    const callArgs = mockDeclareWinner.mock.calls[0]!
    expect(callArgs[0]).toBe(1)  // brandId
    expect(callArgs[1]).toBe(1)  // expId
    expect(callArgs[2]).toEqual({ variant_id: 3 })  // variant_id matches backend contract
    expect(Number.isInteger(callArgs[2].variant_id)).toBe(true)
  })

  it('shows winner after successful declare-winner response', async () => {
    const user = userEvent.setup()
    mockDeclareWinner.mockResolvedValue(winnerResult)
    mockGetExperiment.mockResolvedValue(winnerResult)

    renderPage()
    await waitFor(() => {
      expect(screen.getByText('Hook Test A/B')).toBeInTheDocument()
    })

    const expandBtn = screen.getByText('Hook Test A/B').closest('button')
    await user.click(expandBtn!)

    await waitFor(() => {
      expect(screen.getAllByText('Declare Winner').length).toBeGreaterThan(0)
    })

    await user.click(screen.getAllByText('Declare Winner')[0]!)

    await waitFor(() => {
      expect(screen.getByText('completed')).toBeInTheDocument()
    })
  })

  it('failed request stays inline without replacing page', async () => {
    const user = userEvent.setup()
    mockDeclareWinner.mockRejectedValue(new Error('API Error'))

    renderPage()
    await waitFor(() => {
      expect(screen.getByText('Hook Test A/B')).toBeInTheDocument()
    })

    const expandBtn = screen.getByText('Hook Test A/B').closest('button')
    await user.click(expandBtn!)

    await waitFor(() => {
      expect(screen.getAllByText('Declare Winner').length).toBeGreaterThan(0)
    })

    await user.click(screen.getAllByText('Declare Winner')[0]!)

    await waitFor(() => {
      expect(screen.getByText('Failed to declare winner.')).toBeInTheDocument()
    })

    expect(screen.getByText('Hook Test A/B')).toBeInTheDocument()
    expect(screen.getByText('A/B Experiments')).toBeInTheDocument()
  })

  it('page content remains visible after failed request', async () => {
    const user = userEvent.setup()
    mockDeclareWinner.mockRejectedValue(new Error('API Error'))

    renderPage()
    await waitFor(() => {
      expect(screen.getByText('Hook Test A/B')).toBeInTheDocument()
    })

    const expandBtn = screen.getByText('Hook Test A/B').closest('button')
    await user.click(expandBtn!)

    await waitFor(() => {
      expect(screen.getAllByText('Declare Winner').length).toBeGreaterThan(0)
    })

    await user.click(screen.getAllByText('Declare Winner')[0]!)

    await waitFor(() => {
      expect(screen.getByText('Failed to declare winner.')).toBeInTheDocument()
    })

    expect(screen.getByText('A/B Experiments')).toBeInTheDocument()
    expect(screen.getByText('Variable: hook_style')).toBeInTheDocument()
    expect(screen.getAllByText('Declare Winner').length).toBeGreaterThan(0)
  })

  it('empty experiment list shows create prompt', async () => {
    mockFetchExperiments.mockResolvedValue([])
    renderPage()
    await waitFor(() => {
      expect(screen.getByText('Create Your First Experiment')).toBeInTheDocument()
    })
  })
})
