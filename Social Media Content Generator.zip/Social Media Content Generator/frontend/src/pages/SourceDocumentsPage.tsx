import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'
import { ArrowLeft, FileText, Link as LinkIcon, CheckCircle, XCircle, FileSearch, Loader2 } from 'lucide-react'
import { ErrorState } from '@/components/ui/ErrorState'
import { LoadingSpinner } from '@/components/ui/LoadingSpinner'
import * as api from '@/api/endpoints'
import type { SourceDocument, SourceFact } from '@/types/source'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'

export function SourceDocumentsPage() {
  const { brandId, brand } = useBrandWorkspace()

  const [loading, setLoading] = useState(true)

  const [documents, setDocuments] = useState<SourceDocument[]>([])
  const [error, setError] = useState<string | null>(null)

  const [activeTab, setActiveTab] = useState<'url' | 'text'>('url')
  const [urlInput, setUrlInput] = useState('')
  const [textInput, setTextInput] = useState('')
  const [extracting, setExtracting] = useState(false)
  const [extractedDoc, setExtractedDoc] = useState<SourceDocument | null>(null)

  const [selectedDoc, setSelectedDoc] = useState<SourceDocument | null>(null)
  const [viewingFacts, setViewingFacts] = useState(false)

  const load = useCallback(async () => {
    const data = await api.fetchSourceDocuments(brandId)
    setDocuments(data as SourceDocument[])
  }, [brandId])

  useEffect(() => {
    load().catch(() => setError('Could not load source documents.')).finally(() => setLoading(false))
  }, [brandId, load])

  const handleExtract = async () => {
    if (activeTab === 'url' && !urlInput.trim()) return
    if (activeTab === 'text' && !textInput.trim()) return
    setExtracting(true)
    setError(null)
    try {
      const payload = activeTab === 'url'
        ? { source_type: 'url', original_url: urlInput.trim() }
        : { source_type: 'text', pasted_text: textInput.trim() }
      const result = await api.createSourceDocument(brandId, payload) as SourceDocument
      setExtractedDoc(result)
      await load()
    } catch {
      setError('Failed to extract content.')
    } finally {
      setExtracting(false)
    }
  }

  const toggleFactApproval = async (fact: SourceFact) => {
    try {
      const payload = { approved_by_user: !fact.approved_by_user, excluded_by_user: false }
      await api.updateSourceFact(brandId, fact.id, payload)
      const updateFact = (doc: SourceDocument) => ({
        ...doc,
        facts: doc.facts.map(f => f.id === fact.id ? { ...f, ...payload } : f),
      })
      setExtractedDoc(prev => prev ? updateFact(prev) : prev)
      setDocuments(prev => prev.map(d => d.id === (extractedDoc?.id ?? -1) ? updateFact(d) : d))
      if (selectedDoc && selectedDoc.id === fact.id) {
        setSelectedDoc(prev => prev ? updateFact(prev) : prev)
      }
    } catch {
      setError('Failed to update fact.')
    }
  }

  const toggleFactExclusion = async (fact: SourceFact) => {
    try {
      const payload = { excluded_by_user: !fact.excluded_by_user, approved_by_user: false }
      await api.updateSourceFact(brandId, fact.id, payload)
      const updateFact = (doc: SourceDocument) => ({
        ...doc,
        facts: doc.facts.map(f => f.id === fact.id ? { ...f, ...payload } : f),
      })
      setExtractedDoc(prev => prev ? updateFact(prev) : prev)
      setDocuments(prev => prev.map(d => d.id === (extractedDoc?.id ?? -1) ? updateFact(d) : d))
      if (selectedDoc) {
        setSelectedDoc(prev => prev ? updateFact(prev) : prev)
      }
    } catch {
      setError('Failed to update fact.')
    }
  }

  const viewDocumentFacts = async (doc: SourceDocument) => {
    try {
      const full = await api.getSourceDocument(brandId, doc.id) as SourceDocument
      setSelectedDoc(full)
      setViewingFacts(true)
    } catch {
      setError('Could not load document facts.')
    }
  }

  const handleDeleteDoc = async (docId: number) => {
    try {
      await api.deleteSourceDocument(brandId, docId)
      setDocuments(prev => prev.filter(d => d.id !== docId))
      if (selectedDoc?.id === docId) setViewingFacts(false)
    } catch {
      setError('Failed to delete document.')
    }
  }

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr)
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })
  }

  const FactTable = ({ facts }: { facts: SourceFact[] }) => (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-100 bg-gray-50/50">
            <th className="text-left px-3 py-2 font-semibold text-gray-600">Category</th>
            <th className="text-left px-3 py-2 font-semibold text-gray-600">Label</th>
            <th className="text-left px-3 py-2 font-semibold text-gray-600">Value</th>
            <th className="text-center px-3 py-2 font-semibold text-gray-600">Approve</th>
            <th className="text-center px-3 py-2 font-semibold text-gray-600">Exclude</th>
          </tr>
        </thead>
        <tbody>
          {facts.map(fact => (
            <tr key={fact.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
              <td className="px-3 py-2 text-gray-600 capitalize">{fact.category}</td>
              <td className="px-3 py-2 font-medium text-gray-900">{fact.label}</td>
              <td className="px-3 py-2 text-gray-600 max-w-[240px] truncate" title={fact.value}>{fact.value}</td>
              <td className="px-3 py-2 text-center">
                <button onClick={() => toggleFactApproval(fact)} className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full transition-colors ${fact.approved_by_user ? 'bg-green-50 text-green-700' : 'bg-gray-100 text-gray-400 hover:bg-gray-200'}`}>
                  <CheckCircle className={`w-3.5 h-3.5 ${fact.approved_by_user ? 'fill-green-500 text-white' : ''}`} />
                  {fact.approved_by_user ? 'Approved' : 'Approve'}
                </button>
              </td>
              <td className="px-3 py-2 text-center">
                <button onClick={() => toggleFactExclusion(fact)} className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full transition-colors ${fact.excluded_by_user ? 'bg-red-50 text-red-700' : 'bg-gray-100 text-gray-400 hover:bg-gray-200'}`}>
                  <XCircle className={`w-3.5 h-3.5 ${fact.excluded_by_user ? 'fill-red-500 text-white' : ''}`} />
                  {fact.excluded_by_user ? 'Excluded' : 'Exclude'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {facts.length === 0 && <p className="text-sm text-gray-400 text-center py-6">No facts extracted.</p>}
    </div>
  )

  if (loading) return <LoadingSpinner />

  if (error) return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>
      <ErrorState message={error} onRetry={load} />
    </div>
  )

  return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center gap-3">
        <FileSearch className="w-6 h-6 text-purple-600" />
        <h1 className="text-2xl font-bold text-gray-900">Source Documents</h1>
      </div>

      {/* Add Source Section */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="px-5 pt-5 pb-3 border-b border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900">Add Source</h2>
        </div>

        <div className="px-5 pt-4">
          <div className="flex items-center gap-1 border-b border-gray-100 pb-3 mb-4">
            <button onClick={() => setActiveTab('url')} className={`flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${activeTab === 'url' ? 'bg-purple-50 text-purple-700' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'}`}>
              <LinkIcon className="w-3.5 h-3.5" /> URL
            </button>
            <button onClick={() => setActiveTab('text')} className={`flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${activeTab === 'text' ? 'bg-purple-50 text-purple-700' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'}`}>
              <FileText className="w-3.5 h-3.5" /> Paste Text
            </button>
          </div>

          {activeTab === 'url' ? (
            <div className="flex items-center gap-3 mb-4">
              <input value={urlInput} onChange={e => setUrlInput(e.target.value)} placeholder="https://example.com/article" className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              <Button onClick={handleExtract} disabled={extracting || !urlInput.trim()} className="shrink-0">
                {extracting ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileSearch className="w-4 h-4" />}
                {extracting ? 'Extracting...' : 'Extract'}
              </Button>
            </div>
          ) : (
            <div className="mb-4 space-y-3">
              <textarea value={textInput} onChange={e => setTextInput(e.target.value)} rows={6} placeholder="Paste article or document content here..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              <Button onClick={handleExtract} disabled={extracting || !textInput.trim()}>
                {extracting ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileSearch className="w-4 h-4" />}
                {extracting ? 'Extracting...' : 'Extract'}
              </Button>
            </div>
          )}
        </div>

        {/* Extracted Facts */}
        {extractedDoc && extractedDoc.facts.length > 0 && (
          <div className="border-t border-gray-100">
            <div className="px-5 py-3 bg-gray-50/50 border-b border-gray-100">
              <p className="text-sm font-medium text-gray-700">Extracted Facts from &ldquo;{extractedDoc.title || extractedDoc.original_url || 'pasted text'}&rdquo;</p>
            </div>
            <div className="px-5 py-3">
              <FactTable facts={extractedDoc.facts} />
            </div>
          </div>
        )}
      </div>

      {/* Saved Documents */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="px-5 pt-5 pb-3 border-b border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900">Saved Documents</h2>
        </div>

        {documents.length === 0 ? (
          <div className="p-12 text-center">
            <FileText className="w-8 h-8 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-400 text-sm">No source documents saved yet.</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {documents.map(doc => (
              <div key={doc.id} className="flex items-center justify-between px-5 py-3 hover:bg-gray-50/50 transition-colors">
                <button onClick={() => viewDocumentFacts(doc)} className="flex-1 text-left min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">{doc.title || doc.original_url || 'Untitled Document'}</p>
                  <div className="flex items-center gap-3 text-xs text-gray-400 mt-0.5">
                    <span className="flex items-center gap-1"><FileText className="w-3 h-3" /> {doc.source_type}</span>
                    <span>{formatDate(doc.created_at)}</span>
                    <span>{doc.facts?.length || 0} facts</span>
                  </div>
                </button>
                <button onClick={() => handleDeleteDoc(doc.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 ml-3 shrink-0" title="Delete">
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Document Facts Panel */}
      {viewingFacts && selectedDoc && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={() => setViewingFacts(false)}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-3xl max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold text-gray-900">{selectedDoc.title || 'Document Facts'}</h2>
                <p className="text-sm text-gray-500 mt-0.5">{selectedDoc.source_type} &middot; {formatDate(selectedDoc.created_at)} &middot; {selectedDoc.facts.length} facts</p>
              </div>
              <button onClick={() => setViewingFacts(false)} className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100">✕</button>
            </div>
            {selectedDoc.original_url && (
              <a href={selectedDoc.original_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-sm text-purple-600 hover:text-purple-800 mb-4">
                <LinkIcon className="w-3.5 h-3.5" /> {selectedDoc.original_url}
              </a>
            )}
            <FactTable facts={selectedDoc.facts} />
          </div>
        </div>
      )}
    </div>
  )
}
