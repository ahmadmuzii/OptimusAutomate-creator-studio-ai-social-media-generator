import { lazy, Suspense } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { GuestPreviewRoute } from '@/components/common/GuestPreviewRoute'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import { LandingPage } from '@/pages/LandingPage'
import { PublicCampaignGeneratorPage } from '@/pages/PublicCampaignGeneratorPage'
import { LoginPage } from '@/pages/LoginPage'
import { SignupPage } from '@/pages/SignupPage'
import { ForgotPasswordPage } from '@/pages/ForgotPasswordPage'
import { ResetPasswordPage } from '@/pages/ResetPasswordPage'
import { DashboardHomePage } from '@/pages/DashboardHomePage'
import { GenerateCampaignPage } from '@/pages/GenerateCampaignPage'
import { CalendarPage } from '@/pages/CalendarPage'
import { CaptionsPage } from '@/pages/CaptionsPage'
import { BrandsPage } from '@/pages/BrandsPage'
import { BrandDetailPage } from '@/pages/BrandDetailPage'
import { PersonasPage } from '@/pages/PersonasPage'
import { ConversionPathsPage } from '@/pages/ConversionPathsPage'
import { BrandWorkspaceLayout } from '@/components/layout/BrandWorkspaceLayout'
import { ProfilePage } from '@/pages/ProfilePage'
import { NotFoundPage } from '@/pages/NotFoundPage'
import { ROUTES } from './paths'

const BrandGuardrailsPage = lazy(() => import('@/pages/BrandGuardrailsPage').then(m => ({ default: m.BrandGuardrailsPage })))
const SourceDocumentsPage = lazy(() => import('@/pages/SourceDocumentsPage').then(m => ({ default: m.SourceDocumentsPage })))
const ContentPacksPage = lazy(() => import('@/pages/ContentPacksPage').then(m => ({ default: m.ContentPacksPage })))
const FreshnessPage = lazy(() => import('@/pages/FreshnessPage').then(m => ({ default: m.FreshnessPage })))
const StrategyModesPage = lazy(() => import('@/pages/StrategyModesPage').then(m => ({ default: m.StrategyModesPage })))
const PerformancePage = lazy(() => import('@/pages/PerformancePage').then(m => ({ default: m.PerformancePage })))
const ExperimentsPage = lazy(() => import('@/pages/ExperimentsPage').then(m => ({ default: m.ExperimentsPage })))
const RegionalSettingsPage = lazy(() => import('@/pages/RegionalSettingsPage').then(m => ({ default: m.RegionalSettingsPage })))
const CompetitorsPage = lazy(() => import('@/pages/CompetitorsPage').then(m => ({ default: m.CompetitorsPage })))
const WorkspacesPage = lazy(() => import('@/pages/WorkspacesPage').then(m => ({ default: m.WorkspacesPage })))
const CollaborationPage = lazy(() => import('@/pages/CollaborationPage').then(m => ({ default: m.CollaborationPage })))
const ShareCampaignPage = lazy(() => import('@/pages/ShareCampaignPage').then(m => ({ default: m.ShareCampaignPage })))
const HistoryPage = lazy(() => import('@/pages/HistoryPage').then(m => ({ default: m.HistoryPage })))
const SettingsPage = lazy(() => import('@/pages/SettingsPage').then(m => ({ default: m.SettingsPage })))

function PageLoader() {
  return (
    <div className="flex items-center justify-center py-20">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600" />
    </div>
  )
}

export function AppRoutes() {
  const { isLoading } = useAuth()

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600" />
      </div>
    )
  }

  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        {/* Public */}
        <Route path={ROUTES.home} element={<LandingPage />} />
        <Route path={ROUTES.campaignGenerator} element={<PublicCampaignGeneratorPage />} />
        <Route path={ROUTES.login} element={<LoginPage />} />
        <Route path={ROUTES.signup} element={<SignupPage />} />
        <Route path={ROUTES.forgotPassword} element={<ForgotPasswordPage />} />
        <Route path={ROUTES.resetPassword} element={<ResetPasswordPage />} />

        {/* Legacy redirect: old /generate → /dashboard/generate */}
        <Route path="/generate" element={<Navigate to={ROUTES.generate} replace />} />

        {/* Dashboard — protected for authenticated, guest preview for ?mode=guest */}
        <Route
          path={ROUTES.dashboard}
          element={
            <GuestPreviewRoute>
              <DashboardLayout />
            </GuestPreviewRoute>
          }
        >
          <Route index element={<DashboardHomePage />} />
          <Route path="generate" element={<GenerateCampaignPage />} />
          <Route path="calendar" element={<CalendarPage />} />
          <Route path="captions" element={<CaptionsPage />} />
          <Route path="brands" element={<BrandsPage />} />
          <Route path="brands/:brandId" element={<BrandWorkspaceLayout />}>
            <Route index element={<BrandDetailPage />} />
            <Route path="guardrails" element={<BrandGuardrailsPage />} />
            <Route path="personas" element={<PersonasPage />} />
            <Route path="conversion-paths" element={<ConversionPathsPage />} />
            <Route path="source-documents" element={<SourceDocumentsPage />} />
            <Route path="content-packs" element={<ContentPacksPage />} />
            <Route path="freshness" element={<FreshnessPage />} />
            <Route path="strategies" element={<StrategyModesPage />} />
            <Route path="performance" element={<PerformancePage />} />
            <Route path="experiments" element={<ExperimentsPage />} />
            <Route path="regional" element={<RegionalSettingsPage />} />
            <Route path="competitors" element={<CompetitorsPage />} />
          </Route>
          <Route path="workspaces" element={<WorkspacesPage />} />
          <Route path="campaigns/:campaignId/collaboration" element={<CollaborationPage />} />
          <Route path="campaigns/:campaignId/share" element={<ShareCampaignPage />} />
          <Route path="history" element={<HistoryPage />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>

        <Route path={ROUTES.notFound} element={<NotFoundPage />} />
      </Routes>
    </Suspense>
  )
}
