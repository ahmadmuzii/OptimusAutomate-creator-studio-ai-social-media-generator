export type PlatformKey = 'instagram' | 'linkedin' | 'tiktok' | 'facebook' | 'x'
export type ToneKey = 'professional' | 'funny' | 'luxury' | 'genz'

export interface LiveDemoDay {
  day: number
  theme: string
  idea: string
  contentType: string
  postingTime: string
}

export interface LiveDemoCaption {
  day: number
  caption: string
  cta: string
}

export interface LiveDemoCampaign {
  platform: PlatformKey
  tone: ToneKey
  days: LiveDemoDay[]
  featuredCaptions: LiveDemoCaption[]
  hashtags: string[]
}

export const BASE_DAYS = [
  { day: 1, purpose: 'brand_story' as const, theme: 'Brand Story' },
  { day: 2, purpose: 'education' as const, theme: 'Educational' },
  { day: 3, purpose: 'customer_spotlight' as const, theme: 'Customer Spotlight' },
  { day: 4, purpose: 'behind_the_scenes' as const, theme: 'Behind the Scenes' },
  { day: 5, purpose: 'product_showcase' as const, theme: 'Product Showcase' },
  { day: 6, purpose: 'engagement' as const, theme: 'Community Engagement' },
  { day: 7, purpose: 'conversion' as const, theme: 'Conversion' },
]
