import { describe, it, expect } from 'vitest'
import {
  getPlatformInfo,
  getPlatformIcon,
  getPlatformGradient,
  getPlatformDisplayName,
  mapPlatformToApi,
  normalizePlatform,
  platforms,
} from './platforms'

describe('platforms list', () => {
  it('has all five platforms', () => {
    const ids = platforms.map((p) => p.id)
    expect(ids).toEqual(['instagram', 'linkedin', 'tiktok', 'facebook', 'twitter'])
  })
})

describe('getPlatformInfo', () => {
  it('returns info for instagram by id', () => {
    const info = getPlatformInfo('instagram')
    expect(info.name).toBe('Instagram')
    expect(info.gradient).toBe('from-pink-500 to-purple-600')
  })

  it('returns info for instagram by capitalized name', () => {
    const info = getPlatformInfo('Instagram')
    expect(info.id).toBe('instagram')
  })

  it('returns info for instagram by uppercase', () => {
    const info = getPlatformInfo('INSTAGRAM')
    expect(info.id).toBe('instagram')
  })

  it.each([
    ['linkedin', 'LinkedIn', 'from-blue-600 to-blue-800'],
    ['tiktok', 'TikTok', 'from-black to-gray-800'],
    ['facebook', 'Facebook', 'from-blue-500 to-blue-700'],
    ['twitter', 'X / Twitter', 'from-gray-900 to-black'],
  ])('returns info for %s', (id, name, gradient) => {
    const info = getPlatformInfo(id)
    expect(info.name).toBe(name)
    expect(info.gradient).toBe(gradient)
  })

  it('handles X / Twitter variations', () => {
    expect(getPlatformInfo('x').name).toBe('X / Twitter')
    expect(getPlatformInfo('X').name).toBe('X / Twitter')
    expect(getPlatformInfo('X / Twitter').name).toBe('X / Twitter')
    expect(getPlatformInfo('x/twitter').name).toBe('X / Twitter')
  })

  it('returns fallback for unknown platform', () => {
    const info = getPlatformInfo('MySpace')
    expect(info.name).toBe('MySpace')
    expect(info.gradient).toBe('from-purple-600 to-purple-800')
  })
})

describe('getPlatformIcon', () => {
  it('returns a LucideIcon component for each platform', () => {
    for (const p of platforms) {
      const Icon = getPlatformIcon(p.id)
      expect(Icon).toBeDefined()
    }
  })
})

describe('getPlatformGradient', () => {
  it('returns the gradient string', () => {
    expect(getPlatformGradient('instagram')).toBe('from-pink-500 to-purple-600')
  })
})

describe('getPlatformDisplayName', () => {
  it('returns the display name', () => {
    expect(getPlatformDisplayName('tiktok')).toBe('TikTok')
  })
})

describe('mapPlatformToApi', () => {
  it('maps instagram to Instagram', () => {
    expect(mapPlatformToApi('instagram')).toBe('Instagram')
  })

  it('maps twitter to X', () => {
    expect(mapPlatformToApi('twitter')).toBe('X')
  })

  it('passes through unknown values', () => {
    expect(mapPlatformToApi('MySpace')).toBe('MySpace')
  })
})

describe('normalizePlatform', () => {
  it('returns null for null', () => {
    expect(normalizePlatform(null)).toBeNull()
  })

  it('returns null for undefined', () => {
    expect(normalizePlatform(undefined)).toBeNull()
  })

  it('returns null for empty string', () => {
    expect(normalizePlatform('')).toBeNull()
  })

  it('normalizes instagram', () => {
    expect(normalizePlatform('instagram')).toBe('instagram')
  })

  it('normalizes Instagram with capital I', () => {
    expect(normalizePlatform('Instagram')).toBe('instagram')
  })

  it('normalizes linkedin', () => {
    expect(normalizePlatform('linkedin')).toBe('linkedin')
  })

  it('normalizes LinkedIn', () => {
    expect(normalizePlatform('LinkedIn')).toBe('linkedin')
  })

  it('normalizes tiktok', () => {
    expect(normalizePlatform('tiktok')).toBe('tiktok')
  })

  it('normalizes TikTok', () => {
    expect(normalizePlatform('TikTok')).toBe('tiktok')
  })

  it('normalizes facebook', () => {
    expect(normalizePlatform('facebook')).toBe('facebook')
  })

  it('normalizes Facebook', () => {
    expect(normalizePlatform('Facebook')).toBe('facebook')
  })

  it('normalizes x', () => {
    expect(normalizePlatform('x')).toBe('x')
  })

  it('normalizes X', () => {
    expect(normalizePlatform('X')).toBe('x')
  })

  it('normalizes twitter', () => {
    expect(normalizePlatform('twitter')).toBe('x')
  })

  it('normalizes X / Twitter', () => {
    expect(normalizePlatform('X / Twitter')).toBe('x')
  })

  it('normalizes x/twitter', () => {
    expect(normalizePlatform('x/twitter')).toBe('x')
  })

  it('returns null for unknown platform', () => {
    expect(normalizePlatform('MySpace')).toBeNull()
  })

  it('trims whitespace', () => {
    expect(normalizePlatform('  Instagram  ')).toBe('instagram')
  })
})
