from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse
from structlog.stdlib import BoundLogger

from app.exceptions import AppError
from app.logging_config import get_logger


def app_error_handler(request: Request, exc: AppError) -> JSONResponse:
    logger: BoundLogger = get_logger("api.errors")
    logger.error(
        "app_error",
        path=str(request.url),
        method=request.method,
        status_code=exc.status_code,
        detail=exc.detail,
    )
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail},
        headers=exc.headers or {},
    )


def generic_error_handler(request: Request, exc: Exception) -> JSONResponse:
    logger: BoundLogger = get_logger("api.errors")
    logger.exception(
        "unhandled_error",
        path=str(request.url),
        method=request.method,
        error=str(exc),
    )
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"},
    )
