"""Test Groq API connection.

Usage:
    python scripts/test_groq_connection.py

Requires GROQ_API_KEY to be set in .env or environment.
"""

from __future__ import annotations

import sys

try:
    from app.config import settings
    from app.services.llm_service import call_groq
except ImportError:
    sys.path.insert(0, ".")
    from app.config import settings
    from app.services.llm_service import call_groq


def main() -> int:
    print(f"Groq enabled: {settings.groq_enabled}")
    print(f"Groq model: {settings.groq_model}")
    print(f"Groq timeout: {settings.groq_timeout_seconds}s")
    print(f"Groq max retries: {settings.groq_max_retries}")
    print(f"Groq API key configured: {bool(settings.groq_api_key)}")

    if not settings.groq_api_key:
        print("ERROR: GROQ_API_KEY is not set.")
        return 1

    print("\nCalling Groq API...")
    result = call_groq(
        brand_name="TestBrand",
        brand_description="A test company making AI-powered productivity tools",
        niche="technology",
        target_audience="Developers and tech enthusiasts",
        platform="Twitter",
        tone="professional",
        campaign_goal="brand_awareness",
        days=3,
    )

    if result is None:
        print("FAILED: Groq returned None — check logs for details.")
        return 1

    calendar = result.get("calendar")
    if not calendar:
        print("FAILED: Response has no 'calendar' key.")
        print(f"Raw response keys: {list(result.keys())}")
        return 1

    print(f"SUCCESS: Generated {len(calendar)} days of content.\n")

    for day in calendar:
        print(f"  Day {day.get('day')}: {day.get('contentTheme', 'N/A')}")
        print(f"       {day.get('caption', '')[:80]}...")
        print()

    return 0


if __name__ == "__main__":
    sys.exit(main())
