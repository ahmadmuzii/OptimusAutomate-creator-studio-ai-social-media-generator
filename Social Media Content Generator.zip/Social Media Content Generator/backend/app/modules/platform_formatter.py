from __future__ import annotations

from typing import Any

PLATFORMS: dict[str, dict[str, Any]] = {
    "instagram": {
        "caption_length": "medium",
        "max_caption_chars": 2200,
        "style": "visual, engaging, emoji-rich",
        "cta_style": "action-driven with link in bio reference",
        "hashtag_range": (5, 10),
        "content_types": ["reel", "carousel", "static_post", "story"],
    },
    "linkedin": {
        "caption_length": "long",
        "max_caption_chars": 3000,
        "style": "professional, insightful, thought-leadership",
        "cta_style": "comment-driven, question-based",
        "hashtag_range": (3, 5),
        "content_types": ["static_post", "carousel", "thread"],
    },
    "tiktok": {
        "caption_length": "short",
        "max_caption_chars": 500,
        "style": "trendy, punchy, hook-first",
        "cta_style": "follow for more, duet this",
        "hashtag_range": (4, 7),
        "content_types": ["short_video", "reel"],
    },
    "facebook": {
        "caption_length": "medium",
        "max_caption_chars": 800,
        "style": "community-focused, conversational, shareable",
        "cta_style": "share with a friend, tag someone",
        "hashtag_range": (2, 5),
        "content_types": ["static_post", "carousel", "reel", "story"],
    },
    "x": {
        "caption_length": "very_short",
        "max_caption_chars": 280,
        "style": "concise, witty, thread-friendly",
        "cta_style": "retweet, reply with thoughts",
        "hashtag_range": (1, 3),
        "content_types": ["static_post", "thread"],
    },
}


def get_max_caption_chars(platform: str) -> int:
    config = PLATFORMS.get(platform)
    return config["max_caption_chars"] if config else 2200


def get_content_type_options(platform: str) -> list[str]:
    config = PLATFORMS.get(platform)
    if not config:
        raise ValueError(f"Unsupported platform: {platform}")
    return config["content_types"]


def get_hashtag_range(platform: str) -> tuple[int, int]:
    config = PLATFORMS.get(platform)
    if not config:
        raise ValueError(f"Unsupported platform: {platform}")
    return config["hashtag_range"]


def get_hashtag_count(platform: str) -> int:
    low, high = get_hashtag_range(platform)
    return (low + high) * 2


def format_for_platform(caption: str, platform: str) -> str:
    if platform not in PLATFORMS:
        raise ValueError(f"Unsupported platform: {platform}")
    max_chars = get_max_caption_chars(platform)
    if len(caption) <= max_chars:
        return caption

    truncated = caption[: max_chars - 20].rsplit(" ", 1)[0]
    return truncated + "..."
