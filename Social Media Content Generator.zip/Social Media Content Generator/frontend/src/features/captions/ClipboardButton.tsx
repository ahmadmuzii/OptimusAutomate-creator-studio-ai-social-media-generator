import { Copy, Check } from 'lucide-react'
import { cn } from '@/utils/cn'

interface ClipboardButtonProps {
  isCopied: boolean
  onCopy: () => void
}

export function ClipboardButton({ isCopied, onCopy }: ClipboardButtonProps) {
  return (
    <button
      onClick={onCopy}
      className={cn(
        'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200',
        isCopied
          ? 'bg-green-100 text-green-700'
          : 'bg-gray-100 text-gray-600 hover:bg-purple-100 hover:text-purple-700',
      )}
    >
      {isCopied ? (
        <>
          <Check className="w-3.5 h-3.5" />
          Copied!
        </>
      ) : (
        <>
          <Copy className="w-3.5 h-3.5" />
          Copy
        </>
      )}
    </button>
  )
}
