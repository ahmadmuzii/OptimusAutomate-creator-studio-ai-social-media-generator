from __future__ import annotations


class TestCampaignFreshness:
    """Test campaign freshness / fatigue analysis endpoints."""

    def test_analyze_fatigue_returns_structure(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.get(f"/api/v1/brands/{brand_id}/freshness", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert "fatigue_score" in data
        assert "recommendations" in data

    def test_fatigue_no_campaigns(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.get(f"/api/v1/brands/{brand_id}/freshness", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["fatigue_score"] == 0.0
        assert data["recommendations"] == ["No campaign history yet \u2014 start with fresh content"]

    def test_fatigue_with_campaigns(self, client, auth_headers, created_brand, sample_campaign_payload):
        brand_id = created_brand["id"]
        for i in range(3):
            payload = {**sample_campaign_payload, "name": f"Fatigue Campaign {i}"}
            resp = client.post("/api/v1/campaigns", json=payload, headers=auth_headers)
            assert resp.status_code == 200
            cid = resp.json()["id"]
            client.put(f"/api/v1/campaigns/{cid}", json={"status": "active"}, headers=auth_headers)
        response = client.get(f"/api/v1/brands/{brand_id}/freshness", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["fatigue_score"] > 0
        assert len(data["recommendations"]) > 0
        assert data["total_campaigns"] >= 2

    def test_fatigue_for_campaign_endpoint(self, client, auth_headers, created_brand, created_campaign):
        brand_id = created_brand["id"]
        campaign_id = created_campaign["id"]
        client.put(f"/api/v1/campaigns/{campaign_id}", json={"status": "active"}, headers=auth_headers)
        response = client.get(
            f"/api/v1/brands/{brand_id}/freshness/for-campaign/{campaign_id}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert "recommendations" in data
        assert isinstance(data["recommendations"], list)

    def test_cannot_access_other_users_fatigue(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.get(f"/api/v1/brands/{brand_id}/freshness", headers=second_auth_headers)
        assert response.status_code == 404
