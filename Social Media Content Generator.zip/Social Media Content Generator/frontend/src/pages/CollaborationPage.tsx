import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { ArrowLeft, CheckCircle, XCircle, Clock, MessageSquare, Reply, Edit3, Trash2, Check, RotateCcw, Save, History, ThumbsUp, ThumbsDown } from 'lucide-react'
import * as api from '@/api/endpoints'
import type { ApprovalRequest, CampaignComment, PostVersion } from '@/types/workspace'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'

type Section = 'approvals' | 'comments' | 'versions'

export function CollaborationPage() {
  const { campaignId: cId } = useParams<{ campaignId: string }>()
  const campaignId = Number(cId)

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeSection, setActiveSection] = useState<Section>('approvals')

  const [approvals, setApprovals] = useState<ApprovalRequest[]>([])
  const [creatingApproval, setCreatingApproval] = useState(false)
  const [decisionLoading, setDecisionLoading] = useState<Record<number, boolean>>({})
  const [decisionComment, setDecisionComment] = useState<Record<number, string>>({})
  const [showDecisionInput, setShowDecisionInput] = useState<Record<number, boolean>>({})

  const [comments, setComments] = useState<CampaignComment[]>([])
  const [newComment, setNewComment] = useState('')
  const [addingComment, setAddingComment] = useState(false)
  const [replyToId, setReplyToId] = useState<number | null>(null)
  const [replyContent, setReplyContent] = useState('')
  const [addingReply, setAddingReply] = useState<Record<number, boolean>>({})
  const [editingCommentId, setEditingCommentId] = useState<number | null>(null)
  const [editContent, setEditContent] = useState('')

  const [versions, setVersions] = useState<PostVersion[]>([])
  const [showSaveVersion, setShowSaveVersion] = useState(false)
  const [changeReason, setChangeReason] = useState('')
  const [savingVersion, setSavingVersion] = useState(false)
  const [postIdForVersion, setPostIdForVersion] = useState<number | null>(null)
  const [restoringVersion, setRestoringVersion] = useState<Record<number, boolean>>({})

  useEffect(() => {
    if (!campaignId) { setError('Invalid campaign ID.'); setLoading(false); return }
    Promise.all([
      api.fetchApprovalRequests(campaignId),
      api.fetchCampaignComments(campaignId),
    ])
      .then(([reqs, cmts]) => {
        setApprovals(reqs as ApprovalRequest[])
        setComments(cmts as CampaignComment[])
      })
      .catch(() => setError('Could not load collaboration data.'))
      .finally(() => setLoading(false))
  }, [campaignId])

  const loadApprovals = async () => {
    const data = await api.fetchApprovalRequests(campaignId)
    setApprovals(data as ApprovalRequest[])
  }

  const loadComments = async () => {
    const data = await api.fetchCampaignComments(campaignId)
    setComments(data as CampaignComment[])
  }

  const loadVersions = async (postId: number) => {
    const data = await api.fetchPostVersions(campaignId, postId)
    setVersions(data as PostVersion[])
  }

  const handleCreateApproval = async () => {
    setCreatingApproval(true)
    try {
      await api.createApprovalRequest(campaignId)
      await loadApprovals()
    } catch { setError('Failed to create approval request.') }
    finally { setCreatingApproval(false) }
  }

  const handleDecision = async (reqId: number, decision: 'approved' | 'rejected') => {
    setDecisionLoading(prev => ({ ...prev, [reqId]: true }))
    try {
      const payload: Record<string, unknown> = { decision }
      if (decisionComment[reqId]) payload.comment = decisionComment[reqId]
      await api.addApprovalDecision(campaignId, reqId, payload)
      await loadApprovals()
      setShowDecisionInput(prev => ({ ...prev, [reqId]: false }))
      setDecisionComment(prev => ({ ...prev, [reqId]: '' }))
    } catch { setError('Failed to submit decision.') }
    finally { setDecisionLoading(prev => ({ ...prev, [reqId]: false })) }
  }

  const handleAddComment = async () => {
    if (!newComment.trim()) return
    setAddingComment(true)
    try {
      await api.addCampaignComment(campaignId, { content: newComment.trim() })
      await loadComments()
      setNewComment('')
    } catch { setError('Failed to add comment.') }
    finally { setAddingComment(false) }
  }

  const handleReply = async (parentId: number) => {
    if (!replyContent.trim()) return
    setAddingReply(prev => ({ ...prev, [parentId]: true }))
    try {
      await api.addCampaignComment(campaignId, { content: replyContent.trim(), parent_id: parentId })
      await loadComments()
      setReplyToId(null)
      setReplyContent('')
    } catch { setError('Failed to add reply.') }
    finally { setAddingReply(prev => ({ ...prev, [parentId]: false })) }
  }

  const handleEditComment = async (commentId: number) => {
    if (!editContent.trim()) return
    try {
      await api.updateCampaignComment(campaignId, commentId, { content: editContent.trim() })
      await loadComments()
      setEditingCommentId(null)
      setEditContent('')
    } catch { setError('Failed to update comment.') }
  }

  const handleDeleteComment = async (commentId: number) => {
    try {
      await api.deleteCampaignComment(campaignId, commentId)
      setComments(prev => prev.filter(c => c.id !== commentId))
    } catch { setError('Failed to delete comment.') }
  }

  const handleToggleResolve = async (comment: CampaignComment) => {
    try {
      await api.updateCampaignComment(campaignId, comment.id, { is_resolved: !comment.is_resolved })
      setComments(prev => prev.map(c => c.id === comment.id ? { ...c, is_resolved: !c.is_resolved } : c))
    } catch { setError('Failed to update comment.') }
  }

  const handleSaveVersion = async () => {
    if (!postIdForVersion) return
    setSavingVersion(true)
    try {
      const payload: Record<string, unknown> = { change_reason: changeReason || null }
      await api.createPostVersion(campaignId, postIdForVersion, payload)
      await loadVersions(postIdForVersion)
      setShowSaveVersion(false)
      setChangeReason('')
      setPostIdForVersion(null)
    } catch { setError('Failed to save version.') }
    finally { setSavingVersion(false) }
  }

  const handleRestoreVersion = async (versionId: number) => {
    setRestoringVersion(prev => ({ ...prev, [versionId]: true }))
    try {
      await api.restorePostVersion(campaignId, versionId)
    } catch { setError('Failed to restore version.') }
    finally { setRestoringVersion(prev => ({ ...prev, [versionId]: false })) }
  }

  const approvalStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="w-4 h-4 text-green-500" />
      case 'rejected': return <XCircle className="w-4 h-4 text-red-500" />
      default: return <Clock className="w-4 h-4 text-yellow-500" />
    }
  }

  const approvalStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      approved: 'bg-green-50 text-green-700',
      rejected: 'bg-red-50 text-red-700',
      pending: 'bg-yellow-50 text-yellow-700',
    }
    return colors[status] || 'bg-gray-50 text-gray-600'
  }

  const formatDate = (d: string) => new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600" />
      </div>
    )
  }

  const sections: { key: Section; label: string }[] = [
    { key: 'approvals', label: 'Approvals' },
    { key: 'comments', label: 'Comments' },
    { key: 'versions', label: 'Version History' },
  ]

  const rootComments = comments.filter(c => !c.parent_id)
  const replies = (parentId: number) => comments.filter(c => c.parent_id === parentId)

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Link to={ROUTES.dashboard} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
      </Link>

      <h1 className="text-2xl font-bold text-gray-900">Collaboration</h1>

      <div className="flex items-center gap-2 border-b border-gray-100 pb-3">
        {sections.map(s => (
          <button
            key={s.key}
            onClick={() => setActiveSection(s.key)}
            className={`text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${
              activeSection === s.key
                ? 'bg-purple-50 text-purple-700'
                : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>

      {error && <div className="p-4 bg-red-50 text-sm text-red-600 rounded-lg">{error}</div>}

      {activeSection === 'approvals' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-500">Manage approval requests and decisions.</p>
            <Button onClick={handleCreateApproval} disabled={creatingApproval} loading={creatingApproval} className="flex items-center gap-2">
              <ThumbsUp className="w-4 h-4" />
              {creatingApproval ? 'Creating...' : 'Create Approval Request'}
            </Button>
          </div>

          {approvals.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
              <Clock className="w-8 h-8 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-400 text-sm mb-4">No approval requests yet.</p>
              <Button onClick={handleCreateApproval} disabled={creatingApproval} loading={creatingApproval} className="mx-auto flex items-center gap-2">
                Create First Request
              </Button>
            </div>
          ) : (
            approvals.map(req => (
              <div key={req.id} className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {approvalStatusIcon(req.status)}
                    <span className="font-semibold text-gray-900 text-sm">Request #{req.id}</span>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${approvalStatusBadge(req.status)}`}>
                      {req.status}
                    </span>
                  </div>
                  <span className="text-xs text-gray-400">{formatDate(req.created_at)}</span>
                </div>

                {req.decisions && req.decisions.length > 0 && (
                  <div className="space-y-2 mb-3">
                    {req.decisions.map(d => (
                      <div key={d.id} className="flex items-start gap-2 text-sm bg-gray-50 rounded-lg p-3">
                        {d.decision === 'approved' ? <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 shrink-0" /> : <XCircle className="w-4 h-4 text-red-500 mt-0.5 shrink-0" />}
                        <div>
                          <span className="font-medium text-gray-700 capitalize">{d.decision}</span>
                          {d.comment && <p className="text-gray-500 mt-0.5">{d.comment}</p>}
                          <p className="text-xs text-gray-400 mt-0.5">{formatDate(d.created_at)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {req.status === 'pending' && (
                  <div className="flex items-center gap-2 pt-2 border-t border-gray-50">
                    <Button
                      size="sm"
                      onClick={() => setShowDecisionInput(prev => ({ ...prev, [req.id]: !prev[req.id] }))}
                      variant={showDecisionInput[req.id] ? 'primary' : 'secondary'}
                    >
                      Add Decision
                    </Button>
                    {showDecisionInput[req.id] && (
                      <div className="flex items-center gap-2 flex-1">
                        <input
                          value={decisionComment[req.id] || ''}
                          onChange={e => setDecisionComment(prev => ({ ...prev, [req.id]: e.target.value }))}
                          placeholder="Optional comment..."
                          className="flex-1 rounded-lg border border-gray-200 px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                        />
                        <Button size="sm" onClick={() => handleDecision(req.id, 'approved')} disabled={decisionLoading[req.id]} variant="primary">
                          <ThumbsUp className="w-3.5 h-3.5" /> Approve
                        </Button>
                        <Button size="sm" onClick={() => handleDecision(req.id, 'rejected')} disabled={decisionLoading[req.id]} variant="danger">
                          <ThumbsDown className="w-3.5 h-3.5" /> Reject
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {activeSection === 'comments' && (
        <div className="space-y-4">
          <p className="text-sm text-gray-500">Discuss and review campaign content with your team.</p>

          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <textarea
              value={newComment}
              onChange={e => setNewComment(e.target.value)}
              placeholder="Write a comment..."
              rows={3}
              className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
            />
            <div className="flex justify-end mt-2">
              <Button onClick={handleAddComment} disabled={addingComment || !newComment.trim()} size="sm">
                {addingComment ? 'Posting...' : 'Post Comment'}
              </Button>
            </div>
          </div>

          {rootComments.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
              <MessageSquare className="w-8 h-8 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-400 text-sm">No comments yet. Start the discussion.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {rootComments.map(comment => (
                <div key={comment.id} className={`bg-white rounded-2xl border p-5 shadow-sm transition-colors ${comment.is_resolved ? 'border-green-100 bg-green-50/30' : 'border-gray-100'}`}>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2 text-sm">
                      <span className="font-medium text-gray-900">User #{comment.author_id}</span>
                      <span className="text-xs text-gray-400">{formatDate(comment.created_at)}</span>
                      {comment.is_resolved && <Check className="w-3.5 h-3.5 text-green-500" />}
                    </div>
                    <div className="flex items-center gap-1">
                      <button onClick={() => handleToggleResolve(comment)} className={`p-1.5 rounded-lg transition-colors ${comment.is_resolved ? 'text-green-600 hover:bg-green-50' : 'text-gray-400 hover:bg-gray-50'}`} title={comment.is_resolved ? 'Unresolve' : 'Resolve'}>
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => { setEditingCommentId(comment.id); setEditContent(comment.content) }} className="p-1.5 rounded-lg hover:bg-purple-50 text-gray-400 hover:text-purple-600">
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => handleDeleteComment(comment.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {editingCommentId === comment.id ? (
                    <div className="space-y-2">
                      <textarea
                        value={editContent}
                        onChange={e => setEditContent(e.target.value)}
                        rows={2}
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                      />
                      <div className="flex items-center gap-2">
                        <Button size="sm" onClick={() => handleEditComment(comment.id)} disabled={!editContent.trim()}>Save</Button>
                        <button onClick={() => setEditingCommentId(null)} className="text-xs text-gray-500 hover:text-gray-700">Cancel</button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-700 mb-2">{comment.content}</p>
                  )}

                  <button
                    onClick={() => setReplyToId(replyToId === comment.id ? null : comment.id)}
                    className="text-xs text-purple-600 hover:text-purple-800 flex items-center gap-1"
                  >
                    <Reply className="w-3 h-3" /> Reply
                  </button>

                  {replyToId === comment.id && (
                    <div className="mt-3 flex items-start gap-2">
                      <textarea
                        value={replyContent}
                        onChange={e => setReplyContent(e.target.value)}
                        placeholder="Write a reply..."
                        rows={2}
                        className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                      />
                      <div className="flex flex-col gap-1">
                        <Button size="sm" onClick={() => handleReply(comment.id)} disabled={addingReply[comment.id] || !replyContent.trim()}>
                          {addingReply[comment.id] ? '...' : 'Reply'}
                        </Button>
                        <button onClick={() => { setReplyToId(null); setReplyContent('') }} className="text-xs text-gray-400 hover:text-gray-600">Cancel</button>
                      </div>
                    </div>
                  )}

                  {replies(comment.id).length > 0 && (
                    <div className="mt-3 ml-4 space-y-2 border-l-2 border-gray-100 pl-4">
                      {replies(comment.id).map(reply => (
                        <div key={reply.id} className="text-sm">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-gray-800">User #{reply.author_id}</span>
                              <span className="text-xs text-gray-400">{formatDate(reply.created_at)}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <button onClick={() => handleToggleResolve(reply)} className={`p-1 rounded-lg ${reply.is_resolved ? 'text-green-600' : 'text-gray-400 hover:text-gray-600'}`}>
                                <Check className="w-3 h-3" />
                              </button>
                              <button onClick={() => handleDeleteComment(reply.id)} className="p-1 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500">
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                          <p className="text-gray-600 mt-0.5">{reply.content}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeSection === 'versions' && (
        <div className="space-y-4">
          <p className="text-sm text-gray-500">Track and restore previous versions of campaign posts.</p>

          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <label className="text-sm font-medium text-gray-700 mb-2 block">Post ID</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={postIdForVersion ?? ''}
                onChange={e => {
                  const pid = e.target.value ? parseInt(e.target.value) : null
                  setPostIdForVersion(pid)
                  if (pid) loadVersions(pid)
                }}
                placeholder="Enter post ID to view versions..."
                className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <Button
                size="sm"
                onClick={() => setShowSaveVersion(true)}
                disabled={!postIdForVersion}
                className="flex items-center gap-1"
              >
                <Save className="w-3.5 h-3.5" /> Save Version
              </Button>
            </div>
          </div>

          {versions.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
              <History className="w-8 h-8 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-400 text-sm">No versions saved yet. Enter a post ID and save a version.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {versions.map(ver => (
                <div key={ver.id} className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-purple-50 flex items-center justify-center">
                        <History className="w-4 h-4 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 text-sm">Version {ver.version_number}</h3>
                        <p className="text-xs text-gray-400">{formatDate(ver.created_at)}</p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => handleRestoreVersion(ver.id)}
                      disabled={restoringVersion[ver.id]}
                      className="flex items-center gap-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      {restoringVersion[ver.id] ? 'Restoring...' : 'Restore'}
                    </Button>
                  </div>
                  {ver.change_reason && (
                    <p className="text-sm text-gray-600 mt-2 ml-11">
                      <span className="text-gray-400">Reason:</span> {ver.change_reason}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}

          {showSaveVersion && (
            <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={() => setShowSaveVersion(false)}>
              <div className="fixed inset-0 bg-black/40" />
              <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-md mx-4 p-6" onClick={e => e.stopPropagation()}>
                <h2 className="text-xl font-bold text-gray-900 mb-6">Save Version</h2>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Change Reason</label>
                    <textarea value={changeReason} onChange={e => setChangeReason(e.target.value)} rows={3} placeholder="What changed in this version?" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                  </div>
                  <div className="flex items-center gap-3 pt-4">
                    <Button onClick={handleSaveVersion} disabled={savingVersion}>{savingVersion ? 'Saving...' : 'Save Version'}</Button>
                    <button onClick={() => setShowSaveVersion(false)} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
