import { useState, useRef, useEffect } from 'react'
import {
  Sparkles,
  AlignLeft,
  Briefcase,
  Laugh,
  Palette,
  PenLine,
  MousePointerClick,
  Hash,
  RefreshCw,
  MessageSquarePlus,
  Loader2,
  History,
} from 'lucide-react'
import type { RefinementAction, SupportedTone, CampaignPost } from '@/types/common'
import { ToneSelectionMenu } from './ToneSelectionMenu'

interface PostRefinementMenuProps {
  post: CampaignPost
  isRefining: boolean
  hasRevisions: boolean
  onRefine: (action: RefinementAction, targetTone?: SupportedTone | null, customInstruction?: string | null) => void
  onUndo: () => void
  onShowHistory: () => void
  disabled?: boolean
}

const ACTIONS: { value: RefinementAction; label: string; icon: typeof Sparkles }[] = [
  { value: 'regenerate_caption', label: 'Regenerate caption', icon: RefreshCw },
  { value: 'shorten_caption', label: 'Shorten caption', icon: AlignLeft },
  { value: 'make_professional', label: 'Make more professional', icon: Briefcase },
  { value: 'make_funnier', label: 'Make funnier', icon: Laugh },
  { value: 'change_tone', label: 'Change tone', icon: Palette },
  { value: 'improve_hook', label: 'Improve hook', icon: PenLine },
  { value: 'rewrite_cta', label: 'Rewrite CTA', icon: MousePointerClick },
  { value: 'regenerate_hashtags', label: 'Regenerate hashtags', icon: Hash },
  { value: 'regenerate_complete_post', label: 'Regenerate complete post', icon: Sparkles },
]

export function PostRefinementMenu({
  isRefining,
  hasRevisions,
  onRefine,
  onUndo,
  onShowHistory,
  disabled,
}: PostRefinementMenuProps) {
  const [open, setOpen] = useState(false)
  const [showToneSubmenu, setShowToneSubmenu] = useState(false)
  const [showCustomInput, setShowCustomInput] = useState(false)
  const [customText, setCustomText] = useState('')
  const menuRef = useRef<HTMLDivElement>(null)
  const buttonRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (!open) {
      setShowToneSubmenu(false)
      setShowCustomInput(false)
      setCustomText('')
    }
  }, [open])

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    if (open) {
      document.addEventListener('mousedown', handleClickOutside)
    }
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [open])

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      setShowToneSubmenu(false)
      if (!showToneSubmenu) {
        setOpen(false)
        buttonRef.current?.focus()
      }
    }
  }

  const handleAction = (action: RefinementAction) => {
    if (action === 'change_tone') {
      setShowToneSubmenu(true)
      return
    }
    setOpen(false)
    onRefine(action)
  }

  const handleToneSelect = (tone: SupportedTone) => {
    setOpen(false)
    setShowToneSubmenu(false)
    onRefine('change_tone', tone)
  }

  const handleCustomSubmit = () => {
    if (!customText.trim()) return
    setOpen(false)
    setShowCustomInput(false)
    onRefine('custom', null, customText.trim())
    setCustomText('')
  }

  if (disabled) return null

  return (
    <div ref={menuRef} className="relative" onKeyDown={handleKeyDown}>
      <button
        ref={buttonRef}
        onClick={() => setOpen(!open)}
        disabled={isRefining}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-purple-200 text-purple-700 bg-purple-50 hover:bg-purple-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isRefining ? (
          <Loader2 className="w-3.5 h-3.5 animate-spin" />
        ) : (
          <Sparkles className="w-3.5 h-3.5" />
        )}
        {isRefining ? 'Refining...' : 'Refine'}
      </button>

      {open && !showToneSubmenu && !showCustomInput && (
        <div className="absolute right-0 top-full mt-1 bg-white border border-purple-100 rounded-xl shadow-xl z-50 w-56 py-1 max-h-96 overflow-y-auto">
          {ACTIONS.map((action) => {
            const Icon = action.icon
            return (
              <button
                key={action.value}
                onClick={() => handleAction(action.value)}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-700 hover:bg-purple-50 hover:text-purple-700 transition-colors"
              >
                <Icon className="w-4 h-4 text-gray-400" />
                <span>{action.label}</span>
              </button>
            )
          })}

          <div className="border-t border-gray-100 my-1" />

          <button
            onClick={() => setShowCustomInput(true)}
            className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-700 hover:bg-purple-50 hover:text-purple-700 transition-colors"
          >
            <MessageSquarePlus className="w-4 h-4 text-gray-400" />
            <span>Custom instruction</span>
          </button>

          {hasRevisions && (
            <>
              <div className="border-t border-gray-100 my-1" />
              <button
                onClick={() => { setOpen(false); onUndo(); }}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-700 hover:bg-purple-50 hover:text-purple-700 transition-colors"
              >
                <History className="w-4 h-4 text-gray-400" />
                <span>Undo last change</span>
              </button>
              <button
                onClick={() => { setOpen(false); onShowHistory(); }}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-700 hover:bg-purple-50 hover:text-purple-700 transition-colors"
              >
                <History className="w-4 h-4 text-gray-400" />
                <span>Version history</span>
              </button>
            </>
          )}
        </div>
      )}

      {showToneSubmenu && (
        <ToneSelectionMenu
          onSelect={handleToneSelect}
          onClose={() => setShowToneSubmenu(false)}
        />
      )}

      {showCustomInput && (
        <div className="absolute right-0 top-full mt-1 bg-white border border-purple-100 rounded-xl shadow-xl z-50 w-72 p-3">
          <label className="block text-xs font-medium text-gray-600 mb-1.5">
            Custom instruction
          </label>
          <textarea
            value={customText}
            onChange={(e) => setCustomText(e.target.value.slice(0, 500))}
            placeholder="Make this more engaging for university students without changing the product facts."
            className="w-full text-sm border border-gray-200 rounded-lg p-2 resize-none h-20 focus:outline-none focus:ring-2 focus:ring-purple-300"
            maxLength={500}
          />
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs text-gray-400">{customText.length}/500</span>
            <div className="flex gap-2">
              <button
                onClick={() => setShowCustomInput(false)}
                className="px-3 py-1 text-xs text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleCustomSubmit}
                disabled={!customText.trim()}
                className="px-3 py-1 text-xs font-medium text-white bg-purple-600 rounded-lg hover:bg-purple-700 disabled:opacity-50"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
