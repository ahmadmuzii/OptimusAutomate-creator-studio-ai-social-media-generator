from __future__ import annotations


class TestGuardrailsAPI:
    """Test Brand Guardrail CRUD endpoints."""

    def test_get_guardrails_creates_default(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.get(f"/api/v1/brands/{brand_id}/guardrails", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["brand_id"] == brand_id
        assert data["required_phrases"] == []
        assert data["forbidden_words"] == []
        assert data["competitors_never_mention"] == []

    def test_update_guardrails(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "required_phrases": ["ethically sourced", "sustainable"],
            "forbidden_words": ["cheap", "poor quality"],
            "competitors_never_mention": ["CompetitorX", "CompetitorY"],
            "emoji_allowance": "moderate",
            "max_hashtag_count": 8,
            "required_legal_disclaimer": "*Results may vary.",
        }
        response = client.put(f"/api/v1/brands/{brand_id}/guardrails", json=payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["required_phrases"] == ["ethically sourced", "sustainable"]
        assert data["forbidden_words"] == ["cheap", "poor quality"]
        assert data["emoji_allowance"] == "moderate"
        assert data["max_hashtag_count"] == 8
        assert data["required_legal_disclaimer"] == "*Results may vary."

    def test_update_guardrails_partial(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {"emoji_allowance": "none"}
        response = client.put(f"/api/v1/brands/{brand_id}/guardrails", json=payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["emoji_allowance"] == "none"
        assert data["required_phrases"] == []

    def test_reset_guardrails(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        client.put(f"/api/v1/brands/{brand_id}/guardrails", json={"emoji_allowance": "liberal"}, headers=auth_headers)
        response = client.delete(f"/api/v1/brands/{brand_id}/guardrails", headers=auth_headers)
        assert response.status_code == 200
        get_resp = client.get(f"/api/v1/brands/{brand_id}/guardrails", headers=auth_headers)
        assert get_resp.status_code == 200
        data = get_resp.json()
        assert data["emoji_allowance"] is None

    def test_cannot_access_other_users_guardrails(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.get(f"/api/v1/brands/{brand_id}/guardrails", headers=second_auth_headers)
        assert response.status_code == 404

    def test_field_isolation(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "required_phrases": ["Brewline Coffee Co."],
            "forbidden_words": ["cheap"],
            "competitors_never_mention": ["Starbucks"],
            "preferred_capitalizations": ["CreatorStudio"],
            "product_names": ["Brewline Signature Roast"],
            "service_names": ["Brewline Rewards"],
        }
        response = client.put(f"/api/v1/brands/{brand_id}/guardrails", json=payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["required_phrases"] == ["Brewline Coffee Co."]
        assert data["forbidden_words"] == ["cheap"]
        assert data["competitors_never_mention"] == ["Starbucks"]
        assert data["preferred_capitalizations"] == ["CreatorStudio"]
        assert data["product_names"] == ["Brewline Signature Roast"]
        assert data["service_names"] == ["Brewline Rewards"]

        update = {"forbidden_words": ["awful"]}
        response2 = client.put(f"/api/v1/brands/{brand_id}/guardrails", json=update, headers=auth_headers)
        assert response2.status_code == 200
        data2 = response2.json()
        assert data2["forbidden_words"] == ["awful"]
        assert data2["required_phrases"] == ["Brewline Coffee Co."]
        assert data2["competitors_never_mention"] == ["Starbucks"]
        assert data2["product_names"] == ["Brewline Signature Roast"]
        assert data2["service_names"] == ["Brewline Rewards"]

    def test_brand_check_no_guardrails(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.post(f"/api/v1/brands/{brand_id}/guardrails/check", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "passed"
        assert data["summary"]["passed"] > 0

    def test_brand_check_blocked_forbidden_word(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        client.put(f"/api/v1/brands/{brand_id}/guardrails", json={"forbidden_words": ["cheap"]}, headers=auth_headers)
        response = client.post(f"/api/v1/brands/{brand_id}/guardrails/check", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "passed"
        assert data["summary"]["blocked"] == 0


class TestBrandCheckService:
    """Test Brand Check Service directly."""

    def test_brand_check_forbidden_word_detection(self, db_session):
        from app.models.db_models import BrandGuardrail, BrandProfile, User
        from app.services.brand_check_service import BrandCheckService

        user = User(email="check@test.com", password_hash="hash", name="Check User")
        db_session.add(user)
        db_session.flush()

        brand = BrandProfile(user_id=user.id, name="CheckBrand", niche="tech")
        db_session.add(brand)
        db_session.flush()

        guardrail = BrandGuardrail(brand_id=brand.id, forbidden_words=["cheap", "poor"])
        db_session.add(guardrail)
        db_session.commit()

        service = BrandCheckService()
        result = service.check_guardrails(
            brand,
            guardrail,
            [
                {"caption": "This is a cheap product", "callToAction": "Buy now", "day": 1},
            ],
        )

        assert result.status == "blocked"
        assert result.summary.blocked >= 1
        blocked = [c for c in result.checks if c.status == "blocked"]
        assert any("cheap" in c.message.lower() for c in blocked)

    def test_brand_check_required_phrase_missing(self, db_session):
        from app.models.db_models import BrandGuardrail, BrandProfile, User
        from app.services.brand_check_service import BrandCheckService

        user = User(email="phrase@test.com", password_hash="hash", name="Phrase User")
        db_session.add(user)
        db_session.flush()

        brand = BrandProfile(user_id=user.id, name="PhraseBrand", niche="eco")
        db_session.add(brand)
        db_session.flush()

        guardrail = BrandGuardrail(brand_id=brand.id, required_phrases=["eco-friendly", "sustainable"])
        db_session.add(guardrail)
        db_session.commit()

        service = BrandCheckService()
        result = service.check_guardrails(
            brand,
            guardrail,
            [
                {"caption": "Great product for you", "callToAction": "Shop now", "day": 1},
            ],
        )

        warnings = [c for c in result.checks if c.status == "warning"]
        assert any("eco-friendly" in c.message for c in warnings)

    def test_brand_check_competitor_detection(self, db_session):
        from app.models.db_models import BrandGuardrail, BrandProfile, User
        from app.services.brand_check_service import BrandCheckService

        user = User(email="comp@test.com", password_hash="hash", name="Comp User")
        db_session.add(user)
        db_session.flush()

        brand = BrandProfile(user_id=user.id, name="CompBrand", niche="soda")
        db_session.add(brand)
        db_session.flush()

        guardrail = BrandGuardrail(brand_id=brand.id, competitors_never_mention=["CocaCola", "Pepsi"])
        db_session.add(guardrail)
        db_session.commit()

        service = BrandCheckService()
        result = service.check_guardrails(
            brand,
            guardrail,
            [
                {"caption": "Better than CocaCola", "callToAction": "Try now", "day": 1},
            ],
        )

        blocked = [c for c in result.checks if c.status == "blocked"]
        assert any("CocaCola" in c.message for c in blocked)

    def test_brand_check_legal_disclaimer_missing(self, db_session):
        from app.models.db_models import BrandGuardrail, BrandProfile, User
        from app.services.brand_check_service import BrandCheckService

        user = User(email="legal@test.com", password_hash="hash", name="Legal User")
        db_session.add(user)
        db_session.flush()

        brand = BrandProfile(user_id=user.id, name="LegalBrand", niche="health")
        db_session.add(brand)
        db_session.flush()

        guardrail = BrandGuardrail(brand_id=brand.id, required_legal_disclaimer="*Consult your doctor.")
        db_session.add(guardrail)
        db_session.commit()

        service = BrandCheckService()
        result = service.check_guardrails(
            brand,
            guardrail,
            [
                {"caption": "Our product is great for health", "callToAction": "Buy now", "day": 1},
            ],
        )

        blocked = [c for c in result.checks if c.status == "blocked"]
        assert any("legal disclaimer" in c.message.lower() for c in blocked)

    def test_brand_check_hashtag_limit(self, db_session):
        from app.models.db_models import BrandGuardrail, BrandProfile, User
        from app.services.brand_check_service import BrandCheckService

        user = User(email="hash@test.com", password_hash="hash", name="Hash User")
        db_session.add(user)
        db_session.flush()

        brand = BrandProfile(user_id=user.id, name="HashBrand", niche="fashion")
        db_session.add(brand)
        db_session.flush()

        guardrail = BrandGuardrail(brand_id=brand.id, max_hashtag_count=3)
        db_session.add(guardrail)
        db_session.commit()

        service = BrandCheckService()
        result = service.check_guardrails(
            brand,
            guardrail,
            [
                {
                    "caption": "Nice outfit",
                    "callToAction": "Shop",
                    "hashtags": ["#a", "#b", "#c", "#d", "#e"],
                    "day": 1,
                },
            ],
        )

        warnings = [c for c in result.checks if c.status == "warning"]
        assert any("hashtag" in c.code.lower() for c in warnings)
