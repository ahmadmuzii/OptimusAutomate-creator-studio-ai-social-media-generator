import { useEffect, useRef, useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, Wand2, Calendar, FileText, Building2, Clock, User, Settings, LogOut, Menu, Sparkles, Lock,
} from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useGuestMode } from '@/context/GuestModeContext'
import { useAuthGate } from '@/hooks/useAuthGate'
import { AuthModal } from '@/components/common/AuthModal'
import { ROUTES } from '@/routes/paths'

const navItems = [
  { to: ROUTES.dashboardHome, label: 'Dashboard', icon: LayoutDashboard, guestAccessible: true },
  { to: ROUTES.generate, label: 'Generate', icon: Wand2, guestAccessible: false },
  { to: ROUTES.calendar, label: 'Calendar', icon: Calendar, guestAccessible: true },
  { to: ROUTES.captions, label: 'Captions', icon: FileText, guestAccessible: true },
  { to: ROUTES.brands, label: 'Brands', icon: Building2, guestAccessible: false },
  { to: ROUTES.history, label: 'History', icon: Clock, guestAccessible: false },
  { to: ROUTES.profile, label: 'Profile', icon: User, guestAccessible: false },
  { to: ROUTES.settings, label: 'Settings', icon: Settings, guestAccessible: false },
]

export function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { user, isAuthenticated, logout } = useAuth()
  const { isGuestMode, exitGuestMode } = useGuestMode()
  const { showAuthModal, authModalRedirect, openAuthModal, closeAuthModal } = useAuthGate()
  const navigate = useNavigate()
  const sidebarRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && sidebarOpen) {
        setSidebarOpen(false)
      }
    }
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [sidebarOpen])

  useEffect(() => {
    if (sidebarOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => { document.body.style.overflow = '' }
  }, [sidebarOpen])

  const handleLogout = () => {
    exitGuestMode()
    logout()
    navigate(ROUTES.home)
  }

  const handleNavClick = () => {
    setSidebarOpen(false)
  }

  const handleProtectedNav = (to: string) => {
    setSidebarOpen(false)
    openAuthModal(to)
  }

  const isDemo = isGuestMode && !isAuthenticated

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 transition-opacity duration-200 lg:hidden"
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={closeAuthModal}
        redirectTo={authModalRedirect}
      />

      {/* Sidebar */}
      <aside
        ref={sidebarRef}
        className={`
          fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-gray-200 bg-white
          transition-transform duration-300 ease-in-out
          lg:translate-x-0
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        {/* Logo */}
        <div className="flex h-16 shrink-0 items-center gap-3 border-b border-gray-100 px-6">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-purple-600 to-purple-900">
            <Sparkles className="h-4 w-4 text-white" />
          </div>
          <span className="text-sm font-bold text-gray-900">Creator Studio</span>
          {isDemo && (
            <span className="ml-auto text-[10px] font-semibold text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full">
              Demo
            </span>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
          {navItems.map((item) => {
            const isLocked = isDemo && !item.guestAccessible
            if (isLocked) {
              return (
                <button
                  key={item.to}
                  onClick={() => handleProtectedNav(item.to)}
                  className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-gray-400 transition-all duration-200 hover:bg-gray-50"
                  title="Sign in required"
                >
                  <item.icon className="h-4 w-4" />
                  <span className="flex-1 text-left">{item.label}</span>
                  <Lock className="h-3 w-3 text-gray-300" />
                </button>
              )
            }
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={handleNavClick}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-purple-50 text-purple-700 shadow-sm'
                      : 'text-gray-600 hover:translate-x-0.5 hover:bg-gray-50 hover:text-gray-900'
                  }`
                }
              >
                <item.icon className="h-4 w-4 transition-colors duration-200" />
                {item.label}
              </NavLink>
            )
          })}
        </nav>

        {/* Account */}
        <div className="shrink-0 border-t border-gray-100 p-4">
          {isDemo ? (
            <div className="mb-3">
              <div className="flex items-center gap-3 mb-2">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-purple-400 to-purple-600 text-xs font-bold text-white">
                  G
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-gray-900">Guest</p>
                  <p className="truncate text-xs text-gray-400">Preview mode</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="mb-3 flex items-center gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-purple-700 text-xs font-bold text-white">
                {user?.name?.charAt(0)?.toUpperCase() || 'U'}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-gray-900">{user?.name || 'User'}</p>
                <p className="truncate text-xs text-gray-500">{user?.email}</p>
              </div>
            </div>
          )}
          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm text-gray-600 transition-all duration-200 hover:bg-red-50 hover:text-red-600"
          >
            <LogOut className="h-4 w-4" />
            {isDemo ? 'Leave preview' : 'Sign out'}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="min-h-screen overflow-x-hidden lg:ml-64">
        {/* Mobile top bar with hamburger */}
        <div className="sticky top-0 z-30 flex h-16 items-center border-b border-gray-200 bg-white px-4 lg:hidden">
          <button
            onClick={() => setSidebarOpen(true)}
            className="rounded-lg p-2 text-gray-600 hover:bg-gray-100"
            aria-label="Open sidebar"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="ml-3 flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-md bg-gradient-to-br from-purple-600 to-purple-900">
              <Sparkles className="h-3.5 w-3.5 text-white" />
            </div>
            <span className="text-sm font-bold text-gray-900">Creator Studio</span>
            {isDemo && (
              <span className="text-[10px] font-semibold text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full">
                Demo
              </span>
            )}
          </div>
        </div>

        {/* Demo banner */}
        {isDemo && (
          <div className="bg-gradient-to-r from-purple-600 to-purple-900 px-4 py-2 text-center text-xs font-medium text-white">
            Preview data &mdash; <button onClick={() => navigate('/login')} className="underline hover:no-underline">Sign in</button> to save your work and access all features.
          </div>
        )}

        {/* Page content */}
        <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
