import { Calendar } from 'lucide-react'
import { motion } from 'framer-motion'
import type { CalendarCardData } from '@/types/calendar'
import { pluralize } from '@/utils/formatters'
import { CalendarCard } from './CalendarCard'

interface CalendarCardsProps {
  data: CalendarCardData[]
}

export function CalendarCards({ data }: CalendarCardsProps) {
  if (!data?.length) return null

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
            <Calendar className="w-4 h-4 text-purple-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900">7-Day Content Calendar</h2>
        </div>
        <span className="text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
          {data.length} {pluralize(data.length, 'day')} planned
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {data.map((day, index) => (
          <motion.div
            key={day.day}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1, duration: 0.4 }}
          >
            <CalendarCard {...day} />
          </motion.div>
        ))}
      </div>
    </div>
  )
}
