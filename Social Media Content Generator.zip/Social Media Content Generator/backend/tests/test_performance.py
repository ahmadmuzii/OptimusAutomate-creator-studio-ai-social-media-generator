from __future__ import annotations


class TestPerformanceAPI:
    """Test performance data import, records, summary, and insights endpoints."""

    def _import_rows(self, client, auth_headers, brand_id, rows):
        response = client.post(
            f"/api/v1/brands/{brand_id}/performance/import",
            json={"rows": rows},
            headers=auth_headers,
        )
        assert response.status_code == 200
        return response.json()

    def test_import_performance_data(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        payload = {
            "rows": [
                {
                    "platform": "instagram",
                    "content_type": "carousel",
                    "impressions": 1000,
                    "likes": 100,
                    "comments": 20,
                    "saves": 50,
                    "shares": 30,
                },
                {
                    "platform": "instagram",
                    "content_type": "static_post",
                    "impressions": 500,
                    "likes": 50,
                    "comments": 10,
                    "saves": 20,
                    "shares": 15,
                },
            ]
        }
        response = client.post(
            f"/api/v1/brands/{brand_id}/performance/import",
            json=payload,
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["valid_rows"] == 2

    def test_list_import_batches(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        rows = [
            {"platform": "instagram", "content_type": "carousel", "impressions": 100, "likes": 10},
            {"platform": "instagram", "content_type": "static_post", "impressions": 200, "likes": 20},
        ]
        self._import_rows(client, auth_headers, brand_id, rows)

        response = client.get(
            f"/api/v1/brands/{brand_id}/performance/imports",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["total_rows"] == 2
        assert data[0]["valid_rows"] == 2

    def test_list_performance_records(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        rows = [
            {
                "platform": "instagram",
                "content_type": "carousel",
                "impressions": 1000,
                "likes": 100,
                "comments": 20,
                "saves": 50,
                "shares": 30,
            },
            {
                "platform": "instagram",
                "content_type": "static_post",
                "impressions": 500,
                "likes": 50,
                "comments": 10,
                "saves": 20,
                "shares": 15,
            },
        ]
        self._import_rows(client, auth_headers, brand_id, rows)

        response = client.get(
            f"/api/v1/brands/{brand_id}/performance/records",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2
        assert data[0]["platform"] == "instagram"

    def test_get_performance_summary(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        rows = [
            {
                "platform": "instagram",
                "content_type": "carousel",
                "impressions": 1000,
                "likes": 100,
                "comments": 20,
                "saves": 50,
                "shares": 30,
            },
            {
                "platform": "instagram",
                "content_type": "static_post",
                "impressions": 500,
                "likes": 50,
                "comments": 10,
                "saves": 20,
                "shares": 15,
            },
        ]
        self._import_rows(client, auth_headers, brand_id, rows)

        response = client.get(
            f"/api/v1/brands/{brand_id}/performance/summary",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["total_posts"] == 2
        assert data["avg_impressions"] > 0
        assert data["avg_engagement_rate"] > 0

    def test_generate_insights(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        rows = [
            {
                "platform": "instagram",
                "content_type": "carousel",
                "impressions": 1000,
                "likes": 100,
                "comments": 20,
                "saves": 50,
                "shares": 30,
            },
            {
                "platform": "instagram",
                "content_type": "carousel",
                "impressions": 800,
                "likes": 80,
                "comments": 15,
                "saves": 40,
                "shares": 25,
            },
            {
                "platform": "instagram",
                "content_type": "carousel",
                "impressions": 600,
                "likes": 60,
                "comments": 10,
                "saves": 30,
                "shares": 20,
            },
        ]
        self._import_rows(client, auth_headers, brand_id, rows)

        response = client.post(
            f"/api/v1/brands/{brand_id}/performance/insights/generate",
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert response.json()["insights_generated"] > 0

    def test_list_insights(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        rows = [
            {
                "platform": "instagram",
                "content_type": "carousel",
                "impressions": 1000,
                "likes": 100,
                "comments": 20,
                "saves": 50,
                "shares": 30,
            },
            {
                "platform": "instagram",
                "content_type": "carousel",
                "impressions": 800,
                "likes": 80,
                "comments": 15,
                "saves": 40,
                "shares": 25,
            },
            {
                "platform": "instagram",
                "content_type": "carousel",
                "impressions": 600,
                "likes": 60,
                "comments": 10,
                "saves": 30,
                "shares": 20,
            },
        ]
        self._import_rows(client, auth_headers, brand_id, rows)
        client.post(
            f"/api/v1/brands/{brand_id}/performance/insights/generate",
            headers=auth_headers,
        )

        response = client.get(
            f"/api/v1/brands/{brand_id}/performance/insights",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data) > 0
        assert data[0]["pattern_type"] in ("best_content_type", "best_platform")

    def test_update_insight(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        rows = [
            {
                "platform": "instagram",
                "content_type": "carousel",
                "impressions": 1000,
                "likes": 100,
                "comments": 20,
                "saves": 50,
                "shares": 30,
            },
            {
                "platform": "instagram",
                "content_type": "carousel",
                "impressions": 800,
                "likes": 80,
                "comments": 15,
                "saves": 40,
                "shares": 25,
            },
            {
                "platform": "instagram",
                "content_type": "carousel",
                "impressions": 600,
                "likes": 60,
                "comments": 10,
                "saves": 30,
                "shares": 20,
            },
        ]
        self._import_rows(client, auth_headers, brand_id, rows)
        client.post(
            f"/api/v1/brands/{brand_id}/performance/insights/generate",
            headers=auth_headers,
        )
        insights = client.get(
            f"/api/v1/brands/{brand_id}/performance/insights",
            headers=auth_headers,
        ).json()
        insight_id = insights[0]["id"]

        response = client.patch(
            f"/api/v1/brands/{brand_id}/performance/insights/{insight_id}",
            json={"is_accepted": True},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["is_accepted"] is True

    def test_cannot_access_other_users_performance(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        rows = [
            {"platform": "instagram", "content_type": "carousel", "impressions": 100, "likes": 10},
        ]
        self._import_rows(client, auth_headers, brand_id, rows)

        for endpoint in ("records", "summary", "imports", "insights"):
            response = client.get(
                f"/api/v1/brands/{brand_id}/performance/{endpoint}",
                headers=second_auth_headers,
            )
            assert response.status_code == 404, f"{endpoint} should be 404 for other user"
