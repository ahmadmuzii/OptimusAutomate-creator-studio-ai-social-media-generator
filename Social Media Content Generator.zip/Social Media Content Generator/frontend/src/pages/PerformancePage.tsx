import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'
import { ArrowLeft, BarChart3, Upload, Database, Lightbulb, Plus } from 'lucide-react'
import * as api from '@/api/endpoints'
import type { PerformanceSummary, PerformanceRecord, PerformanceInsight, ImportBatch } from '@/types/performance'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'

type Tab = 'summary' | 'import' | 'records' | 'insights'

const STATUS_COLORS: Record<string, string> = {
  completed: 'bg-green-100 text-green-700',
  processing: 'bg-yellow-100 text-yellow-700',
  failed: 'bg-red-100 text-red-700',
  pending: 'bg-gray-100 text-gray-700',
}

const TABS: { key: Tab; label: string; icon: typeof BarChart3 }[] = [
  { key: 'summary', label: 'Summary', icon: BarChart3 },
  { key: 'import', label: 'Import', icon: Upload },
  { key: 'records', label: 'Records', icon: Database },
  { key: 'insights', label: 'Insights', icon: Lightbulb },
]

export function PerformancePage() {
  const { brandId, brand } = useBrandWorkspace()

  const [loading, setLoading] = useState(true)

  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<Tab>('summary')

  const [summary, setSummary] = useState<PerformanceSummary | null>(null)
  const [records, setRecords] = useState<PerformanceRecord[]>([])
  const [insights, setInsights] = useState<PerformanceInsight[]>([])
  const [batches, setBatches] = useState<ImportBatch[]>([])

  // Import form
  const [csvText, setCsvText] = useState('')
  const [importing, setImporting] = useState(false)

  // Individual record form
  const [recordForm, setRecordForm] = useState<Record<string, string>>({ platform: '', content_type: '', impressions: '', likes: '', comments: '', shares: '' })
  const [addingRecord, setAddingRecord] = useState(false)

  const loadAll = useCallback(async () => {
  }, [])

  const loadSummary = useCallback(async () => {
    try {
      const data = await api.getPerformanceSummary(brandId)
      setSummary(data as PerformanceSummary)
    } catch { /* ignore */ }
  }, [brandId])

  const loadRecords = useCallback(async () => {
    try {
      const data = await api.fetchPerformanceRecords(brandId)
      setRecords(data as PerformanceRecord[])
    } catch { /* ignore */ }
  }, [brandId])

  const loadInsights = useCallback(async () => {
    try {
      const data = await api.fetchPerformanceInsights(brandId)
      setInsights(data as PerformanceInsight[])
    } catch { /* ignore */ }
  }, [brandId])

  const loadBatches = useCallback(async () => {
    try {
      const data = await api.fetchImportBatches(brandId)
      setBatches(data as ImportBatch[])
    } catch { /* ignore */ }
  }, [brandId])

  useEffect(() => {
    loadAll().catch(() => setError('Could not load.')).finally(() => setLoading(false))
  }, [brandId, loadAll])

  useEffect(() => { if (activeTab === 'summary') loadSummary() }, [activeTab, loadSummary])
  useEffect(() => { if (activeTab === 'records') loadRecords() }, [activeTab, loadRecords])
  useEffect(() => { if (activeTab === 'insights') loadInsights() }, [activeTab, loadInsights])
  useEffect(() => { if (activeTab === 'import') loadBatches() }, [activeTab, loadBatches])

  const handleImportCsv = async () => {
    if (!csvText.trim()) return
    setImporting(true)
    try {
      const lines = csvText.trim().split('\n')
      if (lines.length < 2) { setImporting(false); return }
      const headerLine = lines[0]!
      const headers = headerLine.split(',').map(h => h.trim())
      const rows = lines.slice(1).map(line => {
        const vals = line.split(',').map(v => v.trim())
        const row: Record<string, unknown> = {}
        headers.forEach((h, i) => {
          const num = Number(vals[i])
          row[h] = isNaN(num) ? (vals[i] || null) : num
        })
        return row
      })
      await api.importPerformanceData(brandId, { rows } as Record<string, unknown>)
      setCsvText('')
      await loadBatches()
    } catch { setError('Import failed.') }
    finally { setImporting(false) }
  }

  const handleAddRecord = async () => {
    setAddingRecord(true)
    try {
      const row: Record<string, unknown> = {}
      Object.entries(recordForm).forEach(([k, v]) => {
        const num = Number(v)
        row[k] = v ? (isNaN(num) ? v : num) : null
      })
      await api.importPerformanceData(brandId, { rows: [row] } as Record<string, unknown>)
      setRecordForm({ platform: '', content_type: '', impressions: '', likes: '', comments: '', shares: '' })
      await loadBatches()
    } catch { setError('Failed to add record.') }
    finally { setAddingRecord(false) }
  }

  const toggleInsight = async (insight: PerformanceInsight, field: 'is_accepted' | 'is_archived' | 'affect_future_generation') => {
    try {
      const payload = { [field]: !insight[field] }
      await api.updatePerformanceInsight(brandId, insight.id, payload)
      setInsights(prev => prev.map(i => i.id === insight.id ? { ...i, ...payload } as PerformanceInsight : i))
    } catch { setError('Failed to update insight.') }
  }

  const handleGenerateInsights = async () => {
    try {
      await api.generatePerformanceInsights(brandId)
      await loadInsights()
    } catch { setError('Failed to generate insights.') }
  }

  const formatNumber = (n: number | null | undefined) => {
    if (n == null) return '-'
    return n.toLocaleString()
  }

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600" /></div>
  }

  return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center gap-3">
        <BarChart3 className="w-6 h-6 text-purple-600" />
        <h1 className="text-2xl font-bold text-gray-900">Performance</h1>
      </div>

      {error && <div className="p-4 bg-red-50 text-sm text-red-600 rounded-lg">{error}</div>}

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-50 rounded-xl p-1">
        {TABS.map(tab => {
          const Icon = tab.icon
          return (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${activeTab === tab.key ? 'bg-white text-purple-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}>
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          )
        })}
      </div>

      {/* Summary Tab */}
      {activeTab === 'summary' && (
        summary ? (
          <div className="space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                <p className="text-xs text-gray-400 font-medium uppercase tracking-wider">Total Posts</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{formatNumber(summary.total_posts)}</p>
              </div>
              <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                <p className="text-xs text-gray-400 font-medium uppercase tracking-wider">Avg Impressions</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{formatNumber(summary.avg_impressions)}</p>
              </div>
              <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                <p className="text-xs text-gray-400 font-medium uppercase tracking-wider">Avg Engagement Rate</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{summary.avg_engagement_rate != null ? `${(summary.avg_engagement_rate * 100).toFixed(2)}%` : '-'}</p>
              </div>
              <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                <p className="text-xs text-gray-400 font-medium uppercase tracking-wider">Best Platform</p>
                <p className="text-2xl font-bold text-gray-900 mt-1 capitalize">{summary.best_platform || '-'}</p>
              </div>
              <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                <p className="text-xs text-gray-400 font-medium uppercase tracking-wider">Best Content Type</p>
                <p className="text-2xl font-bold text-gray-900 mt-1 capitalize">{summary.best_content_type?.replace(/_/g, ' ') || '-'}</p>
              </div>
            </div>

            {summary.top_performers && summary.top_performers.length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                <h3 className="font-semibold text-gray-900 mb-3">Top Performers</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-left text-gray-400 border-b border-gray-50">
                        <th className="pb-2 font-medium">Platform</th>
                        <th className="pb-2 font-medium">Type</th>
                        <th className="pb-2 font-medium text-right">Impressions</th>
                        <th className="pb-2 font-medium text-right">Engagement Rate</th>
                      </tr>
                    </thead>
                    <tbody>
                      {summary.top_performers.slice(0, 5).map((r, i) => (
                        <tr key={i} className="border-b border-gray-50 last:border-0">
                          <td className="py-2 capitalize">{r.platform || '-'}</td>
                          <td className="py-2 capitalize">{r.content_type?.replace(/_/g, ' ') || '-'}</td>
                          <td className="py-2 text-right">{formatNumber(r.impressions)}</td>
                          <td className="py-2 text-right">{r.engagement_rate != null ? `${(r.engagement_rate * 100).toFixed(2)}%` : '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {summary.insights && summary.insights.length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                <h3 className="font-semibold text-gray-900 mb-3">Summary Insights</h3>
                <ul className="space-y-2">
                  {summary.insights.map((ins, i) => (
                    <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                      <span className="text-purple-500 mt-0.5">•</span>
                      {ins}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
            <BarChart3 className="w-8 h-8 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-400 text-sm">No performance data yet. Import data to see your summary.</p>
          </div>
        )
      )}

      {/* Import Tab */}
      {activeTab === 'import' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-3">Import CSV Data</h3>
            <p className="text-xs text-gray-400 mb-3">Paste CSV data with headers: platform, content_type, impressions, likes, comments, shares, etc.</p>
            <textarea value={csvText} onChange={e => setCsvText(e.target.value)} rows={6} placeholder={`platform,content_type,impressions,likes,comments,shares\ninstagram,carousel,1200,45,12,8\ntiktok,video,3400,120,34,15`} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono" />
            <div className="mt-3">
              <Button onClick={handleImportCsv} disabled={!csvText.trim() || importing} className="flex items-center gap-2">
                <Upload className="w-4 h-4" /> {importing ? 'Importing...' : 'Import CSV'}
              </Button>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-3">Add Individual Record</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <input value={recordForm.platform} onChange={e => setRecordForm(prev => ({ ...prev, platform: e.target.value }))} placeholder="Platform" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              <input value={recordForm.content_type} onChange={e => setRecordForm(prev => ({ ...prev, content_type: e.target.value }))} placeholder="Content type" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              <input type="number" value={recordForm.impressions} onChange={e => setRecordForm(prev => ({ ...prev, impressions: e.target.value }))} placeholder="Impressions" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              <input type="number" value={recordForm.likes} onChange={e => setRecordForm(prev => ({ ...prev, likes: e.target.value }))} placeholder="Likes" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              <input type="number" value={recordForm.comments} onChange={e => setRecordForm(prev => ({ ...prev, comments: e.target.value }))} placeholder="Comments" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              <input type="number" value={recordForm.shares} onChange={e => setRecordForm(prev => ({ ...prev, shares: e.target.value }))} placeholder="Shares" className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
            </div>
            <div className="mt-3">
              <Button onClick={handleAddRecord} disabled={addingRecord} className="flex items-center gap-2">
                <Plus className="w-4 h-4" /> {addingRecord ? 'Adding...' : 'Add Record'}
              </Button>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-3">Import History</h3>
            {batches.length === 0 ? (
              <p className="text-sm text-gray-400">No imports yet.</p>
            ) : (
              <div className="space-y-2">
                {batches.map(batch => (
                  <div key={batch.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full capitalize ${STATUS_COLORS[batch.status] || 'bg-gray-100 text-gray-700'}`}>{batch.status}</span>
                      <span className="text-sm text-gray-700">{batch.filename || `Batch #${batch.id}`}</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                      <span>{batch.total_rows} rows</span>
                      <span className="text-green-600">{batch.valid_rows} valid</span>
                      {batch.invalid_rows > 0 && <span className="text-red-500">{batch.invalid_rows} invalid</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Records Tab */}
      {activeTab === 'records' && (
        records.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
            <Database className="w-8 h-8 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-400 text-sm">No performance records yet.</p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-gray-400 border-b border-gray-50 bg-gray-50/50">
                    <th className="p-3 font-medium">Platform</th>
                    <th className="p-3 font-medium">Content Type</th>
                    <th className="p-3 font-medium text-right">Impressions</th>
                    <th className="p-3 font-medium text-right">Likes</th>
                    <th className="p-3 font-medium text-right">Comments</th>
                    <th className="p-3 font-medium text-right">Shares</th>
                    <th className="p-3 font-medium text-right">Engagement Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {records.map(r => (
                    <tr key={r.id} className="border-b border-gray-50 hover:bg-gray-50/30 transition-colors">
                      <td className="p-3 capitalize">{r.platform || '-'}</td>
                      <td className="p-3 capitalize">{r.content_type?.replace(/_/g, ' ') || '-'}</td>
                      <td className="p-3 text-right">{formatNumber(r.impressions)}</td>
                      <td className="p-3 text-right">{formatNumber(r.likes)}</td>
                      <td className="p-3 text-right">{formatNumber(r.comments)}</td>
                      <td className="p-3 text-right">{formatNumber(r.shares)}</td>
                      <td className="p-3 text-right">{r.engagement_rate != null ? `${(r.engagement_rate * 100).toFixed(2)}%` : '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      )}

      {/* Insights Tab */}
      {activeTab === 'insights' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <Button onClick={handleGenerateInsights} className="flex items-center gap-2">
              <Lightbulb className="w-4 h-4" /> Generate New Insights
            </Button>
          </div>
          {insights.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
              <Lightbulb className="w-8 h-8 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-400 text-sm">No insights generated yet. Click "Generate New Insights" to analyze your data.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {insights.map(insight => (
                <div key={insight.id} className={`bg-white rounded-2xl border p-5 shadow-sm transition-colors ${insight.is_archived ? 'border-gray-100 opacity-60' : 'border-gray-100'}`}>
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 capitalize">{insight.pattern_type.replace(/_/g, ' ')}</span>
                      {insight.platform && <span className="text-xs text-gray-400 ml-2 capitalize">{insight.platform}</span>}
                      {insight.content_type && <span className="text-xs text-gray-400 ml-2 capitalize">{insight.content_type.replace(/_/g, ' ')}</span>}
                    </div>
                    <div className="flex items-center gap-1">
                      <button onClick={() => toggleInsight(insight, 'is_accepted')} className={`px-2 py-1 text-xs font-medium rounded-lg transition-colors ${insight.is_accepted ? 'bg-green-100 text-green-700' : 'bg-gray-50 text-gray-400 hover:text-green-600'}`}>
                        {insight.is_accepted ? 'Accepted' : 'Accept'}
                      </button>
                      <button onClick={() => toggleInsight(insight, 'is_archived')} className={`px-2 py-1 text-xs font-medium rounded-lg transition-colors ${insight.is_archived ? 'bg-gray-200 text-gray-500' : 'bg-gray-50 text-gray-400 hover:text-gray-600'}`}>
                        {insight.is_archived ? 'Archived' : 'Archive'}
                      </button>
                      <button onClick={() => toggleInsight(insight, 'affect_future_generation')} className={`px-2 py-1 text-xs font-medium rounded-lg transition-colors ${insight.affect_future_generation ? 'bg-purple-100 text-purple-700' : 'bg-gray-50 text-gray-400 hover:text-purple-600'}`}>
                        {insight.affect_future_generation ? 'Influencing' : 'Influence Future'}
                      </button>
                    </div>
                  </div>
                  <p className="text-sm text-gray-800 mb-1">{insight.finding}</p>
                  {insight.supporting_metric && (
                    <p className="text-xs text-gray-500">
                      <span className="font-medium">Metric:</span> {insight.supporting_metric}
                    </p>
                  )}
                  {insight.confidence && (
                    <p className="text-xs text-gray-400 mt-1">
                      Confidence: {insight.confidence}
                      {insight.sample_size != null && ` (n=${insight.sample_size})`}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
