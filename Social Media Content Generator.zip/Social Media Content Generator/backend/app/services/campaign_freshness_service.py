from __future__ import annotations

from sqlalchemy.orm import Session

from app.models.db_models import Campaign


class CampaignFreshnessService:
    def __init__(self, db: Session):
        self.db = db

    def analyze_brand_fatigue(self, brand_id: int) -> dict:
        campaigns = (
            self.db.query(Campaign).filter(Campaign.brand_profile_id == brand_id, Campaign.status != "draft").all()
        )

        if not campaigns:
            return {
                "status": "insufficient_data",
                "fatigue_score": 0.0,
                "total_campaigns": 0,
                "total_posts": 0,
                "repeated_themes": {},
                "cta_diversity": 0,
                "recommendations": ["No campaign history yet — start with fresh content"],
            }

        all_themes = []
        for c in campaigns:
            for p in c.posts:
                all_themes.append(p.content_theme.lower())

        theme_counts = {}
        for t in all_themes:
            theme_counts[t] = theme_counts.get(t, 0) + 1

        repeated_themes = {t: c for t, c in theme_counts.items() if c > 2}
        total_themes = len(all_themes)
        repetition_ratio = sum(c - 1 for c in repeated_themes.values()) / max(total_themes, 1)

        all_ctas = [p.call_to_action.lower() for c in campaigns for p in c.posts if p.call_to_action]
        cta_counts = {}
        for cta in all_ctas:
            cta_counts[cta] = cta_counts.get(cta, 0) + 1

        fatigue_score = min(1.0, repetition_ratio * 0.6 + (len(cta_counts) / max(len(all_ctas), 1)) * 0.4)

        recommendations = []
        if repeated_themes:
            recommendations.append(f"Reduce reuse of themes: {', '.join(list(repeated_themes.keys())[:5])}")
        if fatigue_score > 0.5:
            recommendations.append("High fatigue detected — consider new content angles or format changes")
        if not recommendations:
            recommendations.append("Good content diversity — continue varying themes and CTAs")

        return {
            "fatigue_score": round(fatigue_score, 2),
            "total_campaigns": len(campaigns),
            "total_posts": total_themes,
            "repeated_themes": repeated_themes,
            "cta_diversity": len(cta_counts),
            "recommendations": recommendations,
        }

    def get_freshness_recommendations(self, campaign_id: int) -> list[str]:
        campaign = self.db.query(Campaign).filter(Campaign.id == campaign_id).first()
        if not campaign:
            return ["Campaign not found"]

        result = self.analyze_brand_fatigue(campaign.brand_profile_id or 0)
        return result.get("recommendations", [])
