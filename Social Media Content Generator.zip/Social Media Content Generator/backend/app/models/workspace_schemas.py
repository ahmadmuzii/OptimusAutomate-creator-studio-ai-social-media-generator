from __future__ import annotations

import datetime

from pydantic import BaseModel, ConfigDict


class WorkspaceCreate(BaseModel):
    name: str


class WorkspaceUpdate(BaseModel):
    name: str | None = None


class WorkspaceMembershipResponse(BaseModel):
    id: int
    user_id: int
    workspace_id: int
    role: str
    user_email: str | None = None
    created_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)


class WorkspaceResponse(BaseModel):
    id: int
    name: str
    owner_id: int
    memberships: list[WorkspaceMembershipResponse] = []
    created_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)


class AddMemberRequest(BaseModel):
    user_id: int
    role: str = "editor"


class UpdateMemberRoleRequest(BaseModel):
    role: str


class ApprovalRequestCreate(BaseModel):
    campaign_id: int


class ApprovalRequestResponse(BaseModel):
    id: int
    campaign_id: int
    requested_by_id: int
    status: str
    created_at: datetime.datetime
    decisions: list = []

    model_config = ConfigDict(from_attributes=True)


class ApprovalDecisionCreate(BaseModel):
    decision: str
    comment: str | None = None


class PostVersionResponse(BaseModel):
    id: int
    post_id: int
    version_number: int
    change_reason: str | None = None
    caption: str | None = None
    call_to_action: str | None = None
    hashtags: list[str] | None = None
    created_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)
