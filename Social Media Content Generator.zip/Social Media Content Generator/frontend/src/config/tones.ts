export interface ToneConfig {
  id: string
  label: string
  emoji: string
}

export const tones: ToneConfig[] = [
  { id: 'professional', label: 'Professional', emoji: '💼' },
  { id: 'funny', label: 'Funny', emoji: '😂' },
  { id: 'luxury', label: 'Luxury', emoji: '✨' },
  { id: 'genz', label: 'Gen Z', emoji: '🔥' },
  { id: 'motivational', label: 'Motivational', emoji: '💪' },
  { id: 'casual', label: 'Casual', emoji: '☕' },
  { id: 'bold', label: 'Bold', emoji: '🚀' },
] as const

export const toneApiMap: Record<string, string> = {
  professional: 'professional',
  funny: 'funny',
  luxury: 'luxury',
  genz: 'gen_z',
  motivational: 'motivational',
  casual: 'casual',
  bold: 'bold',
}
