import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { useBrandWorkspace } from '@/components/layout/BrandWorkspaceLayout'
import { ArrowLeft, Plus, Trash2, Download, ChevronDown, ChevronRight, Package, Image, Link as LinkIcon, Tag } from 'lucide-react'
import { ErrorState } from '@/components/ui/ErrorState'
import { LoadingSpinner } from '@/components/ui/LoadingSpinner'
import * as api from '@/api/endpoints'
import type { ContentPackTemplate, PackMediaItem, PackLink } from '@/types/contentPack'
import { ROUTES } from '@/routes/paths'
import { Button } from '@/components/ui/Button'

const EMPTY_PACK = {
  name: '', description: '', is_default: false,
  pack_data: {
    title: '', description: '', media: [] as PackMediaItem[],
    links: [] as PackLink[], notes: '', tags: [] as string[],
  },
}

export function ContentPacksPage() {
  const { brandId, brand } = useBrandWorkspace()

  const [loading, setLoading] = useState(true)

  const [templates, setTemplates] = useState<ContentPackTemplate[]>([])
  const [editingId, setEditingId] = useState<number | 'new' | null>(null)
  const [form, setForm] = useState<Record<string, unknown>>({ ...EMPTY_PACK })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [expandedRows, setExpandedRows] = useState<Set<number>>(new Set())

  const load = useCallback(async () => {
    const data = await api.fetchContentPackTemplates(brandId)
    setTemplates(data as ContentPackTemplate[])
  }, [brandId])

  useEffect(() => {
    load().catch(() => setError('Could not load content packs.')).finally(() => setLoading(false))
  }, [brandId, load])

  const startEdit = (template?: ContentPackTemplate) => {
    if (template) {
      setEditingId(template.id)
      setForm({
        name: template.name, description: template.description || '',
        is_default: template.is_default,
        pack_data: {
          title: template.pack_data.title,
          description: template.pack_data.description || '',
          media: template.pack_data.media || [],
          links: template.pack_data.links || [],
          notes: template.pack_data.notes || '',
          tags: template.pack_data.tags || [],
        },
      })
    } else {
      setEditingId('new')
      setForm({ ...EMPTY_PACK })
    }
  }

  const cancelEdit = () => { setEditingId(null); setForm({ ...EMPTY_PACK }) }

  const handleSave = async () => {
    setSaving(true)
    try {
      if (editingId === 'new') {
        await api.createContentPackTemplate(brandId, form)
      } else {
        await api.updateContentPackTemplate(brandId, editingId as number, form)
      }
      await load()
      cancelEdit()
    } catch { setError('Failed to save.') }
    finally { setSaving(false) }
  }

  const handleDelete = async (templateId: number) => {
    try {
      await api.deleteContentPackTemplate(brandId, templateId)
      setTemplates(prev => prev.filter(t => t.id !== templateId))
    } catch { setError('Failed to delete.') }
  }

  const handleExport = async (template: ContentPackTemplate) => {
    try {
      await api.exportContentPack(brandId, { template_id: template.id, format: 'json' })
    } catch { setError('Failed to export.') }
  }

  const toggleRow = (id: number) => {
    setExpandedRows(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      return next
    })
  }

  const updatePackData = (key: string, value: unknown) => {
    setForm(prev => ({ ...prev, pack_data: { ...(prev.pack_data as Record<string, unknown>), [key]: value } }))
  }

  const addMediaItem = () => {
    const media: PackMediaItem[] = [...((form.pack_data as Record<string, unknown>).media as PackMediaItem[] || []), { type: 'image', url: '', alt_text: '', order: 0 }]
    updatePackData('media', media)
  }

  const updateMediaItem = (index: number, field: string, value: string) => {
    const media: PackMediaItem[] = [...((form.pack_data as Record<string, unknown>).media as PackMediaItem[] || [])]
    media[index] = { ...media[index], [field]: value } as PackMediaItem
    updatePackData('media', media)
  }

  const removeMediaItem = (index: number) => {
    const media = [...((form.pack_data as Record<string, unknown>).media as PackMediaItem[] || [])]
    media.splice(index, 1)
    updatePackData('media', media)
  }

  const addLink = () => {
    const links: PackLink[] = [...((form.pack_data as Record<string, unknown>).links as PackLink[] || []), { url: '', title: '', description: '' }]
    updatePackData('links', links)
  }

  const updateLink = (index: number, field: string, value: string) => {
    const links: PackLink[] = [...((form.pack_data as Record<string, unknown>).links as PackLink[] || [])]
    links[index] = { ...links[index], [field]: value } as PackLink
    updatePackData('links', links)
  }

  const removeLink = (index: number) => {
    const links = [...((form.pack_data as Record<string, unknown>).links as PackLink[] || [])]
    links.splice(index, 1)
    updatePackData('links', links)
  }

  const addTag = () => {
    const tags = [...((form.pack_data as Record<string, unknown>).tags as string[] || []), '']
    updatePackData('tags', tags)
  }

  const updateTag = (index: number, value: string) => {
    const tags = [...((form.pack_data as Record<string, unknown>).tags as string[] || [])]
    tags[index] = value
    updatePackData('tags', tags)
  }

  const removeTag = (index: number) => {
    const tags = [...((form.pack_data as Record<string, unknown>).tags as string[] || [])]
    tags.splice(index, 1)
    updatePackData('tags', tags)
  }

  if (loading) return <LoadingSpinner />

  if (error) return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>
      <ErrorState message={error} onRetry={load} />
    </div>
  )

  if (templates.length === 0) return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Package className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Content Packs</h1>
        </div>
        <Button onClick={() => startEdit()} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Template
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Reusable content pack templates for {brand.name}. Each template bundles media, links, and metadata for quick campaign setup.
      </p>

      <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
        <Package className="w-8 h-8 text-gray-300 mx-auto mb-3" />
        <p className="text-gray-400 text-sm mb-4">No content pack templates yet.</p>
        <Button onClick={() => startEdit()} className="mx-auto flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Your First Template
        </Button>
      </div>

      {editingId !== null && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={cancelEdit}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">{editingId === 'new' ? 'New Template' : 'Edit Template'}</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Template Name *</label>
                <input value={form.name as string} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} placeholder="e.g., Product Launch Pack" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Template Description</label>
                <textarea value={form.description as string} onChange={e => setForm(prev => ({ ...prev, description: e.target.value }))} rows={2} placeholder="What is this pack for?" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>

              <fieldset className="border border-gray-100 rounded-lg p-4 space-y-3">
                <legend className="text-sm font-medium text-gray-700 px-1">Pack Data</legend>
                <div>
                  <label className="text-sm font-medium text-gray-700">Content Title</label>
                  <input value={(form.pack_data as Record<string, unknown>).title as string} onChange={e => updatePackData('title', e.target.value)} placeholder="e.g., Summer Product Launch" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Content Description</label>
                  <textarea value={(form.pack_data as Record<string, unknown>).description as string} onChange={e => updatePackData('description', e.target.value)} rows={2} placeholder="Describe the content pack..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Notes</label>
                  <textarea value={(form.pack_data as Record<string, unknown>).notes as string} onChange={e => updatePackData('notes', e.target.value)} rows={2} placeholder="Internal notes..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Tags</label>
                  {((form.pack_data as Record<string, unknown>).tags as string[] || []).map((tag, i) => (
                    <div key={i} className="flex items-center gap-2 mt-1">
                      <input value={tag} onChange={e => updateTag(i, e.target.value)} placeholder="e.g., product" className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <button onClick={() => removeTag(i)} className="p-1 text-gray-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  ))}
                  <button onClick={addTag} className="mt-1 text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1"><Plus className="w-3.5 h-3.5" /> Add tag</button>
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-gray-700">Media Items</label>
                    <button onClick={addMediaItem} className="text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1"><Plus className="w-3.5 h-3.5" /> Add media</button>
                  </div>
                  {((form.pack_data as Record<string, unknown>).media as PackMediaItem[] || []).map((item, i) => (
                    <div key={i} className="flex items-center gap-2 mt-2 bg-gray-50 rounded-lg p-2">
                      <select value={item.type} onChange={e => updateMediaItem(i, 'type', e.target.value)} className="rounded border border-gray-200 px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500">
                        <option value="image">Image</option>
                        <option value="video">Video</option>
                        <option value="audio">Audio</option>
                        <option value="document">Document</option>
                      </select>
                      <input value={item.url} onChange={e => updateMediaItem(i, 'url', e.target.value)} placeholder="URL" className="flex-1 rounded border border-gray-200 px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <input value={item.alt_text || ''} onChange={e => updateMediaItem(i, 'alt_text', e.target.value)} placeholder="Alt text" className="w-28 rounded border border-gray-200 px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <button onClick={() => removeMediaItem(i)} className="p-1 text-gray-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-gray-700">Links</label>
                    <button onClick={addLink} className="text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1"><Plus className="w-3.5 h-3.5" /> Add link</button>
                  </div>
                  {((form.pack_data as Record<string, unknown>).links as PackLink[] || []).map((link, i) => (
                    <div key={i} className="flex items-center gap-2 mt-2 bg-gray-50 rounded-lg p-2">
                      <input value={link.url} onChange={e => updateLink(i, 'url', e.target.value)} placeholder="URL" className="flex-1 rounded border border-gray-200 px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <input value={link.title || ''} onChange={e => updateLink(i, 'title', e.target.value)} placeholder="Title" className="w-28 rounded border border-gray-200 px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <button onClick={() => removeLink(i)} className="p-1 text-gray-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  ))}
                </div>
              </fieldset>

              <div className="flex items-center gap-3 pt-2">
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={form.is_default as boolean} onChange={e => setForm(prev => ({ ...prev, is_default: e.target.checked }))} className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" />
                  <span className="text-sm text-gray-700">Set as default template</span>
                </label>
              </div>

              <div className="flex items-center gap-3 pt-4 border-t border-gray-100">
                <Button onClick={handleSave} disabled={saving || !form.name}>{saving ? 'Saving...' : 'Save'}</Button>
                <button onClick={cancelEdit} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )

  return (
    <div className="w-full space-y-6">
      <Link to={`${ROUTES.brands}/${brandId}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to {brand.name}
      </Link>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Package className="w-6 h-6 text-purple-600" />
          <h1 className="text-2xl font-bold text-gray-900">Content Packs</h1>
        </div>
        <Button onClick={() => startEdit()} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Template
        </Button>
      </div>

      <p className="text-sm text-gray-500">
        Reusable content pack templates for {brand.name}. Each template bundles media, links, and metadata for quick campaign setup.
      </p>

      {/* Editor Modal */}
      {editingId !== null && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-10" onClick={cancelEdit}>
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[85vh] overflow-y-auto mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-gray-900 mb-6">{editingId === 'new' ? 'New Template' : 'Edit Template'}</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Template Name *</label>
                <input value={form.name as string} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} placeholder="e.g., Product Launch Pack" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Template Description</label>
                <textarea value={form.description as string} onChange={e => setForm(prev => ({ ...prev, description: e.target.value }))} rows={2} placeholder="What is this pack for?" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
              </div>

              <fieldset className="border border-gray-100 rounded-lg p-4 space-y-3">
                <legend className="text-sm font-medium text-gray-700 px-1">Pack Data</legend>
                <div>
                  <label className="text-sm font-medium text-gray-700">Content Title</label>
                  <input value={(form.pack_data as Record<string, unknown>).title as string} onChange={e => updatePackData('title', e.target.value)} placeholder="e.g., Summer Product Launch" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Content Description</label>
                  <textarea value={(form.pack_data as Record<string, unknown>).description as string} onChange={e => updatePackData('description', e.target.value)} rows={2} placeholder="Describe the content pack..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Notes</label>
                  <textarea value={(form.pack_data as Record<string, unknown>).notes as string} onChange={e => updatePackData('notes', e.target.value)} rows={2} placeholder="Internal notes..." className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Tags</label>
                  {((form.pack_data as Record<string, unknown>).tags as string[] || []).map((tag, i) => (
                    <div key={i} className="flex items-center gap-2 mt-1">
                      <input value={tag} onChange={e => updateTag(i, e.target.value)} placeholder="e.g., product" className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <button onClick={() => removeTag(i)} className="p-1 text-gray-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  ))}
                  <button onClick={addTag} className="mt-1 text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1"><Plus className="w-3.5 h-3.5" /> Add tag</button>
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-gray-700">Media Items</label>
                    <button onClick={addMediaItem} className="text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1"><Plus className="w-3.5 h-3.5" /> Add media</button>
                  </div>
                  {((form.pack_data as Record<string, unknown>).media as PackMediaItem[] || []).map((item, i) => (
                    <div key={i} className="flex items-center gap-2 mt-2 bg-gray-50 rounded-lg p-2">
                      <select value={item.type} onChange={e => updateMediaItem(i, 'type', e.target.value)} className="rounded border border-gray-200 px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500">
                        <option value="image">Image</option>
                        <option value="video">Video</option>
                        <option value="audio">Audio</option>
                        <option value="document">Document</option>
                      </select>
                      <input value={item.url} onChange={e => updateMediaItem(i, 'url', e.target.value)} placeholder="URL" className="flex-1 rounded border border-gray-200 px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <input value={item.alt_text || ''} onChange={e => updateMediaItem(i, 'alt_text', e.target.value)} placeholder="Alt text" className="w-28 rounded border border-gray-200 px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <button onClick={() => removeMediaItem(i)} className="p-1 text-gray-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-gray-700">Links</label>
                    <button onClick={addLink} className="text-sm text-purple-600 hover:text-purple-800 flex items-center gap-1"><Plus className="w-3.5 h-3.5" /> Add link</button>
                  </div>
                  {((form.pack_data as Record<string, unknown>).links as PackLink[] || []).map((link, i) => (
                    <div key={i} className="flex items-center gap-2 mt-2 bg-gray-50 rounded-lg p-2">
                      <input value={link.url} onChange={e => updateLink(i, 'url', e.target.value)} placeholder="URL" className="flex-1 rounded border border-gray-200 px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <input value={link.title || ''} onChange={e => updateLink(i, 'title', e.target.value)} placeholder="Title" className="w-28 rounded border border-gray-200 px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500" />
                      <button onClick={() => removeLink(i)} className="p-1 text-gray-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  ))}
                </div>
              </fieldset>

              <div className="flex items-center gap-3 pt-2">
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={form.is_default as boolean} onChange={e => setForm(prev => ({ ...prev, is_default: e.target.checked }))} className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" />
                  <span className="text-sm text-gray-700">Set as default template</span>
                </label>
              </div>

              <div className="flex items-center gap-3 pt-4 border-t border-gray-100">
                <Button onClick={handleSave} disabled={saving || !form.name}>{saving ? 'Saving...' : 'Save'}</Button>
                <button onClick={cancelEdit} className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Templates List */}
        <div className="space-y-3">
          {templates.map(template => {
            const isExpanded = expandedRows.has(template.id)
            return (
              <div key={template.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="flex items-center justify-between px-5 py-4">
                  <button onClick={() => toggleRow(template.id)} className="flex items-center gap-3 text-left flex-1 min-w-0">
                    {isExpanded ? <ChevronDown className="w-4 h-4 text-gray-400 shrink-0" /> : <ChevronRight className="w-4 h-4 text-gray-400 shrink-0" />}
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-gray-900">{template.name}</h3>
                        {template.is_default && <span className="text-xs bg-purple-50 text-purple-700 px-2 py-0.5 rounded-full font-medium">Default</span>}
                      </div>
                      {template.description && <p className="text-sm text-gray-500 truncate mt-0.5">{template.description}</p>}
                      <div className="flex items-center gap-3 mt-1 text-xs text-gray-400">
                        {template.pack_data.tags.length > 0 && (
                          <span className="flex items-center gap-1">
                            <Tag className="w-3 h-3" />
                            {template.pack_data.tags.join(', ')}
                          </span>
                        )}
                        <span>{template.pack_data.media.length} media</span>
                        <span>{template.pack_data.links.length} links</span>
                      </div>
                    </div>
                  </button>
                  <div className="flex items-center gap-1 shrink-0 ml-3">
                    <button onClick={() => handleExport(template)} className="p-1.5 rounded-lg hover:bg-gray-50 text-gray-400 hover:text-purple-600" title="Export">
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => startEdit(template)} className="p-1.5 rounded-lg hover:bg-purple-50 text-gray-400 hover:text-purple-600 text-xs font-medium" title="Edit">Edit</button>
                    <button onClick={() => handleDelete(template.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500" title="Delete">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {isExpanded && (
                  <div className="border-t border-gray-50 px-5 py-4 space-y-4">
                    {template.pack_data.media.length > 0 && (
                      <div>
                        <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5"><Image className="w-3.5 h-3.5" /> Media</h4>
                        <div className="space-y-1.5">
                          {template.pack_data.media.map((media, i) => (
                            <div key={i} className="flex items-center gap-2 text-sm bg-gray-50 rounded-lg px-3 py-2">
                              <span className="text-xs font-medium text-gray-400 uppercase w-14">{media.type}</span>
                              <span className="text-gray-600 truncate flex-1">{media.url}</span>
                              {media.alt_text && <span className="text-gray-400 text-xs truncate max-w-[120px]">{media.alt_text}</span>}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    {template.pack_data.links.length > 0 && (
                      <div>
                        <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1.5"><LinkIcon className="w-3.5 h-3.5" /> Links</h4>
                        <div className="space-y-1.5">
                          {template.pack_data.links.map((link, i) => (
                            <div key={i} className="flex items-center gap-2 text-sm bg-gray-50 rounded-lg px-3 py-2">
                              <LinkIcon className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                              <span className="text-gray-600 truncate flex-1">{link.title || link.url}</span>
                              {link.url && <a href={link.url} target="_blank" rel="noopener noreferrer" className="text-purple-600 hover:text-purple-800 text-xs shrink-0">Open</a>}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    {template.pack_data.notes && (
                      <div>
                        <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Notes</h4>
                        <p className="text-sm text-gray-600">{template.pack_data.notes}</p>
                      </div>
                    )}
                    {template.pack_data.media.length === 0 && template.pack_data.links.length === 0 && !template.pack_data.notes && (
                      <p className="text-sm text-gray-400">No additional pack data.</p>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
    </div>
  )
}
