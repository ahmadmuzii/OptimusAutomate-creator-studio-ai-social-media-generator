from typing import Any

from app.ai.context_builder import CampaignGenerationContext
from app.modules.hashtag_generator import generate_hashtags as fallback_hashtags

FALLBACK_THEMES = [
    "Introduction & Brand Story",
    "Behind the Scenes",
    "Product Spotlight",
    "Customer Love",
    "Educational Value",
    "Engagement & Fun",
    "Final CTA & Recap",
]


def fallback_campaign_strategy(ctx: CampaignGenerationContext) -> dict[str, Any]:
    brand_name = ctx.brand.name if ctx.brand else "Brand"
    platform = ctx.request.platform if ctx.request else "instagram"
    goal = ctx.request.campaign_goal if ctx.request else "brand_awareness"
    days_count = ctx.request.days_count if ctx.request else 7

    day_plans = []
    for i in range(days_count):
        theme_index = i % len(FALLBACK_THEMES)
        funnel_stages = ["awareness", "interest", "decision", "interest", "awareness", "action", "retention"]
        stage = funnel_stages[i] if i < len(funnel_stages) else "interest"

        day_plans.append(
            {
                "day": i + 1,
                "theme": FALLBACK_THEMES[theme_index],
                "purpose": f"Day {i + 1} of the {brand_name} {goal.replace('_', ' ')} campaign on {platform}.",
                "funnel_stage": stage,
                "persona_id": ctx.personas[0].id if ctx.personas else None,
                "content_type": _content_type_for_day(i, platform),
                "audience_action": f"Engage with {brand_name}'s content",
                "reason_for_format": "Standard content mix for consistent campaign pacing.",
                "source_fact_ids": [f.id for f in ctx.source_facts[:3]] if ctx.source_facts else [],
                "performance_insight_ids": [ins.id for ins in ctx.performance_insights[:2]]
                if ctx.performance_insights
                else [],
                "competitor_opportunity_ids": [],
            }
        )

    return {
        "campaign_name": f"{brand_name} · {platform.title()} Campaign",
        "campaign_summary": f"A {days_count}-day {goal.replace('_', ' ')} campaign for {brand_name} on {platform}.",
        "strategy": "Multi-day content strategy covering brand story, product highlights, education, and engagement.",
        "day_plans": day_plans,
        "generation_source": "fallback",
    }


def fallback_generate_post(
    ctx: CampaignGenerationContext,
    day_plan: dict[str, Any],
) -> dict[str, Any]:
    brand_name = ctx.brand.name if ctx.brand else "Brand"
    platform = ctx.request.platform if ctx.request else "instagram"
    tone = ctx.request.tone if ctx.request else "professional"
    theme = day_plan.get("theme", "General")
    purpose = day_plan.get("purpose", "")
    content_type = day_plan.get("content_type", "static_post")
    stage = day_plan.get("funnel_stage", "awareness")

    fact_lines = []
    for sf in ctx.source_facts:
        fact_lines.append(f"- {sf.label}: {sf.value}")

    facts_text = "\n".join(fact_lines[:5]) if fact_lines else "- General brand content"

    caption = _fallback_caption(brand_name, theme, platform, tone, facts_text, purpose)
    cta = _fallback_cta(brand_name, platform, tone, ctx.conversion_path)

    htags = fallback_hashtags(
        brand_name=brand_name,
        niche=ctx.brand.niche if ctx.brand else "",
        platform=platform,
        campaign_goal=ctx.request.campaign_goal if ctx.request else "brand_awareness",
        target_audience=ctx.brand.target_audience if ctx.brand else "",
        count=10,
    )

    return {
        "hook": f"Discover what makes {brand_name} special ✨",
        "caption": caption,
        "call_to_action": cta,
        "hashtags": htags,
        "content_theme": theme,
        "post_idea": f"{theme} - {brand_name}",
        "content_type": content_type,
        "suggested_time": _suggested_time(platform),
        "purpose": purpose,
        "funnel_stage": stage,
        "audience_action": day_plan.get("audience_action", f"Engage with {brand_name}"),
        "reason_for_format": day_plan.get("reason_for_format", "Standard format for this content type."),
        "source_fact_ids": day_plan.get("source_fact_ids", []),
        "guardrails_applied": [],
        "performance_insights_applied": [],
        "generation_source": "fallback",
    }


def _fallback_caption(
    brand_name: str,
    theme: str,
    platform: str,
    tone: str,
    facts_text: str,
    purpose: str,
) -> str:
    lines = [
        f"Introducing {brand_name}! 🎉",
        "",
        f"Today's theme: {theme}",
        "",
        facts_text,
        "",
        purpose,
        "",
        f"Follow {brand_name} for more updates!",
    ]
    return "\n".join(lines)


def _fallback_cta(
    brand_name: str,
    platform: str,
    tone: str,
    conversion_path: Any,
) -> str:
    if conversion_path and hasattr(conversion_path, "cta_keyword") and conversion_path.cta_keyword:
        return f"{conversion_path.cta_keyword} — {conversion_path.primary_action or 'Learn more'}"

    platform_ctas = {
        "instagram": "Double tap if you agree! ❤️",
        "linkedin": "Share your thoughts in the comments below.",
        "tiktok": "Follow for more content like this!",
        "facebook": "Tag a friend who needs to see this.",
        "x": "Retweet to spread the word.",
    }
    return platform_ctas.get(platform, "Learn more at our website.")


def _suggested_time(platform: str) -> str:
    times = {
        "instagram": "11:00 AM",
        "linkedin": "8:00 AM",
        "tiktok": "7:00 PM",
        "facebook": "1:00 PM",
        "x": "9:00 AM",
    }
    return times.get(platform, "12:00 PM")


def _content_type_for_day(day: int, platform: str) -> str:
    types = ["carousel", "static_post", "reel", "static_post", "carousel", "story", "static_post"]
    return types[day % len(types)]
