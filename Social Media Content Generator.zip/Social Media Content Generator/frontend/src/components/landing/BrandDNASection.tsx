import { motion } from 'framer-motion'
import { Building2, Users, Target, PenLine, Hash, Palette } from 'lucide-react'
import { useReducedMotionPreference } from '@/hooks/useReducedMotionPreference'
import { staggerContainer, listItem } from '@/lib/animation'
import { Badge } from '@/components/ui/Badge'

const brandProfile = {
  name: 'Urban Brew Studio',
  industry: 'Specialty Coffee & Café',
  audience: 'Urban professionals, 25-40',
  voice: 'Craft-focused, warm, knowledgeable',
  tone: 'Professional & Casual',
  goal: 'Brand awareness & Community building',
  colors: ['#7c3aed', '#6d28d9', '#faf5ff', '#1f2937'],
}

export function BrandDNASection() {
  const reduced = useReducedMotionPreference()

  return (
    <section className="py-20 bg-gray-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 tracking-tight">
            Your brand voice should not reset every time you generate.
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            Saved brand profiles keep your audience, voice, niche, and preferences ready.
          </p>
          <Badge variant="purple" className="mt-4">Brand-aware, not prompt-only</Badge>
        </div>

        <motion.div
          variants={reduced ? undefined : staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto"
        >
          <motion.div
            variants={reduced ? undefined : listItem}
            className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
          >
            <div className="flex items-center gap-2 mb-5">
              <Building2 className="w-5 h-5 text-purple-600" />
              <h3 className="font-semibold text-gray-900">Saved Brand Profile</h3>
            </div>
            <div className="space-y-3">
              {[
                { icon: Building2, label: 'Brand', value: brandProfile.name },
                { icon: Target, label: 'Industry', value: brandProfile.industry },
                { icon: Users, label: 'Audience', value: brandProfile.audience },
                { icon: PenLine, label: 'Voice', value: brandProfile.voice },
                { icon: Hash, label: 'Default Tone', value: brandProfile.tone },
                { icon: Target, label: 'Campaign Goal', value: brandProfile.goal },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-3">
                  <item.icon className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  <span className="text-xs text-gray-400 w-24 flex-shrink-0">{item.label}</span>
                  <span className="text-sm text-gray-900 font-medium">{item.value}</span>
                </div>
              ))}
              <div className="flex items-center gap-3 pt-2">
                <Palette className="w-4 h-4 text-gray-400 flex-shrink-0" />
                <span className="text-xs text-gray-400 w-24 flex-shrink-0">Brand Colors</span>
                <div className="flex gap-1.5">
                  {brandProfile.colors.map((color, i) => (
                    <div
                      key={i}
                      className="w-5 h-5 rounded-full border border-gray-200"
                      style={{ backgroundColor: color }}
                      title={color}
                    />
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            variants={reduced ? undefined : listItem}
            className="bg-gradient-to-br from-purple-50 to-purple-100/50 rounded-2xl border border-purple-100 p-6"
          >
            <div className="flex items-center gap-2 mb-4">
              <PenLine className="w-5 h-5 text-purple-600" />
              <h3 className="font-semibold text-gray-900">Generated Content</h3>
            </div>
            <div className="space-y-3">
              <div className="bg-white rounded-xl p-3 border border-purple-100">
                <div className="text-[10px] font-semibold text-purple-600 mb-1">Day 1 Caption</div>
                <p className="text-xs text-gray-700 leading-relaxed">
                  Every cup at Urban Brew Studio starts with a single origin bean. Our master roasters travel directly to farms in Colombia and Ethiopia to source the finest specialty-grade coffee. This is not just coffee. This is craftsmanship in every sip.
                </p>
              </div>
              <div className="bg-white rounded-xl p-3 border border-purple-100">
                <div className="text-[10px] font-semibold text-purple-600 mb-1">Hashtags</div>
                <div className="flex flex-wrap gap-1">
                  {['#SpecialtyCoffee', '#UrbanBrewStudio', '#ArtisanCoffee', '#SmallBatchRoasting', '#CoffeeCulture'].map((tag) => (
                    <span key={tag} className="text-[10px] px-2 py-0.5 rounded-full bg-purple-100 text-purple-600">{tag}</span>
                  ))}
                </div>
              </div>
              <div className="bg-white rounded-xl p-3 border border-purple-100">
                <div className="text-[10px] font-semibold text-purple-600 mb-1">CTA</div>
                <p className="text-xs text-purple-700 font-medium">Visit us downtown and taste the difference.</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
