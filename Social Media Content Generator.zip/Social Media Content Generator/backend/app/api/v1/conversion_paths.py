from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.api.deps_features import require_feature
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.conversion_schemas import (
    ConversionPathCreate,
    ConversionPathResponse,
    ConversionPathUpdate,
)
from app.models.db_models import BrandProfile, ConversionPath, User

router = APIRouter(
    prefix="/brands/{brand_id}/conversion-paths",
    tags=["Conversion Paths"],
    dependencies=[require_feature("conversion_paths")],
)


def _get_brand_or_404(db: Session, brand_id: int, user_id: int) -> BrandProfile:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != user_id:
        raise NotFoundError("Brand not found")
    return brand


def _conversion_path_to_response(c: ConversionPath) -> ConversionPathResponse:
    return ConversionPathResponse(
        id=c.id,
        brand_id=c.brand_id,
        name=c.name,
        destination_type=c.destination_type,
        destination_value=c.destination_value,
        primary_action=c.primary_action,
        cta_keyword=c.cta_keyword,
        campaign_goal=c.campaign_goal,
        tracking_label=c.tracking_label,
        utm_source=c.utm_source,
        utm_medium=c.utm_medium,
        utm_campaign=c.utm_campaign,
        is_active=c.is_active,
        created_at=c.created_at,
        updated_at=c.updated_at,
    )


@router.get("", response_model=list[ConversionPathResponse])
def list_conversion_paths(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    paths = db.query(ConversionPath).filter(ConversionPath.brand_id == brand_id).all()
    return [_conversion_path_to_response(p) for p in paths]


@router.post("", response_model=ConversionPathResponse)
def create_conversion_path(
    brand_id: int,
    request: ConversionPathCreate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    path = ConversionPath(brand_id=brand_id, **request.model_dump())
    db.add(path)
    db.commit()
    db.refresh(path)
    return _conversion_path_to_response(path)


@router.get("/{path_id}", response_model=ConversionPathResponse)
def get_conversion_path(
    brand_id: int,
    path_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    path = db.query(ConversionPath).filter(ConversionPath.id == path_id, ConversionPath.brand_id == brand_id).first()
    if not path:
        raise NotFoundError("Conversion path not found")
    return _conversion_path_to_response(path)


@router.put("/{path_id}", response_model=ConversionPathResponse)
def update_conversion_path(
    brand_id: int,
    path_id: int,
    request: ConversionPathUpdate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    path = db.query(ConversionPath).filter(ConversionPath.id == path_id, ConversionPath.brand_id == brand_id).first()
    if not path:
        raise NotFoundError("Conversion path not found")

    update_data = request.model_dump(exclude_none=True)
    for key, value in update_data.items():
        setattr(path, key, value)
    db.commit()
    db.refresh(path)
    return _conversion_path_to_response(path)


@router.delete("/{path_id}")
def delete_conversion_path(
    brand_id: int,
    path_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    path = db.query(ConversionPath).filter(ConversionPath.id == path_id, ConversionPath.brand_id == brand_id).first()
    if not path:
        raise NotFoundError("Conversion path not found")
    db.delete(path)
    db.commit()
    return {"detail": "Conversion path deleted"}
