import { useNavigate } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'

export function FinalCTA() {
  const { isAuthenticated } = useAuth()
  const navigate = useNavigate()

  const handlePrimary = () => {
    navigate(isAuthenticated ? '/dashboard/generate' : '/login?redirect=' + encodeURIComponent('/dashboard/generate'))
  }

  const handleSecondary = () => {
    navigate('/tools/campaign-generator')
  }

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-purple-600 via-purple-700 to-purple-900 py-20 md:py-28">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 left-10 w-72 h-72 rounded-full bg-purple-500/20 blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-purple-400/10 blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-48 opacity-5">
          <div className="grid grid-cols-7 gap-3">
            {Array.from({ length: 7 }).map((_, i) => (
              <div key={i} className="h-32 rounded-xl bg-white" />
            ))}
          </div>
        </div>
      </div>

      <div className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight leading-tight">
          Your next content week is one brief away.
        </h2>
        <p className="mt-6 text-lg text-purple-200 max-w-xl mx-auto leading-relaxed">
          Build a structured, brand-aware social media campaign without starting from a blank page every day.
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={handlePrimary}
            className="inline-flex items-center gap-2 bg-white text-purple-700 font-semibold px-8 py-3.5 rounded-xl shadow-xl hover:shadow-2xl hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 text-base"
          >
            Create My First Campaign
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={handleSecondary}
            className="inline-flex items-center gap-2 text-white font-semibold px-8 py-3.5 rounded-xl border border-purple-400/50 hover:bg-purple-600/40 transition-all duration-200 text-base"
          >
            Explore the Demo
          </button>
        </div>
      </div>
    </section>
  )
}
