from __future__ import annotations

from enum import Enum


class Tone(str, Enum):
    PROFESSIONAL = "professional"
    FUNNY = "funny"
    LUXURY = "luxury"
    GEN_Z = "gen_z"
    MOTIVATIONAL = "motivational"
    CASUAL = "casual"
    BOLD = "bold"

    @classmethod
    def values(cls) -> list[str]:
        return [t.value for t in cls]


class Platform(str, Enum):
    INSTAGRAM = "instagram"
    LINKEDIN = "linkedin"
    TIKTOK = "tiktok"
    FACEBOOK = "facebook"
    X = "x"

    @classmethod
    def values(cls) -> list[str]:
        return [p.value for p in cls]


class CampaignGoal(str, Enum):
    BRAND_AWARENESS = "brand_awareness"
    ENGAGEMENT = "engagement"
    SALES = "sales"
    EDUCATION = "education"
    LEAD_GENERATION = "lead_generation"
    COMMUNITY_BUILDING = "community_building"


class ContentType(str, Enum):
    REEL = "reel"
    CAROUSEL = "carousel"
    STATIC_POST = "static_post"
    STORY = "story"
    SHORT_VIDEO = "short_video"
    THREAD = "thread"
