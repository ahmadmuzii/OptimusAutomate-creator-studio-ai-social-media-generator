from __future__ import annotations

from unittest.mock import AsyncMock, patch


class TestSourceDocuments:
    def test_create_pasted_text(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Our product has amazing features that save time and money."},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["source_type"] == "text"
        assert data["pasted_text"] == "Our product has amazing features that save time and money."
        assert data["title"] == ""
        assert len(data["facts"]) > 0

    def test_create_url(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        with patch(
            "app.services.source_fetch_service.SourceFetchService.fetch_url", new_callable=AsyncMock
        ) as mock_fetch:
            mock_fetch.return_value = {
                "title": "Product Page",
                "text": "Our product features fast processing and reliable performance.",
            }
            response = client.post(
                f"/api/v1/brands/{brand_id}/source-documents",
                json={"source_type": "url", "original_url": "https://example.com/product"},
                headers=auth_headers,
            )
        assert response.status_code == 200
        data = response.json()
        assert data["source_type"] == "url"
        assert data["original_url"] == "https://example.com/product"
        assert data["title"] == "Product Page"
        assert len(data["facts"]) > 0

    def test_create_url_fetch_error(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        with patch(
            "app.services.source_fetch_service.SourceFetchService.fetch_url", new_callable=AsyncMock
        ) as mock_fetch:
            mock_fetch.return_value = {"title": "", "text": "", "error": "Request timed out"}
            response = client.post(
                f"/api/v1/brands/{brand_id}/source-documents",
                json={"source_type": "url", "original_url": "https://example.com/slow"},
                headers=auth_headers,
            )
        assert response.status_code == 400

    def test_list_source_documents(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Our product has amazing features."},
            headers=auth_headers,
        )
        response = client.get(
            f"/api/v1/brands/{brand_id}/source-documents",
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 1
        assert any(d["source_type"] == "text" for d in data)

    def test_get_single_document(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Our product has amazing features."},
            headers=auth_headers,
        )
        doc_id = create_resp.json()["id"]
        response = client.get(
            f"/api/v1/brands/{brand_id}/source-documents/{doc_id}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert response.json()["id"] == doc_id

    def test_document_not_found(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.get(
            f"/api/v1/brands/{brand_id}/source-documents/99999",
            headers=auth_headers,
        )
        assert response.status_code == 404

    def test_update_fact_approve(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Our product has amazing features that save time and money."},
            headers=auth_headers,
        )
        fact_id = create_resp.json()["facts"][0]["id"]
        response = client.patch(
            f"/api/v1/brands/{brand_id}/source-documents/facts/{fact_id}",
            json={"approved_by_user": True},
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert response.json()["approved_by_user"] is True

    def test_update_fact_exclude(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Our product has amazing features that save time and money."},
            headers=auth_headers,
        )
        fact_id = create_resp.json()["facts"][0]["id"]
        response = client.patch(
            f"/api/v1/brands/{brand_id}/source-documents/facts/{fact_id}",
            json={"excluded_by_user": True},
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert response.json()["excluded_by_user"] is True

    def test_update_fact_not_found(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.patch(
            f"/api/v1/brands/{brand_id}/source-documents/facts/99999",
            json={"approved_by_user": True},
            headers=auth_headers,
        )
        assert response.status_code == 404

    def test_delete_document(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Our product has amazing features."},
            headers=auth_headers,
        )
        doc_id = create_resp.json()["id"]
        response = client.delete(
            f"/api/v1/brands/{brand_id}/source-documents/{doc_id}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        assert response.json()["detail"] == "Source document deleted"

        get_resp = client.get(
            f"/api/v1/brands/{brand_id}/source-documents/{doc_id}",
            headers=auth_headers,
        )
        assert get_resp.status_code == 404

    def test_delete_document_not_found(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.delete(
            f"/api/v1/brands/{brand_id}/source-documents/99999",
            headers=auth_headers,
        )
        assert response.status_code == 404

    def test_cross_user_access_prevention(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Our product has amazing features."},
            headers=auth_headers,
        )
        doc_id = create_resp.json()["id"]

        response = client.get(
            f"/api/v1/brands/{brand_id}/source-documents/{doc_id}",
            headers=second_auth_headers,
        )
        assert response.status_code == 404

    def test_reextract_document_text(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Old text with features."},
            headers=auth_headers,
        )
        doc_id = create_resp.json()["id"]

        response = client.post(
            f"/api/v1/brands/{brand_id}/source-documents/{doc_id}/extract",
            json={"text": "New text with advanced features and benefits."},
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert "advanced features" in data["extracted_text"]
        assert len(data["facts"]) > 0

    def test_reextract_document_url(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        with patch(
            "app.services.source_fetch_service.SourceFetchService.fetch_url", new_callable=AsyncMock
        ) as mock_fetch:
            mock_fetch.return_value = {
                "title": "Original Page",
                "text": "Original text with features.",
            }
            create_resp = client.post(
                f"/api/v1/brands/{brand_id}/source-documents",
                json={"source_type": "url", "original_url": "https://example.com/original"},
                headers=auth_headers,
            )
        doc_id = create_resp.json()["id"]

        with patch(
            "app.services.source_fetch_service.SourceFetchService.fetch_url", new_callable=AsyncMock
        ) as mock_fetch:
            mock_fetch.return_value = {
                "title": "Updated Page",
                "text": "Re-extracted text with powerful features and amazing benefits.",
            }
            response = client.post(
                f"/api/v1/brands/{brand_id}/source-documents/{doc_id}/extract",
                json={},
                headers=auth_headers,
            )
        assert response.status_code == 200
        data = response.json()
        assert data["title"] == "Updated Page"
        assert "Re-extracted text" in data["extracted_text"]

    def test_reextract_document_not_found(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.post(
            f"/api/v1/brands/{brand_id}/source-documents/99999/extract",
            json={"text": "new text"},
            headers=auth_headers,
        )
        assert response.status_code == 404

    def test_invalid_source_type(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "invalid", "pasted_text": "text"},
            headers=auth_headers,
        )
        assert response.status_code == 400

    def test_url_missing_original_url(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "url"},
            headers=auth_headers,
        )
        assert response.status_code == 400

    def test_text_missing_pasted_text(self, client, auth_headers, created_brand):
        brand_id = created_brand["id"]
        response = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text"},
            headers=auth_headers,
        )
        assert response.status_code == 400

    def test_cross_user_cannot_list(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Our product has amazing features."},
            headers=auth_headers,
        )
        response = client.get(
            f"/api/v1/brands/{brand_id}/source-documents",
            headers=second_auth_headers,
        )
        assert response.status_code == 404

    def test_cross_user_cannot_delete(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Our product has amazing features."},
            headers=auth_headers,
        )
        doc_id = create_resp.json()["id"]

        response = client.delete(
            f"/api/v1/brands/{brand_id}/source-documents/{doc_id}",
            headers=second_auth_headers,
        )
        assert response.status_code == 404

    def test_cross_user_cannot_patch_fact(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Our product has amazing features."},
            headers=auth_headers,
        )
        fact_id = create_resp.json()["facts"][0]["id"]

        response = client.patch(
            f"/api/v1/brands/{brand_id}/source-documents/facts/{fact_id}",
            json={"approved_by_user": True},
            headers=second_auth_headers,
        )
        assert response.status_code == 404

    def test_cross_user_cannot_reextract(self, client, auth_headers, second_auth_headers, created_brand):
        brand_id = created_brand["id"]
        create_resp = client.post(
            f"/api/v1/brands/{brand_id}/source-documents",
            json={"source_type": "text", "pasted_text": "Our product has amazing features."},
            headers=auth_headers,
        )
        doc_id = create_resp.json()["id"]

        response = client.post(
            f"/api/v1/brands/{brand_id}/source-documents/{doc_id}/extract",
            json={"text": "updated text"},
            headers=second_auth_headers,
        )
        assert response.status_code == 404
