from __future__ import annotations

from collections.abc import AsyncGenerator

from app.services.calendar_service import CalendarService
from app.services.caption_service import CaptionService


async def get_caption_service() -> AsyncGenerator[CaptionService, None]:
    yield CaptionService()


async def get_calendar_service() -> AsyncGenerator[CalendarService, None]:
    yield CalendarService()
