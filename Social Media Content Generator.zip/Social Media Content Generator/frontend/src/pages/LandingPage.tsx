import { useEffect, useRef } from 'react'
import { LandingNavbar } from '@/components/landing/LandingNavbar'
import { HeroSection } from '@/components/landing/HeroSection'
import { TrustStrip } from '@/components/landing/TrustStrip'
import { BriefToWeekSection } from '@/components/landing/BriefToWeekSection'
import { StrategyMap } from '@/components/landing/StrategyMap'
import { PlatformLens } from '@/components/landing/PlatformLens'
import { BrandDNASection } from '@/components/landing/BrandDNASection'
import { BeforeAfterSection } from '@/components/landing/BeforeAfterSection'
import { CampaignBalance } from '@/components/landing/CampaignBalance'
import { FeatureGrid } from '@/components/landing/FeatureGrid'
import { ProductWalkthrough } from '@/components/landing/ProductWalkthrough'
import { LiveCampaignExample } from '@/components/landing/LiveCampaignExample'
import { UseCasesSection } from '@/components/landing/UseCasesSection'
import { WorkflowComparison } from '@/components/landing/WorkflowComparison'
import { FAQSection } from '@/components/landing/FAQSection'
import { FinalCTA } from '@/components/landing/FinalCTA'
import { LandingFooter } from '@/components/landing/LandingFooter'

export function LandingPage() {
  const metaRef = useRef<HTMLMetaElement | null>(null)

  useEffect(() => {
    document.title = 'AI Social Media Campaign Generator | Creator Studio'
    if (!metaRef.current) {
      let meta = document.querySelector('meta[name="description"]')
      if (!meta) {
        meta = document.createElement('meta')
        meta.setAttribute('name', 'description')
        document.head.appendChild(meta)
      }
      metaRef.current = meta as HTMLMetaElement
    }
    metaRef.current.setAttribute('content', 'Turn one brand brief into a complete seven-day social media campaign with platform-ready captions, CTAs, hashtags, post ideas, and a visual content calendar.')
  }, [])

  return (
    <div className="min-h-screen bg-white">
      <LandingNavbar />
      <HeroSection />
      <TrustStrip />
      <BriefToWeekSection />
      <StrategyMap />
      <PlatformLens />
      <BrandDNASection />
      <BeforeAfterSection />
      <CampaignBalance />
      <FeatureGrid />
      <ProductWalkthrough />
      <LiveCampaignExample />
      <UseCasesSection />
      <WorkflowComparison />
      <FAQSection />
      <FinalCTA />
      <LandingFooter />
    </div>
  )
}
