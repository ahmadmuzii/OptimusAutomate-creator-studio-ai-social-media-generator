from __future__ import annotations

import random

from app.logging_config import get_logger
from app.modules.hashtag_generator import generate_hashtags
from app.modules.platform_formatter import PLATFORMS
from app.services.llm_service import call_groq_for_caption
from app.utils.brand_name import preserve_brand_name

logger = get_logger("app.modules.caption_generator")

CTAS: dict[str, list[str]] = {
    "instagram": [
        "Follow for more content like this",
        "Save this post for later",
        "Tag a friend who needs to see this",
        "Drop a comment with your thoughts",
        "Share this with your community",
    ],
    "linkedin": [
        "Share your perspective in the comments",
        "What's your experience with this?",
        "Follow for more industry insights",
        "Agree or disagree? Let's discuss below",
    ],
    "tiktok": [
        "Follow for more",
        "Duet this with your take",
        "Share this with someone who needs it",
    ],
    "facebook": [
        "Tag someone who would love this",
        "Tell us what you think below",
        "Share this with your friends",
    ],
    "x": [
        "Retweet if you agree",
        "Reply with your thoughts",
        "Share this with your network",
    ],
}


def _build_caption_text(
    post_idea: str,
    platform: str,
    tone: str,
    brand_details: dict,
) -> str:
    brand_name = brand_details.get("brandName", "the brand")
    niche = brand_details.get("niche", "this space")
    audience = brand_details.get("targetAudience", "our community")
    goal = brand_details.get("campaignGoal", "grow")

    max_chars = PLATFORMS.get(platform, {}).get("max_caption_chars", 2200)

    caption = (
        f"At {brand_name}, we understand {audience} because we're focused on "
        f"one thing: delivering exceptional value in the {niche} space. "
        f"{post_idea}. "
        f"Our goal is to help you {goal.replace('_', ' ')} "
        f"with content and solutions that actually matter."
    )

    if len(caption) > max_chars:
        caption = caption[: max_chars - 20].rsplit(" ", 1)[0] + "..."

    return caption


def _build_cta(platform: str, tone: str, brand_name: str) -> str:
    pool = CTAS.get(platform, CTAS["instagram"])
    cta = random.choice(pool)
    return cta


def generate_caption(
    post_idea: str,
    platform: str,
    tone: str,
    brand_details: dict,
) -> str:
    if platform not in PLATFORMS:
        raise ValueError(f"Unsupported platform: {platform}")

    brand_name = brand_details.get("brandName", "")

    ai_result = call_groq_for_caption(post_idea, platform, tone, brand_details)
    if ai_result and ai_result.get("caption"):
        caption = ai_result["caption"]
        if brand_name:
            caption = preserve_brand_name(caption, brand_name)
        logger.info("caption_generated_via_groq", platform=platform, tone=tone)
        return caption

    logger.info("caption_generated_via_fallback", platform=platform, tone=tone)
    caption = _build_caption_text(post_idea, platform, tone, brand_details)
    if brand_name:
        caption = preserve_brand_name(caption, brand_name)
    return caption


def generate_caption_with_cta(
    post_idea: str,
    platform: str,
    tone: str,
    brand_details: dict,
) -> dict:
    if platform not in PLATFORMS:
        raise ValueError(f"Unsupported platform: {platform}")

    brand_name = brand_details.get("brandName", "")

    ai_result = call_groq_for_caption(post_idea, platform, tone, brand_details)
    if ai_result and ai_result.get("caption"):
        caption = ai_result["caption"]
        cta = ai_result.get("callToAction", "")
        hashtags = ai_result.get("hashtags", [])
        if brand_name:
            caption = preserve_brand_name(caption, brand_name)
            cta = preserve_brand_name(cta, brand_name)
        logger.info("caption_with_cta_generated_via_groq", platform=platform, tone=tone)
        return {
            "caption": caption,
            "callToAction": cta,
            "hashtags": hashtags,
        }

    caption = _build_caption_text(post_idea, platform, tone, brand_details)
    if brand_name:
        caption = preserve_brand_name(caption, brand_name)
    cta = _build_cta(platform, tone, brand_name or "the brand")

    hashtags = generate_hashtags(
        niche=brand_details.get("niche", "general"),
        platform=platform,
        campaign_goal=brand_details.get("campaignGoal", "engagement"),
        brand_name=brand_name,
        count=6,
        post_topic=post_idea,
        target_audience=brand_details.get("targetAudience", ""),
    )

    return {
        "caption": caption,
        "callToAction": cta,
        "hashtags": hashtags,
    }
