from __future__ import annotations

import datetime

from pydantic import BaseModel, ConfigDict


class SourceFactResponse(BaseModel):
    id: int
    category: str
    label: str
    value: str
    source_section: str | None = None
    confidence: float | None = None
    approved_by_user: bool = False
    excluded_by_user: bool = False

    model_config = ConfigDict(from_attributes=True)


class SourceFactUpdate(BaseModel):
    approved_by_user: bool | None = None
    excluded_by_user: bool | None = None


class SourceDocumentCreate(BaseModel):
    source_type: str
    original_url: str | None = None
    pasted_text: str | None = None
    brand_id: int | None = None


class SourceDocumentResponse(BaseModel):
    id: int
    user_id: int
    brand_id: int | None = None
    source_type: str
    original_url: str | None = None
    pasted_text: str | None = None
    title: str | None = None
    extracted_text: str | None = None
    created_at: datetime.datetime
    facts: list[SourceFactResponse] = []

    model_config = ConfigDict(from_attributes=True)


class ExtractRequest(BaseModel):
    url: str | None = None
    text: str | None = None


class ExtractResponse(BaseModel):
    document: SourceDocumentResponse
