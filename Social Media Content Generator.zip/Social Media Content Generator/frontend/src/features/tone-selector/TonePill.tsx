import type { ToneConfig } from '@/config/tones'
import { cn } from '@/utils/cn'

interface TonePillProps {
  tone: ToneConfig
  isSelected: boolean
  onSelect: (id: string) => void
}

export function TonePill({ tone, isSelected, onSelect }: TonePillProps) {
  return (
    <button
      onClick={() => onSelect(tone.id)}
      className={cn(
        'px-5 py-2.5 rounded-full text-sm font-medium border-2 cursor-pointer transition-all duration-200 select-none',
        isSelected
          ? 'bg-gradient-to-r from-purple-600 via-purple-700 to-purple-900 text-white border-transparent shadow-md shadow-purple-500/25'
          : 'bg-white text-gray-600 border-gray-200 hover:border-purple-300 hover:text-purple-700',
      )}
    >
      <span className="mr-1.5">{tone.emoji}</span>
      {tone.label}
    </button>
  )
}
