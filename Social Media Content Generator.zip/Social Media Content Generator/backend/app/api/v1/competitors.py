from __future__ import annotations

import datetime

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps_auth import require_current_user
from app.api.deps_features import require_feature
from app.database import get_db
from app.exceptions import NotFoundError
from app.models.competitor_schemas import (
    CompetitorPostCreate,
    CompetitorPostResponse,
    CompetitorProfileCreate,
    CompetitorProfileResponse,
    CompetitorProfileUpdate,
    GapReportAnalytics,
    GapReportResponse,
)
from app.models.db_models import (
    BrandProfile,
    CompetitorPost,
    CompetitorProfile,
    ContentGapReport,
    User,
)
from app.services.gap_analysis_service import GapAnalysisService

router = APIRouter(
    prefix="/brands/{brand_id}/competitors",
    tags=["Competitors"],
    dependencies=[require_feature("competitor_gaps")],
)


def _get_brand_or_404(db: Session, brand_id: int, user_id: int) -> BrandProfile:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    if not brand or brand.user_id != user_id:
        raise NotFoundError("Brand not found")
    return brand


@router.get("", response_model=list[CompetitorProfileResponse])
def list_competitors(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    competitors = (
        db.query(CompetitorProfile)
        .filter(CompetitorProfile.brand_id == brand_id)
        .order_by(CompetitorProfile.created_at.desc())
        .all()
    )
    return competitors


@router.post("", response_model=CompetitorProfileResponse)
def create_competitor(
    brand_id: int,
    request: CompetitorProfileCreate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    competitor = CompetitorProfile(brand_id=brand_id, **request.model_dump())
    db.add(competitor)
    db.commit()
    db.refresh(competitor)
    return competitor


@router.post("/analyze-gaps", response_model=GapReportAnalytics)
def analyze_gaps(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    service = GapAnalysisService(db)
    report_data = service.analyze(brand_id, current_user.id)
    return report_data


@router.get("/gap-reports", response_model=list[GapReportResponse])
def list_gap_reports(
    brand_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    reports = (
        db.query(ContentGapReport)
        .filter(ContentGapReport.brand_id == brand_id)
        .order_by(ContentGapReport.created_at.desc())
        .all()
    )
    return reports


@router.get("/{comp_id}", response_model=CompetitorProfileResponse)
def get_competitor(
    brand_id: int,
    comp_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    competitor = (
        db.query(CompetitorProfile)
        .filter(CompetitorProfile.id == comp_id, CompetitorProfile.brand_id == brand_id)
        .first()
    )
    if not competitor:
        raise NotFoundError("Competitor not found")
    return competitor


@router.put("/{comp_id}", response_model=CompetitorProfileResponse)
def update_competitor(
    brand_id: int,
    comp_id: int,
    request: CompetitorProfileUpdate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    competitor = (
        db.query(CompetitorProfile)
        .filter(CompetitorProfile.id == comp_id, CompetitorProfile.brand_id == brand_id)
        .first()
    )
    if not competitor:
        raise NotFoundError("Competitor not found")

    update_data = request.model_dump(exclude_none=True)
    for key, value in update_data.items():
        setattr(competitor, key, value)
    db.commit()
    db.refresh(competitor)
    return competitor


@router.delete("/{comp_id}")
def delete_competitor(
    brand_id: int,
    comp_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    competitor = (
        db.query(CompetitorProfile)
        .filter(CompetitorProfile.id == comp_id, CompetitorProfile.brand_id == brand_id)
        .first()
    )
    if not competitor:
        raise NotFoundError("Competitor not found")
    db.delete(competitor)
    db.commit()
    return {"detail": "Competitor deleted"}


@router.get("/{comp_id}/posts", response_model=list[CompetitorPostResponse])
def list_competitor_posts(
    brand_id: int,
    comp_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    competitor = (
        db.query(CompetitorProfile)
        .filter(CompetitorProfile.id == comp_id, CompetitorProfile.brand_id == brand_id)
        .first()
    )
    if not competitor:
        raise NotFoundError("Competitor not found")
    posts = (
        db.query(CompetitorPost)
        .filter(CompetitorPost.competitor_id == comp_id)
        .order_by(CompetitorPost.created_at.desc())
        .all()
    )
    return posts


@router.post("/{comp_id}/posts", response_model=CompetitorPostResponse)
def create_competitor_post(
    brand_id: int,
    comp_id: int,
    request: CompetitorPostCreate,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    competitor = (
        db.query(CompetitorProfile)
        .filter(CompetitorProfile.id == comp_id, CompetitorProfile.brand_id == brand_id)
        .first()
    )
    if not competitor:
        raise NotFoundError("Competitor not found")

    pub_date = None
    if request.publication_date:
        try:
            pub_date = datetime.datetime.fromisoformat(request.publication_date)
        except (ValueError, TypeError):
            pass

    post = CompetitorPost(
        competitor_id=comp_id,
        caption=request.caption,
        content_type=request.content_type,
        platform=request.platform,
        cta_style=request.cta_style,
        hook_type=request.hook_type,
        topics=request.topics,
        publication_date=pub_date,
        engagement_metrics=request.engagement_metrics,
    )
    db.add(post)
    db.commit()
    db.refresh(post)
    return post


@router.delete("/posts/{post_id}")
def delete_competitor_post(
    brand_id: int,
    post_id: int,
    current_user: User = Depends(require_current_user),
    db: Session = Depends(get_db),
):
    _get_brand_or_404(db, brand_id, current_user.id)
    post = (
        db.query(CompetitorPost)
        .join(CompetitorProfile)
        .filter(
            CompetitorPost.id == post_id,
            CompetitorProfile.brand_id == brand_id,
        )
        .first()
    )
    if not post:
        raise NotFoundError("Post not found")
    db.delete(post)
    db.commit()
    return {"detail": "Post deleted"}
