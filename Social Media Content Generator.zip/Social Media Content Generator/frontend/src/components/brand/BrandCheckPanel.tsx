import { useState } from 'react'
import { Shield, CheckCircle, AlertTriangle, XCircle, RefreshCw, Loader2 } from 'lucide-react'
import type { BrandCheckResult } from '@/types/guardrails'

interface Props {
  brandId: number
  onRunCheck?: (brandId: number) => Promise<BrandCheckResult>
}

export function BrandCheckPanel({ brandId, onRunCheck }: Props) {
  const [result, setResult] = useState<BrandCheckResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleRunCheck = async () => {
    if (!onRunCheck) return
    setLoading(true)
    setError(null)
    try {
      const res = await onRunCheck(brandId)
      setResult(res)
    } catch {
      setError('Failed to run brand check.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="p-5 border-b border-gray-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-purple-600" />
          <h3 className="font-semibold text-gray-900">Brand Check</h3>
        </div>
        <button
          onClick={handleRunCheck}
          disabled={loading}
          className="flex items-center gap-1.5 text-sm font-medium text-purple-600 hover:text-purple-800 disabled:opacity-50 transition-colors"
        >
          {loading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4" />
          )}
          {loading ? 'Checking...' : 'Run Check'}
        </button>
      </div>

      {error && (
        <div className="p-4 bg-red-50 text-sm text-red-600">{error}</div>
      )}

      {result && (
        <div className="p-5 space-y-3">
          <div className="flex items-center gap-3 mb-4">
            <div className={`flex items-center gap-1.5 text-sm font-semibold px-3 py-1.5 rounded-full ${
              result.status === 'passed' ? 'bg-green-50 text-green-700' :
              result.status === 'warning' ? 'bg-yellow-50 text-yellow-700' :
              'bg-red-50 text-red-700'
            }`}>
              {result.status === 'passed' ? <CheckCircle className="w-4 h-4" /> :
               result.status === 'warning' ? <AlertTriangle className="w-4 h-4" /> :
               <XCircle className="w-4 h-4" />}
              {result.summary.passed} passed &middot; {result.summary.warnings} warnings &middot; {result.summary.blocked} blocked
            </div>
          </div>

          <div className="space-y-2">
            {result.checks.map((check) => (
              <div
                key={check.code}
                className={`flex items-start gap-3 p-3 rounded-xl text-sm ${
                  check.status === 'passed' ? 'bg-green-50/50' :
                  check.status === 'warning' ? 'bg-yellow-50/50' :
                  'bg-red-50/50'
                }`}
              >
                {check.status === 'passed' ? (
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 shrink-0" />
                ) : check.status === 'warning' ? (
                  <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5 shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-600 mt-0.5 shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-gray-900">{check.label}</span>
                    <span className={`text-xs font-medium px-1.5 py-0.5 rounded-full ${
                      check.status === 'passed' ? 'bg-green-100 text-green-700' :
                      check.status === 'warning' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {check.status}
                    </span>
                  </div>
                  <p className="text-gray-500 mt-0.5">{check.message}</p>
                  {check.matched_text && (
                    <p className="text-xs text-gray-400 mt-1">
                      Matched: &ldquo;{check.matched_text}&rdquo;
                      {check.post_id ? ` (Post ${check.post_id})` : ''}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {!result && !error && (
        <div className="p-8 text-center">
          <Shield className="w-8 h-8 text-gray-300 mx-auto mb-2" />
          <p className="text-sm text-gray-400">
            Run a brand check to evaluate content against guardrails.
          </p>
        </div>
      )}
    </div>
  )
}
