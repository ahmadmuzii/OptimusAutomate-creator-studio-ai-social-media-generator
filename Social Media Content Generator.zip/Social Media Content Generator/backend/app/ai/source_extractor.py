from typing import Any

import structlog

from app.ai.groq_client import groq_json_chat
from app.ai.prompt_builder import (
    build_source_extraction_system_prompt,
    build_source_extraction_user_prompt,
)
from app.ai.response_schemas import SourceExtractionResult

logger = structlog.get_logger(__name__)


def extract_facts_with_groq(
    title: str,
    text: str,
) -> dict[str, Any]:
    system = build_source_extraction_system_prompt()
    user = build_source_extraction_user_prompt(title, text)

    raw = groq_json_chat(
        system_prompt=system,
        user_prompt=user,
        temperature=0.3,
        max_tokens=8192,
    )

    if raw is None:
        logger.info("Groq extraction returned None, using fallback")
        return _fallback_extraction(title, text)

    try:
        validated = SourceExtractionResult(**raw)
        return {
            "document_title": validated.document_title or title,
            "facts": [f.model_dump() for f in validated.facts],
            "extraction_source": "groq",
        }
    except Exception as e:
        logger.warning("Groq extraction validation failed, retrying once", error=str(e))
        raw2 = groq_json_chat(
            system_prompt=system
            + "\n\nYour previous response failed validation. Ensure all fields are correct and JSON is valid.",
            user_prompt=user,
            temperature=0.3,
            max_tokens=8192,
        )
        if raw2:
            try:
                validated = SourceExtractionResult(**raw2)
                return {
                    "document_title": validated.document_title or title,
                    "facts": [f.model_dump() for f in validated.facts],
                    "extraction_source": "groq",
                }
            except Exception as e2:
                logger.warning("Groq extraction retry also failed", error=str(e2))

    logger.info("Groq extraction failed, using fallback")
    return _fallback_extraction(title, text)


CATEGORY_KEYWORDS: dict[str, list[str]] = {
    "product_features": [
        "product",
        "feature",
        "includes",
        "contains",
        "formulated",
        "ingredients",
        "specification",
        "dimensions",
        "material",
        "flavor",
        "variant",
    ],
    "brand_voice": [
        "mission",
        "vision",
        "values",
        "brand",
        "identity",
        "voice",
        "tone",
        "personality",
        "story",
        "founded",
        "origin",
    ],
    "pain_points": [
        "struggle",
        "frustration",
        "problem",
        "difficult",
        "challenge",
        "pain point",
        "hard to",
        "difficult to",
        "waste",
    ],
    "value_props": [
        "benefit",
        "value",
        "advantage",
        "solution",
        "helps",
        "improve",
        "save",
        "increase",
        "reduce",
        "fast",
        "easy",
        "convenient",
    ],
    "testimonials": [
        "review",
        "testimonial",
        "quote",
        "customer said",
        "user said",
        "recommend",
        "love",
        "rating",
        "stars",
    ],
    "case_studies": [
        "case study",
        "result",
        "achieved",
        "before and after",
        "measurement",
        "increase of",
        "decrease of",
        "roi",
    ],
}


def _fallback_extraction(title: str, text: str) -> dict[str, Any]:
    import re

    sentences = re.split(r"(?<=[.!?])\s+", text[:10000])
    facts: list[dict[str, Any]] = []
    seen_values: set[str] = set()

    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence or len(sentence) < 15:
            continue

        matched_category: str | None = None
        for category, keywords in CATEGORY_KEYWORDS.items():
            if any(kw.lower() in sentence.lower() for kw in keywords):
                matched_category = category
                break

        if matched_category is None:
            matched_category = "other"

        preview = sentence[:80]
        if preview in seen_values:
            continue
        seen_values.add(preview)

        facts.append(
            {
                "category": matched_category,
                "label": preview[:100],
                "value": sentence[:1000],
                "source_excerpt": sentence[:500],
                "confidence": 0.4,
            }
        )

    if not facts:
        facts.append(
            {
                "category": "other",
                "label": "Source content",
                "value": text[:1000],
                "source_excerpt": text[:500],
                "confidence": 0.3,
            }
        )

    return {
        "document_title": title or "Extracted Document",
        "facts": facts,
        "extraction_source": "fallback",
    }
