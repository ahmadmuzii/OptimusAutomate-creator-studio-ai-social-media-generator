from __future__ import annotations

import os

import pytest
from fastapi.testclient import TestClient


@pytest.mark.skipif(not os.environ.get("GROQ_API_KEY"), reason="GROQ_API_KEY not set")
class TestCaptions:
    def test_generate_caption_success(self, client: TestClient, sample_caption_payload: dict) -> None:
        response = client.post("/api/v1/generate-caption", json=sample_caption_payload)
        assert response.status_code == 200
        data = response.json()
        assert "caption" in data
        assert "hashtags" in data
        assert isinstance(data["hashtags"], list)
        assert len(data["caption"]) > 0

    def test_generate_caption_invalid_platform(self, client: TestClient, sample_caption_payload: dict) -> None:
        payload = {**sample_caption_payload, "platform": "Snapchat"}
        response = client.post("/api/v1/generate-caption", json=payload)
        assert response.status_code == 400

    def test_generate_caption_invalid_tone(self, client: TestClient, sample_caption_payload: dict) -> None:
        payload = {**sample_caption_payload, "tone": "depressing"}
        response = client.post("/api/v1/generate-caption", json=payload)
        assert response.status_code == 400
