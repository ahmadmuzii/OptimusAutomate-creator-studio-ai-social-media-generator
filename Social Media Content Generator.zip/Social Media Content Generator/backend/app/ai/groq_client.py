import json
import re
from dataclasses import dataclass
from typing import Any, cast

import structlog
import tiktoken

from app.config import settings

logger = structlog.get_logger(__name__)

_GROQ_INSTALLED = False
try:
    from groq import Groq
    _GROQ_INSTALLED = True
except ImportError:
    Groq = None
_GROQ_CLIENT = None

@dataclass
class TokenEstimate:
    input_tokens: int
    max_output_tokens: int
    estimated_total_tokens: int

    def __str__(self) -> str:
        return (
            f"input_tokens={self.input_tokens}, "
            f"max_output_tokens={self.max_output_tokens}, "
            f"estimated_total_tokens={self.estimated_total_tokens}"
        )


def _get_tokenizer_for_model(model: str | None) -> Any:
    if model is None:
        model = settings.groq_model
    try:
        encoding_name = _get_encoding_name_for_model(model)
        return tiktoken.get_encoding(encoding_name)
    except Exception:
        return tiktoken.get_encoding("cl100k_base")


def _get_encoding_name_for_model(model: str) -> str:
    model_lower = model.lower()
    if "llama-3.1-8b" in model_lower or "llama-3.1-70b" in model_lower:
        return "cl100k_base"
    if "llama-3.3" in model_lower:
        return "cl100k_base"
    if "gpt-4" in model_lower:
        return "cl100k_base"
    if "gpt-3.5" in model_lower:
        return "cl100k_base"
    return "cl100k_base"


def estimate_request_tokens(
    messages: list[dict[str, str]],
    max_output_tokens: int,
    model: str | None = None,
) -> TokenEstimate:
    if not messages:
        return TokenEstimate(input_tokens=0, max_output_tokens=max_output_tokens, estimated_total_tokens=max_output_tokens)
    
    try:
        encoding = _get_tokenizer_for_model(model)
        input_tokens = 0
        for message in messages:
            content = message.get("content", "")
            if isinstance(content, str):
                input_tokens += len(encoding.encode(content))

        estimated_total = input_tokens + max_output_tokens
        return TokenEstimate(
            input_tokens=input_tokens,
            max_output_tokens=max_output_tokens,
            estimated_total_tokens=estimated_total,
        )
    except Exception:
        input_tokens = sum(len(m.get("content", "")) // 4 for m in messages)
        estimated_total = input_tokens + max_output_tokens
        return TokenEstimate(
            input_tokens=input_tokens,
            max_output_tokens=max_output_tokens,
            estimated_total_tokens=estimated_total,
        )


def _make_groq_client():
    global _GROQ_CLIENT
    if _GROQ_CLIENT is not None:
        return _GROQ_CLIENT

    if not _GROQ_INSTALLED:
        logger.warning("groq SDK is not installed")
        _GROQ_CLIENT = None
        return None
    if not settings.groq_api_key:
        logger.warning("GROQ_API_KEY is not configured")
        _GROQ_CLIENT = None
        return None

    try:
        _GROQ_CLIENT = Groq(api_key=settings.groq_api_key)
        return _GROQ_CLIENT
    except Exception as e:
        logger.error("Failed to create Groq client", error=str(e))
        _GROQ_CLIENT = None
        return None


def _estimate_message_tokens(messages: list[dict[str, str]]) -> int:
    """Estimate token count for chat messages.

    This is a more precise estimation that accounts for message structure
    and system prompts. This matches how the Groq API actually counts tokens.
    """
    try:
        encoding = _get_tokenizer_for_model(None)
        total_tokens = 0

        for message in messages:
            role = message.get("role", "user")
            content = message.get("content", "")

            role_tokens = len(encoding.encode(role))
            total_tokens += role_tokens

            if isinstance(content, str):
                content_tokens = len(encoding.encode(content))
                total_tokens += content_tokens + 4
            elif isinstance(content, dict) and "function_call" in content:
                function_tokens = len(encoding.encode(str(content)))
                total_tokens += function_tokens + 6

        if messages:
            total_tokens += 3

        return max(total_tokens, 0)
    except Exception:
        return len(str(messages)) * 10


def _validate_request_budget(
    request_type: str,
    messages: list[dict[str, str]],
    max_output_tokens: int,
    model: str | None = None,
) -> tuple[bool, TokenEstimate]:
    estimate = estimate_request_tokens(messages, max_output_tokens, model)

    if estimate.estimated_total_tokens > settings.groq_tpm_budget:
        logger.error(
            "Request exceeds token budget",
            request_type=request_type,
            model=model or settings.groq_model,
            estimated_input_tokens=estimate.input_tokens,
            max_output_tokens=estimate.max_output_tokens,
            estimated_total_tokens=estimate.estimated_total_tokens,
            budget=settings.groq_tpm_budget,
        )
        return False, estimate

    logger.info(
        "Groq request token estimate",
        request_type=request_type,
        model=model or settings.groq_model,
        estimated_input_tokens=estimate.input_tokens,
        max_output_tokens=estimate.max_output_tokens,
        estimated_total_tokens=estimate.estimated_total_tokens,
        budget=settings.groq_tpm_budget,
    )
    return True, estimate


def _should_retry_error(error: Exception) -> bool:
    error_str = str(error).lower()

    if any(code in error_str for code in ["400", "401", "403", "404", "413"]):
        return False

    if any(code in error_str for code in ["408", "429", "500", "502", "503", "504"]):
        return True

    return True


def groq_json_chat(
    system_prompt: str,
    user_prompt: str,
    model: str | None = None,
    temperature: float = 0.7,
    max_tokens: int = 4096,
    retries: int | None = None,
    request_type: str = "generic",
) -> dict[str, Any] | None:
    if not settings.groq_enabled:
        logger.info("Groq is disabled via GROQ_ENABLED")
        return None

    client = _make_groq_client()
    if client is None:
        return None

    model_to_use = model or settings.groq_model
    max_attempts = retries if retries is not None else settings.groq_max_retries

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]

    valid_budget, estimate = _validate_request_budget(
        request_type, messages, max_tokens, model_to_use,
    )
    if not valid_budget:
        logger.error(
            "Request rejected due to token budget",
            request_type=request_type,
            estimated_total_tokens=estimate.estimated_total_tokens,
            budget=settings.groq_tpm_budget,
        )
        return None

    attempt = 0

    while attempt <= max_attempts:
        try:
            response = client.chat.completions.create(
                model=model_to_use,
                messages=messages,
                response_format={"type": "json_object"},
                temperature=temperature,
                max_tokens=max_tokens,
                timeout=settings.groq_timeout_seconds,
            )

            content = response.choices[0].message.content
            if not content:
                logger.warning("Groq returned empty response", attempt=attempt)
                attempt += 1
                continue

            parsed = json.loads(content)
            return parsed

        except json.JSONDecodeError as e:
            if attempt == max_attempts:
                logger.error("Groq returned invalid JSON after all retries", error=str(e))
                return None
            logger.warning("Groq returned invalid JSON, retrying", attempt=attempt, error=str(e))
            attempt += 1
            continue

        except Exception as e:
            if not _should_retry_error(e):
                logger.error("Permanent Groq error - not retrying", error=str(e))
                return None

            if attempt == max_attempts:
                logger.error("Groq failed after all retries", max_attempts=max_attempts, error=str(e))
                return None

            logger.warning(
                "Groq request failed, retrying",
                attempt=attempt,
                max_attempts=max_attempts,
                error=str(e),
            )
            attempt += 1

    logger.error("Groq failed after all retries", max_attempts=max_attempts)
    return None
