import type { CalendarDayColor } from '@/types/calendar'

const DAY_COLORS: CalendarDayColor[] = [
  'from-purple-500 to-purple-600',
  'from-violet-500 to-purple-600',
  'from-fuchsia-500 to-purple-600',
  'from-purple-600 to-indigo-600',
  'from-indigo-500 to-purple-600',
  'from-purple-500 to-violet-600',
  'from-fuchsia-600 to-purple-700',
]

export function getDayColor(day: number): CalendarDayColor {
  return DAY_COLORS[(day - 1) % DAY_COLORS.length]!
}

export function formatHashtags(hashtags: string[]): string {
  return hashtags.join(' ')
}

export function pluralize(count: number, singular: string, plural?: string): string {
  return count === 1 ? singular : (plural ?? `${singular}s`)
}
