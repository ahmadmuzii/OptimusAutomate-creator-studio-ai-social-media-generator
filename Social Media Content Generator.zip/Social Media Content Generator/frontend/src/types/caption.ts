export interface CaptionResponse {
  caption: string
  callToAction: string
  hashtags: string[]
}

export interface CaptionRequest {
  postIdea: string
  platform: string
  tone: string
  brandDetails: Record<string, string>
}

export interface CaptionCardData {
  id: number
  day: number
  platform: string
  caption: string
  callToAction: string
  hashtags: string[]
}
