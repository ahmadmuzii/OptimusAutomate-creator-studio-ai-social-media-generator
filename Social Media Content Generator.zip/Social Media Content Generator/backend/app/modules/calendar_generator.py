from __future__ import annotations

import random
from typing import Any

from app.logging_config import get_logger
from app.modules.hashtag_generator import generate_hashtags
from app.modules.platform_formatter import get_content_type_options, get_hashtag_range
from app.services.llm_service import call_groq
from app.utils.brand_name import validate_campaign_texts

logger = get_logger("app.modules.calendar_generator")

FALLBACK_TIMES = {
    "instagram": ["9:00 AM", "12:00 PM", "3:00 PM", "6:00 PM", "8:00 PM"],
    "linkedin": ["8:00 AM", "10:00 AM", "12:00 PM", "2:00 PM", "5:00 PM"],
    "tiktok": ["7:00 AM", "12:00 PM", "4:00 PM", "7:00 PM", "9:00 PM"],
    "facebook": ["9:00 AM", "1:00 PM", "4:00 PM", "7:00 PM", "9:00 PM"],
    "x": ["8:00 AM", "12:00 PM", "3:00 PM", "6:00 PM", "9:00 PM"],
}

FALLBACK_THEMES = [
    "Brand Introduction & Story",
    "Educational Deep Dive",
    "Solving a Common Pain Point",
    "Behind the Scenes & Brand Values",
    "Product or Service Spotlight",
    "Engagement & Community Interaction",
    "Weekly Roundup & Final CTA",
]


def _get_theme_for_day(day_num: int) -> str:
    return FALLBACK_THEMES[(day_num - 1) % len(FALLBACK_THEMES)]


def _build_fallback_calendar(
    brand_name: str,
    brand_description: str,
    niche: str,
    target_audience: str,
    platform: str,
    tone: str,
    campaign_goal: str,
    days: int = 7,
) -> list[dict[str, Any]]:
    content_types = get_content_type_options(platform)
    times = FALLBACK_TIMES.get(platform, FALLBACK_TIMES["instagram"])
    low_hashtag, high_hashtag = get_hashtag_range(platform)

    calendar = []

    for day_num in range(1, days + 1):
        theme = _get_theme_for_day(day_num)
        content_type = content_types[(day_num - 1) % len(content_types)]
        suggested_time = random.choice(times)

        msg = _build_fallback_caption(
            brand_name,
            brand_description,
            niche,
            target_audience,
            platform,
            tone,
            campaign_goal,
            day_num,
            theme,
        )

        hashtags = generate_hashtags(
            niche=niche,
            platform=platform,
            campaign_goal=campaign_goal,
            brand_name=brand_name,
            count=random.randint(low_hashtag, high_hashtag),
            post_topic=theme,
            target_audience=target_audience,
        )

        cta = _build_fallback_cta(platform, tone, brand_name, campaign_goal)

        calendar.append(
            {
                "day": day_num,
                "contentTheme": theme,
                "postIdea": msg["postIdea"],
                "contentType": content_type,
                "suggestedTime": suggested_time,
                "platform": platform,
                "caption": msg["caption"],
                "callToAction": cta,
                "hashtags": hashtags,
            }
        )

    return calendar


def _build_fallback_caption(
    brand_name: str,
    brand_description: str,
    niche: str,
    target_audience: str,
    platform: str,
    tone: str,
    campaign_goal: str,
    day: int,
    theme: str,
) -> dict[str, str]:
    short_desc = brand_description[:200] if len(brand_description) > 200 else brand_description

    day_idx = (day - 1) % 7 + 1

    post_ideas = {
        1: f"Introduce {brand_name} to the audience — who you are, what {niche} gap you fill, and why it matters",
        2: f"Share a valuable insight about {niche} that helps {target_audience} achieve more",
        3: f"Address a common challenge {target_audience} faces and show how {brand_name} solves it",
        4: f"Give a behind-the-scenes look at what makes {brand_name} authentic and trustworthy",
        5: f"Spotlight what {brand_name} offers — the product/service that delivers on the promise",
        6: f"Start a conversation with {target_audience} about {niche} and invite their input",
        7: f"Wrap up the week with key takeaways and a clear next step for {target_audience}",
    }

    captions = {
        1: (
            f"Meet {brand_name}. {short_desc} "
            f"We built this for {target_audience} — because you deserve better from your {niche} experience. "
            f"This week, we're sharing what makes us different and why we do what we do."
        ),
        2: (
            f"Here's something every {target_audience} should know about {niche}. "
            f"At {brand_name}, we believe knowledge is the first step to making better choices. "
            f"{short_desc.split('.')[0]}. Let's dive in."
        ),
        3: (
            f"Struggling with the same old {niche} problems? You're not alone. "
            f"{brand_name} was created because {target_audience} deserve solutions that actually work. "
            f"{short_desc.split('.')[0]} — designed to make your life easier."
        ),
        4: (
            f"Ever wonder what goes into building {brand_name}? "
            f"We're pulling back the curtain to show you the heart behind what we do. "
            f"Because {target_audience} deserve brands that are real, transparent, and built with purpose."
        ),
        5: (
            f"Let's talk about what {brand_name} brings to the table. "
            f"Built for {target_audience}, crafted with care in the {niche} space. "
            f"{short_desc.split('.')[0]}. See what makes it different."
        ),
        6: (
            f"We want to hear from {target_audience}. What's your biggest takeaway from {niche} so far? "
            f"At {brand_name}, we're not just talking at you — we're building with you. "
            f"Drop your thoughts below."
        ),
        7: (
            f"That's a wrap on this week with {brand_name}! "
            f"We've shared our story, our knowledge, and what drives us. "
            f"Now it's your turn. {target_audience}, let's keep building something great together in {niche}."
        ),
    }

    return {
        "postIdea": post_ideas.get(day_idx, post_ideas[1]),
        "caption": captions.get(day_idx, captions[1]),
    }


def _build_fallback_cta(
    platform: str,
    tone: str,
    brand_name: str,
    campaign_goal: str,
) -> str:
    ctas = {
        "instagram": [
            f"Follow @{brand_name.replace(' ', '').lower()} for more",
            "Save this post for later",
            "Tag a friend who needs to see this",
            "Drop a comment with your thoughts",
        ],
        "linkedin": [
            "Share your perspective below",
            f"Follow {brand_name} for more industry insights",
            "What's your experience with this? Comment below",
        ],
        "tiktok": [
            "Follow for more content like this",
            "Duet this with your take",
            "Share this with someone who needs it",
        ],
        "facebook": [
            "Tag someone who would love this",
            "Share this with your community",
            "Tell us what you think in the comments",
        ],
        "x": [
            "Retweet if you agree",
            "Reply with your thoughts",
            "Share this with your network",
        ],
    }
    pool = ctas.get(platform, ctas["instagram"])
    return random.choice(pool).format(brand_name=brand_name)


def _validate_ai_response(data: Any, days: int = 7) -> list[dict] | None:
    if not isinstance(data, dict):
        return None
    calendar = data.get("calendar")
    if not isinstance(calendar, list) or len(calendar) != days:
        return None

    required = {
        "day",
        "contentTheme",
        "postIdea",
        "contentType",
        "suggestedTime",
        "platform",
        "caption",
        "callToAction",
        "hashtags",
    }

    for item in calendar:
        if not isinstance(item, dict):
            return None
        missing = required - set(item.keys())
        if missing:
            logger.warning("ai_response_missing_fields", missing=list(missing))
            return None
        if not item.get("caption") or not item.get("callToAction"):
            return None
        if not isinstance(item.get("hashtags"), list):
            return None

    return calendar


def generate_calendar(
    brand_name: str,
    brand_description: str,
    niche: str,
    target_audience: str,
    platform: str,
    tone: str,
    campaign_goal: str,
    days: int = 7,
) -> tuple[list[dict[str, Any]], str]:
    ai_result = call_groq(
        brand_name=brand_name,
        brand_description=brand_description,
        niche=niche,
        target_audience=target_audience,
        platform=platform,
        tone=tone,
        campaign_goal=campaign_goal,
        days=days,
    )

    validated = _validate_ai_response(ai_result, days) if ai_result else None
    if validated:
        validated = validate_campaign_texts(validated, brand_name)
        logger.info("calendar_generated_via_groq", platform=platform, tone=tone, days=days)
        return validated, "groq"

    logger.info("calendar_generated_via_fallback", platform=platform, tone=tone, days=days)
    fallback = _build_fallback_calendar(
        brand_name=brand_name,
        brand_description=brand_description,
        niche=niche,
        target_audience=target_audience,
        platform=platform,
        tone=tone,
        campaign_goal=campaign_goal,
        days=days,
    )
    fallback = validate_campaign_texts(fallback, brand_name)
    return fallback, "fallback"
