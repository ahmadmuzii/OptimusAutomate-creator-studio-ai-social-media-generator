from __future__ import annotations

from fastapi import Depends, Header
from sqlalchemy.orm import Session

from app.database import get_db
from app.exceptions import AuthenticationError
from app.models.db_models import User
from app.services.auth_service import decode_access_token, get_user_by_id


def get_current_user(
    authorization: str = Header(None),
    db: Session = Depends(get_db),
) -> User | None:
    if not authorization:
        return None
    if not authorization.startswith("Bearer "):
        return None
    token = authorization[len("Bearer ") :]
    payload = decode_access_token(token)
    if payload is None:
        return None
    user_id = payload.get("sub")
    if user_id is None:
        return None
    try:
        user = get_user_by_id(db, int(user_id))
    except (ValueError, TypeError):
        return None
    return user


def require_current_user(
    authorization: str | None = Header(None),
    db: Session = Depends(get_db),
) -> User:
    if not authorization or not authorization.startswith("Bearer "):
        raise AuthenticationError()
    token = authorization[len("Bearer ") :]
    payload = decode_access_token(token)
    if payload is None:
        raise AuthenticationError()
    user_id = payload.get("sub")
    if user_id is None:
        raise AuthenticationError()
    try:
        user_id_int = int(user_id)
    except (ValueError, TypeError):
        raise AuthenticationError()
    user = get_user_by_id(db, user_id_int)
    if user is None:
        raise AuthenticationError()
    return user
