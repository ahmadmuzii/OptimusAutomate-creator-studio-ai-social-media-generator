from __future__ import annotations

import json
from typing import Any

import structlog
from sqlalchemy.orm import Session

from app.ai.context_builder import (
    CampaignGenerationContext,
    CampaignRequestContext,
    build_campaign_context,
)
from app.ai.groq_client import groq_json_chat
from app.config import settings
from app.models.db_models import (
    BrandGuardrail,
    BrandProfile,
    Campaign,
    CampaignPost,
    CampaignPostRevision,
    RefinementTrace,
    User,
)
from app.models.refinement_schemas import BrandCheckBlock, BrandCheckViolation, RefinedPostOutput
from app.services.brand_check_service import BrandCheckService
from app.utils.brand_name import preserve_brand_name

logger = structlog.get_logger(__name__)

ACTION_LABELS = {
    "regenerate_caption": "Improving caption",
    "shorten_caption": "Shortening caption",
    "make_professional": "Making professional",
    "make_funnier": "Making funnier",
    "change_tone": "Changing tone",
    "improve_hook": "Improving hook",
    "rewrite_cta": "Rewriting CTA",
    "regenerate_hashtags": "Generating new hashtags",
    "regenerate_complete_post": "Creating a fresh post",
    "custom": "Applying custom refinement",
}

ALLOWED_FIELDS_MAP: dict[str, list[str]] = {
    "regenerate_caption": ["caption", "hook", "post_idea"],
    "shorten_caption": ["caption"],
    "make_professional": ["caption", "hook", "post_idea"],
    "make_funnier": ["caption", "hook", "post_idea", "call_to_action"],
    "change_tone": ["hook", "caption", "call_to_action", "tone"],
    "improve_hook": ["hook", "caption"],
    "rewrite_cta": ["call_to_action"],
    "regenerate_hashtags": ["hashtags"],
    "regenerate_complete_post": [
        "hook",
        "caption",
        "call_to_action",
        "hashtags",
        "content_theme",
        "post_idea",
        "content_type",
        "suggested_time",
    ],
    "custom": ["hook", "caption", "call_to_action", "hashtags", "content_theme", "post_idea", "content_type", "tone"],
}

REFINEMENT_PROMPTS: dict[str, str] = {
    "regenerate_caption": (
        "Generate a new caption for this social media post while preserving:\n"
        "- campaign day, theme, content type, platform\n"
        "- selected tone, hook purpose, CTA goal\n"
        "- hashtags, approved source facts, selected persona, campaign strategy\n"
        "Only the caption should change unless small consistency changes are needed."
    ),
    "shorten_caption": (
        "Rewrite the caption to be clearly shorter (40-60% of original length).\n"
        "Preserve core message, required brand name, approved facts, CTA intent, and platform suitability.\n"
        "Do not simply truncate. Respect platform limits."
    ),
    "make_professional": (
        "Rewrite the caption using polished language, clear structure, and credible wording.\n"
        "Remove unnecessary slang and excessive punctuation.\n"
        "Preserve facts, CTA destination, and campaign strategy."
    ),
    "make_funnier": (
        "Add light, natural humour to this caption.\n"
        "Do NOT make offensive jokes, mock customers, mock competitors, introduce unsupported claims,\n"
        "turn every sentence into a joke, or violate brand formality or profanity rules."
    ),
    "change_tone": (
        "Rewrite the caption fields using the selected tone.\n"
        "Update hook, caption, and CTA wording where appropriate.\n"
        "Do NOT change factual claims, product names, dates, prices, URLs, campaign goal, or conversion path."
    ),
    "improve_hook": (
        "Regenerate only the opening hook.\n"
        "The new hook must fit the platform, match the selected persona, support the post purpose,\n"
        "avoid clickbait, lead naturally into the existing caption,\n"
        "and avoid repeating recent campaign hooks.\n"
        "Update the caption opening only where needed for smooth continuity."
    ),
    "rewrite_cta": (
        "Generate a new CTA based on the campaign goal, funnel stage, conversion path,\n"
        "destination type, CTA keyword, persona preference, and platform rules.\n"
        "Do not generate a destination or keyword that was not configured."
    ),
    "regenerate_hashtags": (
        "Generate a new hashtag group while preserving the rest of the post.\n"
        "Apply platform-specific hashtag counts, guardrail minimum and maximum,\n"
        "brand hashtag, topic relevance, and hashtag freshness.\n"
        "Return hashtags as an array.\n"
        "Modify only hashtags. Return caption, hook, CTA unchanged."
    ),
    "regenerate_complete_post": (
        "Generate a completely new version of the post while preserving its strategic role.\n"
        "You may update hook, caption, CTA, hashtags, content theme wording, post idea,\n"
        "content type where strategically appropriate, visual direction, and suggested posting time.\n"
        "Preserve campaign day number, campaign goal, brand identity, selected persona,\n"
        "approved source facts, strategy position, conversion path, safety rules, and campaign continuity."
    ),
}


def build_refinement_system_prompt() -> str:
    return """You are a professional social media copywriter specializing in post refinement.

RULES:
1. Only modify the fields explicitly permitted for the requested action.
2. Never invent unsupported claims, prices, dates, statistics, discounts, certifications, or testimonials.
3. Source facts are the ONLY approved information about products, services, prices, and offers.
4. Never override safety rules, restricted claims, or required legal disclaimers.
5. Preserve exact product names and preferred capitalisation.
6. Respect all brand guardrails including forbidden words, competitors, hashtag limits, and language settings.
7. The refined post must remain consistent with the complete campaign strategy.
8. Output ONLY valid JSON matching the required schema."""


def build_refinement_user_prompt(
    action: str,
    ctx: CampaignGenerationContext,
    post: CampaignPost,
    target_tone: str | None = None,
    custom_instruction: str | None = None,
    other_posts: list[CampaignPost] | None = None,
) -> str:
    sections: list[str] = []

    sections.append("=== REFINEMENT ACTION ===")
    action_desc = REFINEMENT_PROMPTS.get(action, "Refine this post.")
    if target_tone and action == "change_tone":
        action_desc += f"\nSelected tone: {target_tone}"
    if custom_instruction:
        action_desc += f"\nCustom instruction: {custom_instruction}"
    sections.append(action_desc)

    sections.append("\n=== CURRENT POST ===")
    sections.append(f"Day: {post.day}")
    sections.append(f"Content Theme: {post.content_theme or ''}")
    sections.append(f"Post Idea: {post.post_idea or ''}")
    sections.append(f"Content Type: {post.content_type or ''}")
    sections.append(f"Suggested Time: {post.suggested_time or ''}")
    sections.append(f"Platform: {post.platform or ''}")
    sections.append(f"Current Tone: {post.tone_override or ctx.request.tone if ctx.request else 'professional'}")
    sections.append(f"Hook: {(post.post_idea or '')[:200]}")
    sections.append(f"Caption: {post.caption}")
    sections.append(f"CTA: {post.call_to_action or ''}")
    sections.append(f"Hashtags: {json.dumps(post.hashtags or [])}")

    if ctx.brand:
        sections.append("\n=== BRAND IDENTITY ===")
        sections.append(f"Brand Name: {ctx.brand.name}")
        if ctx.brand.description:
            sections.append(f"Description: {ctx.brand.description}")
        if ctx.brand.niche:
            sections.append(f"Niche: {ctx.brand.niche}")
        if ctx.brand.target_audience:
            sections.append(f"Target Audience: {ctx.brand.target_audience}")

    if ctx.guardrails.count_active_rules() > 0:
        g = ctx.guardrails
        sections.append("\n=== BRAND GUARDRAILS (PRIORITY: HIGH) ===")
        if g.required_phrases:
            sections.append(f"Required Phrases that MUST appear: {', '.join(g.required_phrases)}")
        if g.forbidden_words:
            sections.append(f"Forbidden Words (NEVER use): {', '.join(g.forbidden_words)}")
        if g.competitors_never_mention:
            sections.append(f"Competitors NEVER to mention: {', '.join(g.competitors_never_mention)}")
        if g.restricted_claims:
            sections.append(f"Restricted Claims (avoid): {', '.join(g.restricted_claims)}")
        if g.preferred_capitalizations:
            sections.append(f"Preferred Capitalizations: {', '.join(g.preferred_capitalizations)}")
        if g.product_names:
            sections.append(f"Product Names: {', '.join(g.product_names)}")
        if g.required_legal_disclaimer:
            sections.append(f"Required Legal Disclaimer: {g.required_legal_disclaimer}")
        if g.emoji_allowance:
            sections.append(f"Emoji Allowance: {g.emoji_allowance}")
        if g.formality_level:
            sections.append(f"Formality Level: {g.formality_level}")
        if g.max_hashtag_count is not None:
            sections.append(f"Max Hashtag Count: {g.max_hashtag_count}")
        if g.min_hashtag_count is not None:
            sections.append(f"Min Hashtag Count: {g.min_hashtag_count}")
        if g.preferred_cta_style:
            sections.append(f"Preferred CTA Style: {g.preferred_cta_style}")
        if g.forbidden_cta_styles:
            sections.append(f"Forbidden CTA Styles: {', '.join(g.forbidden_cta_styles)}")

    if ctx.personas:
        sections.append("\n=== PERSONA ===")
        for p in ctx.personas:
            if p.id == post.persona_id:
                sections.append(f"Name: {p.name or 'Unnamed'}")
                if p.main_problem:
                    sections.append(f"Problem: {p.main_problem}")
                if p.desired_outcome:
                    sections.append(f"Desired Outcome: {p.desired_outcome}")
                if p.objections:
                    sections.append(f"Objections: {p.objections}")
                if p.motivation:
                    sections.append(f"Motivation: {p.motivation}")
                if p.cta_preference:
                    sections.append(f"CTA Preference: {p.cta_preference}")
                break

    if ctx.source_facts:
        sections.append("\n=== APPROVED SOURCE FACTS ===")
        for f in ctx.source_facts:
            sections.append(f"  [{f.category}] {f.label}: {f.value}")

    if ctx.conversion_path:
        sections.append("\n=== CONVERSION PATH ===")
        sections.append(f"Destination Type: {ctx.conversion_path.destination_type or ''}")
        sections.append(f"Destination Value: {ctx.conversion_path.destination_value or ''}")
        sections.append(f"Primary Action: {ctx.conversion_path.primary_action or ''}")
        if ctx.conversion_path.cta_keyword:
            sections.append(f"CTA Keyword: {ctx.conversion_path.cta_keyword}")

    if ctx.strategy:
        sections.append("\n=== STRATEGY ===")
        sections.append(f"Name: {ctx.strategy.name or ''}")
        if ctx.strategy.description:
            sections.append(f"Description: {ctx.strategy.description}")

    if ctx.request:
        sections.append("\n=== CAMPAIGN CONTEXT ===")
        sections.append(f"Platform: {ctx.request.platform}")
        sections.append(f"Campaign Goal: {ctx.request.campaign_goal}")
        sections.append(f"Original Tone: {ctx.request.tone}")

    if ctx.regional_settings:
        r = ctx.regional_settings
        sections.append("\n=== REGIONAL SETTINGS ===")
        if r.default_language:
            sections.append(f"Default Language: {r.default_language}")
        if r.support_roman_urdu:
            sections.append("Supports Roman Urdu")

    if ctx.freshness_context.recent_hooks:
        sections.append("\n=== FRESHNESS ===")
        sections.append("Avoid repeating these recent hooks:")
        for h in ctx.freshness_context.recent_hooks[-5:]:
            sections.append(f"  - {h[:100]}")

    if ctx.performance_insights:
        sections.append("\n=== PERFORMANCE LEARNINGS ===")
        for ins in ctx.performance_insights:
            sections.append(f"  {ins.pattern_type}: {ins.finding}")

    if ctx.experiment_learnings:
        sections.append("\n=== EXPERIMENT LEARNINGS ===")
        for el in ctx.experiment_learnings:
            sections.append(f"  {el.experiment_name}: {el.winner_label} won")

    if other_posts:
        sections.append("\n=== OTHER CAMPAIGN POSTS ===")
        for op in other_posts:
            if op.id != post.id:
                sections.append(f"  Day {op.day}: {op.content_theme or ''} | {op.post_idea or ''[:60]}")

    allowed = ALLOWED_FIELDS_MAP.get(action, ["caption"])
    sections.append("\n=== ALLOWED TO MODIFY ===")
    sections.append(f"Fields you may change: {', '.join(allowed)}")
    sections.append("Return ALL fields in the output schema. Return unchanged fields exactly as they were.")

    sections.append("\n=== OUTPUT JSON SCHEMA ===")
    sections.append("{")
    sections.append('  "hook": "Opening hook",')
    sections.append('  "caption": "Full caption text",')
    sections.append('  "call_to_action": "CTA text",')
    sections.append('  "hashtags": ["#tag1", "#tag2"],')
    sections.append('  "content_theme": "Content theme",')
    sections.append('  "post_idea": "Brief post idea",')
    sections.append('  "content_type": "carousel|reel|static_post|story|thread|short_video",')
    sections.append('  "suggested_time": "Best posting time or null",')
    sections.append('  "tone": "Current tone",')
    sections.append('  "changed_fields": ["field1", "field2"]')
    sections.append("}")

    return "\n".join(sections)


def save_revision(db: Session, post: CampaignPost, action: str, user_id: int, source: str) -> CampaignPostRevision:
    max_rev = (
        db.query(CampaignPostRevision.revision_number)
        .filter(CampaignPostRevision.campaign_post_id == post.id)
        .order_by(CampaignPostRevision.revision_number.desc())
        .first()
    )
    next_num = (max_rev[0] + 1) if max_rev else 1

    revision = CampaignPostRevision(
        campaign_post_id=post.id,
        revision_number=next_num,
        action=action,
        previous_hook=post.post_idea,
        previous_caption=post.caption,
        previous_call_to_action=post.call_to_action,
        previous_hashtags=post.hashtags,
        previous_tone=post.tone_override,
        previous_content_theme=post.content_theme,
        previous_post_idea=post.post_idea,
        previous_content_type=post.content_type,
        previous_suggested_time=post.suggested_time,
        generation_source=source,
        created_by_user_id=user_id,
    )
    db.add(revision)
    return revision


def save_refinement_trace(
    db: Session,
    campaign_id: int,
    post_id: int,
    action: str,
    target_tone: str | None,
    groq_used: bool,
    source: str,
    changed_fields: list[str],
    user_id: int,
) -> None:
    trace = RefinementTrace(
        campaign_id=campaign_id,
        post_id=post_id,
        action=action,
        target_tone=target_tone,
        groq_used=groq_used,
        groq_model=settings.groq_model if groq_used else None,
        generation_source=source,
        changed_fields=changed_fields,
        created_by=user_id,
    )
    db.add(trace)


def run_brand_check_on_post(
    db: Session,
    brand_id: int,
    post_data: dict[str, Any],
) -> BrandCheckBlock | None:
    brand = db.query(BrandProfile).filter(BrandProfile.id == brand_id).first()
    guardrail = db.query(BrandGuardrail).filter(BrandGuardrail.brand_id == brand_id).first()
    if not guardrail:
        return None

    service = BrandCheckService()
    texts = [
        {
            "day": 1,
            "contentTheme": post_data.get("content_theme", ""),
            "postIdea": post_data.get("hook", "") or post_data.get("post_idea", ""),
            "caption": post_data.get("caption", ""),
            "callToAction": post_data.get("call_to_action", ""),
            "hashtags": post_data.get("hashtags", []),
        }
    ]

    result = service.check_guardrails(brand, guardrail, texts)
    if result.status == "blocked":
        violations = []
        for check in result.checks:
            if check.status == "blocked" and check.matched_text:
                violations.append(
                    BrandCheckViolation(
                        type=check.code,
                        text=check.matched_text,
                    )
                )
            elif check.status == "blocked":
                violations.append(
                    BrandCheckViolation(
                        type=check.code,
                        text=check.message or "Unknown violation",
                    )
                )

        message = next(
            (c.message for c in result.checks if c.status == "blocked"),
            "The refined content violated a brand guardrail.",
        )
        return BrandCheckBlock(message=message or "Brand check failed", violations=violations)

    return None


def _generate_fallback_refinement(
    action: str,
    post: CampaignPost,
    target_tone: str | None = None,
    custom_instruction: str | None = None,
) -> dict[str, Any] | None:
    caption = post.caption or ""
    hashtags = post.hashtags or []

    if action == "shorten_caption":
        words = caption.split()
        if len(words) > 15:
            shortened = " ".join(words[: max(len(words) // 2, 10)])
            return {
                "hook": post.post_idea or "",
                "caption": shortened,
                "call_to_action": post.call_to_action or "",
                "hashtags": hashtags,
                "content_theme": post.content_theme or "",
                "post_idea": post.post_idea or "",
                "content_type": post.content_type or "static_post",
                "suggested_time": post.suggested_time,
                "tone": post.tone_override or "professional",
                "changed_fields": ["caption"],
            }

    if action == "make_professional":
        return {
            "hook": post.post_idea or "",
            "caption": caption,
            "call_to_action": post.call_to_action or "",
            "hashtags": hashtags,
            "content_theme": post.content_theme or "",
            "post_idea": post.post_idea or "",
            "content_type": post.content_type or "static_post",
            "suggested_time": post.suggested_time,
            "tone": "professional",
            "changed_fields": ["tone"],
        }

    if action == "regenerate_hashtags":
        from app.modules.hashtag_generator import generate_hashtags

        try:
            new_hashtags = generate_hashtags(
                niche="general",
                platform=post.platform or "instagram",
                campaign_goal="brand_awareness",
                brand_name="",
            )
        except Exception:
            new_hashtags = [f"#{t}" for t in ["social", "content", "brand", "marketing", "growth"]]

        return {
            "hook": post.post_idea or "",
            "caption": caption,
            "call_to_action": post.call_to_action or "",
            "hashtags": new_hashtags[:15],
            "content_theme": post.content_theme or "",
            "post_idea": post.post_idea or "",
            "content_type": post.content_type or "static_post",
            "suggested_time": post.suggested_time,
            "tone": post.tone_override or "professional",
            "changed_fields": ["hashtags"],
        }

    return None


def refine_campaign_post(
    *,
    db: Session,
    current_user: User,
    campaign: Campaign,
    post: CampaignPost,
    action: str,
    target_tone: str | None = None,
    custom_instruction: str | None = None,
) -> dict[str, Any]:
    brand_id = campaign.brand_profile_id
    if not brand_id:
        return {"error": "Campaign has no associated brand", "status": "error"}

    request = CampaignRequestContext(
        platform=campaign.platform,
        tone=campaign.tone,
        campaign_goal=campaign.campaign_goal,
        days_count=1,
    )

    ctx = build_campaign_context(db, brand_id, current_user.id, request)
    if not ctx.brand:
        return {"error": "Brand not found or unauthorized", "status": "error"}

    other_posts = db.query(CampaignPost).filter(CampaignPost.campaign_id == campaign.id).all()

    groq_result = None
    fallback_used = False
    source = "groq"

    if settings.groq_enabled:
        system_prompt = build_refinement_system_prompt()
        user_prompt = build_refinement_user_prompt(
            action=action,
            ctx=ctx,
            post=post,
            target_tone=target_tone,
            custom_instruction=custom_instruction,
            other_posts=other_posts,
        )

        groq_result = groq_json_chat(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            temperature=0.7,
            max_tokens=4096,
        )

    if groq_result is None:
        fallback_result = _generate_fallback_refinement(action, post, target_tone, custom_instruction)
        if fallback_result is None:
            return {"error": "This refinement is not available right now. Please try again.", "status": "error"}
        groq_result = fallback_result
        fallback_used = True
        source = "fallback"

    try:
        validated = RefinedPostOutput(**groq_result)
    except Exception as e:
        logger.warning("Refinement output validation failed", error=str(e))
        if not fallback_used:
            fallback_result = _generate_fallback_refinement(action, post, target_tone, custom_instruction)
            if fallback_result:
                validated = RefinedPostOutput(**fallback_result)
                source = "fallback"
                fallback_used = True
            else:
                return {"error": "Refinement output could not be validated.", "status": "error"}
        else:
            return {"error": "Refinement output could not be validated.", "status": "error"}

    brand_name = ctx.brand.name if ctx.brand else ""
    validated.caption = preserve_brand_name(validated.caption, brand_name)
    if validated.call_to_action:
        validated.call_to_action = preserve_brand_name(validated.call_to_action, brand_name)
    if validated.post_idea:
        validated.post_idea = preserve_brand_name(validated.post_idea, brand_name)
    if validated.hook:
        validated.hook = preserve_brand_name(validated.hook, brand_name)

    allowed = ALLOWED_FIELDS_MAP.get(action, ["caption"])
    refined_data = validated.model_dump()
    changed = refined_data.get("changed_fields", [])

    if action != "regenerate_complete_post":
        for field in changed:
            if field not in allowed:
                if field == "tone" and action == "change_tone":
                    continue
                refined_data[field] = getattr(post, field, "")
                if field in changed:
                    changed.remove(field)

    post_update = {
        "caption": refined_data.get("caption", post.caption),
        "hook": refined_data.get("hook", post.post_idea or ""),
        "call_to_action": refined_data.get("call_to_action", post.call_to_action),
        "hashtags": refined_data.get("hashtags", post.hashtags or []),
        "content_theme": refined_data.get("content_theme", post.content_theme or ""),
        "post_idea": refined_data.get("post_idea", post.post_idea or ""),
        "content_type": refined_data.get("content_type", post.content_type or ""),
        "suggested_time": refined_data.get("suggested_time", post.suggested_time or ""),
    }

    if action == "change_tone" and target_tone:
        post_update["tone_override"] = target_tone
        if "tone" not in changed:
            changed.append("tone")
    elif action == "make_professional":
        post_update["tone_override"] = "professional"
    elif action == "make_funnier":
        post_update["tone_override"] = "funny"

    block = run_brand_check_on_post(db, brand_id, post_update)
    if block is not None:
        return {
            "status": "blocked",
            "message": block.message,
            "violations": [v.model_dump() for v in block.violations],
        }

    save_revision(db, post, action, current_user.id, source)

    post.caption = post_update["caption"]
    post.call_to_action = post_update["call_to_action"]
    post.hashtags = post_update["hashtags"]
    post.content_theme = post_update["content_theme"]
    post.post_idea = post_update["post_idea"]
    post.content_type = post_update["content_type"]
    post.suggested_time = post_update["suggested_time"]
    if "tone_override" in post_update:
        post.tone_override = post_update["tone_override"]

    db.commit()
    db.refresh(post)

    save_refinement_trace(
        db=db,
        campaign_id=campaign.id,
        post_id=post.id,
        action=action,
        target_tone=target_tone,
        groq_used=not fallback_used,
        source=source,
        changed_fields=changed,
        user_id=current_user.id,
    )
    db.commit()

    final_tone = post.tone_override or campaign.tone

    return {
        "status": "success",
        "post": {
            "id": post.id,
            "campaign_id": post.campaign_id,
            "day_number": post.day,
            "hook": post_update.get("hook", post.post_idea or ""),
            "caption": post.caption,
            "call_to_action": post.call_to_action,
            "hashtags": post.hashtags or [],
            "content_theme": post.content_theme or "",
            "post_idea": post.post_idea or "",
            "content_type": post.content_type or "",
            "suggested_time": post.suggested_time or "",
            "tone": final_tone,
            "updated_at": post.updated_at.isoformat() if post.updated_at else "",
        },
        "refinement": {
            "action": action,
            "generation_source": source,
            "fallback_used": fallback_used,
            "warnings": [],
        },
    }
